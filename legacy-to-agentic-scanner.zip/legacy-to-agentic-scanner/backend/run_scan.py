#!/usr/bin/env python3
"""
Command-line entry point for the whole pipeline: point it at a folder or a
zip file, and it produces a report. This exists so the core pipeline can be
run and tested before the web upload page / dashboard exist.

Usage:
    export GROQ_API_KEY=gsk_...
    python3 run_scan.py /path/to/repo_or_zip.zip
"""

import os
import sys
import tempfile
import time

sys.path.insert(0, os.path.dirname(__file__))


def _load_dotenv():
    """Tiny .env loader so we don't need an extra dependency for this."""
    env_path = os.path.join(os.path.dirname(__file__), ".env")
    if not os.path.exists(env_path):
        return
    with open(env_path) as f:
        for line in f:
            line = line.strip()
            if not line or line.startswith("#") or "=" not in line:
                continue
            key, _, value = line.partition("=")
            os.environ.setdefault(key.strip(), value.strip())


_load_dotenv()

from app.intake import extract_zip, scan_and_filter
from app.ai_analyze import analyze_files
from app.grouping import group_files
from app.report import build_report, report_to_markdown


def main():
    if len(sys.argv) != 2:
        print("Usage: python3 run_scan.py <path-to-repo-folder-or-zip>")
        sys.exit(1)

    input_path = sys.argv[1]
    repo_name = os.path.basename(input_path.rstrip("/")).replace(".zip", "")

    print(f"=== Scanning: {input_path} ===\n")

    if input_path.lower().endswith(".zip"):
        print("[1/5] Unzipping...")
        tmp_dir = tempfile.mkdtemp(prefix="scan_")
        root_dir = extract_zip(input_path, tmp_dir)
    else:
        root_dir = input_path

    print("[2/5] Finding real source code, ignoring generated/vendor junk...")
    intake_result = scan_and_filter(root_dir)
    print(f"      kept {len(intake_result.kept_files)} of {intake_result.total_files_seen} files "
          f"({intake_result.ignored_count} ignored)")

    print("[3/5] Sending files to AI for analysis (this is the slow step)...")
    t0 = time.time()

    def on_progress(done, total):
        print(f"      batch {done}/{total} done", end="\r")

    file_facts = analyze_files(intake_result.kept_files, progress_callback=on_progress)
    print(f"\n      done in {time.time() - t0:.0f}s")

    print("[4/5] Grouping files into features...")
    groups = group_files(file_facts, None)
    print(f"      found {len(groups)} groups")

    print("[5/5] Asking AI to summarize each feature...")
    t0 = time.time()

    def on_group_progress(done, total):
        print(f"      feature {done}/{total} done", end="\r")

    reports = build_report(groups, progress_callback=on_group_progress)
    print(f"\n      done in {time.time() - t0:.0f}s")

    intake_stats = {
        "total_files_seen": intake_result.total_files_seen,
        "ignored_count": intake_result.ignored_count,
        "kept_count": len(intake_result.kept_files),
    }
    markdown = report_to_markdown(reports, repo_name, intake_stats)

    out_path = f"report_{repo_name}.md"
    with open(out_path, "w") as f:
        f.write(markdown)

    print(f"\n=== Done. Report written to {out_path} ===")


if __name__ == "__main__":
    main()
