# Assessment report: IFS_Employee_Diary-EIS_Employee_Diary_Web-master

## Overview
- Files scanned: 1735
- Ignored as junk/generated/vendor: 1341
- Real source files analyzed: 394
- Features/capabilities identified: 185
- Possible AI-agent candidates found: 0

## All features found
### Accessmanager
(AI summary failed for this feature, see log)
*Spans 2 files:* EIS.DataAccess/UserManagement/AccessManager/IAccessManagerDataRepository.cs, EIS.DataAccess/UserManagement/AccessManager/AccessManagerDataRepository.cs

### Accessright
(AI summary failed for this feature, see log)
*Spans 3 files:* EIS.BusinessComponent/AccessRightManagement/IAccessRightManager.cs, EIS.BusinessComponent/AccessRightManagement/AccessRightManager.cs, EIS.Entities/AccessRight.cs

### Accessrights
(AI summary failed for this feature, see log)
*Spans 3 files:* EIS.UI/UserManagement/AccessRights.aspx.cs, EIS.UI/UserManagement/AccessRights.aspx, EIS.WebApi/Controllers/AccessRights/AccessRightsController.cs

### Accountbinding
(AI summary failed for this feature, see log)
*File:* EIS.WebApi/Models/AccountBindingModels.cs

### Accountview
(AI summary failed for this feature, see log)
*File:* EIS.WebApi/Models/AccountViewModels.cs

### Activeandinactivestatusenum
(AI summary failed for this feature, see log)
*File:* EIS.CommonComponent/Enum/ActiveAndInActiveStatusEnum.cs

### Api
(AI summary failed for this feature, see log)
*File:* EIS.WebApi/Areas/HelpPage/Views/Help/Api.cshtml

### Apiclient
(AI summary failed for this feature, see log)
*File:* EIS.UI/App_Start/ApiClient.cs

### Apidescriptionextensions
(AI summary failed for this feature, see log)
*File:* EIS.WebApi/Areas/HelpPage/ApiDescriptionExtensions.cs

### Apigroup
(AI summary failed for this feature, see log)
*File:* EIS.WebApi/Areas/HelpPage/Views/Help/DisplayTemplates/ApiGroup.cshtml

### Applicationlog
(AI summary failed for this feature, see log)
*Spans 6 files:* EIS.BusinessComponent/ApplicationLogs/IApplicationLog.cs, EIS.BusinessComponent/ApplicationLogs/ApplicationLog.cs, EIS.Entities/ApplicationLog.cs, EIS.DataAccess/ApplicationLogs/ApplicationLogDataRepository.cs, EIS.DataAccess/ApplicationLogs/IApplicationLogDataRepository.cs, EIS.WebApi/Controllers/ApplicationLog/ApplicationLogController.cs

### Applicationoauthprovider
(AI summary failed for this feature, see log)
*File:* EIS.WebApi/Providers/ApplicationOAuthProvider.cs

### Appreciation
(AI summary failed for this feature, see log)
*Spans 8 files:* EIS.BusinessComponent/Appreciation/Appreciation.cs, EIS.BusinessComponent/Appreciation/IAppreciation.cs, EIS.UI/EmployeeDetail/Appreciation.aspx, EIS.UI/EmployeeDetail/Appreciation.aspx.cs, EIS.Entities/Appreciation.cs, EIS.DataAccess/Appreciation/AppreciationRepository.cs, EIS.DataAccess/Appreciation/IAppreciationRepository.cs, EIS.WebApi/Controllers/Appreciation/AppreciationController.cs

### Bapositive
(AI summary failed for this feature, see log)
*Spans 9 files:* EIS.BusinessComponent/BAPositives/BAPositive.cs, EIS.BusinessComponent/BAPositives/IBAPositive.cs, EIS.UI/EmployeeDetail/BAPositive.aspx, EIS.UI/EmployeeDetail/BAPositive.aspx.cs, EIS.UI/EmployeeBasicDetail/BAPositive.aspx, EIS.UI/EmployeeBasicDetail/BAPositive.aspx.cs, EIS.Entities/BAPositiveDetail.cs, EIS.DataAccess/BAPositives/BAPositiveDataRepository.cs, EIS.DataAccess/BAPositives/IBAPositiveDataRepository.cs

### Bapositivedetail
(AI summary failed for this feature, see log)
*File:* EIS.WebApi/Controllers/BAPositives/BAPositiveDetailController.cs

### Basecontext
(AI summary failed for this feature, see log)
*Spans 2 files:* EIS.UI/Infrastructure/BaseContext.cs, EIS.UI/Infrastructure/IBaseContext.cs

### Bundleconfig
(AI summary failed for this feature, see log)
*Spans 2 files:* EIS.UI/App_Start/BundleConfig.cs, EIS.WebApi/App_Start/BundleConfig.cs

### Challengeresult
(AI summary failed for this feature, see log)
*File:* EIS.WebApi/Results/ChallengeResult.cs

### Chosenproto
(AI summary failed for this feature, see log)
*File:* EIS.UI/Scripts/chosen.proto.js

### Class1
(AI summary failed for this feature, see log)
*File:* PayloadCreation/Class1.cs

### Clipboard
(AI summary failed for this feature, see log)
*File:* EIS.UI/Scripts/clipboard.js

### Collectionmodeldescription
(AI summary failed for this feature, see log)
*Spans 2 files:* EIS.WebApi/Areas/HelpPage/Views/Help/DisplayTemplates/CollectionModelDescription.cshtml, EIS.WebApi/Areas/HelpPage/ModelDescriptions/CollectionModelDescription.cs

### Communication
(AI summary failed for this feature, see log)
*Spans 2 files:* EIS.UI/EmployeeDetail/CommunicationDetail.aspx.cs, EIS.UI/EmployeeDetail/CommunicationDetail.aspx

### Complaint
(AI summary failed for this feature, see log)
*Spans 2 files:* EIS.UI/EmployeeDetail/Complaint.aspx, EIS.UI/EmployeeDetail/Complaint.aspx.cs

### Complextypemodeldescription
(AI summary failed for this feature, see log)
*Spans 2 files:* EIS.WebApi/Areas/HelpPage/Views/Help/DisplayTemplates/ComplexTypeModelDescription.cshtml, EIS.WebApi/Areas/HelpPage/ModelDescriptions/ComplexTypeModelDescription.cs

### Constants
(AI summary failed for this feature, see log)
*File:* EIS.WebApi/ServiceConstants/Constants.cs

### Corelead
(AI summary failed for this feature, see log)
*Spans 7 files:* EIS.BusinessComponent/CoreLeadMaster/CoreLead.cs, EIS.BusinessComponent/CoreLeadMaster/ICoreLead.cs, EIS.UI/CLM/CoreLeadMaster.aspx.cs, EIS.UI/CLM/CoreLeadMaster.aspx, EIS.Entities/CoreLeadModel.cs, EIS.DataAccess/CoreLeadMaster/CoreLeadDataRepository.cs, EIS.DataAccess/CoreLeadMaster/ICoreLeadDataRepository.cs

### Coreleadmodel
(AI summary failed for this feature, see log)
*File:* EIS.WebApi/Controllers/CoreLeadModel/CoreLeadModelController.cs

### Crewboard
(AI summary failed for this feature, see log)
*Spans 6 files:* EIS.BusinessComponent/CrewBoards/CrewBoard.cs, EIS.BusinessComponent/CrewBoards/ICrewBoard.cs, EIS.Entities/CrewBoard.cs, EIS.DataAccess/CrewBoards/CrewBoardDataRepository.cs, EIS.DataAccess/CrewBoards/ICrewBoardDataRepository.cs, EIS.WebApi/Controllers/CrewBoards/CrewBoardController.cs

### Crewonboard
(AI summary failed for this feature, see log)
*Spans 2 files:* EIS.UI/COB/Crewonboard.aspx, EIS.UI/COB/Crewonboard.aspx.cs

### Crewrostermodal
(AI summary failed for this feature, see log)
*File:* EIS.Entities/CrewRosterModal.cs

### Cruuzdocument
(AI summary failed for this feature, see log)
*Spans 2 files:* EIS.BusinessComponent/CruuzDocumentDetails/CruuzDocumentDetails.cs, EIS.BusinessComponent/CruuzDocumentDetails/ICruuzDocumentDetails.cs

### Cruuzdocumentdetails
(AI summary failed for this feature, see log)
*Spans 2 files:* EIS.DataAccess/CruuzDocumentDetailsRepository/CruuzDocumentDetailsRepository.cs, EIS.DataAccess/CruuzDocumentDetailsRepository/ICruuzDocumentDetailsRepository.cs

### Cruuzdocumentdetailstype
(AI summary failed for this feature, see log)
*File:* EIS.Entities/CruuzDocumentDetailsType.cs

### Cruuzdocumentsdetails
(AI summary failed for this feature, see log)
*File:* EIS.WebApi/Controllers/CruuzDocumentDetails/CruuzDocumentsDetailsController.cs

### Custom
(AI summary failed for this feature, see log)
*File:* EIS.UI/Scripts/custom.js

### Databaseconstants
(AI summary failed for this feature, see log)
*File:* EIS.CommonComponent/DatabaseUtilityClass/DatabaseConstants.cs

### Dbconfig
(AI summary failed for this feature, see log)
*File:* EIS.DataAccess/Helpers/DbConfigHelper.cs

### Detailsview
(AI summary failed for this feature, see log)
*File:* EIS.UI/Scripts/WebForms/DetailsView.js

### Dictionarymodeldescription
(AI summary failed for this feature, see log)
*Spans 2 files:* EIS.WebApi/Areas/HelpPage/Views/Help/DisplayTemplates/DictionaryModelDescription.cshtml, EIS.WebApi/Areas/HelpPage/ModelDescriptions/DictionaryModelDescription.cs

### Dirpagination
(AI summary failed for this feature, see log)
*File:* EIS.UI/Scripts/dirPagination.js

### Downloadfile
(AI summary failed for this feature, see log)
*Spans 2 files:* EIS.UI/EmployeeBasicDetail/DownloadFile.aspx.cs, EIS.UI/EmployeeBasicDetail/DownloadFile.aspx

### Easyresponsivetabs
(AI summary failed for this feature, see log)
*File:* EIS.UI/Scripts/easyResponsiveTabs.js

### Education
(AI summary failed for this feature, see log)
*Spans 2 files:* EIS.UI/EmployeeDetail/Education.aspx.cs, EIS.UI/EmployeeDetail/Education.aspx

### Eis
(AI summary failed for this feature, see log)
*Spans 5 files:* EIS.UI/EIS.Master, EIS.UI/EIS.Master.cs, EIS.UI/EISMaster.Master, EIS.UI/EISMaster.Master.cs, EIS.UI/ApplicationJS/EIS.js

### Eis.ui
(AI summary failed for this feature, see log)
*Spans 2 files:* EIS.UI/Index.aspx.cs, EIS.UI/Index.aspx

### Eisemployee
(AI summary failed for this feature, see log)
*Spans 2 files:* EIS.UI/EISEmployeeDetail.Master.cs, EIS.UI/EISEmployeeDetail.Master

### Email
(AI summary failed for this feature, see log)
*File:* EIS.CommonComponent/EmailHelper/EmailHelper.cs

### Employee
(AI summary failed for this feature, see log)
*Spans 3 files:* EIS.UI/ApplicationJS/EmployeeDetail/EmployeeDetail.js, EIS.UI/EmployeeDetail/EmployeeDetail.aspx, EIS.UI/EmployeeDetail/EmployeeDetail.aspx.cs

### Employeebasic
(AI summary failed for this feature, see log)
*Spans 4 files:* EIS.UI/ApplicationJS/EmployeeBasicDetail/EmployeeBasicDetail.js, EIS.UI/EmployeeBasicDetail/EmployeeBasicDetail.aspx.cs, EIS.UI/EmployeeBasicDetail/EmployeeBasicDetail.aspx, EIS.Entities/EmployeeBasicDetail.cs

### Employeebasicdetail
(AI summary failed for this feature, see log)
*Spans 2 files:* EIS.UI/EmployeeBasicDetail/Default.aspx.cs, EIS.UI/EmployeeBasicDetail/Default.aspx

### Employeebasicdetail
(AI summary failed for this feature, see log)
*File:* EIS.WebApi/Controllers/EmployeeBasicDetail/EmployeeBasicDetailController.cs

### Employeebasicdetailglobalization
(AI summary failed for this feature, see log)
*File:* EIS.UI/ApplicationJS/EmployeeBasicDetail/EmployeeBasicDetailGlobalization.js

### Employeecommunication
(AI summary failed for this feature, see log)
*Spans 5 files:* EIS.BusinessComponent/EmployeeCommunications/IEmployeeCommunication.cs, EIS.BusinessComponent/EmployeeCommunications/EmployeeCommunication.cs, EIS.Entities/EmployeeCommunicationDetail.cs, EIS.DataAccess/EmployeeCommunications/EmployeeCommunicationDataRepository.cs, EIS.DataAccess/EmployeeCommunications/IEmployeeCommunicationDataRepository.cs

### Employeeeducation
(AI summary failed for this feature, see log)
*Spans 6 files:* EIS.BusinessComponent/EmployeeEducations/EmployeeEducation.cs, EIS.BusinessComponent/EmployeeEducations/IEmployeeEducation.cs, EIS.Entities/EmployeeEducation.cs, EIS.DataAccess/EmployeeEducations/IEmployeeEducationDataRepository.cs, EIS.DataAccess/EmployeeEducations/EmployeeEducationDataRepository.cs, EIS.WebApi/Controllers/EmployeeEducationDetails/EmployeeEducationController.cs

### Employeefamily
(AI summary failed for this feature, see log)
*Spans 5 files:* EIS.BusinessComponent/EmployeeFamilyDetails/EmployeeFamilyDetail.cs, EIS.BusinessComponent/EmployeeFamilyDetails/IEmployeeFamilyDetail.cs, EIS.Entities/EmployeeFamilyDetail.cs, EIS.DataAccess/EmployeeFamilyDetails/IEmployeeFamilyDataRepository.cs, EIS.DataAccess/EmployeeFamilyDetails/EmployeeFamilyDataRepository.cs

### Employeefamilydetail
(AI summary failed for this feature, see log)
*File:* EIS.WebApi/Controllers/EmployeeFamilyDetails/EmployeeFamilyDetailController.cs

### Employeelifecycle
(AI summary failed for this feature, see log)
*Spans 8 files:* EIS.BusinessComponent/EmployeeLifeCycles/IEmployeeLifeCycle.cs, EIS.BusinessComponent/EmployeeLifeCycles/EmployeeLifeCycle.cs, EIS.UI/EmployeeDetail/EmployeeLifeCycle.aspx.cs, EIS.UI/EmployeeDetail/EmployeeLifeCycle.aspx, EIS.Entities/EmployeeLifeCycle.cs, EIS.DataAccess/EmployeeLifeCycles/IEmployeeLifeCycleDataRepository.cs, EIS.DataAccess/EmployeeLifeCycles/EmployeeLifeCycleDataRepository.cs, EIS.WebApi/Controllers/EmployeeLifeCycles/EmployeeLifeCycleController.cs

### Enumtypemodeldescription
(AI summary failed for this feature, see log)
*Spans 2 files:* EIS.WebApi/Areas/HelpPage/Views/Help/DisplayTemplates/EnumTypeModelDescription.cshtml, EIS.WebApi/Areas/HelpPage/ModelDescriptions/EnumTypeModelDescription.cs

### Enumvaluedescription
(AI summary failed for this feature, see log)
*File:* EIS.WebApi/Areas/HelpPage/ModelDescriptions/EnumValueDescription.cs

### Error
(AI summary failed for this feature, see log)
*File:* EIS.WebApi/Views/Shared/Error.cshtml

### Excelpackageextensions
(AI summary failed for this feature, see log)
*Spans 2 files:* EIS.UI/Helpers/ExcelPackageExtensions.cs, EIS.WebApi/ServiceHelper/ExcelPackageExtensions.cs

### Exceptionlog
(AI summary failed for this feature, see log)
*File:* EIS.ExceptionHandler/Repository/ExceptionLogDataRepository.cs

### Family
(AI summary failed for this feature, see log)
*Spans 2 files:* EIS.UI/EmployeeDetail/Family.aspx, EIS.UI/EmployeeDetail/Family.aspx.cs

### Feedback
(AI summary failed for this feature, see log)
*Spans 8 files:* EIS.BusinessComponent/Feedback/Feedback.cs, EIS.BusinessComponent/Feedback/IFeedback.cs, EIS.UI/EmployeeDetail/Feedback.aspx.cs, EIS.UI/EmployeeDetail/Feedback.aspx, EIS.Entities/Feedback.cs, EIS.DataAccess/Feedback/IFeedbackRepository.cs, EIS.DataAccess/Feedback/FeedbackRepository.cs, EIS.WebApi/Controllers/EmployeeDetail/FeedbackController.cs

### Filedownloadashx
(AI summary failed for this feature, see log)
*File:* EIS.UI/Handler/FileDownload.ashx.cs

### Filterconfig
(AI summary failed for this feature, see log)
*File:* EIS.WebApi/App_Start/FilterConfig.cs

### Focus
(AI summary failed for this feature, see log)
*File:* EIS.UI/Scripts/WebForms/Focus.js

### Foldercreation
(AI summary failed for this feature, see log)
*File:* EIS.Entities/FolderCreationUtility.cs

### Folderreadwrite
(AI summary failed for this feature, see log)
*File:* EIS.UI/FolderReadWriteServiceMethod/FolderReadWriteService.cs

### Folderstructure
(AI summary failed for this feature, see log)
*Spans 6 files:* EIS.BusinessComponent/FolderStructures/FolderStructure.cs, EIS.BusinessComponent/FolderStructures/IFolderStructure.cs, EIS.Entities/FolderStructure.cs, EIS.DataAccess/FolderStructures/IFolderStructureDataRepository.cs, EIS.DataAccess/FolderStructures/FolderStructureDataRepository.cs, EIS.WebApi/Controllers/FolderStuctures/FolderStructureController.cs

### Formmanagement
(AI summary failed for this feature, see log)
*Spans 2 files:* EIS.UI/UserManagement/FormManagement.aspx.cs, EIS.UI/UserManagement/FormManagement.aspx

### Formmanagement1
(AI summary failed for this feature, see log)
*Spans 2 files:* EIS.UI/UserManagement/FormManagement1.aspx.cs, EIS.UI/UserManagement/FormManagement1.aspx

### Globalasax
(AI summary failed for this feature, see log)
*Spans 2 files:* EIS.UI/Global.asax.cs, EIS.WebApi/Global.asax.cs

### Gridview
(AI summary failed for this feature, see log)
*File:* EIS.UI/Scripts/WebForms/GridView.js

### Help
(AI summary failed for this feature, see log)
*File:* EIS.WebApi/Areas/HelpPage/Controllers/HelpController.cs

### Help
(AI summary failed for this feature, see log)
*File:* EIS.WebApi/Areas/HelpPage/Views/Help/Index.cshtml

### Helper
(AI summary failed for this feature, see log)
*Spans 3 files:* EIS.BusinessComponent/Helpers/Helper.cs, EIS.UI/Helpers/Helper.cs, EIS.DataAccess/Helpers/Helper.cs

### Helppageapi
(AI summary failed for this feature, see log)
*Spans 2 files:* EIS.WebApi/Areas/HelpPage/Models/HelpPageApiModel.cs, EIS.WebApi/Areas/HelpPage/Views/Help/DisplayTemplates/HelpPageApiModel.cshtml

### Helppagearearegistration
(AI summary failed for this feature, see log)
*File:* EIS.WebApi/Areas/HelpPage/HelpPageAreaRegistration.cs

### Helppageconfig
(AI summary failed for this feature, see log)
*File:* EIS.WebApi/Areas/HelpPage/App_Start/HelpPageConfig.cs

### Helppageconfigurationextensions
(AI summary failed for this feature, see log)
*File:* EIS.WebApi/Areas/HelpPage/HelpPageConfigurationExtensions.cs

### Helppagesamplegenerator
(AI summary failed for this feature, see log)
*File:* EIS.WebApi/Areas/HelpPage/SampleGeneration/HelpPageSampleGenerator.cs

### Helppagesamplekey
(AI summary failed for this feature, see log)
*File:* EIS.WebApi/Areas/HelpPage/SampleGeneration/HelpPageSampleKey.cs

### Home
(AI summary failed for this feature, see log)
*File:* EIS.WebApi/Controllers/HomeController.cs

### Home
(AI summary failed for this feature, see log)
*File:* EIS.WebApi/Views/Home/Index.cshtml

### Hrhubapitokendetail
(AI summary failed for this feature, see log)
*File:* EIS.WebApi/Controllers/HrhubAPITokenDetail/HrhubAPITokenDetailController.cs

### Hrhubtoken
(AI summary failed for this feature, see log)
*Spans 2 files:* EIS.BusinessComponent/HrhubTokenDetail/HrhubTokenDetail.cs, EIS.BusinessComponent/HrhubTokenDetail/IHrhubTokenDetail.cs

### Identity
(AI summary failed for this feature, see log)
*File:* EIS.WebApi/Models/IdentityModels.cs

### Identityconfig
(AI summary failed for this feature, see log)
*File:* EIS.WebApi/App_Start/IdentityConfig.cs

### Iframeresizer
(AI summary failed for this feature, see log)
*File:* EIS.UI/Scripts/IframeResizer/index.js

### Iframeresizer
(AI summary failed for this feature, see log)
*File:* EIS.UI/Scripts/IframeResizer/iframeResizer.js

### Iframeresizercontentwindow
(AI summary failed for this feature, see log)
*File:* EIS.UI/Scripts/IframeResizer/iframeResizer.contentWindow.js

### Imagesample
(AI summary failed for this feature, see log)
*Spans 2 files:* EIS.WebApi/Areas/HelpPage/SampleGeneration/ImageSample.cs, EIS.WebApi/Areas/HelpPage/Views/Help/DisplayTemplates/ImageSample.cshtml

### Invalidsample
(AI summary failed for this feature, see log)
*Spans 2 files:* EIS.WebApi/Areas/HelpPage/SampleGeneration/InvalidSample.cs, EIS.WebApi/Areas/HelpPage/Views/Help/DisplayTemplates/InvalidSample.cshtml

### Keyvaluepairmodeldescription
(AI summary failed for this feature, see log)
*Spans 2 files:* EIS.WebApi/Areas/HelpPage/Views/Help/DisplayTemplates/KeyValuePairModelDescription.cshtml, EIS.WebApi/Areas/HelpPage/ModelDescriptions/KeyValuePairModelDescription.cs

### Keyvault
(AI summary failed for this feature, see log)
*Spans 2 files:* EIS.UI/Helpers/KeyVault.cs, EIS.DataAccess/Helpers/KeyVault.cs

### Layout
(AI summary failed for this feature, see log)
*Spans 2 files:* EIS.WebApi/Areas/HelpPage/Views/Shared/_Layout.cshtml, EIS.WebApi/Views/Shared/_Layout.cshtml

### Lettersissued
(AI summary failed for this feature, see log)
*Spans 2 files:* EIS.UI/EmployeeDetail/LettersIssued.aspx, EIS.UI/EmployeeDetail/LettersIssued.aspx.cs

### Lms
(AI summary failed for this feature, see log)
*Spans 8 files:* EIS.BusinessComponent/LMS/ILMS.cs, EIS.BusinessComponent/LMS/LMS.cs, EIS.UI/EmployeeDetail/LMS.aspx, EIS.UI/EmployeeDetail/LMS.aspx.cs, EIS.Entities/LMS.cs, EIS.DataAccess/LMS/LMSRepository.cs, EIS.DataAccess/LMS/ILMSRepository.cs, EIS.WebApi/Controllers/LMS/LMSController.cs

### Login
(AI summary failed for this feature, see log)
*Spans 2 files:* EIS.UI/Login.aspx, EIS.UI/Login.aspx.cs

### Logtoservermodule
(AI summary failed for this feature, see log)
*File:* EIS.UI/Scripts/logToServer.module.js

### Master
(AI summary failed for this feature, see log)
*Spans 2 files:* EIS.DataAccess/MasterData/IMasterDataRepository.cs, EIS.DataAccess/MasterData/MasterDataRepository.cs

### Masterdata
(AI summary failed for this feature, see log)
*Spans 2 files:* EIS.BusinessComponent/MasterData/MasterData.cs, EIS.BusinessComponent/MasterData/IMasterData.cs

### Medicalendorsement
(AI summary failed for this feature, see log)
*Spans 5 files:* EIS.BusinessComponent/MedicalEndorsement/IMedicalEndorsement.cs, EIS.BusinessComponent/MedicalEndorsement/MedicalEndorsement.cs, EIS.Entities/MedicalEndorsement.cs, EIS.DataAccess/MedicalEndorsement/IMedicalEndorsementRepository.cs, EIS.DataAccess/MedicalEndorsement/MedicalEndorsementRepository.cs

### Medicalendorsementreport
(AI summary failed for this feature, see log)
*Spans 3 files:* EIS.UI/MedicalEndorsement/MedicalEndorsementReport.aspx, EIS.UI/MedicalEndorsement/MedicalEndorsementReport.aspx.cs, EIS.WebApi/Controllers/MedicalEndorsementReport/MedicalEndorsementReportController.cs

### Medicalissued
(AI summary failed for this feature, see log)
*Spans 2 files:* EIS.UI/EmployeeDetail/MedicalIssued.aspx.cs, EIS.UI/EmployeeDetail/MedicalIssued.aspx

### Menu
(AI summary failed for this feature, see log)
*File:* EIS.UI/Scripts/WebForms/Menu.js

### Menustandards
(AI summary failed for this feature, see log)
*File:* EIS.UI/Scripts/WebForms/MenuStandards.js

### Microsoftajax
(AI summary failed for this feature, see log)
*File:* EIS.UI/Scripts/WebForms/MSAjax/MicrosoftAjax.js

### Microsoftajaxapplicationservices
(AI summary failed for this feature, see log)
*File:* EIS.UI/Scripts/WebForms/MSAjax/MicrosoftAjaxApplicationServices.js

### Microsoftajaxcomponent
(AI summary failed for this feature, see log)
*File:* EIS.UI/Scripts/WebForms/MSAjax/MicrosoftAjaxComponentModel.js

### Microsoftajaxcore
(AI summary failed for this feature, see log)
*File:* EIS.UI/Scripts/WebForms/MSAjax/MicrosoftAjaxCore.js

### Microsoftajaxglobalization
(AI summary failed for this feature, see log)
*File:* EIS.UI/Scripts/WebForms/MSAjax/MicrosoftAjaxGlobalization.js

### Microsoftajaxhistory
(AI summary failed for this feature, see log)
*File:* EIS.UI/Scripts/WebForms/MSAjax/MicrosoftAjaxHistory.js

### Microsoftajaxnetwork
(AI summary failed for this feature, see log)
*File:* EIS.UI/Scripts/WebForms/MSAjax/MicrosoftAjaxNetwork.js

### Microsoftajaxserialization
(AI summary failed for this feature, see log)
*File:* EIS.UI/Scripts/WebForms/MSAjax/MicrosoftAjaxSerialization.js

### Microsoftajaxtimer
(AI summary failed for this feature, see log)
*File:* EIS.UI/Scripts/WebForms/MSAjax/MicrosoftAjaxTimer.js

### Microsoftajaxwebforms
(AI summary failed for this feature, see log)
*File:* EIS.UI/Scripts/WebForms/MSAjax/MicrosoftAjaxWebForms.js

### Microsoftajaxwebservices
(AI summary failed for this feature, see log)
*File:* EIS.UI/Scripts/WebForms/MSAjax/MicrosoftAjaxWebServices.js

### Modeldescription
(AI summary failed for this feature, see log)
*File:* EIS.WebApi/Areas/HelpPage/ModelDescriptions/ModelDescription.cs

### Modeldescriptiongenerator
(AI summary failed for this feature, see log)
*File:* EIS.WebApi/Areas/HelpPage/ModelDescriptions/ModelDescriptionGenerator.cs

### Modeldescriptionlink
(AI summary failed for this feature, see log)
*File:* EIS.WebApi/Areas/HelpPage/Views/Help/DisplayTemplates/ModelDescriptionLink.cshtml

### Modeldocumentationprovider
(AI summary failed for this feature, see log)
*File:* EIS.WebApi/Areas/HelpPage/ModelDescriptions/IModelDocumentationProvider.cs

### Modelname
(AI summary failed for this feature, see log)
*File:* EIS.WebApi/Areas/HelpPage/ModelDescriptions/ModelNameHelper.cs

### Modelnameattribute
(AI summary failed for this feature, see log)
*File:* EIS.WebApi/Areas/HelpPage/ModelDescriptions/ModelNameAttribute.cs

### Nexttokinesb
(AI summary failed for this feature, see log)
*File:* EIS.Entities/NextToKinEsbModel.cs

### Nginfinitescroll
(AI summary failed for this feature, see log)
*File:* EIS.UI/Scripts/ng-infinite-scroll.js

### Ngtable
(AI summary failed for this feature, see log)
*File:* EIS.UI/Scripts/ng-table.js

### Ninjectwebcommon
(AI summary failed for this feature, see log)
*Spans 2 files:* EIS.UI/App_Start/NinjectWebCommon.cs, EIS.WebApi/App_Start/NinjectWebCommon.cs

### Objectgenerator
(AI summary failed for this feature, see log)
*File:* EIS.WebApi/Areas/HelpPage/SampleGeneration/ObjectGenerator.cs

### Page
(AI summary failed for this feature, see log)
*Spans 3 files:* EIS.UI/UserManagement/PageManager.aspx.cs, EIS.UI/UserManagement/PageManager.aspx, EIS.Entities/Page.cs

### Pageaccessrights
(AI summary failed for this feature, see log)
*Spans 5 files:* EIS.BusinessComponent/PageAccessRights/PageAccessRights.cs, EIS.BusinessComponent/PageAccessRights/IPageAccessRights.cs, EIS.DataAccess/PageAccessRights/IPageAccessRightsRepository.cs, EIS.DataAccess/PageAccessRights/PageAccessRightsRepository.cs, EIS.WebApi/Controllers/PageAccessRights/PageAccessRightsController.cs

### Pagemanager
(AI summary failed for this feature, see log)
*Spans 5 files:* EIS.BusinessComponent/PageManagement/IPageManagerMaster.cs, EIS.BusinessComponent/PageManagement/PageManagerMaster.cs, EIS.DataAccess/UserManagement/PageManager/IPageManagerDataRepository.cs, EIS.DataAccess/UserManagement/PageManager/PageManagerDataRepository.cs, EIS.WebApi/Controllers/PageManager/PageManagerController.cs

### Pagename
(AI summary failed for this feature, see log)
*File:* EIS.CommonComponent/PageName/PageName.cs

### Parameterannotation
(AI summary failed for this feature, see log)
*File:* EIS.WebApi/Areas/HelpPage/ModelDescriptions/ParameterAnnotation.cs

### Parameterdescription
(AI summary failed for this feature, see log)
*File:* EIS.WebApi/Areas/HelpPage/ModelDescriptions/ParameterDescription.cs

### Parameters
(AI summary failed for this feature, see log)
*File:* EIS.WebApi/Areas/HelpPage/Views/Help/DisplayTemplates/Parameters.cshtml

### Pep
(AI summary failed for this feature, see log)
*Spans 5 files:* EIS.BusinessComponent/PEPDetails/IPEPDetail.cs, EIS.BusinessComponent/PEPDetails/PEPDetail.cs, EIS.UI/EmployeeDetail/PEP.aspx, EIS.UI/EmployeeDetail/PEP.aspx.cs, EIS.Entities/PEPDetail.cs

### Pepdetail
(AI summary failed for this feature, see log)
*Spans 3 files:* EIS.DataAccess/PEPDetails/IPEPDetailDataRepository.cs, EIS.DataAccess/PEPDetails/PEPDetailDataRepository.cs, EIS.WebApi/Controllers/PEPDetails/PEPDetailController.cs

### Pepdetailspopup
(AI summary failed for this feature, see log)
*Spans 2 files:* EIS.UI/EmployeeBasicDetail/PEPDetailsPopUp.aspx, EIS.UI/EmployeeBasicDetail/PEPDetailsPopUp.aspx.cs

### Pilotdashboard
(AI summary failed for this feature, see log)
*Spans 8 files:* EIS.BusinessComponent/PilotDashboard/IPilotDashboard.cs, EIS.BusinessComponent/PilotDashboard/PilotDashboard.cs, EIS.UI/PilotDashboard/PilotDashboard.aspx, EIS.UI/PilotDashboard/PilotDashboard.aspx.cs, EIS.Entities/PilotDashboard.cs, EIS.DataAccess/PilotDashboard/IPilotDashboardRepository.cs, EIS.DataAccess/PilotDashboard/PilotDashboardRepository.cs, EIS.WebApi/Controllers/PilotDashboard/PilotDashboardController.cs

### Pilotdashboardsearch
(AI summary failed for this feature, see log)
*Spans 2 files:* EIS.UI/PilotDashboard/PilotDashboardSearch.aspx.cs, EIS.UI/PilotDashboard/PilotDashboardSearch.aspx

### Previousemployer
(AI summary failed for this feature, see log)
*Spans 8 files:* EIS.BusinessComponent/EmployeePreviousEmployer/IPreviousEmployer.cs, EIS.BusinessComponent/EmployeePreviousEmployer/PreviousEmployer.cs, EIS.UI/EmployeeDetail/PreviousEmployer.aspx.cs, EIS.UI/EmployeeDetail/PreviousEmployer.aspx, EIS.Entities/PreviousEmployer.cs, EIS.DataAccess/EmployeePreviousEmployer/PreviousEmployerDataRepository.cs, EIS.DataAccess/EmployeePreviousEmployer/IPreviousEmployerDataRepository.cs, EIS.WebApi/Controllers/EmployeePreviousEmployer/PreviousEmployerController.cs

### Print
(AI summary failed for this feature, see log)
*File:* EIS.UI/Scripts/UploadDocumentJs/Print.js

### Prototype
(AI summary failed for this feature, see log)
*File:* EIS.UI/Scripts/prototype.js

### Reference
(AI summary failed for this feature, see log)
*Spans 4 files:* EIS.UI/Web References/EISFolderReadWriteProd/Reference.cs, EIS.UI/Web References/QAEISFolderReadWriteProd/Reference.cs, EIS.UI/Service References/EISAddRenameUploadFolderQA/Reference.cs, EIS.UI/Service References/EISAddRenameUploadFolderProd/Reference.cs

### References
(AI summary failed for this feature, see log)
*Spans 2 files:* EIS.UI/Scripts/_references.js, EIS.WebApi/Scripts/_references.js

### Resource
(AI summary failed for this feature, see log)
*File:* EIS.WebApi/Areas/HelpPage/Views/Help/ResourceModel.cshtml

### Returntype
(AI summary failed for this feature, see log)
*File:* EIS.CommonComponent/ReturnTypes/ReturnType.cs

### Reward
(AI summary failed for this feature, see log)
*Spans 4 files:* EIS.BusinessComponent/Rewards/RewardDetails.cs, EIS.BusinessComponent/Rewards/IRewardDetails.cs, EIS.DataAccess/Rewards/RewardDataRepository.cs, EIS.DataAccess/Rewards/IRewardDataRepository.cs

### Rewards
(AI summary failed for this feature, see log)
*Spans 6 files:* EIS.UI/EmployeeDetail/Rewards.aspx.cs, EIS.UI/EmployeeDetail/Rewards.aspx, EIS.UI/EmployeeBasicDetail/Rewards.aspx.cs, EIS.UI/EmployeeBasicDetail/Rewards.aspx, EIS.Entities/Rewards.cs, EIS.WebApi/Controllers/Rewards/RewardsController.cs

### Role
(AI summary failed for this feature, see log)
*Spans 8 files:* EIS.BusinessComponent/RoleManagement/RoleMaster.cs, EIS.BusinessComponent/RoleManagement/IRoleMaster.cs, EIS.UI/UserManagement/Role.aspx.cs, EIS.UI/UserManagement/Role.aspx, EIS.Entities/Role.cs, EIS.DataAccess/UserManagement/Role/IRoleMasterDataRepository.cs, EIS.DataAccess/UserManagement/Role/RoleMasterDataRepository.cs, EIS.WebApi/Controllers/Role/RoleController.cs

### Roles
(AI summary failed for this feature, see log)
*Spans 2 files:* EIS.UI/UserManagement/Roles.aspx.cs, EIS.UI/UserManagement/Roles.aspx

### Routeconfig
(AI summary failed for this feature, see log)
*File:* EIS.WebApi/App_Start/RouteConfig.cs

### Sampledirection
(AI summary failed for this feature, see log)
*File:* EIS.WebApi/Areas/HelpPage/SampleGeneration/SampleDirection.cs

### Samples
(AI summary failed for this feature, see log)
*File:* EIS.WebApi/Areas/HelpPage/Views/Help/DisplayTemplates/Samples.cshtml

### Searchemployee
(AI summary failed for this feature, see log)
*Spans 4 files:* EIS.BusinessComponent/SearchEmployee/ISearchEmployee.cs, EIS.BusinessComponent/SearchEmployee/SearchEmployee.cs, EIS.DataAccess/SearchEmployee/ISearchEmployeeRepository.cs, EIS.DataAccess/SearchEmployee/SearchEmployeeRepository.cs

### Service
(AI summary failed for this feature, see log)
*Spans 2 files:* EIS.DataAccess/Helpers/ServiceHelper.cs, EIS.WebApi/ServiceHelper/ServiceHelper.cs

### Serviceconstants
(AI summary failed for this feature, see log)
*File:* EIS.DataAccess/Helpers/ServiceConstants.cs

### Sfapiurls
(AI summary failed for this feature, see log)
*File:* EIS.CommonComponent/Configurations/SFApiUrls.cs

### Simpletypemodeldescription
(AI summary failed for this feature, see log)
*Spans 2 files:* EIS.WebApi/Areas/HelpPage/Views/Help/DisplayTemplates/SimpleTypeModelDescription.cshtml, EIS.WebApi/Areas/HelpPage/ModelDescriptions/SimpleTypeModelDescription.cs

### Smartnav
(AI summary failed for this feature, see log)
*File:* EIS.UI/Scripts/WebForms/SmartNav.js

### Startup
(AI summary failed for this feature, see log)
*File:* EIS.WebApi/Startup.cs

### Startup1
(AI summary failed for this feature, see log)
*File:* EIS.UI/App_Start/Startup1.cs

### Startupauth
(AI summary failed for this feature, see log)
*File:* EIS.WebApi/App_Start/Startup.Auth.cs

### Stations
(AI summary failed for this feature, see log)
*Spans 8 files:* EIS.BusinessComponent/StationManagement/IStationsMaster.cs, EIS.BusinessComponent/StationManagement/StationsMaster.cs, EIS.UI/UserManagement/Stations.aspx.cs, EIS.UI/UserManagement/Stations.aspx, EIS.Entities/Stations.cs, EIS.DataAccess/UserManagement/Stations/IStationsMasterDataRepository.cs, EIS.DataAccess/UserManagement/Stations/StationsMasterDataRepository.cs, EIS.WebApi/Controllers/Stations/StationsController.cs

### Synopsis
(AI summary failed for this feature, see log)
*Spans 2 files:* EIS.UI/EmployeeDetail/Synopsis.aspx.cs, EIS.UI/EmployeeDetail/Synopsis.aspx

### Synopsisnew
(AI summary failed for this feature, see log)
*Spans 2 files:* EIS.UI/EmployeeDetail/SynopsisNew.aspx, EIS.UI/EmployeeDetail/SynopsisNew.aspx.cs

### Table2excel
(AI summary failed for this feature, see log)
*File:* EIS.UI/Scripts/table2excel.js

### Textsample
(AI summary failed for this feature, see log)
*Spans 2 files:* EIS.WebApi/Areas/HelpPage/SampleGeneration/TextSample.cs, EIS.WebApi/Areas/HelpPage/Views/Help/DisplayTemplates/TextSample.cshtml

### Tokeninfo
(AI summary failed for this feature, see log)
*File:* EIS.Entities/TokenInfo.cs

### Treeview
(AI summary failed for this feature, see log)
*File:* EIS.UI/Scripts/WebForms/TreeView.js

### Unauthorizedaccess
(AI summary failed for this feature, see log)
*Spans 2 files:* EIS.UI/UnAuthorizedAccess.aspx.cs, EIS.UI/UnAuthorizedAccess.aspx

### Upload
(AI summary failed for this feature, see log)
*Spans 2 files:* EIS.UI/EmployeeBasicDetail/Upload.aspx.cs, EIS.UI/EmployeeBasicDetail/Upload.aspx

### Uploaddocument
(AI summary failed for this feature, see log)
*Spans 3 files:* EIS.UI/EmployeeBasicDetail/UploadDocument.aspx, EIS.UI/EmployeeBasicDetail/UploadDocument.aspx.cs, EIS.WebApi/Controllers/UploadDocument/UploadDocumentController.cs

### Uploaddocuments
(AI summary failed for this feature, see log)
*Spans 4 files:* EIS.UI/EmployeeDetail/UploadDocuments.aspx, EIS.UI/EmployeeDetail/UploadDocuments.aspx.cs, EIS.UI/UploadDocumentUtility/UploadDocuments.aspx, EIS.UI/UploadDocumentUtility/UploadDocuments.aspx.cs

### User
(AI summary failed for this feature, see log)
*Spans 8 files:* EIS.BusinessComponent/UserManagement/UserMaster.cs, EIS.BusinessComponent/UserManagement/IUserMaster.cs, EIS.UI/UserManagement/User.aspx.cs, EIS.UI/UserManagement/User.aspx, EIS.Entities/User.cs, EIS.DataAccess/UserManagement/User/IUserMasterDataRepository.cs, EIS.DataAccess/UserManagement/User/UserMasterDataRepository.cs, EIS.WebApi/Controllers/User/UserController.cs

### Users
(AI summary failed for this feature, see log)
*Spans 2 files:* EIS.UI/UserManagement/Users.aspx.cs, EIS.UI/UserManagement/Users.aspx

### Viewstart
(AI summary failed for this feature, see log)
*Spans 2 files:* EIS.WebApi/Areas/HelpPage/Views/_ViewStart.cshtml, EIS.WebApi/Views/_ViewStart.cshtml

### Webapiconfig
(AI summary failed for this feature, see log)
*File:* EIS.WebApi/App_Start/WebApiConfig.cs

### Webforms
(AI summary failed for this feature, see log)
*File:* EIS.UI/Scripts/WebForms/WebForms.js

### Webparts
(AI summary failed for this feature, see log)
*File:* EIS.UI/Scripts/WebForms/WebParts.js

### Webuivalidation
(AI summary failed for this feature, see log)
*File:* EIS.UI/Scripts/WebForms/WebUIValidation.js

### Xmldocumentationprovider
(AI summary failed for this feature, see log)
*File:* EIS.WebApi/Areas/HelpPage/XmlDocumentationProvider.cs
