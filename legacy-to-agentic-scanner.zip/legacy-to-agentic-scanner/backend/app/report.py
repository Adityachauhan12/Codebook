"""
Step 5 and 6: turn per-file notes into per-feature summaries, then
assemble the whole thing into one report.
"""

from dataclasses import dataclass

from .ai_client import chat_json
from .grouping import group_label

GROUP_SYSTEM_PROMPT = """You are writing one section of a report for a non-technical \
reviewer about an old business application. You are given short notes about several \
files that all belong to the same feature/capability of the app.

Write your answer as JSON with this exact shape:
{"feature_summary": "2-3 plain-English sentences describing what this feature does \
for the business, written for someone who does not read code",
 "agent_candidate": true or false,
 "agent_reason": "if agent_candidate is true, 1-2 sentences explaining which specific \
part looks like a hardcoded guess at human judgement and why an AI agent could do it \
better; if false, one short sentence saying why this is fine as normal deterministic \
code (e.g. it's a simple CRUD/data-entry feature)"}

Only mark agent_candidate true if at least one file's notes mention a "rule pile" \
(large hardcoded conditions/keyword lists approximating judgement). A feature that is \
just create/read/update/delete of a database record is NOT a candidate.

Respond with ONLY the JSON object, no other text."""


@dataclass
class FeatureReport:
    name: str
    files: list
    feature_summary: str
    agent_candidate: bool
    agent_reason: str


def _summarize_group(group_name: str, facts: list) -> FeatureReport:
    label = group_label(group_name, facts)
    notes_text = "\n".join(
        f"- {f.file}: starts_action={f.starts_action}, "
        f"talks_to_external={f.talks_to_external}, rule_pile={f.rule_pile} -- {f.summary}"
        for f in facts
    )
    user_prompt = f"Feature name (from file naming): {label}\n\nFile notes:\n{notes_text}"

    try:
        data = chat_json(GROUP_SYSTEM_PROMPT, user_prompt, max_tokens=500)
        return FeatureReport(
            name=label,
            files=[f.file for f in facts],
            feature_summary=data["feature_summary"],
            agent_candidate=bool(data["agent_candidate"]),
            agent_reason=data["agent_reason"],
        )
    except Exception as exc:  # noqa: BLE001
        print(f"  [warning] feature summary failed for '{label}': {exc}")
        return FeatureReport(
            name=label,
            files=[f.file for f in facts],
            feature_summary="(AI summary failed for this feature, see log)",
            agent_candidate=False,
            agent_reason=str(exc),
        )


def build_report(groups: dict, progress_callback=None) -> list:
    """groups: dict[stem] -> list[FileFacts], from grouping.group_files().
    Returns list[FeatureReport], largest groups first."""
    ordered = sorted(groups.items(), key=lambda kv: -len(kv[1]))
    reports = []
    for i, (stem, facts) in enumerate(ordered):
        reports.append(_summarize_group(stem, facts))
        if progress_callback:
            progress_callback(i + 1, len(ordered))

    return reports


def report_to_markdown(reports: list, repo_name: str, intake_stats: dict) -> str:
    lines = [f"# Assessment report: {repo_name}", ""]
    lines.append("## Overview")
    lines.append(f"- Files scanned: {intake_stats['total_files_seen']}")
    lines.append(f"- Ignored as junk/generated/vendor: {intake_stats['ignored_count']}")
    lines.append(f"- Real source files analyzed: {intake_stats['kept_count']}")
    lines.append(f"- Features/capabilities identified: {len(reports)}")
    candidates = [r for r in reports if r.agent_candidate]
    lines.append(f"- Possible AI-agent candidates found: {len(candidates)}")
    lines.append("")

    if candidates:
        lines.append("## Possible AI-agent candidates")
        for r in candidates:
            lines.append(f"### {r.name}")
            lines.append(r.feature_summary)
            lines.append(f"**Why:** {r.agent_reason}")
            lines.append(f"*Files involved:* {', '.join(r.files)}")
            lines.append("")

    lines.append("## All features found")
    for r in sorted(reports, key=lambda r: r.name):
        flag = " 🤖" if r.agent_candidate else ""
        lines.append(f"### {r.name}{flag}")
        lines.append(r.feature_summary)
        if len(r.files) > 1:
            lines.append(f"*Spans {len(r.files)} files:* {', '.join(r.files)}")
        else:
            lines.append(f"*File:* {r.files[0]}")
        lines.append("")

    return "\n".join(lines)
