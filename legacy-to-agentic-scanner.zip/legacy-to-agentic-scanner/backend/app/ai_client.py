"""
One shared place for talking to the AI provider. Everything else in this
app (ai_analyze.py, report.py) calls chat_json() and never touches the
provider SDK directly -- so swapping providers means editing this one file,
or in this case just setting an environment variable.

Set LLM_PROVIDER to "groq" (default) or "openai" in backend/.env, along with
the matching API key. Nothing else in the app needs to change either way.
"""

import json
import os
import re
import time

from openai import OpenAI, RateLimitError

PROVIDER_SETTINGS = {
    "groq": {
        "base_url": "https://api.groq.com/openai/v1",
        "api_key_env": "GROQ_API_KEY",
        "model_env": "GROQ_MODEL",
        "default_model": "openai/gpt-oss-20b",
    },
    "openai": {
        "base_url": None,  # use OpenAI's default endpoint
        "api_key_env": "OPENAI_API_KEY",
        "model_env": "OPENAI_MODEL",
        "default_model": "gpt-5",
    },
}

MAX_RATE_LIMIT_RETRIES = 5
_WAIT_TIME_RE = re.compile(r"try again in (\d+(?:\.\d+)?)s", re.IGNORECASE)

_client = None


def _get_provider_name() -> str:
    return os.environ.get("LLM_PROVIDER", "groq").strip().lower()


def _get_provider_settings() -> dict:
    provider = _get_provider_name()
    if provider not in PROVIDER_SETTINGS:
        raise RuntimeError(
            f"Unknown LLM_PROVIDER '{provider}'. Use 'groq' or 'openai'."
        )
    return PROVIDER_SETTINGS[provider]


def get_model() -> str:
    settings = _get_provider_settings()
    return os.environ.get(settings["model_env"], settings["default_model"])


def _get_client() -> OpenAI:
    global _client
    if _client is not None:
        return _client

    settings = _get_provider_settings()
    api_key = os.environ.get(settings["api_key_env"])
    if not api_key:
        raise RuntimeError(
            f"{settings['api_key_env']} is not set. Create backend/.env with "
            f"{settings['api_key_env']}=... before running the AI analysis step "
            f"(LLM_PROVIDER is currently '{_get_provider_name()}')."
        )

    if settings["base_url"]:
        _client = OpenAI(api_key=api_key, base_url=settings["base_url"])
    else:
        _client = OpenAI(api_key=api_key)
    return _client


def _strip_code_fence(text: str) -> str:
    text = text.strip()
    if text.startswith("```"):
        text = text.strip("`")
        if text.lower().startswith("json"):
            text = text[4:]
    return text.strip()


def chat_json(system_prompt: str, user_prompt: str, max_tokens: int = 1200):
    """Calls the model with a system+user prompt, expects a JSON reply
    (object or array), and returns it already parsed.

    On a 429 (rate limit) we sleep for however long the server says to wait,
    then retry, instead of failing the batch outright. Free-tier Groq needs
    this regularly; a paid OpenAI key should rarely hit it.
    """
    client = _get_client()

    for attempt in range(MAX_RATE_LIMIT_RETRIES):
        try:
            response = client.chat.completions.create(
                model=get_model(),
                max_tokens=max_tokens,
                temperature=0,
                messages=[
                    {"role": "system", "content": system_prompt},
                    {"role": "user", "content": user_prompt},
                ],
            )
            text = response.choices[0].message.content
            cleaned = _strip_code_fence(text)
            return json.loads(cleaned)

        except RateLimitError as exc:
            match = _WAIT_TIME_RE.search(str(exc))
            wait_seconds = float(match.group(1)) + 1.0 if match else 10.0
            if attempt == MAX_RATE_LIMIT_RETRIES - 1:
                raise
            time.sleep(wait_seconds)

    raise RuntimeError("unreachable")  # loop always returns or raises
