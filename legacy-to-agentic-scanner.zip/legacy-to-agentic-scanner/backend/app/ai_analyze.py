"""
Step 3: send real source files to the AI and get back structured notes
about each one. Works the same way regardless of what language the file
is written in -- the questions we ask are language-neutral.

To keep the number of API calls sane on a repo with 1000+ small files,
files are packed into batches (by total character count) and analyzed
several at a time in one call, rather than one call per file.
"""

from dataclasses import dataclass, asdict
from concurrent.futures import ThreadPoolExecutor, as_completed

from .ai_client import chat_json

# This app is currently configured for a free-tier Groq account with an
# 8,000-tokens-PER-MINUTE budget shared across every request. Small batches
# and one request at a time keep us under that ceiling instead of tripping
# it on every call. Raise these once running against a paid tier / higher
# rate limit.
MAX_BATCH_CHARS = 8_000
MAX_WORKERS = 1

SYSTEM_PROMPT = """You are analyzing files from an old business application, one \
batch of files at a time. You do not know what language or framework each file \
uses in advance -- figure it out from the content.

For EACH file in the batch, answer these four questions:
1. starts_action: does this file get triggered directly by something outside \
the app -- a web request, a button click, a scheduled job, a queue message? \
(true/false)
2. talks_to_external: does this file directly read or write a database, call \
another service over the network, or read/write a file? (true/false)
3. rule_pile: does this file contain a large set of hardcoded conditions, \
keyword checks, or lookup rules that look like someone's rough guess at human \
judgement (as opposed to simple, obviously-correct logic like basic CRUD or \
validation)? (true/false)
4. summary: one plain-English sentence describing what this file does.

Respond with ONLY a JSON array, one object per file, in this exact shape:
[{"file": "<relative path as given>", "starts_action": true, \
"talks_to_external": false, "rule_pile": false, "summary": "..."}]

No prose outside the JSON array."""


@dataclass
class FileFacts:
    file: str
    starts_action: bool
    talks_to_external: bool
    rule_pile: bool
    summary: str


def _make_batches(kept_files, read_content_fn):
    """Group files into batches under MAX_BATCH_CHARS. A single very large
    file becomes its own batch rather than being dropped."""
    batches = []
    current_batch = []
    current_chars = 0

    for entry in kept_files:
        content = read_content_fn(entry)
        content_len = len(content)

        if current_batch and current_chars + content_len > MAX_BATCH_CHARS:
            batches.append(current_batch)
            current_batch = []
            current_chars = 0

        current_batch.append((entry, content))
        current_chars += content_len

    if current_batch:
        batches.append(current_batch)

    return batches


def _read_file_text(entry) -> str:
    try:
        with open(entry.absolute_path, "r", encoding="utf-8", errors="replace") as f:
            return f.read()
    except OSError:
        return ""


def _build_user_prompt(batch) -> str:
    parts = []
    for entry, content in batch:
        parts.append(f"--- FILE: {entry.relative_path} ---\n{content}\n")
    return "\n".join(parts)


def _analyze_batch(batch, on_error):
    prompt = _build_user_prompt(batch)
    try:
        raw_list = chat_json(SYSTEM_PROMPT, prompt, max_tokens=1200)
        return [FileFacts(**item) for item in raw_list]
    except Exception as exc:  # noqa: BLE001 - we want to keep going on any failure
        on_error(exc, [entry.relative_path for entry, _ in batch])
        return [
            FileFacts(
                file=entry.relative_path,
                starts_action=False,
                talks_to_external=False,
                rule_pile=False,
                summary="(AI analysis failed for this file, see log)",
            )
            for entry, _ in batch
        ]


def analyze_files(kept_files, progress_callback=None, error_callback=None):
    """Runs Step 3 over every kept file. Returns a list[FileFacts].

    progress_callback(done_batches, total_batches) is called after each batch.
    error_callback(exception, list_of_filenames) is called if a batch fails.
    """
    batches = _make_batches(kept_files, _read_file_text)

    all_facts = []
    done = 0

    def _noop_error(exc, filenames):
        print(f"  [warning] batch failed ({exc}): {filenames}")

    error_callback = error_callback or _noop_error

    with ThreadPoolExecutor(max_workers=MAX_WORKERS) as pool:
        futures = {pool.submit(_analyze_batch, b, error_callback): b for b in batches}
        for future in as_completed(futures):
            all_facts.extend(future.result())
            done += 1
            if progress_callback:
                progress_callback(done, len(batches))

    return all_facts


def facts_to_dicts(facts):
    return [asdict(f) for f in facts]
