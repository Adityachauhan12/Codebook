"""
Step 4: group files into "features" (business capabilities) so the report
reads as a handful of coherent flows instead of a list of hundreds of files.

v1 heuristic, deliberately simple: strip common layer-word suffixes off each
file's base name (RoleController -> Role, RoleMasterDataRepository -> Role,
Role.aspx -> Role) and group files whose remaining "stem" matches. Anything
left over falls back to being grouped by its immediate parent folder name.

This is intentionally not clever. It is a starting point to improve once we
have run it against more than one repo.
"""

import os
import re
from collections import defaultdict

# Longest suffixes first, so "MasterDataRepository" is tried before "Master".
LAYER_SUFFIXES = sorted([
    "MasterDataRepository", "DataRepository", "Repository",
    "Controller", "Service", "Manager", "Master",
    "Details", "Detail", "Model", "Models", "Entity",
    "Helper", "Helpers", "Utility", "Utilities",
    "designer",
], key=len, reverse=True)

STOPWORD_STEMS = {"i", "base", "abstract", "index", "default"}


def _strip_extension(filename: str) -> str:
    name = filename
    # handle double extensions like Role.aspx.cs, IRole.cs etc.
    while True:
        base, ext = os.path.splitext(name)
        if ext.lower() in (".cs", ".aspx", ".ascx", ".master", ".cshtml", ".vb",
                            ".js", ".jsx", ".ts", ".tsx", ".py", ".java", ".rb",
                            ".go", ".php"):
            name = base
        else:
            break
    return name


def _strip_interface_prefix(name: str) -> str:
    # "IRoleMaster" -> "RoleMaster"
    if len(name) > 1 and name[0] == "I" and name[1].isupper():
        return name[1:]
    return name


def _strip_layer_suffix(name: str) -> str:
    for suffix in LAYER_SUFFIXES:
        if name.endswith(suffix) and len(name) > len(suffix):
            return name[: -len(suffix)]
    return name


def compute_stem(relative_path: str) -> str:
    filename = os.path.basename(relative_path)
    name = _strip_extension(filename)
    name = _strip_interface_prefix(name)
    name = _strip_layer_suffix(name)
    name = re.sub(r"[^A-Za-z0-9]", "", name).lower()
    return name


def group_files(file_facts, relative_paths_by_file):
    """file_facts: list of FileFacts (has .file = relative path).
    Returns dict[group_name] -> list[FileFacts]."""
    stem_groups = defaultdict(list)

    for fact in file_facts:
        rel_path = fact.file
        stem = compute_stem(rel_path)

        if not stem or stem in STOPWORD_STEMS or len(stem) < 3:
            # fallback: group by parent folder name instead
            parent = os.path.basename(os.path.dirname(rel_path)) or "root"
            stem = f"folder:{parent.lower()}"

        stem_groups[stem].append(fact)

    # merge tiny single-file "groups" that share a fallback folder key back
    # together where sensible is left for a later pass -- v1 keeps it simple.
    return dict(stem_groups)


def group_label(stem: str, facts: list) -> str:
    if stem.startswith("folder:"):
        raw = stem.split(":", 1)[1]
    else:
        raw = stem
    # turn "roledetail" back into "Role Detail"-ish label using the original
    # filenames for a nicer display name.
    example_file = os.path.basename(facts[0].file)
    return raw.capitalize() if raw else example_file
