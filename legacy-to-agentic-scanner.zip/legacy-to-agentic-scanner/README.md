# Legacy-to-Agentic Scanner (v1 core pipeline)

Takes an old codebase (zip or folder) and produces a report describing what
it does and which parts look like good candidates to become AI agents.

## What's built so far

A command-line pipeline (`backend/run_scan.py`) that does 5 steps:

1. Unzip (if given a zip)
2. Find real source code, ignore generated/vendor/binary junk
3. Send each real file to Claude, get back short structured notes
4. Group files into features by name (e.g. RoleController + RoleMaster +
   Role.aspx all become one "Role" feature)
5. Ask Claude to write a plain-English summary of each feature, and flag any
   that look like AI-agent candidates

Output: a Markdown report (`report_<name>.md`).

Not built yet (on purpose, deferred): the web upload page, the report
download/export, user accounts. See project memory for why.

## Running it

```bash
cd backend
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt

cp .env.example .env
# edit .env and put your real Groq API key in it

python3 run_scan.py /path/to/some/repo_or_zip.zip
```

## Known v1 limitations (things to improve, not bugs)

- Grouping is name-based only (strips words like "Controller", "Repository").
  Doesn't merge plurals ("Role" vs "Roles" become separate groups yet).
- No framework-specific understanding yet (e.g. doesn't know what a .NET
  route attribute or Angular controller binding is) -- relies entirely on
  the AI reading step for that.
- No caching: re-scanning the same repo re-analyzes every file from scratch.
- Single long-running script, no progress UI beyond terminal print.
