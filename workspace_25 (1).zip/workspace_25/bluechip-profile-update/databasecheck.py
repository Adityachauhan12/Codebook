from datetime import datetime
from dateutil import parser

def normalize_dob(dob_str):
    if not dob_str or not dob_str.strip():
        return None
    try:
        parsed_date = parser.parse(dob_str, dayfirst=True)
        return parsed_date.strftime('%Y-%m-%d')
    except (ValueError, TypeError):
        return "Invalid date format"

def db_check(user_req: list,
             ciam_profile: dict,
             navitaire_profile: dict,
             capillary_profile: dict):
    """
    Compare user change requests with three profile sources.
    Strict Validation Rules:
    - Match with Old Value -> Update allowed.
    - Match with New Value -> Already updated (Skip).
    - Missing Value -> BLOCK_ALL (Data incomplete).
    - Mismatch (neither Old nor New) -> BLOCK_ALL (Data inconsistent).
    """

    ciam_profile = ciam_profile or {}
    navitaire_profile = navitaire_profile or {}
    capillary_profile = capillary_profile or {}
    
    nameupdate = {"ciam": "no update required", "navitaire": "no update required", "capillary": "no update required", "status": "clear"}
    dobupdate = {"ciam": "no update required", "navitaire": "no update required", "capillary": "no update required", "status": "clear"}
    genderupdate = {"ciam": "no update required", "navitaire": "no update required", "capillary": "no update required", "status": "clear"}

    for req in user_req:
        intent = req.get("Intent Name", "").lower().strip()
 
        # ---------- NAME ----------
        if intent == "name change":
            parts = [req.get("Previous Value First Name", "").strip().lower()]
            if req.get("Previous Value Last Name"):
                parts.append(req["Previous Value Last Name"].strip().lower())
            prevname = " ".join(p for p in parts if p)

            new_parts = [req.get("New Value First Name", "").strip().lower()]
            if req.get("New Value Last Name"):
                new_parts.append(req["New Value Last Name"].strip().lower())
            newname = " ".join(np for np in new_parts if np)
            
            profiles = {"ciam": ciam_profile, "navitaire": navitaire_profile, "capillary": capillary_profile}

            for db_key, profile in profiles.items():
                val = (profile.get("full_name") or "").strip().lower()
                
                if not val:
                    nameupdate[db_key] = "Missing Value"
                    nameupdate["status"] = "BLOCK_ALL" # Block if any DB is missing name
                elif val == prevname:
                    nameupdate[db_key] = "Match with previous value"
                elif val == newname:
                    nameupdate[db_key] = "Match with new value"
                else:
                    nameupdate[db_key] = "Mismatch with db"
                    nameupdate["status"] = "BLOCK_ALL" # Block if random value found
        # ---------- DOB ----------
        elif intent == "dob change":
            req_dob = normalize_dob(req.get("Previous Value", ""))
            new_dob = normalize_dob(req.get("New Value", ""))
            
            dbs = {"ciam": ciam_profile.get("dob"), "navitaire": navitaire_profile.get("dob"), "capillary": capillary_profile.get("dob")}
            
            for db_key, raw_val in dbs.items():
                db_val = normalize_dob(raw_val)
                
                if not db_val:
                    dobupdate[db_key] = "Missing Value"
                    dobupdate["status"] = "BLOCK_ALL" # Block if DOB missing
                elif db_val == req_dob:
                    dobupdate[db_key] = "Match with previous value"
                elif db_val == new_dob:
                    dobupdate[db_key] = "Match with new value"
                else:
                    dobupdate[db_key] = "Mismatch with db"
                    dobupdate["status"] = "BLOCK_ALL"
 
        # ---------- GENDER ----------
        elif intent == "gender change":
            req_gender = req.get("Previous Value", "").strip().lower()[:1]
            new_gender = req.get("New Value", "").strip().lower()[:1]
 
            def norm_gender(val):
                if not val: return None
                val = str(val).strip().lower()
                if val=="xx": return None
                if val in ("1", "m", "male"): return "m"
                if val in ("2", "f", "female"): return "f"
                return val[:1] if val else None

            genders = {"ciam": ciam_profile.get("gender"), "navitaire": navitaire_profile.get("gender"), "capillary": capillary_profile.get("gender")}
            
            for db_key, raw_val in genders.items():
                db_gen = norm_gender(raw_val)
                
                if not db_gen:
                    genderupdate[db_key] = "Missing Value" 
                    genderupdate["status"] = "BLOCK_ALL" # Block if Gender missing
                elif db_gen == req_gender:
                    genderupdate[db_key] = "Match with previous value"
                elif db_gen == new_gender:
                    genderupdate[db_key] = "Match with new value"
                else:
                    genderupdate[db_key] = "Mismatch with db"
                    genderupdate["status"] = "BLOCK_ALL"

    return {
        "nameupdate": nameupdate,
        "dobupdate": dobupdate,
        "genderupdate": genderupdate
    }