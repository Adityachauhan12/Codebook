from dateutil import parser
def normalize_dob(dob_str):
    """
    Normalize a date of birth string to the format 'YYYY-MM-DD'.

    This function attempts to parse a date string using flexible formats,
    assuming the day comes first (dayfirst=True). It then returns the date
    in ISO format ('YYYY-MM-DD'). If the input is invalid or cannot be parsed,
    it returns the string "Invalid date format".

    Parameters:
        dob_str (str): A string representing a date of birth in various formats,
                       e.g., '12-05-1990', '1990/05/12', '12 May 1990'.

    Returns:
        str: A normalized date string in 'YYYY-MM-DD' format,
             or "Invalid date format" if parsing fails.
    """
    try:
        # Attempt to parse the input string with day-first assumption
        parsed_date = parser.parse(dob_str, dayfirst=True)
        # Format the parsed date to 'YYYY-MM-DD'
        return parsed_date.strftime('%Y-%m-%d')
    except (ValueError, TypeError):
        # Return error message if parsing fails
        return "Invalid date format"

def transform_case_summary(caseEinsteinSummary):
    """
    Transforms a list of case summary dictionaries into a structured format
    based on the type of intent (name, dob, gender).

    Parameters:
    caseEinsteinSummary (list): A list of dictionaries, each containing keys:
        - 'intent': The type of change (e.g., 'name', 'dob', 'gender')
        - 'oldEntity': The previous value
        - 'newEntity': The new value

    Returns:
    list: A list of transformed dictionaries with structured keys based on intent.
    """

    output = []
    for case in caseEinsteinSummary:
        # Extract and sanitize input values
        item=caseEinsteinSummary[case]
        intent = item.get("intent", "").lower().strip()
        old_val = item.get("oldEntity", {})
        new_val = item.get("newEntity",{})

        if intent == "name":
            # Split full names into components
            # Extract previous name components
            prev_first = old_val.get("FirstName").strip().lower()
            prev_last = old_val.get("LastName").strip().lower()

            # Extract new name components
            new_first = new_val.get("FirstName").strip().lower()
            new_last= new_val.get("LastName").strip().lower()

            # Append structured name change
            output.append({
                "Intent Name": "Name Change",
                "Previous Value First Name": prev_first,
                "Previous Value Last Name": prev_last,
                "New Value First Name": new_first,
                "New Value Last Name": new_last
            })

        elif intent == "dob":
            # Normalize date of birth values using external function
            # Normalize date of birth values using external function
            normalized_old = normalize_dob(old_val)
            normalized_new = normalize_dob(new_val)

            # Append structured DOB change

            # Append structured DOB change
            output.append({
                "Intent Name": "DOB Change",
                "Previous Value": normalized_old,
                "New Value": normalized_new
            })

        elif intent == "gender":
            # Append structured gender change with lowercase normalization
            # Append structured gender change with lowercase normalization
            output.append({
                "Intent Name": "Gender Change",
                "Previous Value": old_val.lower(),
                "New Value": new_val.lower()
            })

    return output