from semantic_kernel import Kernel
from semantic_kernel.prompt_template.prompt_template_config import PromptTemplateConfig
from semantic_kernel.prompt_template.input_variable import InputVariable

def extract_update_directives(reco: dict):

    ids = {
        "ciam_user_id": reco.get("person_key_ciam", ""),
        "nav_person_key": reco.get("person_key_navitaire", ""),
        "cap_unique_identifier": str(reco.get("person_key_capillary", ""))
    }

    raw_checks = reco.get("Database Check", {})
    need_ciam = need_nav = need_cap = False

    if isinstance(raw_checks, dict):
        for intent_name, systems_status in raw_checks.items():
            if isinstance(systems_status, dict):
                if systems_status.get("ciam", "").strip().lower() == "match with previous value":
                    need_ciam = True
                if systems_status.get("navitaire", "").strip().lower() == "match with previous value":
                    need_nav = True
                if systems_status.get("capillary", "").strip().lower() == "match with previous value":
                    need_cap = True
    

    systems = [need_ciam, need_nav, need_cap]

    values = {}
    for ent in reco.get("Entities", []):
        name = ent.get("Intent Name", "").lower()
        if "name" in name:
            if ent.get("New Value First Name"):
                values["first_name"] = ent["New Value First Name"]
            if ent.get("New Value Last Name"):
                values["last_name"] = ent["New Value Last Name"]
        if "dob" in name and ent.get("New Value"):
            values["dob"] = ent["New Value"]
        if "gender" in name and ent.get("New Value"):
            values["gender"] = ent["New Value"]
        if "mobile" in name or "phone" in name:
            if ent.get("New Value"):
                values["mobile"] = ent["New Value"]

    return systems, ids, values


class AutoreplyClass:
    def __init__(self, kernel: Kernel):
        self.kernel = kernel

    async def auto_reply(
        self,
        semantic_agent_output: str,
        document_intelligence_output: str,
        databse_lookup: str,
        prompt: str
    ) -> str:

        try:
            self.prompt_template_config = PromptTemplateConfig(
                template=prompt,
                name="auto_reply",
                template_format="semantic-kernel",
                input_variables=[
                    InputVariable(name="semantic_agent_output", description="JSON response containing both the semantic agent's result", is_required=True),
                    InputVariable(name="document_intelligence_output", description="JSON response containing the document intelligence result", is_required=True),
                    InputVariable(name="databse_lookup", description="JSON response containing the result of a database lookup", is_required=True)
                ],
            )

            self.auto_reply_helper = self.kernel.add_function(
                function_name="auto_reply_function",
                plugin_name="Reply",
                prompt_template_config=self.prompt_template_config,
            )
            result = await self.auto_reply_helper.invoke(
                self.kernel,
                semantic_agent_output=semantic_agent_output,
                document_intelligence_output=document_intelligence_output,
                databse_lookup=databse_lookup
            )
            return result
        except Exception:
            raise
