def populate_old_entities(profile_update, reference_json):
    """
    Populate missing oldEntity values in profile_update using reference_json.
    Only fills: FirstName, LastName, DOB, Gender.
    Treats empty strings and "N/A" as missing.
    """

    def is_missing(value):
        return not value or str(value).strip().upper() == "N/A"

    for key, value in profile_update.items():
        old_entity = value.get("oldEntity")

        # Case 1: oldEntity is a dict (Name)
        if isinstance(old_entity, dict):
            if "FirstName" in old_entity and is_missing(old_entity["FirstName"]):
                old_entity["FirstName"] = reference_json.get("firstName", "")
            if "LastName" in old_entity and is_missing(old_entity["LastName"]):
                old_entity["LastName"] = reference_json.get("lastName", "")

        # Case 2: oldEntity is a single value (DOB, Gender)
        elif isinstance(old_entity, str):
            if is_missing(old_entity):
                if key == "DOB":
                    profile_update[key]["oldEntity"] = reference_json.get("dob", "")
                elif key == "Gender":
                    profile_update[key]["oldEntity"] = reference_json.get("gender", "")

    return profile_update


