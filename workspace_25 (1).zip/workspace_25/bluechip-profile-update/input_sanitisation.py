from pydantic import BaseModel, EmailStr, StringConstraints
from typing import List, Annotated, Optional

# --- String Types ---
StrippedStr = Annotated[str, StringConstraints(strip_whitespace=True)]
LimitedStr = Annotated[str, StringConstraints(strip_whitespace=True, max_length=200)]

# --- Email Message Model ---
class EmailMessage(BaseModel):
    ToAddress: Optional[EmailStr] = None
    FromAddress: Optional[EmailStr] = None
    Subject: Optional[LimitedStr] = None
    TextBody: Optional[StrippedStr] = None
    MessageDate: Optional[str] = None

# --- Profile Update Entities ---
class NameEntity(BaseModel):
    FirstName: Optional[StrippedStr] = None
    LastName: Optional[StrippedStr] = None

class ProfileUpdateEntity(BaseModel):
    oldEntity: Optional[NameEntity | StrippedStr] = None
    newEntity: Optional[NameEntity | StrippedStr] = None
    intent: Optional[StrippedStr] = None

class ProfileUpdate(BaseModel):
    Name: Optional[ProfileUpdateEntity] = None
    DOB: Optional[ProfileUpdateEntity] = None
    Gender: Optional[ProfileUpdateEntity] = None

# --- Einstein Summary ---
class CaseEinsteinSummary(BaseModel):
    ProfileUpdate: ProfileUpdate
    CaseSummary: Optional[StrippedStr] = None

# --- Main Case Input Model ---
class CaseInput(BaseModel):
    caseRecId: Optional[StrippedStr] = None
    caseNumber: Optional[StrippedStr] = None
    caseDescription: Optional[LimitedStr] = None
    caseSubject: Optional[LimitedStr] = None
    Loyalty_Tier: Optional[StrippedStr] = None
    Loyalty_Number: Optional[StrippedStr] = None
    caseSuppliedEmail: Optional[EmailStr] = None
    caseCategory: Optional[LimitedStr] = None
    csaeSubCategory: Optional[LimitedStr] = None
    csaeReasons: Optional[LimitedStr] = None
    casseCreatedDateTime: Optional[StrippedStr] = None
    caseStatus: Optional[StrippedStr] = None
    caseOwnerName: Optional[LimitedStr] = None
    caseRelatedEmailMessages: Optional[List[EmailMessage]] = None
    caseEinsteinSummary: Optional[CaseEinsteinSummary] = None

    class Config:
        extra = "ignore"  # drop unexpected keys safely

# --- Sanitizer Function ---
def sanitize_input(data: dict) -> dict:
    """
    Validate and sanitize incoming JSON against the CaseInput schema.
    - Strips whitespace
    - Validates email formats
    - Drops unexpected keys
    """
    return CaseInput(**data).model_dump()