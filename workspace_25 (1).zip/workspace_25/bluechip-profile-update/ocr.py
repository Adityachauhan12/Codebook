import io
import re
import base64
import tempfile
from typing import Tuple
from PIL import Image
from azure.core.credentials import AzureKeyCredential
from azure.ai.documentintelligence import DocumentIntelligenceClient
from azure.ai.documentintelligence.models import AnalyzeResult
from dotenv import load_dotenv
import os
load_dotenv()


AZURE_DI_ENDPOINT = os.getenv("AZURE_DI_ENDPOINT")
AZURE_DI_KEY = os.getenv("AZURE_DI_KEY")

# -----------------------
# Helpers: detect/convert
# -----------------------
def _strip_data_url(b64: str) -> str:
    return b64.split(",", 1)[1] if isinstance(b64, str) and b64.startswith("data:") else b64

def _b64_to_bytes(b64: str) -> bytes:
    clean = re.sub(r"\s+", "", _strip_data_url(b64).strip())
    return base64.b64decode(clean, validate=True)

def _sniff_kind(data: bytes) -> str:
    if data.startswith(b"%PDF-"): return "pdf"
    if data.startswith(b"\x89PNG\r\n\x1a\n"): return "png"
    if data.startswith(b"\xff\xd8\xff"): return "jpeg"
    if data.startswith(b"II*\x00") or data.startswith(b"MM\x00*"): return "tiff"
    if data.startswith(b"BM"): return "bmp"
    if len(data) >= 12 and data[:4] == b"RIFF" and data[8:12] == b"WEBP": return "webp"
    if len(data) >= 12 and data[4:8] == b"ftyp" and data[8:12] in (b"heic", b"heif", b"hevc", b"mif1", b"avif"):
        return "heic"
    return "unknown"

def _convert_to_png_bytes(data: bytes) -> bytes:
    img = Image.open(io.BytesIO(data))
    if img.mode not in ("L", "RGB"):
        img = img.convert("RGB")
    buf = io.BytesIO()
    img.save(buf, format="PNG")
    return buf.getvalue()

def _normalize_bytes_and_choose_ext(data: bytes) -> Tuple[bytes, str, str]:
    """
    Returns (normalized_bytes, extension_with_dot, content_type)
    Converts unsupported formats (webp/heic/unknown) -> PNG.
    """
    kind = _sniff_kind(data)
    if kind == "pdf":
        return data, ".pdf", "application/pdf"
    if kind == "png":
        return data, ".png", "image/png"
    if kind == "jpeg":
        return data, ".jpg", "image/jpeg"
    if kind == "tiff":
        return data, ".tiff", "image/tiff"
    if kind == "bmp":
        return data, ".bmp", "image/bmp"
    # Convert unsupported/unknown to PNG
    png = _convert_to_png_bytes(data)
    return png, ".png", "image/png"

# -----------------------------------------
# Main: Base64 -> file -> DI (file stream)
# -----------------------------------------
def analyze_layout_from_base64_via_file(b64_payload: str, model_id: str = "prebuilt-layout") -> str:
    """
    1) Decode base64 (raw or data URL)
    2) Detect/normalize format; convert unsupported to PNG
    3) Write to a real temp file with the correct extension
    4) Open file as binary stream and pass as the *positional* body to DI
    5) Return concatenated text content
    """
    if not AZURE_DI_ENDPOINT or not AZURE_DI_KEY:
        raise RuntimeError("Set AZURE_DI_ENDPOINT and AZURE_DI_KEY.")

    raw = _b64_to_bytes(b64_payload)
    file_bytes, ext, content_type = _normalize_bytes_and_choose_ext(raw)

    tmp_path = None
    try:
        fd, tmp_path = tempfile.mkstemp(suffix=ext)
        with os.fdopen(fd, "wb") as f:
            f.write(file_bytes)


        client = DocumentIntelligenceClient(endpoint=AZURE_DI_ENDPOINT, credential=AzureKeyCredential(AZURE_DI_KEY))
        with open(tmp_path, "rb") as f:
            poller = client.begin_analyze_document(
                model_id,
                f,
                content_type=content_type,
            )
        result: AnalyzeResult = poller.result()


        return (result.content or "").strip()
    except Exception:
        raise
    finally:
        if tmp_path and os.path.exists(tmp_path):
            try:
                os.remove(tmp_path)
            except Exception:
                pass
