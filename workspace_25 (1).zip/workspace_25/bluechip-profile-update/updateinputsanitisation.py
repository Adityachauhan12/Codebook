import re
from base64 import b64encode, b64decode
import os
import json
from Crypto.Cipher import AES

def aes256_encrypt_json(data: dict) -> dict:
    """
    Encrypt a JSON dictionary using AES-256-GCM and return dict with base64 strings.
    """
    key = b64decode(os.getenv("AES_KEY"))  # 32 bytes key for AES-256
    nonce = os.urandom(12)  # Recommended: 12 bytes for GCM
 
    json_str = json.dumps(data).encode("utf-8")
 
    cipher = AES.new(key, AES.MODE_GCM, nonce=nonce)
    ciphertext, tag = cipher.encrypt_and_digest(json_str)
 
    return {
        "encrypted": b64encode(ciphertext).decode("utf-8"),
        "nonce": b64encode(nonce).decode("utf-8"),
        "tag": b64encode(tag).decode("utf-8")
    }

def sanitize_values_update(values):
    """
    Validate the 'values' dictionary fields:
    - first_name, last_name: only alphabets, spaces, hyphens, apostrophes
    - dob: strict YYYY-MM-DD format
    - gender: any alphabetic string (a-z, A-Z)
    Always requires values to be strings.
    Returns True if valid, False otherwise.
    """

    patterns = {
        "name": re.compile(r"^[A-Za-z\s\-']+$"),   # letters, spaces, hyphen, apostrophe
        "dob": re.compile(r"^\d{4}-\d{2}-\d{2}$"), # YYYY-MM-DD
        "gender": re.compile(r"^[A-Za-z]+$") # only alphabets
    }

    for key, val in values.items():
        if not isinstance(val, str):
            return False

    if "first_name" in values and not patterns["name"].match(values["first_name"]):
        return False
    if "last_name" in values and not patterns["name"].match(values["last_name"]):
        return False
    if "dob" in values and not patterns["dob"].match(values["dob"]):
        return False
    if "gender" in values and values["gender"] and not patterns["gender"].match(values["gender"]):
        return False

    return True


import re

# Define patterns
patterns = {
    "name": re.compile(r"^[A-Za-z\s\-']+$"),   # letters, spaces, hyphen, apostrophe
    "dob": re.compile(r"^\d{4}-\d{2}-\d{2}$"), # YYYY-MM-DD
    "gender": re.compile(r"^[A-Za-z]+$")       # only alphabets
}

def validate_entities(entities):
    for ent in entities:
        intent = ent["Intent Name"]

        if intent == "Name Change":
            for key in ["Previous Value First Name", "Previous Value Middle Name",
                        "Previous Value Last Name", "New Value First Name",
                        "New Value Middle Name", "New Value Last Name"]:
                val = ent.get(key, "")
                if val and not patterns["name"].match(val):
                    return False

        elif intent == "DOB Change":
            for key in ["Previous Value", "New Value"]:
                val = ent.get(key, "")
                if val and not patterns["dob"].match(val):
                    return False

        elif intent == "Gender Change":
            for key in ["Previous Value", "New Value"]:
                val = ent.get(key, "")
                if val and not patterns["gender"].match(val):
                    return False

    return True


def check_value_lengths(data,log):
    """
    Recursively validate string lengths in a dictionary or list:
    - first_name, last_name, dob, gender: max length 32
    - all other string keys: max length 1000
    Returns 0 if all values are within limits, 1 for name length issues, 2 for other issues.
    """
    strict_keys = {"first_name", "last_name", "dob", "gender", 
                   "FirstName", "LastName", "DOB", "Gender"}  # handle nested keys too
    name_keys = {"first_name", "last_name", "FirstName", "LastName"}

    if isinstance(data, dict):
        for key, val in data.items():
            if isinstance(val, str):
                max_len = 32 if key in strict_keys else 5000
                if len(val) > max_len:
                    if key in name_keys:
                        
                        abbreviated_name = val[:32]
                        if len(abbreviated_name) <= 32:
                            log.info(f"Member suggestion: Truncate '{aes256_encrypt_json(key)}' by removing spaces: '{aes256_encrypt_json(abbreviated_name)}'")
                        else:
                            abbreviated_name = val[:32]
                            log.info(f"Member suggestion: Truncate '{aes256_encrypt_json(key)}' to 32 characters: '{aes256_encrypt_json(abbreviated_name)}'")
                        return 1
                    else:
                        return 2
            elif isinstance(val, dict):
                result = check_value_lengths(val,log)
                if result != 0:
                    return result
            elif isinstance(val, list):
                result = check_value_lengths(val,log)
                if result != 0:
                    return result
            
        return 0

    elif isinstance(data, list):
        for item in data:
            result = check_value_lengths(item,log)
            if result != 0:
                return result
        return 0

    else:
        # non-string primitive
        return 0
