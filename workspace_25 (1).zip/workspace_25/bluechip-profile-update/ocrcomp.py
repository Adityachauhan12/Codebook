from dateutil import parser
def normalize(value: str) -> str:
    """Normalize string for comparison (lowercase, strip)."""
    if not value:
        return ""
    # .strip() removes outer spaces
    # .replace(" ", "") removes internal spaces ("A B" -> "AB")
    return value.strip().lower()

def is_lexicographical_match(name1, name2):
    """Returns True if both names contain identical words, ignoring order and case."""
    if not name1 or not name2:
        return False
    # Split into words, sort them alphabetically, and compare
    return sorted(name1.strip().lower().split()) == sorted(name2.strip().lower().split())

def is_no_space_match(name1, name2):
    """Checks for Spacing Issues """
    if not name1 or not name2: return False
    # Remove ALL spaces and compare
    return name1.strip().lower() == name2.strip().lower()

def normalize_date(value: str) -> str:
    """Convert any date-like string to YYYY-MM-DD, if possible."""
    if not value or not value.strip():
        return ""
    try:
        return parser.parse(value, dayfirst=True).strftime("%Y-%m-%d")
    except Exception:
        return value.strip()  # fallback if not a valid date
 
def compare_intents(primary, intents):
    """
    Compares a primary record against a list of intent-based changes and evaluates
    whether the expected values match the original values after normalization.

    Parameters:
    primary (dict): Dictionary containing original values for keys like 'first_name',
                    'middle_name', 'last_name', 'dob', 'gender' in the govt id'.
    intents (list): List of dictionaries, each representing an intent to change a field.
                    Each dictionary includes an 'Intent Name' and expected new values.

    Returns:
    list: A list of comparison results for each intent, including match status and reasoning.
    """

    results = []

    for intent in intents:
        intent_name = intent.get("Intent Name")

        # Handle name change comparison
        if intent_name == "Name Change":
            orig_full_name = normalize(primary.get("full_name", ""))

            exp_full_name = normalize(intent.get("New Value First Name", ""))+" "+ normalize(intent.get("New Value Last Name", ""))

            # Compare normalized name components
            match = (
                normalize(orig_full_name) == normalize(exp_full_name)
            )

            results.append({
                "Intent Name": "Name Change",
                "Comparison Analysis": "TRUE" if match else "FALSE",
                "Original Value Full Name": orig_full_name,
                "Expected Value Full Name": exp_full_name,
                "Reasoning": "TRUE because the comparison matches ignoring capitalization."
                if match else "FALSE because one or more values do not match."
            })

        # Handle date of birth comparison
        elif intent_name == "DOB Change":
            orig_dob = primary.get("dob", "")
            exp_dob = intent.get("New Value", "")

            norm_orig = normalize_date(orig_dob)
            norm_exp = normalize_date(exp_dob)

            match = norm_orig == norm_exp

            results.append({
                "Intent Name": "DOB Change",
                "Comparison Analysis": "TRUE" if match else "FALSE",
                "Original Value": orig_dob,
                "Expected Value": exp_dob,
                "Reasoning": "TRUE because the DOBs match after normalization."
                if match else "FALSE because the DOBs do not match."
            })

        # Handle gender comparison
        elif intent_name == "Gender Change":
            orig_gender = primary.get("gender", "")
            exp_gender = intent.get("New Value", "")

            match = normalize(orig_gender) == normalize(exp_gender)

            results.append({
                "Intent Name": "Gender Change",
                "Comparison Analysis": "TRUE" if match else "FALSE",
                "Original Value": orig_gender,
                "Expected Value": exp_gender,
                "Reasoning": "TRUE because the gender matches ignoring capitalization."
                if match else "FALSE because the gender values do not match."
            })

    return results

 