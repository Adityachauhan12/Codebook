# Standard Library Imports
import os
import re
import json
import uuid
import logging
import unicodedata
from datetime import datetime, timedelta, date
from base64 import b64encode, b64decode

# Third-Party Imports
from fastapi import FastAPI, Request
from fastapi.responses import JSONResponse
from dotenv import load_dotenv
from Crypto.Cipher import AES
from Crypto.Util.Padding import pad, unpad
import jwt
import asyncio

# Internal Module Imports
from dataextraction import transform_case_summary
from validator import Validator,check_id_spoofing_gpt4o
from databasecheck import db_check
from kernelsetup import kernel
from prompts import (
    prompt_semantic_check,
    prompt_feedback,
    prompt_id_formatting,
    prompt_tagging,
    prompt_einstein_prompt,
    prompt_use_provided_logic
)

from autoreply import AutoreplyClass, extract_update_directives
from ocr import analyze_layout_from_base64_via_file
from mcp_client import fetch_profiles, update_profiles_client, check_audit_status, fetch_govt_id_via_mcp
from ocrcomp import compare_intents,is_lexicographical_match,is_no_space_match
from populateOldEntity import populate_old_entities
from dbFetch import fetch_profiles_with_retry
from api_health import api_health_check
from sortgovtid import sort_govt_docs
from applogger import init_logger
from logging import LoggerAdapter
 
from slowapi import Limiter
from slowapi.util import get_ipaddr
from starlette.middleware.base import BaseHTTPMiddleware
from starlette.responses import Response
from fastapi.middleware.cors import CORSMiddleware
from input_sanitisation import sanitize_input
from updateinputsanitisation import sanitize_values_update, validate_entities, check_value_lengths
from inputstz import is_valid_value
import jwt,html

from slowapi import _rate_limit_exceeded_handler
from slowapi.middleware import SlowAPIMiddleware
from slowapi.errors import RateLimitExceeded


from azure.monitor.opentelemetry import configure_azure_monitor
from opentelemetry import trace, metrics
from opentelemetry.instrumentation.fastapi import FastAPIInstrumentor
from middleNameLogic import is_middle_name_addition

# import ssl
# import asyncpg
# from contextlib import asynccontextmanager
# from datetime import timezone

base_logger = init_logger("profile-update-recommender")

def get_ip_addr(request: Request):
   forwarded = request.headers.get("X-Forwarded-For")
   if forwarded:

       return forwarded.split(",")[0].strip()
   return request.client.host  # Fallback for local/dev
# def get_ssl_context():
#     """
#     Azure Cosmos DB for PostgreSQL requires TLS/SSL.
#     """
#     ssl_context = ssl.create_default_context()
#     return ssl_context

PRIVATE_KEY = os.getenv("TOKEN_ENCODING_KEY").replace("\\n", "\n")
PUBLIC_KEY = os.getenv("TOKEN_DECODING_KEY").replace("\\n", "\n")

load_dotenv()

# DB_HOST=os.getenv("DB_HOST")
# DB_PORT=int(os.getenv("DB_PORT"))
# DB_NAME=os.getenv("DB_NAME")
# DB_USER=os.getenv("DB_USER")
# DB_PASSWORD=os.getenv("DB_PASSWORD")

# async def init_db(pool):
#     """
#     Initialize database schema and table.
#     """
#     create_table_sql = f"""
#     CREATE SCHEMA IF NOT EXISTS profileupdate;

#     CREATE TABLE IF NOT EXISTS profileupdate.feedback (
#         id UUID PRIMARY KEY,
#         case_rec_id TEXT NOT NULL,
#         decision TEXT NOT NULL,
#         reason TEXT,
#         success_code INT,
#         feedback_timestamp TIMESTAMPTZ NOT NULL,
#         session_id UUID NOT NULL,
#         payload JSONB NOT NULL
#     );
#     """

#     async with pool.acquire() as conn:
#         await conn.execute(create_table_sql)

# @asynccontextmanager
# async def lifespan(app: FastAPI):
#     """
#     Manage database pool lifecycle using context manager.
#     Replaces deprecated @app.on_event()
#     """
#     # Startup
#     if not all([DB_HOST, DB_PORT, DB_NAME, DB_USER, DB_PASSWORD]):
#         raise RuntimeError("Database environment variables are missing.")

#     try:
#         app.state.pg_pool = await asyncpg.create_pool(
#             host=DB_HOST,
#             port=DB_PORT,
#             user=DB_USER,
#             password=DB_PASSWORD,
#             database=DB_NAME,
#             ssl=get_ssl_context(),
#             min_size=1,
#             max_size=5
#         )

#         # Initialize database
#         await init_db(app.state.pg_pool)

#     except Exception as e:
#         base_logger.error(f"Failed to initialize database pool: {e}", exc_info=True)
#         raise

#     yield  # Application runs here

#     # Shutdown
#     pool = getattr(app.state, "pg_pool", None)
#     if pool:
#         await pool.close()
#         base_logger.info("Database pool closed.")
# app = FastAPI(lifespan=lifespan)
app = FastAPI()

DEFAULT_SERVER_URL = os.getenv("DEFAULT_SERVER_URL")
FastAPIInstrumentor.instrument_app(app)


# Pretend database of clients
CLIENTS = {
    os.getenv("BLUECHIP_CLIENT_ID"): os.getenv("BLUECHIP_CLIENT_SECRET")
}

limiter = Limiter(key_func=get_ip_addr)
app.state.limiter = limiter
app.add_middleware(SlowAPIMiddleware)
app.add_exception_handler(RateLimitExceeded, _rate_limit_exceeded_handler)

class SecureHeadersMiddleware(BaseHTTPMiddleware):
    async def dispatch(self, request: Request, call_next):
        response: Response = await call_next(request)
        # Implement recommended headers
        response.headers["Strict-Transport-Security"] = "max-age=3600"
        response.headers["X-Content-Type-Options"] = "nosniff"
        response.headers["Cache-Control"] = "max-age=900, must-revalidate"
        response.headers[
            "Content-Security-Policy"
        ] = "default-src 'self'; object-src 'none'; form-action 'none'; report-to csp-endpoint;"
        # Keep your existing additional headers
        response.headers["X-Frame-Options"] = "DENY"
        response.headers["X-XSS-Protection"] = "1; mode=block"
        return response

app.add_middleware(SecureHeadersMiddleware)
# CORS restrictions (kept as-is)
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["Authorization", "Content-Type", "Bluechip-Client-Id", "Bluechip-Client-Secret"],
)

def extract_first_json_array_from_string(input_str: str):
    """
    Extracts the first JSON array found within a given string.

    This function searches the input string for the first occurrence of a JSON array,
    defined by square brackets [ ... ], and attempts to parse it using the `json` module.

    Parameters:
        input_str (str): A string that potentially contains a JSON array.

    Returns:
        list: The parsed JSON array as a Python list.

    Raises:
        ValueError: If no JSON array is found in the input string.
        json.JSONDecodeError: If the extracted substring is not a valid JSON array.
    """
    match = re.search(r'\[.*\]', input_str, re.S)
    if not match:
        raise ValueError("No JSON array found in the string")
    json_str = match.group(0)
    json_array = json.loads(json_str)
    return json_array    
 
def aes256_encrypt_json(data: dict) -> dict:
    """
    Encrypt a JSON dictionary using AES-256-GCM and return dict with base64 strings.
    """
    try:
        key = b64decode(os.getenv("AES_KEY"))  # 32 bytes key for AES-256
        nonce = os.urandom(12)  # Recommended: 12 bytes for GCM

        json_str = json.dumps(data).encode("utf-8")

        cipher = AES.new(key, AES.MODE_GCM, nonce=nonce)
        ciphertext, tag = cipher.encrypt_and_digest(json_str)

        return {
            "encrypted": b64encode(ciphertext).decode("utf-8"),
            "nonce": b64encode(nonce).decode("utf-8"),
            "tag": b64encode(tag).decode("utf-8")
        }
    except Exception:
        # Fallback if encryption keys fail, ensures log flow doesn't crash app
        return {"error": "Encryption Failed"}
    
    

def contains_diacritics(value: str) -> bool:
    if not value:
        return False
    normalized = unicodedata.normalize("NFD", value)
    return any(unicodedata.category(ch).startswith("M") for ch in normalized)

def remove_diacritics(value: str) -> str:
    if not value:
        return value
    normalized = unicodedata.normalize("NFD", value)
    return "".join(ch for ch in normalized if not unicodedata.category(ch).startswith("M"))

def normalize_govt_id_full_name_if_needed(case_summary_data, extracted_ids_list, log=None):
    """
    For 'name' intent only:
    - if newEntity contains diacritics -> do nothing
    - if newEntity contains no diacritics and govt id full_name contains diacritics
      -> remove diacritics from govt id full_name
    """
    if not extracted_ids_list:
        return extracted_ids_list

    for intent_key, item in case_summary_data.items():
        intent_val_str = str(item.get("intent", "")).lower()

        if "name" not in intent_val_str:
            continue

        new_ent = item.get("newEntity")
        if not isinstance(new_ent, dict):
            continue

        fname = str(new_ent.get("FirstName") or "").strip()
        lname = str(new_ent.get("LastName") or "").strip()

        extracted_name = f"{fname} {lname}".strip()

        if not extracted_name or extracted_name.lower() == "n/a":
            continue

        if contains_diacritics(extracted_name):
            continue

        for govt_id_obj in extracted_ids_list:
            if not isinstance(govt_id_obj, dict):
                continue

            govt_full_name = str(govt_id_obj.get("full_name") or "").strip()

            if govt_full_name and contains_diacritics(govt_full_name):
                normalized_full_name = remove_diacritics(govt_full_name)
                govt_id_obj["full_name"] = normalized_full_name

                if log:
                    log.info(
                        f"Government ID full_name normalized based on extracted name intent. "
                        f"Before: {aes256_encrypt_json(govt_full_name)}, "
                        f"After: {aes256_encrypt_json(normalized_full_name)}"
                    )

    return extracted_ids_list
     
@app.get("/health")
async def api_health():
    return await api_health_check()

    
    
@app.post("/profile_update_recommendation")
@limiter.limit("10/minute")
async def process_json(request: Request):
    
    session_id = str(uuid.uuid4())
    auth_header = request.headers.get("Authorization")
    if not auth_header:
        return JSONResponse(content={"Error": "Missing token"}, status_code=401)

    try:
        scheme, token = auth_header.split()
        if scheme.lower() != "bearer":
            return JSONResponse(content={"Error": "Invalid auth scheme"}, status_code=401)
        
        decoded = _verify_token(token)
        body = await request.json()
        case_id = body.get("caseRecId", "unknown")
        log = LoggerAdapter(base_logger, {"session_id": session_id, "case_id": case_id})
        log.info("Profile recommendation request received. Starting processing workflow.")
        profile_update = body.get("caseEinsteinSummary", {}).get("ProfileUpdate",{})
        if profile_update == {}:
            log.info("Manual Flow triggered, Profile Update Request Missing in Ticket Body")
            log.info({"statuscodeibc":"702"})
            encrypted_respo = aes256_encrypt_json({"Response":"Manual Flow Triggered",
                        "Reason":"Profile Update Request Missing in Ticket Body",
                    "SuccessCode": "702"})
            response = JSONResponse(content={"encrypted_data": encrypted_respo})
            response.headers["X-Session-ID"] = session_id
            return response
        # input sanitisation from salesforce ->
        if is_valid_value(profile_update) is False:
            log.info("Manual Flow triggered, Input validation failed: The request structure is invalid.")
            log.info({"statuscodeibc":"702"})
            encrypted_respo = aes256_encrypt_json({"Response":"Manual Flow Triggered",
                        "Reason":"Invalid inputs",
                    "SuccessCode": "702"})
            response = JSONResponse(content={"encrypted_data": encrypted_respo})
            response.headers["X-Session-ID"] = session_id
            return response
            
      
       
        sanitize_input(body)
        lencheck=check_value_lengths(body,log)
        if lencheck != 0:
            if lencheck == 1:
                log.info("Manual Flow triggered, Input validation failed: Name field exceeds 32 characters.")
                log.info({"statuscodeibc":"702"})
                encrypted_respo = aes256_encrypt_json({"Response":"Manual Flow Triggered",
                        "Reason":"Invalid inputs: name length issue, please truncate names within 32 characters",
                    "SuccessCode": "702"})
                response = JSONResponse(content={"encrypted_data": encrypted_respo})
                response.headers["X-Session-ID"] = session_id
                return response
            elif lencheck == 2:
                log.info("Manual Flow triggered, Input validation failed: One or more fields exceed their character limits.")
                log.info({"statuscodeibc":"702"})
                encrypted_respo = aes256_encrypt_json({"Response":"Manual Flow Triggered",
                        "Reason":"Invalid inputs: field length issue, please shorten the inputs",
                    "SuccessCode": "702"})
                response = JSONResponse(content={"encrypted_data": encrypted_respo})
                response.headers["X-Session-ID"] = session_id
                return response
            else:
                log.info("Manual Flow triggered, Input validation failed: General field length validation error.")
                log.info({"statuscodeibc":"702"})
                encrypted_respo = aes256_encrypt_json({"Response":"Manual Flow Triggered",
                        "Reason":"Invalid inputs: field length validation failed",
                    "SuccessCode": "702"})
                response = JSONResponse(content={"encrypted_data": encrypted_respo})
                response.headers["X-Session-ID"] = session_id
                return response
        
                
        result = await main(body, log)
        encrypted_respo = aes256_encrypt_json(result)
        response = JSONResponse(content={"encrypted_data": encrypted_respo})
        response.headers["X-Session-ID"] = session_id
        return response

    except jwt.ExpiredSignatureError:
        encrypted_respo = aes256_encrypt_json({"error": "Token expired"})
        response = JSONResponse(content={"encrypted_data": encrypted_respo})
        response.headers["X-Session-ID"] = session_id
        return response

    except jwt.InvalidAlgorithmError:
        encrypted_respo = aes256_encrypt_json({"error": "Invalid token algorithm"})
        response = JSONResponse(content={"encrypted_data": encrypted_respo})
        response.headers["X-Session-ID"] = session_id
        return response

    except jwt.InvalidTokenError:
        encrypted_respo = aes256_encrypt_json({"error": "Invalid token"})
        response = JSONResponse(content={"encrypted_data": encrypted_respo})
        response.headers["X-Session-ID"] = session_id
        return response

    except Exception as e:
        encrypted_respo = aes256_encrypt_json({"error": "Internal server error"})
        response = JSONResponse(content={"encrypted_data": encrypted_respo})
        response.headers["X-Session-ID"] = session_id
        return response

async def main(salesforce:dict,log):
    s_id = log.extra.get("session_id")
    c_id = log.extra.get("case_id")

    log.info("Start the main function")
    if not salesforce:
        log.info("Manual Flow Triggered: Processing halted because no data was received from Salesforce.")
        log.info({"statuscodeibc":"703"})
        return {"Response": "Manual Flow Triggered",
                "Reason":"No data received from salesforce",
                "SuccessCode":"703"}
    log.info(f"Payload Ticket Received from Salesforce: {aes256_encrypt_json(salesforce)}")
    y=aes256_encrypt_json(salesforce)
    # --- 1. OPTIMIZED DATABASE FETCH (SINGLE CALL) ---
    user_contact = salesforce.get("caseSuppliedEmail")
    if not user_contact:
        log.info("Manual Flow Triggered: Processing halted because no email address was provided in the request.")
        return {"Response": "Manual Flow Triggered","Reason": "No Email Provided","SuccessCode": "702" }
    
    log.info(f"Retrieving user profiles from Navitaire, CIAM, and Capillary for user: {aes256_encrypt_json({'email': user_contact})}")
    # Call the retry helper
    navitaire_profile, ciam_profile, capillary_profile, db_error = await fetch_profiles_with_retry(
        DEFAULT_SERVER_URL, s_id, c_id, user_contact, log
    )

    # CHECK 1: SYSTEM FAILURE (Manual Flow)
    if db_error:
        log.error(f"Manual Flow Triggered: Database retrieval failed after retries. Error details: {db_error}")
        return {
            "Response": "Manual Flow Triggered",
            "Reason": f"Database Error: Could not fetch customer profiles.{db_error}",
            "SuccessCode": "702",
            "data": "Please retry this endpoint after 5 minutes."
        }

    # CHECK 2: UNREGISTERED USER (Validation)
    # Check if user exists in ANY of the databases
    has_navitaire = bool(navitaire_profile)
    has_capillary = bool(capillary_profile)
    has_ciam = False
    if ciam_profile and isinstance(ciam_profile, dict) and ciam_profile.get("value"):
        has_ciam = True

    if not any([has_navitaire, has_ciam, has_capillary]):
        log.info(f"Manual Flow Triggered: User not found in any database (Navitaire, CIAM, or Capillary).")
        log.info({"statuscodeibc":"702"})
        return {
            "Response": "Manual Flow Triggered",
            "Reason": f"The Email Id: '{user_contact}' is Unregistered in all 3 Databases.",
            "SuccessCode": "702"
        }
    
    log.info(f"User profiles retrieved successfully. Presence - Navitaire: {has_navitaire}, CIAM: {has_ciam}, Capillary: {has_capillary}")

    # Prepare Payload for later use
    db_payload = [navitaire_profile, ciam_profile, capillary_profile]
    log.info(f"MCP Payload: {aes256_encrypt_json(db_payload)}")
    try:
        # Extract case summary details
        case_summary_data = salesforce.get("caseEinsteinSummary", {}).get("ProfileUpdate")
        # FIX 1: Check if the ProfileUpdate dictionary itself is empty
        if not case_summary_data:
            log.info("Manual Flow Triggered: The request contained no update details.")
            validator_instance = Validator(kernel)
            missing_report_str = "Write a polite email asking the customer to provide the details they wish to update, as the request contained no data."
            
            einstein_prompt_output = await validator_instance.einstein_prompt_generator(
                missing_report_str, prompt_use_provided_logic
            )
            return {
                "Response": "Manual Flow Triggered",
                "Reason": "No update details provided",
                "Einstein_prompt": str(einstein_prompt_output),
                "SuccessCode": "703"
            }
        has_capillary = bool(capillary_profile)
        if not has_capillary:
            log.info("Manual Flow Triggered: User is missing from the Loyalty Management System (Capillary).")
            log.info({"statuscodeibc":"702"})
            return {
                    "Response": "Manual Flow Triggered",
                    "Reason": f"Could not retrieve details existing in the LMS system for the user {user_contact}.",
                    "SuccessCode":"702"}
        case_summary_data=populate_old_entities(case_summary_data,capillary_profile)
        required_fields = ["oldEntity", "newEntity", "intent"]
        
        verification_status = (capillary_profile.get("status") or "").strip()
        status_normalized = verification_status.lower()

        # Centralized reasons for each non-verified status
        STATUS_REASONS = {
            "pending_for_verification": (
                "IBC account is pending for verification. Please ask member to complete verification by logging on the website/app."
            ),
            "locked": (
                "IBC account is locked. Profile updates are not allowed. Please contact IndiGo Team as per defined process."
            ),
            "under_investigation": (
                "IBC account is under investigation. Profile updates are not allowed. Please contact IndiGo Team as per defined process."
            ),
            "deactivated": (
                "IBC account is deactivated. Profile updates are not allowed. Please contact IndiGo Team as per defined process."
            ),
        }

        if status_normalized == "verified":
            # Allow profile update based on other rules defined later in the flow
            log.info(
                "Profile is verified. Proceeding with further rules for profile update."
            )
            # DO NOT return; proceed with the rest of your update logic
        else:
            # If it's a known non-verified status, return with the mapped reason
            if status_normalized in STATUS_REASONS:
                log.info(
                    "Manual Flow Triggered: Profile not eligible for update.",
                    extra={"statuscodeibc": "702", "statusLabel": status_normalized or "unknown"},
                )
                return {
                    "Response": "Manual Flow Triggered",
                    "Reason": STATUS_REASONS[status_normalized],
                    "SuccessCode": "702",
                }
            else:
                # Fallback for unexpected/empty statuses
                log.info(
                    "Manual Flow Triggered: Unknown or unsupported profile status.",
                    extra={"statuscodeibc": "702", "statusLabel": status_normalized or "unknown"},
                )
                return {
                    "Response": "Manual Flow Triggered",
                    "Reason": (
                        f"We are unable to proceed because the profile's status is "
                        f"'{status_normalized or 'unknown'}', which prevents us from moving forward."
                    ),
                    "SuccessCode": "702",
                }
        missing_report = []

        # Validate each intent in ProfileUpdate
        for intent_key, item in case_summary_data.items():
            # --- NEW: SPECIAL CHARACTER CHECK FOR NAME INTENT ---
            intent_val_str = str(item.get("intent", "")).lower()
            if "name" in intent_val_str:
                new_ent = item.get("newEntity")
                if isinstance(new_ent, dict):
                    # Safely get the strings, fallback to empty, and strip accidental whitespace
                    fname = str(new_ent.get("FirstName") or "").strip()
                    lname = str(new_ent.get("LastName") or "").strip()
                    
                    # Check for special characters, EXCLUDING exact matches for 'n/a' (case-insensitive)
                    fname_invalid = fname.lower() != "n/a" and bool(re.search(r'[^a-zA-Z\s]', fname))
                    lname_invalid = lname.lower() != "n/a" and bool(re.search(r'[^a-zA-Z\s]', lname))
                    
                    if fname_invalid or lname_invalid:
                        log.info(f"Manual Flow Triggered: Special characters found in requested name. FN: '{aes256_encrypt_json(fname)}', LN: '{aes256_encrypt_json(lname)}'")
                        return {
                            "Response": "Manual Flow Triggered",
                            "Reason": "Special characters are not allowed in the new name.",
                            "SuccessCode": "702"
                        }
            
            missing_fields = []
            
            # FIX 2: Check each required field explicitly.
            for field in required_fields:
                value = item.get(field)

                # Case A: Field is completely missing (None)
                if value is None:
                    missing_fields.append(field)
                
                # Case B: Field is a Dictionary (e.g. Name) -> Check subfields
                elif isinstance(value, dict):
                    if not value: # Empty dict
                        missing_fields.append(field)
                    else:
                        for subfield, subval in value.items():
                            # -> UPDATED: Now also catches "N/A" as a missing value
                            if subval is None or (isinstance(subval, str) and (not subval.strip() or subval.strip().lower() == "n/a")):
                                missing_fields.append(f"{field}.{subfield}")

                # Case C: Field is a String -> Check for empty string or "N/A"
                elif isinstance(value, str):
                    # -> UPDATED: Now also catches "N/A" as a missing value
                    if not value.strip() or value.strip().lower() == "n/a":
                        missing_fields.append(field)

            if missing_fields:
                intent_value = item.get("intent") or intent_key # Fallback to key if intent is missing
                missing_report.append({
                    "intent": intent_value,
                    "missing_fields": missing_fields
                })

        missing_report_str = (
            "**NOTE**"  
            "*VERY IMPORTANT*: Do not mention any points of either Acceptance or Rejection."
            "Only specify what required details are missing exactly"
            "                                                                           "
            "Follow this rule:"
            "     -> If oldEntity.LastName → say Last name is missing in the *Existing* profile"
            "     -> If newEntity.LastName → say Last name is missing in the *Proposed* profile"
            "     -> Apply the same pattern for FirstName,DOB,Gender etc."
            "                                                                           "
            "Below is the list of missing details where oldEntity is the previous value, "
            "newEntity is the new value which needs to be updated to and intent is the type"
            "of value which is being changed. Please ask customer to fill the same: \n"
            + str(missing_report)
        )

 

        if missing_report:
            validator_instance = Validator(kernel)
            einstein_prompt_output = await validator_instance.einstein_prompt_generator(
                missing_report_str, prompt_use_provided_logic
            )
            einstein_prompt_output_str = str(einstein_prompt_output)
            log.info(f"Manual Flow Triggered, Required input fields are missing. This is the einstein prompt to send to customer. Also: {aes256_encrypt_json(einstein_prompt_output_str)}")
            log.info({"statuscodeibc":"703"})
            return {
                "Response": "Manual Flow Triggered",
                "Reason": "Some details are missing",
                "Einstein_prompt": einstein_prompt_output_str,
                "SuccessCode":"703"
            }
        else:
            log.info("Input data validation passed. All required fields are present.")

    except Exception as e:
        log.exception(f"Manual Flow Triggered: Exception occurred during missing details check: {e}", exc_info=True)
        log.info("Exception occurred", extra={"statuscodeibc": str(e)})
        return {
            "Response": "Manual Flow Triggered",
            "Reason": str(e),
            "data": "Please retry this endpoint after 5 minutes."
        }
    ####################################### GOVT ID FETCH ################################################
    try:
        log.info("Fetching and processing Government ID attachments")
        id = salesforce["caseRecId"]
        govt_id_data_and_mail_trail = await fetch_govt_id_via_mcp(DEFAULT_SERVER_URL, s_id, c_id, id)
        attachments = govt_id_data_and_mail_trail.get("caseRelatedAttachments")
        if govt_id_data_and_mail_trail.get("Error_Response","") == "Error occured in Govt ID Fetch":
            return {
                    "Response": "Manual Flow Triggered",
                    "Reason": "Salesforce Govt ID Fetch API did not respond for this request. Please try again after a few minutes.",
                    "SuccessCode":"702"}
        if not attachments:
            validator_instance = Validator(kernel)
            missing_report_str=(
                "Write a polite email to the customer explaining that we cannot proceed because "
                "no valid identity document was found. Ask them to kindly provide one of the "
                "following proofs: Passport, Aadhar card, or Driving License"
            )
            einstein_prompt_output = await validator_instance.einstein_prompt_generator(
                    missing_report_str, prompt_use_provided_logic
            )
            einstein_prompt_output_str = str(einstein_prompt_output)
            log.info("Manual Flow Triggered: No valid Government ID attachment was found in the request.")
            log.info({"statuscodeibc":"703"})
            return {
                    "Response": "Manual Flow Triggered",
                    "Reason": "Valid Document not attached",
                    "Einstein_prompt": einstein_prompt_output_str,
                    "SuccessCode":"703"}
    except Exception as e:
        log.exception(f"Manual Flow Triggered: Exception occurred while fetching Government ID: {e}", exc_info=True)
        log.info("Exception occurred", extra={"statuscodeibc": str(e)})
        return {"Response": "Manual Flow Triggered","Reason":str(e),"data": "Please retry this endpoint after 5min."}
    
    # ############################### PROFILE TAGGING CHECK ################################################
    try:
        log.info("Checking Ticket Tagging")
        tagging = Validator(kernel)
        extracted_einstein_summary = str(salesforce.get("caseEinsteinSummary", {}).get("CaseSummary"))
        final_tagging = await tagging.profile_tagging(extracted_einstein_summary, prompt_tagging)
        log.info(f"Profile Tagging verification result: {final_tagging}")
        final_tagging = str(final_tagging)
        final_tagging = extract_first_json_array_from_string(final_tagging)
        if final_tagging[0]["Verdict"].lower()=="false":
            log.info("Manual Flow Triggered: Incorrect ticket tagging detected. The case is unrelated to profile updates.") 
            log.info({"statuscodeibc":"701"})
            return {"Response": "Manual Flow Triggered",
                    "Reason": "Incorrect tagging - case not related to profile update",
                    "SuccessCode":"701" }
    except Exception as e:
        log.exception(f"Manual Flow Triggered: Exception during tagging verification: {e}", exc_info=True)
        log.info("Exception occurred", extra={"statuscodeibc": str(e)})
        return {"Response": "Manual Flow Triggered","Reason":str(e),"data": "Please retry this endpoint after 5min."}


    # ############################### CAPILLARY AUDIT FIELD FILTER ##################################
    blocked_intent_summary = []
    try:
        log.info("Checking Capillary Audit Logs for restricted fields.")
        
        # 1. Identify User (Defaulting to Email as per your previous logic)
        user_email = salesforce.get("caseSuppliedEmail")
        
        if user_email:
            # 2. Call the new MCP Client function
            # Note: We use "email" as the identifier name. Adjust if you have phone logic.
            audit_result = await check_audit_status(DEFAULT_SERVER_URL, s_id, c_id, "email", user_email)

            blocked_fields = set(audit_result.get("blocked_fields", []))
            log.info(f"Fields blocked by Audit logs: {blocked_fields}")

            # 3. Check for Total Block
            if "ALL" in blocked_fields:
                error_detail = audit_result.get('error', 'Unknown Failure')
                log.info(f"Manual Flow Triggered: Audit Service Unavailable. Reason: {error_detail}")
                manual_msg = f"Profile update blocked entirely by Audit Policy: {error_detail}."
                return {
                    "Response": "Manual Flow Triggered", 
                    "Reason": f"Audit Service Unavailable: {error_detail}", 
                    "SuccessCode": "702"
                }

            # 4. Filter the Salesforce Payload
            # We look at the 'ProfileUpdate' dict where the intents are stored
            profile_update_requests = salesforce.get("caseEinsteinSummary", {}).get("ProfileUpdate", {})

                     
            if profile_update_requests:
                intents_to_remove = []

                # Map Capillary Field Names -> Keywords expected in your 'intent' strings
                # Adjust these keywords based on what 'intent' actually looks like in your Einstein data
                field_map = {
                    "name":      ["name", "first name", "last name", "firstname", "lastname"],
                    "dob":       ["dob", "date of birth", "birth"],
                    "gender":    ["gender"],
                }

                for key, item in profile_update_requests.items():
                    # item contains 'intent' e.g., "Name Change"
                    intent_name = str(item.get("intent", "")).lower()
                    
                    # Check if this intent targets a blocked field
                    is_blocked = False
                    for cap_field in blocked_fields:
                        keywords = field_map.get(cap_field, [])
                        # If any keyword matches the intent string, block it
                        if any(k in intent_name for k in keywords):
                            is_blocked = True
                            break
                    
                    if is_blocked:
                        intents_to_remove.append(key)

                        #adding fields not to be updated to ledger before deleting
                        blocked_intent_summary.append({
                            "intent": intent_name,
                            "field": cap_field,
                            "reason": "Field has been updated already"
                        })

                        log.info(f"Removing request '{key}' Filtering out intent: {intent_name}) because the field '{cap_field}' is locked by audit logs.")

                # 5. Remove the blocked intents
                for k in intents_to_remove:
                    del profile_update_requests[k]

                # 6. Check if ANYTHING is left
                if not profile_update_requests:
                    log.info("Manual Flow Triggered: All requested updates were blocked by audit logs. Fields can only be updated once.")
                    validator_instance = Validator(kernel)
                    manual_msg = ("Write a polite email to the customer explaining that we cannot process their request. "
                        "Inform them that the specific fields they want to update have already been updated recently. "
                        "State that our security policy allows only one update per field to prevent unauthorized changes. "
                        "Apologize for the inconvenience")
                    einstein_prompt = await validator_instance.einstein_prompt_generator(manual_msg, prompt_use_provided_logic)
                    return {
                        "Response": "Manual Flow Triggered", 
                        "Reason": "All requested updates were blocked by audit logs. Fields can only be updated once.", 
                        "Einstein_prompt": str(einstein_prompt), 
                        "SuccessCode": "702"
                    }
        else:
            log.warning("No email found in Salesforce payload, skipping Audit Check.")

    except Exception as e:
        log.exception(f"Manual Flow Triggered: Exception in audit filter: {e}", exc_info=True)
        # Fail-safe: If audit check crashes, we route to manual (702) to be safe
        return {"Response": "Manual Flow Triggered","Reason": "Internal Error during Audit Filter","SuccessCode": "702"}
    
     ###############################  DATA EXTRACTION #####################################################
    try:
        log.info("Starting data extraction from json and OCR processing")
        extracted_information = salesforce.get("caseEinsteinSummary", {}).get("ProfileUpdate")
        
        # FIX: Use .get() with default empty list
        ids_list = govt_id_data_and_mail_trail.get("caseRelatedAttachments", [])
        
        # Double check safety (though Fix 1 should catch this, it prevents crashes here)
        if not ids_list:
            log.info("Manual Flow Triggered: No attachments found in Government ID list during the data extraction.")
            return {"Response": "Manual Flow Triggered","Reason": "Valid Document not attached","SuccessCode": "703"}
        stexdocintel=datetime.now()
        final_extraction=transform_case_summary(extracted_information)
    
        base64_ids_list = []  ##
        for id in ids_list:
            base64_govtid = id["Base64URL"]
            government_id_info = analyze_layout_from_base64_via_file(base64_govtid)
            log.info(f"Raw government ID info: {aes256_encrypt_json(government_id_info)}")
            base64_ids_list.append(government_id_info)

        intent_name="Intent Name"
        enexdocintel=datetime.now()
        log.info(f"Data extraction from Government ID completed. Time taken {enexdocintel-stexdocintel}")
        log.info(f"The Extracted Data: {aes256_encrypt_json(final_extraction)}")
        extracted_intents = final_extraction
        log.info("Extracted intents from request", extra={"intents": [i[intent_name] for i in extracted_intents]})

    except Exception as e:
        log.exception(f"Manual Flow Triggered: Exception during data extraction: {e}", exc_info=True)
        log.info("Exception occurred", extra={"statuscodeibc": str(e)})
        return {"Response": "Manual Flow Triggered","Reason": str(e), "data": "Please retry this endpoint after 5min."}

    ############################### INITIALISING SOME VARIABLES ##########################################
    try:
        previous_entity = ""
        new_entity = ""
        ocr_op = ""
        semantic_op = ""
        semantic_output_list = None
        db_op = ""
        semantic_output_list_str = ""
        spoof_check = 0

        validator = Validator(kernel)
        feedback = AutoreplyClass(kernel)
    except Exception as e:
        log.exception("Manual Flow Triggered: Exception during variable initialization.")
        log.info("Exception occurred", extra={"statuscodeibc": str(e)})
        return {"Response": "Manual Flow Triggered","Reason": str(e),"data": "Please retry this endpoint after 5min."}


    ###################### GOVERNMENT ID FORMATTING #####################################################
    try:
        log.info("Formatting Government ID data")
        extracted_ids_list = []
        stformat=datetime.now()
        for id in base64_ids_list:
            formatted_govt_info = await validator.id_formatter(id, prompt_id_formatting)
            formatted_govt_info = str(formatted_govt_info)
            formatted_govt_info_array = extract_first_json_array_from_string(formatted_govt_info)
            log.info(f"Formatted Government ID info: {aes256_encrypt_json(formatted_govt_info_array)}")
            extracted_ids_list.append(formatted_govt_info_array[0])
        
        extracted_ids_list = normalize_govt_id_full_name_if_needed(
            case_summary_data,
            extracted_ids_list,
            log
        )
        enformat=datetime.now()
        log.info(f"ID formatting completed. Time taken: {enformat - stformat}")
    except Exception as e:
        log.exception(f"Manual Flow Triggered: Exception during Government ID formatting: {e}", exc_info=True)
        log.info("Exception occurred", extra={"statuscodeibc": str(e)})
        return {"Response": "Manual Flow Triggered", "Reason": str(e), "data": "Please retry this endpoint after 5min."}

    ###################### CHECK FOR MULTIPLE IDS OF THE SAME TYPE #####################################
    try:
        log.info("Checking for multiple government IDs of the same type.")
        seen_id_types = set()
        
        for formatted_doc in extracted_ids_list:
            id_type = str(formatted_doc.get("govt_id", "")).strip().lower()
            
            if id_type:
                if id_type in seen_id_types:
                    log.info(f"Manual Flow Triggered: Multiple documents of type '{id_type}' detected.")
                    return {
                        "Response": "Manual Flow Triggered",
                        "Reason": f"Multiple ID proofs of same type are attached. Please evaluate.",
                        "SuccessCode": "703" 
                    }
                seen_id_types.add(id_type)
        spoof_check = 1
                
    except Exception as e:
        log.exception(f"Manual Flow Triggered: Exception during duplicate ID check: {e}", exc_info=True)
        return {"Response": "Manual Flow Triggered", "Reason": str(e), "data": "Please retry this endpoint after 5min."}

    ###################### Spoof Check for the Different Government IDs #####################################
    try:
        if(spoof_check==1):
            for id_doc in ids_list:
                base64_govtid = id_doc["Base64URL"]
                
                log.info("Running GPT-4o Vision Spoof Check...")
                spoof_check_result = await check_id_spoofing_gpt4o(base64_govtid, log)
                
                if spoof_check_result.get("Verdict") == "SPOOF":
                    log.info(f"Manual Flow Triggered: Spoofed ID detected by GPT-4o. Reason: {aes256_encrypt_json(spoof_check_result.get('Reason'))}")
                    return {
                        "Response": "Manual Flow Triggered",
                        "Reason": f"WARNING!!! Uploaded document rejected by security scan: {spoof_check_result.get('Reason')}.",
                        "SuccessCode": "702"
                    }
                elif spoof_check_result.get("Verdict") == "VALID":
                    log.info(f"valid ID detected by AI. Reason: {aes256_encrypt_json(spoof_check_result)}")
    except Exception as e:
        log.exception(f"Manual Flow Triggered: Exception during Spoof Check: {e}", exc_info=True)
        log.info("Exception occurred", extra={"statuscodeibc": str(e)})
        return {"Response": "Manual Flow Triggered","Reason": str(e), "data": "Please retry this endpoint after 5min."}


    ###################### Comparing New Entity with Government ID Details ##############################
    try:
        stocrreq=datetime.now()
        formatted_govt_info=sort_govt_docs(extracted_ids_list)
        log.info("Comparing extracted request data against Government ID")
        log.info(f"Formatted Government ID: {aes256_encrypt_json(formatted_govt_info)}")
        if len(formatted_govt_info) == 0:
            return {
                "Response": "Manual Flow Triggered",
                "Reason": "Ask user to attach aadhar card, passport or driving license",
                "SuccessCode": "703"                
            }
        if (formatted_govt_info[0].get("govt_id").lower()=="passport" or formatted_govt_info[0].get("govt_id").lower()=="driving license"):
            expiry_date = formatted_govt_info[0].get("date_of_expiry")
            exp_date = datetime.strptime(expiry_date, "%Y-%m-%d").date()
            today = date.today()
            if today > exp_date:
                days = (today - exp_date).days
                return {
                    "Response": "Manual Flow Triggered",
                    "reason": f"The identity verification process is unable to proceed, as the {formatted_govt_info[0].get('govt_id').lower()} associated with this Document ID has been expired since {days} days. It expired on {expiry_date}. Valid document is needed to proceed with the request.",
                    "expiry_date": expiry_date,
                    "success_code": "702"
                }
        ocr_op=compare_intents(formatted_govt_info[0],final_extraction)

        # --- NAME FORMAT HANDLER (Rule 4a & 4b) ---
        # 1. Get ID Core
        id_doc = formatted_govt_info[0]
        id_text = id_doc.get("full_name", "")
        if not id_text.strip():
            id_text = f"{id_doc.get('first_name', '')} {id_doc.get('last_name', '')}"
        
        # Helper: Clean tokens (Remove LNU, None, spaces)
        def clean_core_string(text):
            if not text: return ""
            noise = ["lnu", "none", "na", "null", "nan", "blank"]
            tokens = [t for t in str(text).lower().split() if t not in noise]
            return "".join(tokens)

        id_core = clean_core_string(id_text)
        log.info(f"ID Core: '{aes256_encrypt_json(id_core)}'")

        for intent in ocr_op:
            intent_name_val = str(intent.get("Intent Name", "")).strip().lower()
            
            # Check if it's a Name Change and OCR failed
            if intent.get("Comparison Analysis") == "FALSE" and "name" in intent_name_val:
                
                # --- FIX START: RECOVER MISSING DATA ---
                req_f = intent.get("New Value First Name")
                req_l = intent.get("New Value Last Name")

                # If keys are missing in ocr_op, look them up in final_extraction (Source of Truth)
                if req_f is None or req_l is None:
                    for raw_item in final_extraction:
                        # Match the intent (Name Change) to find the original values
                        if str(raw_item.get("Intent Name", "")).lower() == intent_name_val:
                            req_f = raw_item.get("New Value First Name", "")
                            req_l = raw_item.get("New Value Last Name", "")
                            log.info(f"Recovered missing name values from source: F='{aes256_encrypt_json(req_f)}', L='{aes256_encrypt_json(req_l)}'")
                            break
                
                # Ensure they are strings for processing
                req_f = str(req_f or "").strip().lower()
                req_l = str(req_l or "").strip().lower()
                # --- FIX END ---

                # 2. Clean Request
                req_f_core = clean_core_string(req_f)
                req_l_core = clean_core_string(req_l)
                
                log.info(f"Req Core: F='{aes256_encrypt_json(req_f_core)}' L='{aes256_encrypt_json(req_l_core)}' vs ID='{aes256_encrypt_json(id_core)}'")
                
                override_match = False
                reason = ""

                # --- CHECK 1: Composition Match (Standard) ---
                if (req_f_core + req_l_core) == id_core:
                    override_match = True
                    reason = "Allowed: Standard Split or LNU format match."

                # --- CHECK 2: Swap Match (B/A) ---
                elif sorted(list(req_f_core + req_l_core)) == sorted(list(id_core)):
                     override_match = True
                     reason = "Allowed: Name Swap (B/A) format match."

                # --- CHECK 3: Duplicate/Single Match (A/A or Full/Empty) ---
                # This explicitly handles your current case:
                # Req F: "EknathGeethaKannan", Req L: "EknathGeethaKannan" == ID: "EknathGeethaKannan"
                elif (req_f_core == id_core and req_l_core == id_core) or \
                     (req_f_core == id_core and not req_l_core) or \
                     (req_l_core == id_core and not req_f_core):
                    override_match = True
                    reason = "Allowed: Duplicate Name or Single-Field Full Name match."

                if override_match:
                    intent["Comparison Analysis"] = "TRUE"
                    intent["Reasoning"] = reason
                    log.info(f"Government ID check skipped. Reason: {aes256_encrypt_json(reason)}")
    
        enocrreq=datetime.now()
        log.info(f"Comparison logic completed. Time taken: {enocrreq - stocrreq}")
        log.info(f"New entity comparison with Government ID: {aes256_encrypt_json(ocr_op)}")
        intent_list = ocr_op
        intent_list_str = str(intent_list)
    except Exception as e:
        log.exception(f"Manual Flow Triggered: Exception during New Entity comparison with Government ID details: {e}", exc_info=True)
        # You can return None, an empty list, or a custom error object
        log.info("Exception occurred", extra={"statuscodeibc": str(e)})
        return {"Response": "Manual Flow Triggered","Reason": str(e), "data": "Please retry this endpoint after 5min."}

    ################Parsing through Multiple intents and Performing Semantic Check on Name Intent ##################
    try:
        log.info("Checking if name changes are due to typographical reasons")
        different_intents_to_be_updated = []

        #### WHAT ALL INTENTS ARE THERE
        for intent in intent_list:
                different_intents_to_be_updated.append(intent[intent_name].lower())
        
        number_of_intents_false = 0
        intents_to_be_updated = []
        for intent in intent_list:

            if intent[intent_name].lower()=="name change" and intent["Comparison Analysis"].lower()=="true":

                for x in extracted_intents:

                    if x[intent_name].lower()=="name change":

                        previous_entity = x["Previous Value First Name"] +" "+  x["Previous Value Last Name"]
                        previous_entity=previous_entity.strip().lower()
                        new_entity = x["New Value First Name"] + " "+ x["New Value Last Name"]
                        new_entity=new_entity.strip().lower()

                        if x["Previous Value First Name"]==x["New Value First Name"] and x["Previous Value Last Name"]==x["New Value Last Name"]:
                            log.info(f"Early Exit triggered, Existing Name: '{aes256_encrypt_json(previous_entity)}' is identical to New Name: {aes256_encrypt_json(new_entity)}. No update required.")
                            return {
                                "Response":"Manual Flow Triggered",
                                "Reason": "No changes detected. The new name is identical to the old name.",
                                "SuccessCode": "704" 
                            }
                        
                        if previous_entity.replace(" ", "") == new_entity.replace(" ", "") and previous_entity != new_entity:
                            log.info(f"Manual Flow Triggered: Space discrepancy detected. DB Name: '{aes256_encrypt_json(previous_entity)}', Requested Name: '{aes256_encrypt_json(new_entity)}'")
                            return {
                                "Response": "Manual Flow Triggered",
                                "Reason": "Space discrepancy between the ID proof and the proposed name. Please connect with the member to understand the reason for the name update, as retro-claim can be done without updating the name.",
                                "SuccessCode": "702"
                            }

                        try:    
                            stsem=datetime.now()
                            semantic_op
                            semantic_output_list 
                            if previous_entity == new_entity or (is_middle_name_addition(previous_entity, new_entity) is True):
                                semantic_output_list = [{
                                    "Verdict": "Typing_Error",
                                    "Previous Value Name": previous_entity,
                                    "New Value Name": new_entity,
                                    "Reason": "No Change: Names are identical after normalization."
                                }]
                                log.info(f"Typographical name check : {aes256_encrypt_json(semantic_op)}")
                            # --- 2. NEW CODE: UNIVERSAL SEMANTIC BYPASS (Rule 4a & 4b) ---
                            else:
                                # Helper: Clean tokens safely (Protect "Falnu", remove "lnu", lowercase)
                                def get_clean_tokens(text):
                                    if not text: return []
                                    return [t for t in text.lower().split() if t != "lnu"]
    
                                # Clean both OLD and NEW names
                                old_tokens = get_clean_tokens(previous_entity)
                                new_tokens = get_clean_tokens(new_entity)
                                
                                bypass_match = False
                                bypass_reason = ""
    
                                # Check A: Permutation Match (Covers A/B <-> B/A, LNU removal)
                                if sorted(old_tokens) == sorted(new_tokens):
                                    bypass_match = True
                                    bypass_reason = "Format Update: Reordering or LNU removal detected."
    
                                # Check B: Duplication Match (Covers A -> A/A, AB -> AB/AB)
                                elif set(old_tokens) == set(new_tokens):
                                    bypass_match = True
                                    bypass_reason = "Format Update: Name Duplication (A/A or AB/AB) detected."

                                # --- CHECK C: LNU Subset Match (Fix for 'Arun K' -> 'LNU Arun') ---
                                # Logic: If user added 'LNU' and the rest of the name is a SUBSET of the old name (dropping initials/parts).
                                elif "lnu" in new_entity and set(new_tokens).issubset(set(old_tokens)):
                                    bypass_match = True
                                    bypass_reason = "Format Update: LNU added with valid name subset (Initials/Parts dropped)."

                                # --- CHECK D: Subset & Duplication Match (Fix for multi-word duplication) ---
                                # Logic: If EVERY word in the new name exists in the old name, allow it.
                                elif set(new_tokens).issubset(set(old_tokens)):
                                    bypass_match = True
                                    bypass_reason = "Format Update: Name constructed entirely from existing profile name parts (Duplication or dropped initials)."
    
                                # Apply Bypass
                                if bypass_match:
                                    semantic_output_list = [{
                                        "Verdict": "Typing_Error",
                                        "Previous Value Name": previous_entity,
                                        "New Value Name": new_entity,
                                        "Reason": bypass_reason
                                    }]
                                    log.info(f"Semantic Bypass Applied: {aes256_encrypt_json(semantic_output_list)}")
                                    semantic_op = str(semantic_output_list)
                                    log.info(f"Typographical Name Check Bypass Applied: {aes256_encrypt_json(semantic_output_list)}")
                                    semantic_op = str(semantic_output_list)
                                elif is_lexicographical_match(previous_entity, new_entity):
                                    semantic_output_list = [{
                                        "Verdict": "Typing_Error",
                                        "Previous Value Name": previous_entity,
                                        "New Value Name": new_entity,
                                        "Reason": "Name Swap Detected: Words match exactly but order is different."
                                    }]
                                    log.info(f"Typographical name check (Name swap detected) : {aes256_encrypt_json(semantic_op)}")
                                elif is_no_space_match(previous_entity, new_entity):
                                    semantic_output_list = [{
                                        "Verdict": "Typing_Error",
                                        "Previous Value Name": previous_entity,
                                        "New Value Name": new_entity,
                                        "Reason": "Spacing Fix: Detected Insertion/Deletion of Spaces in Name"
                                    }]
                                    log.info(f"Typographical name check (Space insertion/deletion) : {aes256_encrypt_json(semantic_op)}")
                                else:                 
                                    semantic_op = await validator.semantic_name_checker(previous_entity.lower(), new_entity.lower(), prompt_semantic_check)
                                    ensem=datetime.now()
                                    log.info(f"Typographical time taken is {ensem-stsem}")
                                    semantic_op = str(semantic_op)
                                    log.info(f"Typographical name check completed: {aes256_encrypt_json(semantic_op)}")
                                    semantic_output_list = extract_first_json_array_from_string(semantic_op)
                        except Exception as e:
                            log.exception(f"Exception during Typographical Name check: {e}", exc_info=True)
                            log.info("Exception occurred", extra={"statuscodeibc": str(e)})
                            return {"Response": "Manual Flow Triggered", "Reason": str(e), "data": "Please retry this endpoint after 5min."}
                        
                        if semantic_output_list[0]["Verdict"].lower()=="fraud" and (is_middle_name_addition(previous_entity, new_entity) is False):
                            validator_instance = Validator(kernel)
                            name_mismatch=(
                                "Write a polite email to the customer explaining that we cannot process their name change request. "
                                "Explain that the new name provided is significantly different from the name currently on their profile. "
                                "State that for security reasons, we do not allow complete name changes. "
                                "Advise them to contact customer support directly if they believe this is an error."
                            )
                            einstein_prompt_output = await validator_instance.einstein_prompt_generator(
                                    name_mismatch, prompt_use_provided_logic
                            )
                            einstein_prompt_output_str = str(einstein_prompt_output)
                            log.info("Manual Flow Triggered: Fraud alert triggered due to significant name change (Potential Identity Change).")
                            log.info({"statuscodeibc":"702"})
                            return {"Response": "Manual Flow Triggered",
                                    "Reason": "This request appears to be an complete identity change. Please route them to the enrollment flow  with the help of internal team if user's IBC balance is zero; otherwise reject the request.",
                                    "Einstein_prompt": einstein_prompt_output_str,
                                    "SuccessCode":"702"}  
                        else:
                            intents_to_be_updated.append(x)
            elif intent["Comparison Analysis"].lower()=="true" and intent[intent_name].lower()!="name change" and "name change" not in different_intents_to_be_updated:

                full_name_capillary = db_payload[2]["full_name"]
                full_name_capillary=full_name_capillary.strip().lower()
                full_name_govt_id = formatted_govt_info[0]["full_name"]
                if full_name_capillary.strip()!=full_name_govt_id.strip().lower():
                    log.info("Manual Flow Triggered: Security mismatch detected. Name on Government ID does not match LMS profile name during DOB/Gender update.")
                    log.info({"statuscodeibc":"702"})
                    validator_instance = Validator(kernel)
                    name_mismatch=(
                        "Write a polite email to the customer rejecting their request. "
                        "Explain that the name on the uploaded Government ID does not match the name currently registered on their Bluechip profile. "
                        "State that for security reasons, we cannot accept documents that do not belong to the account holder. "
                        "Ask them to please upload a valid ID document that matches their registered name."
                    )
                    einstein_prompt_output = await validator_instance.einstein_prompt_generator(
                            name_mismatch, prompt_use_provided_logic
                    )
                    einstein_prompt_output_str = str(einstein_prompt_output)
                    
                    return {"Response": "Manual Flow Triggered",
                            "Reason": "This request appears to be an complete identity change. Name on Government ID does not match LMS profile name during DOB/Gender update.",
                            "Einstein_prompt": einstein_prompt_output_str,
                            "SuccessCode":"702"}
                else:
                    for x in extracted_intents:
                        if x[intent_name].lower()!="name change":
                            intents_to_be_updated.append(x)

            elif intent["Comparison Analysis"].lower()=="true" and intent[intent_name].lower()!="name change" and "name change" in different_intents_to_be_updated:
                for x in extracted_intents:
                    if x[intent_name].lower()!="name change":
                        intents_to_be_updated.append(x)

            if intent["Comparison Analysis"].lower()=="false":
                validator_instance = Validator(kernel)
                missing_report_str=(
                    "Write a polite email rejecting the profile update request. "
                    "Explain that the details entered in the request do not match the information found on the uploaded Government ID document. "
                    "State that for security reasons, the input must match the ID proof exactly. "
                    "Ask the customer to verify their input details or upload a clearer document and try again."
                )
                einstein_prompt_output = await validator_instance.einstein_prompt_generator(
                    missing_report_str, prompt_use_provided_logic
                )
                einstein_prompt_output_str = str(einstein_prompt_output)
                log.info("Manual Flow Triggered: Input details do not match the extracted Government ID information.")
                log.info({"statuscodeibc":"702"})
                return {
                    "Response": "Manual Flow Triggered",
                    "Reason": "Government ID Details are not matching",
                    "Einstein_prompt": einstein_prompt_output_str,
                    "SuccessCode":"702"}   
    except Exception as e:
        log.exception(f"Manual Flow Triggered: Exception during Intent Logic Loop: {e}", exc_info=True)
        log.info("Exception occurred", extra={"statuscodeibc": str(e)})
        return {"Response": "Manual Flow Triggered","Reason": str(e), "data": "Please retry this endpoint after 5min."}

 
    ########### DATABASE CHECK FUNCTION CALLED ###########
    try:
        log.info("Comparing requested updated against existing data in databases( CIAM, Capillary and Navitaire)")
        stdebc = datetime.now()
        result_dbcheck = db_check(intents_to_be_updated, ciam_profile, navitaire_profile, capillary_profile)
        endebc = datetime.now()
        log.info(f"Database Check completed. Output: {aes256_encrypt_json(result_dbcheck)}, Time Taken: {endebc-stdebc}")
        
        # ==============================================================================
        # 1. CASE: BLOCKING (Detailed Error Reporting)
        # ==============================================================================
        
        # Identify specific blocking reasons
        blocking_details = []
        for field in ["nameupdate", "dobupdate", "genderupdate"]:
            if result_dbcheck[field].get("status") == "BLOCK_ALL":
                # Check which specific DB caused it
                for db_key in ["ciam", "navitaire", "capillary"]:
                    val = result_dbcheck[field].get(db_key)
                    if val in ["Missing Value", "Mismatch with db"]:
                        # E.g., "nameupdate: navitaire - Mismatch with db"
                        blocking_details.append(f"{field}: {db_key} - {val}")

        if blocking_details:
            error_summary = "; ".join(blocking_details)
            log.info(f"Manual Flow Triggered: Database validation failed. Blocking details found: {error_summary}")          
            validator_instance = Validator(kernel)
            
            # We explicitly tell Einstein what is wrong so the email is clear
            manual_msg = (
                f"Write a polite email explaining that we cannot proceed with the automated update. "
                f"The following inconsistencies were found in the records: {error_summary}. "
                "Because of this mismatch/missing data, the case is being routed to a specialist."
            )
            
            einstein_prompt_output = await validator_instance.einstein_prompt_generator(
                manual_msg, prompt_use_provided_logic
            )
            
            return {
                "Response": f"Manual Flow Triggered. Issues: {error_summary}",
                "Einstein_prompt": str(einstein_prompt_output),
                "SuccessCode": "702",
                "Database_Analysis": result_dbcheck 
            }       
        # ==============================================================================
        # 2. CASE: ALL ALREADY UPDATED
        # ==============================================================================
        def check_all_new(update_dict):
            # Only check systems that aren't 'no update required'
            relevant = [k for k in ["ciam", "navitaire", "capillary"] if update_dict[k] != "no update required"]
            if not relevant: return False
            return all(update_dict[k] == "Match with new value" for k in relevant)

        # Check if EVERY requested field is ALREADY set to the New Value in ALL relevant DBs
        all_systems_updated = all(
            check_all_new(result_dbcheck[field]) 
            for field in ["nameupdate", "dobupdate", "genderupdate"]
            # Filter: Only check fields that actually have a requested update
            if any(result_dbcheck[field][k] != "no update required" for k in ["ciam", "navitaire", "capillary"])
        )

        if all_systems_updated:
            log.info("Manual Flow Triggered: The requested changes have already been updated in all systems. No update needed.")
            return {
                "Response": "Manual Flow Triggered",
                "Reason": "The requested changes have already been updated in all systems.",
                "SuccessCode": "200",
                "data": "Already Updated"
            }

        # ==============================================================================
        # 3. CASE: UPDATE / PARTIAL UPDATE (Match with Old Entity)
        # ==============================================================================
        # If we reached here, it means:
        # A) No critical blocks/mismatches.
        # B) Not everything is already updated.
        # C) Therefore, some systems match "Previous Value" and need updating.
        

    except Exception as e:
        log.exception(f"Manual Flow Triggered: Exception during comparison of requested update with Databases: {e}", exc_info=True)
        return {"Response": "Manual Flow Triggered","Reason": str(e), "data": "Please retry this endpoint after 5min."}  
      
    ########### AUTOREPLY FUNCTION CALLED AFTER FETCHING DETAILS FROM DB ################################
    # This block handles the actual construction of the response and determining which systems to update
    try:
        log.info("Generating auto-reply.")
        stauto=datetime.now()
        auto_reply_output = await feedback.auto_reply(
            semantic_output_list_str,
            intent_list_str,
            result_dbcheck, #contains new status strings("Match with previous value")
            prompt=prompt_feedback)
        enauto=datetime.now()
        log.info(f"Auto-reply generated successfully. Time taken: {enauto - stauto}")
        auto_reply_output = str(auto_reply_output)
        log.info(f"Auto-reply final output generated: {aes256_encrypt_json(auto_reply_output)}")
        auto_reply_output = extract_first_json_array_from_string(auto_reply_output)
        ciam_profile = ciam_profile or {}
        navitaire_profile = navitaire_profile or {}
        capillary_profile = capillary_profile or {}

        auto_reply_suggestion={
            "Database Check":result_dbcheck,
            "SUGGESTION":auto_reply_output[0]["Suggestion"],
            "Entities":intents_to_be_updated,
            "blocked_updates": blocked_intent_summary,
            "person_key_ciam":ciam_profile.get("userid",""),
            "person_key_capillary":capillary_profile.get("Unique_identifier",""),  
            "person_key_navitaire":navitaire_profile.get("person_key",""),
            "caseRecId": c_id,
            "SuccessCode":"704"
        }
        log.info({"statuscodeibc":"704"})
        systems, ids, values = extract_update_directives(auto_reply_suggestion)
        auto_reply_suggestion["systems"] = systems
        auto_reply_suggestion["ids"] = ids
        auto_reply_suggestion["values"] = values
        auto_reply_suggestion["UPDATE_CIAM"] = systems[0]
        auto_reply_suggestion["UPDATE_CAPILLARY"] = systems[2]
        auto_reply_suggestion["UPDATE_NAVITAIRE"] = systems[1]
        auto_reply_suggestion_str = str(auto_reply_suggestion)
        einstein_prompt = await validator.einstein_prompt_generator(auto_reply_suggestion_str,prompt_einstein_prompt)
        einstein_prompt = str(einstein_prompt)
        auto_reply_suggestion["einstein_prompt"] = einstein_prompt
        auto_reply_suggestion["db_payload"] = db_payload

        log.info(f"Systems to update - CIAM: {systems[0]}, Navitaire: {systems[1]}, Capillary: {systems[2]}")
        
        return auto_reply_suggestion

    except Exception as e:
        # Log any exception that occurs during the final auto-reply generation
        log.exception(f"Manual Flow Triggered: Exception in Final Auto-Reply Generation: {e}", exc_info=True)        
        # Return a structured error response
        log.info("Exception occurred", extra={"statuscodeibc": str(e)})
        return {
            "Response": "Manual Flow Triggered",
            "Reason": str(e),
            "data": "Please retry this endpoint after 5min."
        }



def extract_bearer_token(auth_header: str):
    if not auth_header:
        return None, "Missing token"
    try:
        scheme, token = auth_header.split()
        if scheme.lower() != "bearer":
            return None, "Invalid auth scheme"
        return token, None
    except ValueError:
        return None, "Invalid authorization header"

async def validate_and_sanitize_input(body,log):
    if is_valid_value(body) is False:
        return False, "Manual Flow Triggered, invalid inputs"
    if sanitize_values_update(body.get("values", {})) is False:
        return False, "Manual Flow Triggered, Input is invalid"
    if validate_entities(body.get("Entities", {})) is False:
        return False, "Manual Flow Triggered, Input is invalid"
    lencheck = check_value_lengths(body,log)
    if lencheck != 0:
        if lencheck == 1:
            return False, "Manual Flow Triggered, Name length issue - please truncate names within 32 characters"
        elif lencheck == 2:
            return False, "Manual Flow Triggered, Field length issue - please shorten the inputs"
        else:
            return False, "Manual Flow Triggered, Field length validation failed"
    sanitize_input(body)
    return True, None

def get_failed_systems(res, sys_flags):
    failed = [False, False, False]
    if sys_flags[0] and res.get("ciam", {}).get("status_code") != 204: failed[0] = True
    if sys_flags[1] and res.get("navitaire", {}).get("status_code") != 200: failed[1] = True
    if sys_flags[2] and res.get("capillary", {}).get("status_code") != 200: failed[2] = True
    return failed

def log_system_status(case_id, attempt, failed_flags, systems, log):
    system_names = ["ciam", "navitaire", "capillary"]

    succeeded = []
    failed = []

    for idx, name in enumerate(system_names):
        # Skip systems that were not part of this request
        if not systems[idx]:
            continue

        if failed_flags[idx]:
            failed.append(name)
        else:
            succeeded.append(name)

    log.info(
        f"[{case_id}] Attempt {attempt} execution summary | "
        f"Successful: {', '.join(succeeded) if succeeded else 'None'} | "
        f"Failed: {', '.join(failed) if failed else 'None'}"
    )

async def handle_profile_update(request: Request, session_id: str, decoded, log):
    body = await request.json()
    log.info(f"Profile Update Payload: {aes256_encrypt_json(body)}")

    valid, error = await validate_and_sanitize_input(body,log)
    if not valid:
        log.info(f"Manual Flow Triggered: Update aborted due to invalid input: {error}")
        log.info({"statuscodeibc":f"{str(error)}"})
        return JSONResponse(content={"Response": "Manual Flow Triggered","SuccessCode": error})
    
    systems = body.get("systems", [False, False, False])
    ids = body.get("ids", {})
    values = body.get("values", {})
    case_id = body.get("caseRecId")

    db_payload = body.get("db_payload", [])

    # Order specified: 0=Navitaire, 1=CIAM, 2=Capillary
    nav_data = db_payload[0]
    ciam_data = db_payload[1]
    cap_data = db_payload[2]

    log.info("Profile update request received", extra={
        "systems": systems,
        "ids": ids,
        "values_preview": {k: str(v)[:50] for k, v in values.items()}
    })

    # ==========================================
    # STEP 2: ATTEMPT 1 - Initial Update
    # ==========================================
    log.info(f"[{case_id}] Executing Attempt 1 of Profile Update.")
    update_result = await update_profiles_client(
        DEFAULT_SERVER_URL, systems=systems, ids=ids, values=values, 
        session_id=session_id, case_id=case_id
    )

    failed_attempt_1 = get_failed_systems(update_result, systems)
    log_system_status(case_id, 1, failed_attempt_1, systems, log)

    if not any(failed_attempt_1):
        log.info(f"[{case_id}] Attempt 1 was successfully completed across all targeted systems: CIAM, Navitaire and Capillary.")
        log.info("Profile update completed", extra={"update_result_preview": str(update_result)[:200]})
        response = JSONResponse(content=update_result)
        response.headers["X-Session-ID"] = session_id
        return response
    
    # ==========================================
    # STEP 3: ATTEMPT 2 - The Retry
    # ==========================================
    log.info(f"[{case_id}] Profile Update Attempt 1 failed for some systems. Initiating Attempt 2 for failed systems.")
    
    # Pass 'failed_attempt_1' as the systems list so it ONLY retries the ones that broke
    retry_result = await update_profiles_client(
        DEFAULT_SERVER_URL, systems=failed_attempt_1, ids=ids, values=values, 
        session_id=session_id, case_id=case_id
    )

    # Merge the retry results back into our main update_result payload
    if failed_attempt_1[0]: update_result["ciam"] = retry_result.get("ciam", {})
    if failed_attempt_1[1]: update_result["navitaire"] = retry_result.get("navitaire", {})
    if failed_attempt_1[2]: update_result["capillary"] = retry_result.get("capillary", {})

    failed_attempt_2 = get_failed_systems(update_result, systems)
    log_system_status(case_id, 2, failed_attempt_2, systems, log)

    if not any(failed_attempt_2):
        log.info(f"[{case_id}] Attempt 2 Successful.")
        log.info("Profile update completed", extra={"update_result_preview": str(update_result)[:200]})
        response = JSONResponse(content=update_result)
        response.headers["X-Session-ID"] = session_id
        return response
    
    # ==========================================
    # STEP 4: ATTEMPT 3 - The Rollback
    # ==========================================
    log.info(f"[{case_id}] Attempt 2 Failed. Data inconsistency detected! Initiating Rollback using payload baseline.")
    # Safely extract the 'Old' values from the freshly fetched profiles

    nav_full = nav_data.get("full_name", "")
    nav_first = nav_data.get("first_name") or (nav_full.split(" ", 1)[0] if nav_full else "")
    nav_last = nav_data.get("last_name") or (nav_full.split(" ", 1)[1] if len(nav_full.split(" ", 1)) > 1 else "")

    # Map the isolated previous data back to the update format
    old_values_by_system = {
        "ciam": {
            "first_name": ciam_data.get("first_name", ""),
            "last_name": ciam_data.get("last_name", ""),
            "dob": ciam_data.get("dob", ""),
            "gender": ciam_data.get("gender", "")
        },
        "navitaire": {
            "first_name": nav_first,
            "last_name": nav_last,
            "dob": nav_data.get("dob", ""),
            "gender": nav_data.get("gender", "")
        },
        "capillary": {
            "first_name": cap_data.get("firstName", ""), # Note camelCase per your Capillary JSON
            "last_name": cap_data.get("lastName", ""),
            "dob": cap_data.get("dob", ""),
            "gender": cap_data.get("gender", "")
        }
    }
  
    # Initialize a dictionary to collect the results of our rollback calls
    combined_rollback_result = {}

    # Execute isolated rollbacks ONLY for systems that were part of the initial update request
    if systems[0]: 
        log.info(f"[{case_id}] Rolling back CIAM")
        ciam_rb = await update_profiles_client(
            DEFAULT_SERVER_URL, systems=[True, False, False], ids=ids, 
            values=old_values_by_system["ciam"], session_id=session_id, case_id=case_id
        )
        combined_rollback_result.update(ciam_rb)

    if systems[1]:
        log.info(f"[{case_id}] Rolling back Navitaire")
        nav_rb = await update_profiles_client(
            DEFAULT_SERVER_URL, systems=[False, True, False], ids=ids, 
            values=old_values_by_system["navitaire"], session_id=session_id, case_id=case_id
        )
        combined_rollback_result.update(nav_rb)

    if systems[2]:
        log.info(f"[{case_id}] Rolling back Capillary")
        cap_rb = await update_profiles_client(
            DEFAULT_SERVER_URL, systems=[False, False, True], ids=ids, 
            values=old_values_by_system["capillary"], session_id=session_id, case_id=case_id
        )
        combined_rollback_result.update(cap_rb)

    # Check if any of the targeted rollbacks failed
    failed_rollbacks = get_failed_systems(combined_rollback_result, systems)

    if any(failed_rollbacks):
        # Determine exactly which ones failed to provide a highly specific error message
        failed_sys_names = []
        if failed_rollbacks[0]: failed_sys_names.append("CIAM")
        if failed_rollbacks[1]: failed_sys_names.append("Navitaire")
        if failed_rollbacks[2]: failed_sys_names.append("Capillary")
        
        log.info(f"[{case_id}] Rollback failed for {', '.join(failed_sys_names)}! Data is inconsistent across the 3 systems.")
        return JSONResponse(content={
            "Response": "Manual Flow Triggered",
            "Reason": f"System update failed, and the subsequent automated rollback ALSO failed for {', '.join(failed_sys_names)}. Manual data reconciliation is required.",
            "SuccessCode": "702",
            "RollbackDetails": combined_rollback_result
        })

    log.info(f"[{case_id}] Rollback complete. Safely reverted to original database state.")
    return JSONResponse(content={
        "Response": "Manual Flow Triggered",
        "Reason": "System update failed after retries. Rollback initiated for data integrity.",
        "SuccessCode": "702"
    })

@app.post("/profile_update")
async def profile_update(request: Request):
    session_id = str(uuid.uuid4())
    auth_header = request.headers.get("Authorization")
    token, auth_error = extract_bearer_token(auth_header)
    if auth_error:
        return JSONResponse(content={"error": auth_error})
    try:
        decoded = _verify_token(token)
        log = LoggerAdapter(base_logger, {"session_id": session_id})
        log.info("Endpoint invoked: /profile_update")
        return await handle_profile_update(request, session_id, decoded, log)
    except jwt.ExpiredSignatureError:
        return JSONResponse(content={"error": "Token expired"})
    except jwt.InvalidTokenError:
        return JSONResponse(content={"error": "Invalid token"})
    except Exception as e:
        log = LoggerAdapter(base_logger, {"session_id": session_id})
        log.exception(f"Manual Flow Triggered: Exception in profile update endpoint in updating the Databases: {e}", exc_info=True)
        return {"Response": "Manual Flow Triggered","Reason": str(e), "data": "Please retry this endpoint after 5min."}

def _get_token_alg(token: str) -> str:
    try:
        header = jwt.get_unverified_header(token)
        return header.get("alg", "")
    except Exception:
        return ""

def _verify_token(token: str):
    alg = _get_token_alg(token)
    if alg != "RS256":
        raise jwt.InvalidAlgorithmError("Unexpected token algorithm")

    decoded = jwt.decode(token, PUBLIC_KEY, algorithms=["RS256"], options={"verify_exp": True})
    return decoded


def _generate_token_for_client(client_id: str) -> str:
    payload = {
        "user_id": client_id,
        "role": "admin",
        "exp": datetime.utcnow() + timedelta(minutes=10)
    }
    token = jwt.encode(payload, PRIVATE_KEY, algorithm="RS256")
    return token


@app.post("/token")
@limiter.limit("10/minute")
def token_generation(request: Request):
    client_id = request.headers.get("bluechip_client_id")
    client_secret = request.headers.get("bluechip_client_secret")
    if client_id not in CLIENTS or CLIENTS[client_id] != client_secret:
        return JSONResponse(content={"Response": "Manual Flow Triggered","Reason": "Invalid credentials"}, status_code=401)

    token = _generate_token_for_client(client_id)
    return JSONResponse(content={"access_token": token, "ttl_in_seconds": 600})

# @app.post("/feedback")
# async def agent_feedback(request: Request):
#     """
#     Record agent feedback for a case.
#     """
#     session_id = str(uuid.uuid4())
#     auth_header = request.headers.get("Authorization")
#     log = LoggerAdapter(base_logger, {"session_id": session_id})

#     # 1. Validate Token
#     token, auth_error = extract_bearer_token(auth_header)
#     if auth_error:
#         log.warning(f"Authorization failed: {auth_error}")
#         return JSONResponse(content={"error": auth_error}, status_code=401)

#     try:
#         decoded = _verify_token(token)
#         body = await request.json()

#         # 2. Extract Payload Data
#         case_id = body.get("caseRecId")
#         decision = body.get("decision")   
#         reason = body.get("reason", "")
#         success_code = body.get("success_code")

#         log = LoggerAdapter(base_logger, {"session_id": session_id, "case_id": case_id})
#         log.info(f"Endpoint invoked: /feedback. Decision: {decision}")

#         if not case_id or not decision:
#             log.warning("Manual Flow Triggered: Missing caseRecId or decision in the payload.")
#             return JSONResponse(
#                 content={"Response": "Failed", "Reason": "Missing required fields"},
#                 status_code=400
#             )

#         # 3. Construct Feedback JSON
#         feedback_id = str(uuid.uuid4())
#         timestamp = datetime.now(timezone.utc).isoformat()

#         feedback_document = {
#             "id": feedback_id,
#             "caseRecId": case_id,
#             "decision": decision,
#             "reason": reason,
#             "success_code":success_code,
#             "timestamp": timestamp,
#             "session_id": session_id,
#         }

#         # 4. Save to PostgreSQL / Cosmos DB for PostgreSQL
#         insert_sql = f"""
#         INSERT INTO profileupdate.feedback (
#             id,
#             case_rec_id,
#             decision,
#             reason,
#             success_code,
#             feedback_timestamp,
#             session_id,
#             payload
#         )
#         VALUES ($1, $2, $3, $4, $5, $6, $7, $8::jsonb)
#         """

#         async with request.app.state.pg_pool.acquire() as conn:
#             await conn.execute(
#                 insert_sql,
#                 uuid.UUID(feedback_id),
#                 case_id,
#                 decision,
#                 reason,
#                 success_code,
#                 datetime.fromisoformat(timestamp),
#                 uuid.UUID(session_id),
#                 json.dumps(feedback_document)
#             )

#         log.info(f"Successfully recorded agent feedback for case {case_id} to PostgreSQL.")

#         # 5. Return Success
#         return JSONResponse(content={
#             "Response": "Success",
#             "Message": "Agent feedback recorded successfully",
#             "SuccessCode": "200"
#         })

#     except jwt.ExpiredSignatureError:
#         log.warning("Token expired")
#         return JSONResponse(content={"error": "Token expired"}, status_code=401)

#     except jwt.InvalidTokenError:
#         log.warning("Invalid token provided")
#         return JSONResponse(content={"error": "Invalid token"}, status_code=401)

#     except json.JSONDecodeError:
#         log.warning("Invalid JSON in request body")
#         return JSONResponse(content={"Response": "Failed", "Reason": "Invalid JSON"}, status_code=400)

#     except Exception as e:
#         log.exception(f"Manual Flow Triggered: Exception in agent feedback endpoint: {e}", exc_info=True)
#         return JSONResponse(content={"Response": "Failed", "Reason": str(e)}, status_code=500)
    
if __name__=="__main__":
    import uvicorn
    uvicorn.run("main:app",host="0.0.0.0",port=8000,reload=True)
