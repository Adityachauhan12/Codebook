import json
def sort_govt_docs(docs_list):
    """
    Filters and sorts a list of government document dictionaries based on predefined priority.
    Parameters:
    docs_list (list): A list of dictionaries, each containing a 'govt_id' key that specifies
                      the type of government document (e.g., 'passport', 'aadhaar', 'driving_license').

    Returns:
    list: A filtered and sorted list of dictionaries, ordered by document priority:
          passport (1), aadhaar (2), driving_license (3).
    """

    # Define sorting priority for known government document types
    priority = {
        "passport": 1,
        "aadhaar": 2,
        "driving license": 3
    }

    # Filter out documents that are not in the priority list
    filtered = [
        doc for doc in docs_list
        if doc.get("govt_id", "").lower().strip() in priority
    ]

    # Sort the filtered documents based on their priority
    filtered.sort(key=lambda doc: priority[doc["govt_id"].lower().strip()])

    return filtered

 