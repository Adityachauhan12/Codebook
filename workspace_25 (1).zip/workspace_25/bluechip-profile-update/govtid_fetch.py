import requests
import os
from dotenv import load_dotenv
import json

load_dotenv()

client_id = os.getenv("SALESFORCE_CLIENT_ID")
client_secret = os.getenv("SALESFORCE_CLIENT_SECRET")
base_url = os.getenv("SALESFORCE_BASE_URL")
user_key = os.getenv("SALESFORCE_USER_KEY", "")


def get_govt_tkn():
    url = f"{base_url}/services/oauth2/token?grant_type=client_credentials&client_id={client_id}&client_secret={client_secret}"

    payload = {}
    headers = {"user_key": user_key}

    response = requests.request("POST", url, headers=headers, data=payload, timeout=15)
    final_response = json.loads(response.text)
    return final_response


def get_govt_id(id: str, log):
    try:
        log.info("hitting the salesforce url for govt id fetch.")
        url = f"{base_url}/services/apexrest/CaseRelatedAttachments/{id}"

        payload = {}
        token = get_govt_tkn()
        final_token = token["access_token"]
        log.info("access token received.")
        headers = {"Authorization": f"Bearer {final_token}", "user_key": user_key}

        response = requests.request(
            "GET", url, headers=headers, data=payload, timeout=15
        )
        final_response = json.loads(response.text)
        log.info("final response generated for govt id -> fetched")
        return final_response
    except Exception as e:
        log.info(f"exception occured in govt id fetch{e}")
        return {"Error_Response": "Error occured in Govt ID Fetch"}
