import requests
import logging

def validate_capillary_audit(log, token, identifier_name, identifier_value):
    """
    Performs sequential API calls: Lookup -> Audit Logs -> Validation logic.
    """
    headers = {
        "X-CAP-API-OAUTH-TOKEN": token,
        "Content-Type": "application/json"
    }

    # 1. CUSTOMER LOOKUP
    lookup_url = f"https://apac.api.capillarytech.com/v2/customers/lookup"
    lookup_params = {
        "source": "INSTORE",
        "identifierName": identifier_name,
        "identifierValue": identifier_value
    }

    try:
        log.info(f"Calling Capillary Lookup for {identifier_value}")
        res = requests.get(lookup_url, headers=headers, params=lookup_params)
        res.raise_for_status()
        customer_data = res.json()
        
        entity_id = customer_data.get("entity")
        if not entity_id:
            log.warning("No entity ID found in lookup.")
            return False, "Customer entity not found"

        # 2. AUDIT LOGS FETCH
        audit_url = "https://apac.api.capillarytech.com/api_gateway/v2/audits"
        audit_params = {
            "entityType": "CUSTOMER",
            "entityId": entity_id,
            "source": "INSTORE"
        }

        log.info(f"Fetching audits for Entity ID: {entity_id}")
        audit_res = requests.get(audit_url, headers=headers, params=audit_params)
        audit_res.raise_for_status()
        audit_data = audit_res.json().get("data", [])

        # 3. LOGIC VALIDATION
        restricted_stores = ["demo.salesforce", "program_ops", "demo.SF_Agentic_AI_Profile","SF_Agentic_AI_Profile"]
        protected_fields = ["FirstName", "LastName", "gender", "dob"]

        for entry in audit_data:
            # Check Store Code
            store_code = entry.get("store", {}).get("code")
            if store_code in restricted_stores:
                return False, f"Recent update by restricted source: {store_code}"

            # Check Field Updates
            for event in entry.get("events", []):
                field = event.get("updatedField")
                if field in protected_fields:
                    # Logic: If previous is NOT N/A and current exists, it's a restricted overwrite
                    prev = event.get("additionalFields", {}).get("previousValue")
                    curr = event.get("additionalFields", {}).get("currentValue")
                    
                    if prev not in [None, "NA", "N/A", ""] and curr:
                        return False, f"Field '{field}' already contains existing data."

        return True, "Success"

    except Exception as e:
        log.error(f"Capillary API Error: {str(e)}")
        # In case of API failure, we default to False to stay safe (Manual Flow)
        return False, f"API Error: {str(e)}"
