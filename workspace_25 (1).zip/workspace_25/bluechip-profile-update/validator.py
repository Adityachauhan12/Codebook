import json
from semantic_kernel import Kernel
from semantic_kernel.prompt_template.prompt_template_config import PromptTemplateConfig
from semantic_kernel.prompt_template.input_variable import InputVariable
from openai import AsyncAzureOpenAI
import os
from dotenv import load_dotenv
load_dotenv()
aclient = AsyncAzureOpenAI(
    azure_endpoint=os.getenv("AZURE_OPENAI_ENDPOINT"),
    api_key=os.getenv("AZURE_OPENAI_API_KEY"),
    api_version="2024-12-01-preview"
)

class Validator:
    def __init__(self, kernel: Kernel):
        self.kernel = kernel

    async def semantic_name_checker(self, prev_entity: str, new_entity: str, prompt: str) -> str:
        try:
            self.prompt_template_config = PromptTemplateConfig(
                template=prompt,
                name="Typing Error Checker",
                template_format="semantic-kernel",
                input_variables=[
                    InputVariable(name="prev_entity", description="previous entity string", is_required=True),
                    InputVariable(name="new_entity", description="new entity string", is_required=True)
                ],
            )

            self.semantic_valid = self.kernel.add_function(
                function_name="Typing_Error_Checker",
                plugin_name="Valid",
                prompt_template_config=self.prompt_template_config,
            )
            result = await self.semantic_valid.invoke(self.kernel, prev_entity=prev_entity, new_entity=new_entity)
            return result
        except Exception:
            raise

    async def id_formatter(self, input: str, prompt: str) -> str:
        try:
            self.prompt_template_config = PromptTemplateConfig(
                template=prompt,
                name="ID Formatter",
                template_format="semantic-kernel",
                input_variables=[
                    InputVariable(name="input", description="string", is_required=True)
                ],
            )

            self.semantic_valid = self.kernel.add_function(
                function_name="ID_Formatter",
                plugin_name="Formatter",
                prompt_template_config=self.prompt_template_config,
            )
            result = await self.semantic_valid.invoke(self.kernel, input=input)
            return result
        except Exception:
            raise
    async def profile_tagging(self, summary: str, prompt: str) -> str:
        self.prompt_template_config = PromptTemplateConfig(
            template=prompt,
            name="Profile_Tagging",
            template_format="semantic-kernel",
            input_variables=[
                InputVariable(name="summary", description="summary of the salesforce ticket", is_required=True)
            ],
        )
    
        self.semantic_valid = self.kernel.add_function(
            function_name="Profile_Tagging",
            plugin_name="Profile_Tagging",
            prompt_template_config=self.prompt_template_config,
        )
        result = await self.semantic_valid.invoke(self.kernel, summary = summary)
        return result
    async def einstein_prompt_generator(self, auto_reply_suggestion: str, prompt: str) -> str:
        try:
            prompt = prompt.strip()
            self.prompt_template_config = PromptTemplateConfig(
                template=prompt,
                name="Prompt Generator",
                template_format="semantic-kernel",
                input_variables=[
                    InputVariable(name="auto_reply_suggestion", description="structured suggestion JSON", is_required=True)
                ],
            )

            self.semantic_valid = self.kernel.add_function(
                function_name="Prompt_Generator",
                plugin_name="Generator",
                prompt_template_config=self.prompt_template_config,
            )
            result = await self.semantic_valid.invoke(self.kernel, auto_reply_suggestion= auto_reply_suggestion)
            return result
        except Exception:
            raise

async def check_id_spoofing_gpt4o(base64_image: str, log) -> dict:
    """
    Uses GPT-4o Vision to determine if the uploaded ID is a real physical document
    or a spoof (e.g., text on a plain white paper or a digital screen).
    """
    prompt = """
    You are a strict security and identity verification expert.
    Analyze the attached image of an identity document. 
    Determine if it is a photograph of a REAL, physical document (like a plastic card, passport book, or official paper) OR if it is a SPOOF.

    A SPOOF includes ONLY:
    1. Identity information written entirely by hand on a plain sheet of paper (e.g., handwritten name, ID number, or photo drawn/sketched).

    A REAL document includes:
    1. Printed text or graphics on paper (official forms, certificates, etc.).
    2. Screenshots or photos of a digital screen showing an official document.
    3. Visible physical edges of a card/book or official paper.
    4. Complex background patterns, micro-printing, or watermarks.
    5. Holograms or realistic physical lighting/shadows.
    6. A human photograph.

    Return ONLY a JSON object with this exact structure:
    {"Verdict": "VALID" or "SPOOF", "Reason": "A brief 1-sentence explanation of what you see"}
    """
    
    try:
        response = await aclient.chat.completions.create(
            model=os.getenv("AZURE_OPENAI_DEPLOYMENT_NAME", "gpt-4o"), # Use your GPT-4o deployment name
            messages=[
                {
                    "role": "user",
                    "content": [
                        {"type": "text", "text": prompt},
                        {
                            "type": "image_url",
                            "image_url": {
                                # Note: Assuming it's a JPEG, adjust mime type if needed based on your fetcher
                                "url": f"data:image/jpeg;base64,{base64_image}"
                            }
                        }
                    ]
                }
            ],
            response_format={ "type": "json_object" },
            max_tokens=200
        )
        
        result_str = response.choices[0].message.content
        return json.loads(result_str)
        
    except Exception as e:
        log.error(f"GPT-4o Vision check failed: {e}")
        # Fail open or fail closed depending on your risk tolerance
        return {"Verdict": "ERROR", "Reason": str(e)}