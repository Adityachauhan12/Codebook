import os
import asyncio
from fastmcp import Client
import requests
import httpx
from fastmcp.client.transports import StreamableHttpTransport
from dotenv import load_dotenv

load_dotenv()

PRIVATE_KEY = os.getenv("TOKEN_ENCODING_KEY","").replace("\\n", "\n")
PUBLIC_KEY = os.getenv("TOKEN_DECODING_KEY","").replace("\\n", "\n")
DEFAULT_SERVER_URL = os.getenv("DEFAULT_SERVER_URL")
bcp_id = os.getenv("BLUECHIP_CLIENT_ID")
bcp_secret= os.getenv("BLUECHIP_CLIENT_SECRET")
AZURE_DI_ENDPOINT = os.getenv("AZURE_DI_ENDPOINT")
endpoint=os.getenv("AZURE_OPENAI_ENDPOINT")
client_id = os.getenv("SALESFORCE_CLIENT_ID")
client_secret = os.getenv("SALESFORCE_CLIENT_SECRET")
Salesforce_endpoint = os.getenv("SALESFORCE_BASE_URL")


def create_custom_httpx_client(**kwargs):
    """
    Factory to create a custom httpx client with SSL verification enabled.
    """
    kwargs["verify"] = True
    return httpx.AsyncClient(**kwargs)   
# Create a transport with the custom httpx client factory
transport = StreamableHttpTransport(
    url=DEFAULT_SERVER_URL,
    httpx_client_factory=create_custom_httpx_client,
)
# Initialize the MCP client with the custom transport
client = Client(transport=transport)
async def call_tool():
    try:
        async with client:
            tools = await client.list_tools()
            return True  # success, return the list
    except Exception as e:
        # Connection failed or server not up
        return False
    


def ping_salesforce(base_url: str):
    try:
        # Use HEAD for a lightweight check
        resp = requests.head(base_url, timeout=5)
        if resp.status_code == 200:
            return True
        else:
            return False
    except Exception as e:
        return False


def pingg(endpoint):
    try:
        resp = requests.head(endpoint, timeout=5)
        if resp.status_code in (200, 401, 403, 404):
            return True
        else:
            return False
    except Exception as e:
        return False


async def api_health_check():
    results = {}

    # Check keys
    if PUBLIC_KEY == "":
        results["public_key"] = "public key not fetched"
    else:
        results["public_key"] = "ok"

    if PRIVATE_KEY == "":
        results["private_key"] = "private key not fetched"
    else:
        results["private_key"] = "ok"

    if bcp_id == "":
        results["bluechip_id"] = "bluechip id not configured"
    else:
        results["bluechip_id"] = "ok"

    if bcp_secret == "":
        results["bluechip_secret"] = "bluechip secret not configured"
    else:
        results["bluechip_secret"] = "ok"

    # MCP server
    y = await call_tool()
    results["mcp_server"] = "ok" if y != False else "mcp connection not established"

    # Salesforce
    ping_result = ping_salesforce(Salesforce_endpoint)
    results["salesforce"] = "ok" if ping_result != False else "salesforce govt id connection failed"

    # Azure Document Intelligence
    azure_di = pingg(AZURE_DI_ENDPOINT)
    results["azure_document_intelligence"] = "ok" if azure_di != False else "azure document intelligence connection failed"

    # Azure OpenAI
    openaii = pingg(endpoint)
    results["azure_openai"] = "ok" if openaii != False else "openai connection failed"

    # Overall service status
    overall = "ok" if all(v == "ok" for v in results.values()) else "issues detected"
    results["serviceStatus"] = overall

    return results
