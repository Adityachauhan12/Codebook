import warnings
import logging
warnings.filterwarnings("ignore", message="pkg_resources is deprecated.*")
logging.getLogger("azure").setLevel(logging.ERROR)
logging.getLogger("azure.monitor").setLevel(logging.ERROR)
logging.getLogger("azure.monitor.opentelemetry.exporter").setLevel(logging.ERROR)
logging.getLogger("azure.core.pipeline.policies.http_logging_policy").setLevel(logging.ERROR)
logging.getLogger("opentelemetry").setLevel(logging.ERROR)
logging.getLogger("urllib3").setLevel(logging.ERROR)
# Suppress FastAPI, Starlette, and Uvicorn noise
logging.getLogger("uvicorn").setLevel(logging.WARNING)
logging.getLogger("uvicorn.access").setLevel(logging.CRITICAL)
logging.getLogger("uvicorn.error").setLevel(logging.WARNING)
logging.getLogger("fastapi").setLevel(logging.WARNING)
logging.getLogger("asyncio").setLevel(logging.WARNING)
logging.getLogger("azure.core.pipeline.policies.http_logging_policy").setLevel(logging.WARNING)

import os
import sys
from dotenv import load_dotenv
from azure.monitor.opentelemetry import configure_azure_monitor
from opentelemetry.sdk._logs import LoggingHandler


# Load environment
load_dotenv()
# Configure Azure Monitor (OpenTelemetry)
configure_azure_monitor(
    connection_string=os.getenv("APPLICATIONINSIGHTS_CONNECTION_STRING"),
    disable_offline_storage = True
)

warnings.filterwarnings("ignore", message="pkg_resources is deprecated.*")

class SafeFormatter(logging.Formatter):
    def format(self, record):
        # Provide safe defaults if missing
        if not hasattr(record, "session_id"):
            record.session_id = "N/A"
        if not hasattr(record, "case_id"):
            record.case_id = "N/A"
        return super().format(record)

class ContextLoggerAdapter(logging.LoggerAdapter):
    def process(self, msg, kwargs):
        extra = self.extra.copy()
        # Merge any extras passed in explicitly
        if "extra" in kwargs:
            extra.update(kwargs["extra"])
        kwargs["extra"] = extra
        return msg, kwargs

class AppLogger:
    _configured = False

    def __init__(self):
        self.adapter = None
        self.azure_handler = LoggingHandler()

    def make_logger(self, name: str, session_id=None, case_id=None) -> logging.LoggerAdapter:
        if not AppLogger._configured:
            stdout_handler = logging.StreamHandler(sys.stdout)
            stdout_handler.setLevel(logging.INFO)
            stdout_handler.addFilter(lambda r: r.levelno <= logging.INFO)
            stderr_handler = logging.StreamHandler(sys.stderr)
            stderr_handler.setLevel(logging.WARNING)
            stderr_handler.addFilter(lambda r: r.levelno > logging.INFO)
            formatter = SafeFormatter(
                "[%(asctime)s] [%(levelname)s] [%(name)s] [session_id=%(session_id)s case_id=%(case_id)s] %(message)s",
                "%Y-%m-%d %H:%M:%S",
            )
            stdout_handler.setFormatter(formatter)
            stderr_handler.setFormatter(formatter)
            logging.basicConfig(
                level=logging.INFO,
                handlers=[stdout_handler, stderr_handler, self.azure_handler],
                force=True
            )
            # Suppress all noisy loggers
            noisy_loggers = [
                "azure", "azure.monitor", "azure.monitor.opentelemetry.exporter",
                "azure.core.pipeline.policies.http_logging_policy", "opentelemetry",
                "urllib3", "uvicorn", "uvicorn.error", "uvicorn.access", "fastapi",
                "asyncio", "semantic_kernel.kernel_function_log_messages",
                "semantic_kernel.function_call_logger", "semantic_kernel.kernel","semantic_kernel.functions.kernel_function","httpx","semantic_kernel.connectors.ai.open_ai.services.open_ai_handler","mcp.client.streamable_http","semantic_kernel.contents.chat_history"
            ]
            for nl in noisy_loggers:
                logging.getLogger(nl).setLevel(logging.CRITICAL)
                logging.getLogger(nl).disabled = True
            AppLogger._configured = True

        base_logger = logging.getLogger(name)
        context = {
            "session_id": session_id if session_id else "N/A",
            "case_id": case_id if case_id else "N/A"
        }
        self.adapter = ContextLoggerAdapter(base_logger, context)
        return self.adapter

# Singleton instance for application-wide logger
project_logger = None

def init_logger(name: str, session_id=None, case_id=None) -> logging.LoggerAdapter:
    global project_logger
    project_logger = AppLogger()
    return project_logger.make_logger(name, session_id=session_id, case_id=case_id)