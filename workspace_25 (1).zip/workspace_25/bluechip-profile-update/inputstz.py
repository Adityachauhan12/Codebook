import re

# Allowed characters: a-z, A-Z, 0-9, dot, at, hyphen, _
pattern = re.compile(r'^[a-zA-Z0-9_\s.,&:@+\-\/\'"()]*$')

def is_valid_value(value):
    if isinstance(value, str):
        # Check if the whole string matches allowed characters
        return bool(pattern.match(value))
    elif isinstance(value, dict):
        return all(is_valid_value(v) for v in value.values())
    elif isinstance(value, list):
        return all(is_valid_value(v) for v in value)
    elif isinstance(value, (bool, int, float)) or value is None:
        # Non-string primitives are always valid
        return True
    else:
        # Any other type is invalid
        return False
