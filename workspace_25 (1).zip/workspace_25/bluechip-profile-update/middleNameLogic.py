def is_middle_name_addition(name1: str, name2: str) -> bool:
    # Split into parts
    parts1 = name1.strip().split()
    parts2 = name2.strip().split()
    
    # Must have at least first and last names
    if len(parts1) < 2 or len(parts2) < 2:
        return False
    
    # First and last names must match exactly
    if parts1[0] != parts2[0] or parts1[-1] != parts2[-1]:
        return False
    
    # Extract middle names
    middle1 = parts1[1:-1]
    middle2 = parts2[1:-1]
    
    # Identify shorter and longer middle sections
    if len(middle1) <= len(middle2):
        short, long = middle1, middle2
    else:
        short, long = middle2, middle1
    
    # If the shorter middle is empty, it's always fine (addition allowed)
    if not short:
        return True
    
    # Check if shorter middle is subsequence of longer middle
    i = j = 0
    while i < len(short) and j < len(long):
        if short[i] == long[j]:
            i += 1
        j += 1
    
    return i == len(short)
