import asyncio
import json
import os
from typing import Any, Dict, Optional, Tuple
from dotenv import load_dotenv
from mcp import ClientSession
from mcp.client.streamable_http import streamablehttp_client
from base64 import b64decode
from Crypto.Cipher import AES
from Crypto.Util.Padding import unpad
from datetime import datetime
from applogger import init_logger

# ------------------ CONFIG ------------------
load_dotenv()
_log = init_logger("mcp_client")
DEFAULT_SERVER_URL = os.getenv("DEFAULT_SERVER_URL")
CIAM_DOB_EXTENSION = os.getenv("CIAM_DOB_EXTENSION")
CIAM_GENDER_EXTENSION = os.getenv("CIAM_GENDER_EXTENSION")
CIAM_USERTYPE_EXTENSION = os.getenv("CIAM_USERTYPE_EXTENSION")


# ------------------ HELPERS ------------------
def _coerce_to_json(part) -> Optional[Any]:
    """Convert a part object to JSON if possible."""
    t = getattr(part, "type", None) or getattr(part, "kind", None)
    if t == "json":
        return getattr(part, "data", None) or getattr(part, "json", None)
    if t == "text":
        txt = getattr(part, "text", "") or ""
        try:
            return json.loads(txt)
        except Exception:
            return None
    return None


from base64 import b64encode


def aes256_encrypt_json(data: dict) -> dict:
    """
    Encrypt a JSON dictionary using AES-256-GCM and return dict with base64 strings.
    """
    _log.debug("[aes256_encrypt_json] Encrypting payload keys=%s", list(data.keys()))
    key = b64decode(os.getenv("AES_KEY"))  # 32 bytes key for AES-256
    nonce = os.urandom(12)  # Recommended: 12 bytes for GCM

    json_str = json.dumps(data).encode("utf-8")

    cipher = AES.new(key, AES.MODE_GCM, nonce=nonce)
    ciphertext, tag = cipher.encrypt_and_digest(json_str)

    _log.debug("[aes256_encrypt_json] Encryption successful")
    return {
        "encrypted": b64encode(ciphertext).decode("utf-8"),
        "nonce": b64encode(nonce).decode("utf-8"),
        "tag": b64encode(tag).decode("utf-8"),
    }


def aes256_decrypt_json(encrypted_data: dict) -> dict:
    """
    Decrypt an AES-256-GCM encrypted dict and return the original JSON dictionary.
    """
    _log.debug("[aes256_decrypt_json] Starting decryption")
    key = b64decode(os.getenv("AES_KEY"))
    nonce = b64decode(encrypted_data["nonce"])
    tag = b64decode(encrypted_data["tag"])
    ciphertext = b64decode(encrypted_data["encrypted"])

    cipher = AES.new(key, AES.MODE_GCM, nonce=nonce)
    decrypted_json = cipher.decrypt_and_verify(ciphertext, tag)

    _log.debug("[aes256_decrypt_json] Decryption successful")
    return json.loads(decrypted_json.decode("utf-8"))


def read_tool_json(result) -> Optional[Any]:
    """Extract the first JSON object from a tool result."""
    if not getattr(result, "content", None):
        return None
    for part in result.content:
        obj = _coerce_to_json(part)
        if obj is not None:
            return obj
    return None


def filter_ciam_user(ciam_json: Any) -> Optional[Dict[str, Any]]:
    """Reduce CIAM JSON to a minimal user profile dict."""
    if isinstance(ciam_json, dict) and "value" in ciam_json and ciam_json["value"]:
        user = ciam_json["value"][0]
        return {
            "full_name": user.get("displayName"),
            "first_name": user.get("givenName"),
            "last_name": user.get("surname"),
            "mobile": user.get("mobilePhone"),
            "dob": user.get(CIAM_DOB_EXTENSION),
            "email": user.get("mail"),
            "gender": user.get(CIAM_GENDER_EXTENSION),
            "userid": user.get("id"),
        }
    if isinstance(ciam_json, dict):
        return ciam_json
    return None


def build_ciam_payload(values: dict) -> dict:
    payload = {}
    fn = values.get("first_name")
    ln = values.get("last_name")
    dob = values.get("dob")
    gender = values.get("gender")
    mobile = values.get("mobile")

    if fn:
        payload["givenName"] = fn
    if ln:
        payload["surname"] = ln
    if fn or ln:
        parts = [p for p in [fn, ln] if p]
        payload["displayName"] = " ".join(parts)
    if mobile:
        payload["mobilePhone"] = mobile
    if dob:
        payload[CIAM_DOB_EXTENSION] = dob
    if gender:
        normalized_gender = gender.strip().capitalize()
        if normalized_gender in {"Male", "Female"}:
            payload[CIAM_GENDER_EXTENSION] = normalized_gender
    return payload


def build_navitaire_payload(values: dict) -> dict:
    payload = {}
    name = {}
    details = {}
    fn = values.get("first_name")
    mn = ""
    ln = values.get("last_name")
    g = values.get("gender")
    dob = values.get("dob")

    if fn:
        name["FirstName"] = fn
    if mn:
        name["middle"] = ""
    if ln:
        name["LastName"] = ln
    if g:
        name["title"] = "MR" if g.lower().startswith("m") else "MS"
        details["gender"] = 1 if g.lower().startswith("m") else 2
    if dob:
        details["dateOfBirth"] = dob
    if name:
        payload["name"] = name
    if details:
        payload["details"] = details
    return payload


def build_capillary_payload(values: dict, uid: str) -> dict:
    payload = {}
    profiles = {}
    extended = {}
    fn = values.get("first_name")
    ln = values.get("last_name")
    g = values.get("gender")
    dob = values.get("dob")

    if fn:
        profiles["firstName"] = fn
    if ln:
        profiles["lastName"] = ln
    if g:
        profiles["gender"] = g
    if dob:
        profiles["dob"] = dob

    profiles["Unique_identifier"] = str(uid)
    return profiles


# ------------------ MAIN FUNCTION ------------------


# ------------------ AUDIT CHECK ------------------
async def check_audit_status(
    server_url: str,
    session_id: str,
    case_id: str,
    identifier_name: str,
    identifier_value: str,
) -> dict:
    """
    Connects to MCP server and calls 'check_audit_eligibility'.
    Returns decrypted dict: {"status": "clean"|"partial_block", "blocked_fields": [...]}
    """
    _log.info(
        "[check_audit_status] START server_url=%s session_id=%s case_id=%s "
        "identifier_name=%s",
        server_url,
        session_id,
        case_id,
        identifier_name,
    )
    async with streamablehttp_client(server_url) as (read, write, _):
        async with ClientSession(read, write) as session:
            try:
                _log.debug("[check_audit_status] Initializing MCP session")
                await session.initialize()
                _log.debug(
                    "[check_audit_status] MCP session initialized, calling check_audit_eligibility"
                )

                res = await session.call_tool(
                    "check_audit_eligibility",
                    {
                        "session_id": session_id,
                        "case_id": case_id,
                        "identifier_name": identifier_name,
                        "identifier_value": identifier_value,
                    },
                )
                _log.debug("[check_audit_status] Tool call returned, parsing response")

                # Parse response using the exact pattern from fetch_profiles
                data = res.model_dump_json()
                data = json.loads(data)

                _log.debug(
                    "[check_audit_status] Raw content length=%s",
                    len(data.get("content", [])),
                )

                # The server tool returns the encrypted JSON string in the 'text' field
                nested_json = json.loads(data["content"][0]["text"])

                # If error occurred on server side before encryption
                if "error" in nested_json and "encrypted" not in nested_json:
                    _log.error(
                        "[check_audit_status] Server-side error before encryption: %s",
                        nested_json["error"],
                    )
                    return {"error": nested_json["error"], "blocked_fields": ["ALL"]}

                # Decrypt
                _log.debug("[check_audit_status] Decrypting server response")
                decrypted = aes256_decrypt_json(nested_json)
                _log.info(
                    "[check_audit_status] SUCCESS status=%s blocked_fields=%s",
                    decrypted.get("status"),
                    decrypted.get("blocked_fields"),
                )
                return decrypted

            except Exception as e:
                # Fail-safe: If API/connection fails, we return an error state
                # The calling function in main.py should handle this (likely fallback to manual)
                _log.error(
                    "[check_audit_status] EXCEPTION server_url=%s error=%s",
                    server_url,
                    str(e),
                    exc_info=True,
                )
                return {"error": str(e), "blocked_fields": ["ALL"]}


async def fetch_profiles(
    server_url: str,
    *,
    session_id,
    case_id,
    user_contact_navitaire: Optional[str] = None,
    user_contact_ciam: Optional[str] = None,
    user_contact_capillary: Optional[str] = None,
) -> Tuple[
    Optional[Dict[str, Any]], Optional[Dict[str, Any]], Optional[Dict[str, Any]]
]:
    """
    Connect to MCP server and return:
    (navitaire_profile, ciam_profile, capillary_profile)
    """
    _log.info(
        "[fetch_profiles] START server_url=%s session_id=%s case_id=%s "
        "nav_contact=%s ciam_contact=%s cap_contact=%s",
        server_url,
        session_id,
        case_id,
        bool(user_contact_navitaire),
        bool(user_contact_ciam),
        bool(user_contact_capillary),
    )

    async with streamablehttp_client(server_url) as (read, write, _):
        async with ClientSession(read, write) as session:
            try:
                _log.debug("[fetch_profiles] Initializing MCP session")
                await session.initialize()
                _log.debug("[fetch_profiles] MCP session initialized")
            except Exception as e:
                _log.error(
                    "[fetch_profiles] Failed to initialize MCP session: %s",
                    str(e),
                    exc_info=True,
                )

                return None, None, None

            # # --- NAVITAIRE ---
            async def get_navitaire():
                navitaire_profile = None
                stnav = datetime.now()
                try:
                    if user_contact_navitaire:
                        is_email = "@" in user_contact_navitaire
                        _log.debug(
                            "[fetch_profiles][get_navitaire] Calling get_user_profile "
                            "contact_type=%s",
                            "email" if is_email else "phone",
                        )
                        res_nav = await session.call_tool(
                            "get_user_profile",
                            (
                                {
                                    "session_id": session_id,
                                    "case_id": case_id,
                                    "email": user_contact_navitaire,
                                }
                                if is_email
                                else {
                                    "session_id": session_id,
                                    "case_id": case_id,
                                    "phone_number": user_contact_navitaire,
                                }
                            ),
                        )
                        data = res_nav.model_dump_json()
                        data = json.loads(data)
                        _log.debug(
                            "[fetch_profiles][get_navitaire] Raw response content_count=%s",
                            len(data.get("content", [])),
                        )
                        nested_json = json.loads(data["content"][0]["text"])
                        if "encrypted" not in nested_json:
                            _log.warning(
                                "[fetch_profiles][get_navitaire] Unexpected response (no encrypted key): %s",
                                nested_json,
                            )
                            return {"error": f"navitaire_bad_response: {nested_json}"}
                        new_data = {
                            "encrypted": nested_json["encrypted"],
                            "nonce": nested_json["nonce"],
                            "tag": nested_json["tag"],
                        }
                        decrypted = aes256_decrypt_json(new_data)
                        ennav = datetime.now()
                        _log.info(
                            "[fetch_profiles][get_navitaire] SUCCESS elapsed=%.3fs "
                            "has_data=%s",
                            (ennav - stnav).total_seconds(),
                            bool(decrypted),
                        )
                        return decrypted
                    else:
                        _log.debug(
                            "[fetch_profiles][get_navitaire] Skipped — no contact provided"
                        )
                except Exception as e:
                    _log.error(
                        "[fetch_profiles][get_navitaire] EXCEPTION error=%s",
                        str(e),
                        exc_info=True,
                    )
                    return {"error": f"navitaire_exception: {type(e).__name__}: {e}"}

            # --- CIAM ---
            async def get_ciam():
                stciam = datetime.now()
                ciam_profile = None
                try:
                    if user_contact_ciam:
                        _log.debug(
                            "[fetch_profiles][get_ciam] Calling get_user_ciam "
                            "customer_id=%s",
                            user_contact_ciam,
                        )
                        res_ciam = await session.call_tool(
                            "get_user_ciam",
                            {
                                "session_id": session_id,
                                "case_id": case_id,
                                "customer_id": user_contact_ciam,
                            },
                        )
                        data = res_ciam.model_dump_json()
                        data = json.loads(data)
                        _log.debug(
                            "[fetch_profiles][get_ciam] Raw response content_count=%s",
                            len(data.get("content", [])),
                        )
                        nested_json = json.loads(data["content"][0]["text"])
                        if "encrypted" not in nested_json:
                            _log.warning(
                                "[fetch_profiles][get_ciam] Unexpected response (no encrypted key): %s",
                                nested_json,
                            )
                            return {"error": f"ciam_bad_response: {nested_json}"}
                        new_data = {
                            "encrypted": nested_json["encrypted"],
                            "nonce": nested_json["nonce"],
                            "tag": nested_json["tag"],
                        }
                        decrypted = aes256_decrypt_json(new_data)
                        ciam_profile = filter_ciam_user(
                            decrypted
                        )  # if ciam_json else None
                        enciam = datetime.now()
                        _log.info(
                            "[fetch_profiles][get_ciam] SUCCESS elapsed=%.3fs "
                            "has_profile=%s",
                            (enciam - stciam).total_seconds(),
                            bool(ciam_profile),
                        )
                        return ciam_profile
                    else:
                        _log.debug(
                            "[fetch_profiles][get_ciam] Skipped — no contact provided"
                        )
                except Exception as e:
                    _log.error(
                        "[fetch_profiles][get_ciam] EXCEPTION error=%s",
                        str(e),
                        exc_info=True,
                    )
                    return {"error": f"ciam_exception: {type(e).__name__}: {e}"}

            ## --- CAPILLARY ---
            async def get_capillary():
                capillary_profile = None
                stcap = datetime.now()
                try:
                    if user_contact_capillary:
                        _log.debug(
                            "[fetch_profiles][get_capillary] Calling fetch_customer_details_capillary "
                            "customer_id=%s",
                            user_contact_capillary,
                        )
                        res_cap = await session.call_tool(
                            "fetch_customer_details_capillary",
                            {
                                "customer_id": user_contact_capillary,
                                "session_id": session_id,
                                "case_id": case_id,
                            },
                        )
                        data = res_cap.model_dump_json()
                        data = json.loads(data)
                        _log.debug(
                            "[fetch_profiles][get_capillary] Raw response content_count=%s",
                            len(data.get("content", [])),
                        )
                        nested_json = json.loads(data["content"][0]["text"])
                        if "encrypted" not in nested_json:
                            _log.warning(
                                "[fetch_profiles][get_capillary] Unexpected response (no encrypted key): %s",
                                nested_json,
                            )
                            return {"error": f"capillary_bad_response: {nested_json}"}
                        new_data = {
                            "encrypted": nested_json["encrypted"],
                            "nonce": nested_json["nonce"],
                            "tag": nested_json["tag"],
                        }
                        decrypted = aes256_decrypt_json(new_data)
                        encap = datetime.now()
                        _log.info(
                            "[fetch_profiles][get_capillary] SUCCESS elapsed=%.3fs "
                            "has_data=%s",
                            (encap - stcap).total_seconds(),
                            bool(decrypted),
                        )
                        return decrypted
                    else:
                        _log.debug(
                            "[fetch_profiles][get_capillary] Skipped — no contact provided"
                        )
                except Exception as e:
                    _log.error(
                        "[fetch_profiles][get_capillary] EXCEPTION error=%s",
                        str(e),
                        exc_info=True,
                    )
                    return {"error": f"capillary_exception: {type(e).__name__}: {e}"}

            _log.debug("[fetch_profiles] Launching parallel gather for all 3 systems")
            navitaire_profile, ciam_profile, capillary_profile = await asyncio.gather(
                get_navitaire(), get_ciam(), get_capillary()
            )
            _log.info(
                "[fetch_profiles] DONE navitaire=%s ciam=%s capillary=%s",
                bool(navitaire_profile),
                bool(ciam_profile),
                bool(capillary_profile),
            )
            return navitaire_profile, ciam_profile, capillary_profile


async def update_profiles_client(
    server_url: str,
    *,
    session_id,
    case_id,
    systems: list[bool],
    ids: dict,
    values: dict,
) -> dict:
    _log.info(
        "[update_profiles_client] START session_id=%s case_id=%s "
        "systems=%s ids_keys=%s values_keys=%s",
        session_id,
        case_id,
        systems,
        list(ids.keys()),
        list(values.keys()),
    )
    results = {}

    async with streamablehttp_client(server_url) as (read, write, _):
        async with ClientSession(read, write) as session:
            _log.debug("[update_profiles_client] Initializing MCP session")
            await session.initialize()
            _log.debug("[update_profiles_client] MCP session initialized")

            # ---------------- CIAM ----------------
            if systems[0] and ids.get("ciam_user_id"):
                _log.debug(
                    "[update_profiles_client][CIAM] Building payload for user_id=%s",
                    ids.get("ciam_user_id"),
                )
                ciam_payload = build_ciam_payload(values)
                _log.debug(
                    "[update_profiles_client][CIAM] payload_keys=%s",
                    list(ciam_payload.keys()) if ciam_payload else None,
                )
                if ciam_payload:
                    # Encrypt the dict payload directly
                    encrypted_payload_ciam = aes256_encrypt_json(ciam_payload)
                    _log.debug(
                        "[update_profiles_client][CIAM] Calling update_user_by_id"
                    )

                    res_ciam = await session.call_tool(
                        "update_user_by_id",
                        {
                            "user_id": ids["ciam_user_id"],
                            "update_payload": encrypted_payload_ciam,
                            "session_id": session_id,
                            "case_id": case_id,
                        },
                    )
                    results["ciam"] = read_tool_json(res_ciam)
                    _log.info(
                        "[update_profiles_client][CIAM] result=%s",
                        results["ciam"],
                    )

                else:
                    _log.warning(
                        "[update_profiles_client][CIAM] Empty payload — skipping update "
                        "for user_id=%s",
                        ids.get("ciam_user_id"),
                    )
                    results["ciam"] = "error in navitaire execution"

            elif systems[0]:
                _log.warning(
                    "[update_profiles_client][CIAM] systems[0]=True but ciam_user_id missing from ids"
                )

                # ---------------- Navitaire ----------------
            if systems[1] and ids.get("nav_person_key"):
                _log.debug(
                    "[update_profiles_client][Navitaire] Building payload for person_key=%s",
                    ids.get("nav_person_key"),
                )
                nav_payload = build_navitaire_payload(values)
                _log.debug(
                    "[update_profiles_client][Navitaire] payload_keys=%s",
                    list(nav_payload.keys()) if nav_payload else None,
                )
                if nav_payload:
                    # Build the raw payload for Navitaire update
                    navitaire_update_payload = {
                        "person_key": ids["nav_person_key"],
                        "first_name": nav_payload.get("name", {}).get("FirstName"),
                        "middle_name": "",
                        "last_name": nav_payload.get("name", {}).get("LastName"),
                        "gender": values.get("gender"),
                        "dob": values.get("dob"),
                    }
                    encrypted_payload = aes256_encrypt_json(navitaire_update_payload)
                    _log.debug(
                        "[update_profiles_client][Navitaire] Calling update_user_profile"
                    )
                    res_nav = await session.call_tool(
                        "update_user_profile",
                        {
                            "encrypted_payload": encrypted_payload,
                            "session_id": session_id,
                            "case_id": case_id,
                        },
                    )
                    results["navitaire"] = read_tool_json(res_nav)
                    _log.info(
                        "[update_profiles_client][Navitaire] result=%s",
                        results["navitaire"],
                    )

                else:
                    _log.warning(
                        "[update_profiles_client][Navitaire] Empty payload — skipping update "
                        "for person_key=%s",
                        ids.get("nav_person_key"),
                    )
                    results["navitaire"] = "error in navitaire execution"

            elif systems[1]:
                _log.warning(
                    "[update_profiles_client][Navitaire] systems[1]=True but nav_person_key missing from ids"
                )

            # ---------------- Capillary ----------------
            if systems[2] and ids.get("cap_unique_identifier"):
                _log.debug(
                    "[update_profiles_client][Capillary] Building payload for uid=%s",
                    ids.get("cap_unique_identifier"),
                )
                cap_payload = build_capillary_payload(
                    values, ids["cap_unique_identifier"]
                )
                _log.debug(
                    "[update_profiles_client][Capillary] payload_keys=%s",
                    list(cap_payload.keys()) if cap_payload else None,
                )
                if cap_payload:
                    # Encrypt the dict payload directly
                    encrypted_payload_cap = aes256_encrypt_json(cap_payload)
                    _log.debug(
                        "[update_profiles_client][Capillary] Calling update_capillary"
                    )

                    res_cap = await session.call_tool(
                        "update_capillary",
                        {
                            "details": encrypted_payload_cap,
                            "session_id": session_id,
                            "case_id": case_id,
                        },
                    )
                    results["capillary"] = read_tool_json(res_cap)
                    _log.info(
                        "[update_profiles_client][Capillary] result=%s",
                        results["capillary"],
                    )
                else:
                    _log.warning(
                        "[update_profiles_client][Capillary] Empty payload — skipping update "
                        "for uid=%s",
                        ids.get("cap_unique_identifier"),
                    )
                    results["capillary"] = (
                        "could not perform update on capillary retry manually"
                    )

            elif systems[2]:
                _log.warning(
                    "[update_profiles_client][Capillary] systems[2]=True but cap_unique_identifier missing from ids"
                )

    _log.info("[update_profiles_client] DONE results_keys=%s", list(results.keys()))
    return results


async def fetch_govt_id_via_mcp(
    server_url: str,
    session_id: str,
    case_id: str,
    case_rec_id: str,
) -> dict:
    """
    Connect to MCP server and call get_salesforce_govt_id tool.
    Returns the decrypted govt ID response dict, or
    {"Error_Response": "Error occured in Govt ID Fetch"} on failure.
    """
    _log.info(
        "[fetch_govt_id_via_mcp] START server_url=%s session_id=%s case_id=%s case_rec_id_provided=%s",
        server_url,
        session_id,
        case_id,
        bool(case_rec_id),
    )
    async with streamablehttp_client(server_url) as (read, write, _):
        async with ClientSession(read, write) as session:
            try:
                _log.debug("[fetch_govt_id_via_mcp] Initializing MCP session")
                await session.initialize()
                _log.debug(
                    "[fetch_govt_id_via_mcp] MCP session initialized, calling get_salesforce_govt_id"
                )

                res = await session.call_tool(
                    "get_salesforce_govt_id",
                    {
                        "session_id": session_id,
                        "case_id": case_id,
                        "case_rec_id": case_rec_id,
                    },
                )

                data = res.model_dump_json()
                data = json.loads(data)
                _log.debug(
                    "[fetch_govt_id_via_mcp] Raw content length=%s",
                    len(data.get("content", [])),
                )
                nested_json = json.loads(data["content"][0]["text"])

                # Server returned an unencrypted error (e.g. token failure before encrypt)
                if "Error_Response" in nested_json or "encrypted" not in nested_json:
                    _log.error(
                        "[fetch_govt_id_via_mcp] Server-side error before encryption: %s",
                        nested_json,
                    )
                    return {"Error_Response": "Error occured in Govt ID Fetch"}

                decrypted = aes256_decrypt_json(nested_json)
                _log.info("[fetch_govt_id_via_mcp] SUCCESS")
                return decrypted

            except Exception as e:
                _log.error(
                    "[fetch_govt_id_via_mcp] EXCEPTION error=%s",
                    str(e),
                    exc_info=True,
                )
                return {"Error_Response": "Error occured in Govt ID Fetch"}
