from mcp_client import fetch_profiles
import asyncio


async def fetch_profiles_with_retry(
    server_url, s_id, c_id, user_contact, log, retries=2
):
    """
    Fetches profiles from all 3 databases with retry logic.
    Returns: (navitaire, ciam, capillary, error_message)
    """
    final_nav = None
    final_ciam = None
    final_cap = None
    last_error = None
    for attempt in range(1, retries + 1):
        try:
            log.info(f"Database Fetch Attempt {attempt}/{retries}...")

            # Fetch from ALL 3 systems at once
            nav, ciam, cap = await asyncio.wait_for(
                fetch_profiles(
                    server_url,
                    session_id=s_id,
                    case_id=c_id,
                    user_contact_navitaire=user_contact,  # Pass contact to all
                    user_contact_ciam=user_contact,
                    user_contact_capillary=user_contact,
                ),
                timeout=35,
            )

            # 2. ACCUMULATOR: Update if our saved variable is empty ({}, None) or has a hard error
            if not final_cap or (
                isinstance(final_cap, dict) and final_cap.get("error")
            ):
                final_cap = cap

            if not final_nav or (
                isinstance(final_nav, dict) and final_nav.get("error")
            ):
                final_nav = nav

            if not final_ciam or (
                isinstance(final_ciam, dict) and final_ciam.get("error")
            ):
                final_ciam = ciam

            # 3. CHECK FOR COMPLETION: Now ALL THREE strictly check for missing data ({})
            cap_failed = not final_cap or (
                isinstance(final_cap, dict) and final_cap.get("error")
            )
            nav_failed = not final_nav or (
                isinstance(final_nav, dict) and final_nav.get("error")
            )
            ciam_failed = not final_ciam or (
                isinstance(final_ciam, dict) and final_ciam.get("error")
            )

            # Build per-system detail for logs so failures are traceable
            def _fail_reason(result, label: str) -> str:
                if not result:
                    return f"{label}=empty(no data returned)"
                if isinstance(result, dict) and result.get("error"):
                    return f"{label}=error:{result['error']}"
                return f"{label}=ok"

            # If all three have valid data, we are DONE!
            if not cap_failed and not nav_failed and not ciam_failed:
                log.info(
                    f"All required databases fetched successfully on attempt {attempt}."
                )
                return final_nav, final_ciam, final_cap, None

            # If we reach here, at least one is still {}, None, or an error
            nav_detail = _fail_reason(final_nav, "navitaire")
            ciam_detail = _fail_reason(final_ciam, "ciam")
            cap_detail = _fail_reason(final_cap, "capillary")
            raise ValueError(
                f"Partial fetch — {nav_detail} | {ciam_detail} | {cap_detail}"
            )

        except Exception as e:
            last_error = str(e)
            log.warning(f"DB Fetch Attempt {attempt} failed: {e}")
            if attempt < retries:
                await asyncio.sleep(1)  # Short backoff before retry

    return final_nav, final_ciam, final_cap, last_error  # All retries failed
