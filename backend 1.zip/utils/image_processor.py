"""
Image Processing Utilities
Handles image loading, resizing, format conversion, and encoding
"""

import os
from PIL import Image
import io
import base64
from typing import List, Tuple, Optional


# Aspect ratios supported by the Gemini image generation API
GEMINI_ASPECT_RATIOS = [
    "1:1", "2:3", "3:4", "4:5", "9:16",
    "3:2", "4:3", "5:4", "16:9", "21:9",
]

# Precomputed (label, float_value) pairs — avoids re-parsing strings on every call
_GEMINI_RATIO_VALUES: List[Tuple[str, float]] = [
    (ar, int(ar.split(":")[0]) / int(ar.split(":")[1]))
    for ar in GEMINI_ASPECT_RATIOS
]


def find_nearest_aspect_ratio(width: int, height: int) -> str:
    """
    Return the Gemini-supported aspect ratio whose ratio (A/B) is closest
    to width/height.  Comparison is done on the precomputed numeric ratio value.
    """
    target = width / height
    return min(_GEMINI_RATIO_VALUES, key=lambda x: abs(target - x[1]))[0]


def resize_to_exact(image: Image.Image, width: int, height: int) -> Image.Image:
    """Resize a PIL image to exact pixel dimensions (no padding, no aspect lock)."""
    return image.resize((width, height), Image.Resampling.LANCZOS)


class ImageProcessor:
    """Utility class for image processing"""

    # Standard sizes for different platforms
    PLATFORM_SIZES = {
        "whatsapp": (1200, 1200),      # Square format
        "email": (1200, 400),           # Header image
        "instagram": (1080, 1080),      # Square format
    }
    
    SUPPORTED_FORMATS = ["png", "jpg", "jpeg", "webp"]
    MAX_IMAGE_SIZE_MB = 5
    
    @staticmethod
    def load_image(image_path: str) -> Optional[Image.Image]:
        """Load image from file path"""
        try:
            if not os.path.exists(image_path):
                print(f"Error: Image not found at {image_path}")
                return None
            
            img = Image.open(image_path)
            return img
        except Exception as e:
            print(f"Error loading image: {e}")
            return None
    
    @staticmethod
    def resize_image(image: Image.Image, size: Tuple[int, int], maintain_aspect: bool = True) -> Image.Image:
        """
        Resize image to specified dimensions
        
        Args:
            image: PIL Image object
            size: Target size (width, height)
            maintain_aspect: If True, maintains aspect ratio with padding
        """
        try:
            if maintain_aspect:
                # Calculate aspect ratio and resize with padding
                image.thumbnail(size, Image.Resampling.LANCZOS)
                # Create new image with target size and white background
                final_image = Image.new('RGB', size, color='white')
                offset = ((size[0] - image.width) // 2, (size[1] - image.height) // 2)
                final_image.paste(image, offset)
                return final_image
            else:
                # Direct resize without maintaining aspect ratio
                return image.resize(size, Image.Resampling.LANCZOS)
        except Exception as e:
            print(f"Error resizing image: {e}")
            return image
    
    @staticmethod
    def convert_to_format(image: Image.Image, format: str = "png") -> Image.Image:
        """Convert image to specified format"""
        try:
            if format.lower() in ["jpg", "jpeg"]:
                # Convert RGBA to RGB for JPEG
                if image.mode in ["RGBA", "LA", "P"]:
                    rgb_image = Image.new("RGB", image.size, (255, 255, 255))
                    rgb_image.paste(image, mask=image.split()[-1] if image.mode in ["RGBA", "LA"] else None)
                    return rgb_image
            return image
        except Exception as e:
            print(f"Error converting image format: {e}")
            return image
    
    @staticmethod
    def encode_image_to_base64(image: Image.Image, format: str = "png") -> str:
        """Encode PIL image to base64 string"""
        try:
            buffer = io.BytesIO()
            format_upper = format.upper() if format.lower() != "jpg" else "JPEG"
            image.save(buffer, format=format_upper)
            buffer.seek(0)
            b64_string = base64.standard_b64encode(buffer.getvalue()).decode("utf-8")
            return b64_string
        except Exception as e:
            print(f"Error encoding image: {e}")
            return ""
    
    @staticmethod
    def load_and_prepare_images(image_paths: List[str], platform: str = "instagram") -> List[str]:
        """
        Load multiple images, resize, and encode to base64
        Returns list of base64 encoded images (max 14 for API limits)
        """
        encoded_images = []
        max_images = 14  # API limit
        
        if not image_paths:
            return encoded_images
        
        target_size = ImageProcessor.PLATFORM_SIZES.get(platform, (1080, 1080))
        
        for image_path in image_paths[:max_images]:
            try:
                img = ImageProcessor.load_image(image_path)
                if img:
                    # Resize to platform specifications
                    resized_img = ImageProcessor.resize_image(img, target_size, maintain_aspect=True)
                    # Convert to appropriate format
                    converted_img = ImageProcessor.convert_to_format(resized_img, "png")
                    # Encode to base64
                    b64 = ImageProcessor.encode_image_to_base64(converted_img, "png")
                    if b64:
                        encoded_images.append(b64)
            except Exception as e:
                print(f"Error processing image {image_path}: {e}")
                continue
        
        return encoded_images
    
    @staticmethod
    def get_images_from_directory(directory_path: str, limit: int = 5) -> List[str]:
        """Get all images from a directory"""
        image_paths = []

        if not os.path.isdir(directory_path):
            print(f"Error: Directory not found {directory_path}")
            return image_paths

        try:
            for file in sorted(os.listdir(directory_path)):
                if any(file.lower().endswith(fmt) for fmt in ImageProcessor.SUPPORTED_FORMATS):
                    full_path = os.path.join(directory_path, file)
                    image_paths.append(full_path)
            if len(image_paths) > limit:
                print(f"Count exceeded! only picking top {limit} images in directory")
                return image_paths[:limit]
        except Exception as e:
            print(f"Error reading directory: {e}")
        
        return image_paths
    
    @staticmethod
    def save_generated_image(image_bytes: bytes, output_path: str, filename: str) -> str:
        """Save generated image bytes to file"""
        try:
            os.makedirs(output_path, exist_ok=True)
            full_path = os.path.join(output_path, filename)
            
            # Save from bytes
            img = Image.open(io.BytesIO(image_bytes))
            img.save(full_path)
            
            return full_path
        except Exception as e:
            print(f"Error saving image: {e}")
            return ""
