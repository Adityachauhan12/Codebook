"""
Shared rate-limiter instance used by main.py and all APIRouters.

Key function: Azure AD OID from the Bearer JWT, falling back to remote IP.

Also exports require_generation_rate_limit — a FastAPI Depends() that enforces
4 requests/minute per user on generation endpoints. Uses the limits library
directly (instead of @limiter.limit decorators) so it works reliably for both
sync def and async def route handlers.
"""

import logging
import time

import jwt as _pyjwt
from fastapi import HTTPException
from slowapi import Limiter
from slowapi.util import get_remote_address
from starlette.requests import Request

from db.connection import get_db


logger = logging.getLogger(__name__)


def _get_rate_limit_key(request: Request) -> str:
    """Use the Azure AD OID from the Bearer JWT as the rate-limit bucket key.
    Falls back to remote IP for public/unauthenticated endpoints."""
    auth_header = request.headers.get("Authorization", "")
    if auth_header.startswith("Bearer "):
        try:
            claims = _pyjwt.decode(
                auth_header[7:],
                options={"verify_signature": False},
            )
            oid = claims.get("oid")
            if oid:
                return f"user:{oid}"
        except Exception:
            pass
    return get_remote_address(request)


limiter = Limiter(key_func=_get_rate_limit_key, default_limits=["20/minute"])


_GEN_LIMIT = 4


def increment_generation_rate_limit(bucket_key: str) -> int:
    """Atomically increment and return the current fixed-window counter."""
    window_start = int(time.time() // 60)

    with get_db() as conn:
        with conn.cursor() as cur:
            cur.execute(
                """
                INSERT INTO rate_limit_counters (bucket_key, window_start, count)
                VALUES (%s, %s, 1)
                ON CONFLICT (bucket_key, window_start)
                DO UPDATE SET count = rate_limit_counters.count + 1
                RETURNING count
                """,
                (bucket_key, window_start),
            )
            current_count = int(cur.fetchone()[0])
        conn.commit()

    return current_count


def require_generation_rate_limit(request: Request) -> None:
    """FastAPI Depends() enforcing 4 generation requests/minute per user (OID or IP)."""
    if getattr(request.state, "generation_rate_limited", False):
        return

    bucket_key = _get_rate_limit_key(request)
    retry_after = max(1, 60 - (int(time.time()) % 60))

    try:
        current_count = increment_generation_rate_limit(bucket_key)

        if current_count > _GEN_LIMIT:
            raise HTTPException(
                status_code=429,
                detail=f"Rate limit exceeded: {_GEN_LIMIT} per 1 minute",
                headers={"Retry-After": str(retry_after)},
            )
    except HTTPException:
        raise
    except Exception:
        logger.warning(
            "Rate limit check failed closed for bucket=%s path=%s",
            bucket_key,
            request.url.path,
            exc_info=True,
        )
        raise HTTPException(
            status_code=429,
            detail="Rate limit check unavailable",
        )
