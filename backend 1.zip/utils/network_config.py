"""
Network configuration helpers.
"""

import os
import certifi
import httpx


_PROXY_ENV_VARS = [
    "HTTP_PROXY",
    "HTTPS_PROXY",
    "ALL_PROXY",
    "http_proxy",
    "https_proxy",
    "all_proxy",
]

_BROKEN_PROXY_VALUES = {
    "http://127.0.0.1:9",
    "https://127.0.0.1:9",
    "http://localhost:9",
    "https://localhost:9",
}


def clear_invalid_local_proxies() -> None:
    """Remove known-bad local proxy settings that break outbound SDK calls."""
    for env_var in _PROXY_ENV_VARS:
        value = os.getenv(env_var)
        if value and value.strip().lower() in _BROKEN_PROXY_VALUES:
            os.environ.pop(env_var, None)


def _httpx_verify_enabled() -> bool:
    """Read HTTPX_VERIFY from the environment, defaulting to True."""
    value = os.getenv("HTTPX_VERIFY", "TRUE")
    return value.strip().lower() not in {"0", "false", "no", "off"}


def build_http_client(timeout: float = 60.0) -> httpx.Client:
    """Build an HTTP client using env-driven TLS verification and no inherited proxy env."""
    clear_invalid_local_proxies()
    return httpx.Client(
        verify=certifi.where() if _httpx_verify_enabled() else False,
        trust_env=False,
        timeout=timeout,
    )
