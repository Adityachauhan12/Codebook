import os
from azure.identity import ClientSecretCredential
from azure.storage.blob import BlobServiceClient
from dotenv import load_dotenv

load_dotenv()

# creatives: blob-level public read so image URLs work directly in the frontend/gallery
# references: private — only accessible by the backend via managed identity
CONTAINERS = [
    ("creatives"),
    ("references"),
]

try:
    account_name = os.getenv("AZURE_STORAGE_ACCOUNT_NAME")
    account_url = f"https://{account_name}.blob.core.windows.net"

    credential = ClientSecretCredential(
        tenant_id=os.getenv("AZURE_TENANT_ID",""),
        client_id=os.getenv("AZURE_CLIENT_ID",""),
        client_secret=os.getenv("AZURE_CLIENT_SECRET","")
    )
    client = BlobServiceClient(account_url=account_url, credential=credential)

    for name in CONTAINERS:
        container = client.get_container_client(name)
        if not container.exists():
            container.create_container()
            print(f"Container '{name}' created")
        else:
            print(f"Container '{name}' already exists — skipping")

except Exception as e:
    print(f"Error creating blob containers: {e}")
    raise
