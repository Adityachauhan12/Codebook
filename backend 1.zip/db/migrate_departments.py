"""
Department migration script.

Iterates every user row that is missing a department (or sub_department),
calls the SuccessFactors API to look up the values, and writes them back.

Run from the backend/ directory:
    python db/migrate_departments.py

Optional flags:
    --dry-run   Print what would be updated without writing to the DB.
    --overwrite Also refresh users that already have a department set.

Environment variables required (same as the main application):
    PGHOST, PGPORT, PGDATABASE, PGUSER, PGPASSWORD  (or Azure credential)
    SF_TOKEN_URL, SF_EMPLOYEE_URL, SF_USER_KEY, SF_CLIENT_ID, SF_CLIENT_SECRET
"""

import argparse
import logging
import os
import sys
import time

# Ensure the parent directory (backend/) is on sys.path so service imports work.
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from dotenv import load_dotenv

load_dotenv()

import psycopg2
import psycopg2.extras
from azure.identity import ClientSecretCredential

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s %(levelname)s %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S",
)
logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# DB connection (mirrors db/connection.py)
# ---------------------------------------------------------------------------

def _get_db_conn():
    credential = ClientSecretCredential(
        tenant_id=os.getenv("AZURE_TENANT_ID", ""),
        client_id=os.getenv("AZURE_CLIENT_ID", ""),
        client_secret=os.getenv("AZURE_CLIENT_SECRET", ""),
    )
    token = credential.get_token("https://token.postgres.cosmos.azure.com/.default").token
    return psycopg2.connect(
        host=os.getenv("PGHOST"),
        port=int(os.getenv("PGPORT", "5432")),
        dbname=os.getenv("PGDATABASE"),
        user=os.getenv("PGUSER"),
        password=token,
        sslmode="require",
    )


# ---------------------------------------------------------------------------
# Main migration
# ---------------------------------------------------------------------------

def run(dry_run: bool = False, overwrite: bool = False) -> None:
    from services.successfactors_service import get_employee_department

    conn = _get_db_conn()
    conn.autocommit = False
    cur = conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor)

    if overwrite:
        cur.execute("SELECT id, email, department, sub_department FROM users ORDER BY email")
    else:
        cur.execute(
            """
            SELECT id, email, department, sub_department FROM users
            WHERE department IS NULL OR sub_department IS NULL
            ORDER BY email
            """
        )

    users = cur.fetchall()
    total = len(users)
    logger.info("Found %d user(s) to process", total)

    updated = 0
    skipped = 0

    for i, user in enumerate(users, 1):
        user_id = user["id"]
        email = user["email"]
        existing_dept = user["department"]
        existing_sub = user["sub_department"]

        logger.info(
            "[%d/%d] %s  (dept=%r  sub=%r)",
            i, total, email, existing_dept, existing_sub,
        )

        dept, sub_dept = get_employee_department(email)

        if not dept and not sub_dept:
            logger.warning("  → SF returned no data — skipping")
            skipped += 1
            continue

        final_dept = dept if (overwrite or not existing_dept) else existing_dept
        final_sub = sub_dept if (overwrite or not existing_sub) else existing_sub

        logger.info("  → will set dept=%r  sub_department=%r", final_dept, final_sub)

        if not dry_run:
            cur.execute(
                "UPDATE users SET department = %s, sub_department = %s WHERE id = %s",
                (final_dept, final_sub, user_id),
            )
            # Propagate to existing creatives that have no department set yet.
            cur.execute(
                """
                UPDATE creatives
                SET department     = COALESCE(department, %s),
                    sub_department = COALESCE(sub_department, %s)
                WHERE user_id = %s
                """,
                (final_dept, final_sub, user_id),
            )
            conn.commit()
            updated += 1

        # Small delay to avoid hammering the SF API
        time.sleep(0.3)

    cur.close()
    conn.close()

    if dry_run:
        logger.info("DRY RUN — %d would be updated, %d skipped", total - skipped, skipped)
    else:
        logger.info("Done — updated %d, skipped %d", updated, skipped)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Backfill department/sub_department from SuccessFactors")
    parser.add_argument("--dry-run", action="store_true", help="Print changes without writing to DB")
    parser.add_argument("--overwrite", action="store_true", help="Refresh even users that already have a department")
    args = parser.parse_args()
    run(dry_run=args.dry_run, overwrite=args.overwrite)
