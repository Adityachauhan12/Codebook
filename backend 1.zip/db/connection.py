from contextlib import contextmanager
import os
import psycopg2
from azure.identity import ClientSecretCredential
from dotenv import load_dotenv

load_dotenv()

_credential = ClientSecretCredential(
    tenant_id=os.getenv("AZURE_TENANT_ID", ""),
    client_id=os.getenv("AZURE_CLIENT_ID", ""),
    client_secret=os.getenv("AZURE_CLIENT_SECRET", ""),
)


def _get_token() -> str:
    # Token is fetched fresh each call — DefaultAzureCredential caches and
    # auto-refreshes it, so this is safe to call on every connection.
    #token = _credential.get_token("https://ossrdbms-aad.database.windows.net/.default")
    token = _credential.get_token("https://token.postgres.cosmos.azure.com/.default")
    return token.token


def _connect() -> psycopg2.extensions.connection:
    return psycopg2.connect(
        host=os.getenv("PGHOST"),
        port=int(os.getenv("PGPORT", "5432")),
        dbname=os.getenv("PGDATABASE"),
        user=os.getenv("PGUSER"),
        password=_get_token(),
        sslmode="require",
    )


@contextmanager
def get_db():
    conn = _connect()
    try:
        yield conn
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()
