import os
import psycopg2
from azure.identity import ClientSecretCredential
from dotenv import load_dotenv

load_dotenv()

credential = ClientSecretCredential(
    tenant_id=os.getenv("AZURE_TENANT_ID", ""),
    client_id=os.getenv("AZURE_CLIENT_ID", ""),
    client_secret=os.getenv("AZURE_CLIENT_SECRET", ""),
)

sql = """
-- users.id IS the azure_oid (text primary key).
-- No separate azure_oid column; all downstream tables reference users(id) directly.
CREATE TABLE IF NOT EXISTS users (
    id          TEXT        PRIMARY KEY,
    email       TEXT        NOT NULL UNIQUE,
    name        TEXT        NOT NULL,
    department  TEXT,
    created_at  TIMESTAMPTZ DEFAULT NOW()
);

-- projects.user_id references users(id) which is the azure_oid.
CREATE TABLE IF NOT EXISTS projects (
    id          UUID        PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id    TEXT        NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    name        TEXT        NOT NULL,
    description TEXT,
    created_at  TIMESTAMPTZ DEFAULT NOW(),
    UNIQUE (user_id, name)
);

-- creatives link to a project (and through it to the owner).
-- user_id is a direct reference to users(id) for fast per-user queries.
-- project_id is NOT NULL: every creative must belong to a project.
CREATE TABLE IF NOT EXISTS creatives (
    id              UUID        PRIMARY KEY DEFAULT gen_random_uuid(),
    project_id      UUID        NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
    user_id         TEXT        NOT NULL REFERENCES users(id),
    text            TEXT,
    image_url       TEXT,
    department      TEXT,
    category        TEXT,
    metadata        JSONB,
    show_in_gallery         BOOLEAN     DEFAULT TRUE,
    user_email              TEXT,
    user_name               TEXT,
    text_input_tokens       INTEGER     DEFAULT 0,
    text_output_tokens      INTEGER     DEFAULT 0,
    image_input_tokens      INTEGER     DEFAULT 0,
    image_output_tokens     INTEGER     DEFAULT 0,
    created_at              TIMESTAMPTZ DEFAULT NOW()
);

-- Single-row config table for token cost constants (per million tokens, USD).
-- id = 1 is enforced by CHECK; the seed INSERT is idempotent.
CREATE TABLE IF NOT EXISTS config (
    id                          INTEGER     PRIMARY KEY CHECK (id = 1),
    text_input_tokens_cost      NUMERIC(10,2)   NOT NULL DEFAULT 2.00,
    text_output_tokens_cost     NUMERIC(10,2)   NOT NULL DEFAULT 8.00,
    image_input_tokens_cost     NUMERIC(10,2)   NOT NULL DEFAULT 2.00,
    image_output_tokens_cost    NUMERIC(10,2)   NOT NULL DEFAULT 120.00
);

INSERT INTO config (id) VALUES (1) ON CONFLICT DO NOTHING;

-- Idempotent migration: add updated_at to projects if it does not already exist.
ALTER TABLE projects ADD COLUMN IF NOT EXISTS updated_at TIMESTAMPTZ;

-- Idempotent migrations: sub_department columns.
ALTER TABLE users     ADD COLUMN IF NOT EXISTS sub_department TEXT;
ALTER TABLE creatives ADD COLUMN IF NOT EXISTS sub_department TEXT;

-- Idempotent migrations: gpt-image-2 pricing columns in config.
ALTER TABLE config ADD COLUMN IF NOT EXISTS text2_input_tokens_cost   NUMERIC(10,2) NOT NULL DEFAULT 5.00;
ALTER TABLE config ADD COLUMN IF NOT EXISTS image2_input_tokens_cost  NUMERIC(10,2) NOT NULL DEFAULT 8.00;
ALTER TABLE config ADD COLUMN IF NOT EXISTS image2_output_tokens_cost NUMERIC(10,2) NOT NULL DEFAULT 30.00;

-- Idempotent migration: track which image model produced each creative.
ALTER TABLE creatives ADD COLUMN IF NOT EXISTS model_category TEXT
    CHECK (model_category IN ('gemini-3-pro-image-preview', 'gpt-image-2'));

-- Feedback table: one row per (creative, user), upserted on re-submit.
CREATE TABLE IF NOT EXISTS creative_feedback (
    id           UUID        PRIMARY KEY DEFAULT gen_random_uuid(),
    creative_id  UUID        NOT NULL REFERENCES creatives(id) ON DELETE CASCADE,
    user_id      TEXT        NOT NULL REFERENCES users(id),
    reaction     TEXT        CHECK (reaction IN ('like', 'dislike')),
    comment      TEXT,
    created_at   TIMESTAMPTZ DEFAULT NOW(),
    UNIQUE (creative_id, user_id)
);

-- Token revocation: records bearer tokens that have been explicitly revoked
-- (i.e. the user logged out before the token's natural Azure AD expiry).
-- Rows are automatically purged by the background cleanup job once expires_at passes.
CREATE TABLE IF NOT EXISTS revoked_tokens (
    jti        TEXT        PRIMARY KEY,
    user_id    TEXT,
    revoked_at TIMESTAMPTZ DEFAULT NOW(),
    expires_at TIMESTAMPTZ NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_revoked_tokens_expires ON revoked_tokens (expires_at);

-- Fixed-window rate limiting counters shared across all workers/instances.
CREATE TABLE IF NOT EXISTS rate_limit_counters (
    bucket_key   TEXT        NOT NULL,
    window_start  BIGINT      NOT NULL,
    count         INTEGER     NOT NULL DEFAULT 1,
    PRIMARY KEY (bucket_key, window_start)
);
CREATE INDEX IF NOT EXISTS idx_rate_limit_counters_window_start ON rate_limit_counters (window_start);

-- Maker-Checker: approval history for Product & Marketplaces creatives.
-- Every state change is a new row; rows are never overwritten.
-- user_id is NULL on the initial pending row (no approver yet); populated when approver acts.
CREATE TABLE IF NOT EXISTS creative_approval_history (
    approval_request_id  UUID        PRIMARY KEY DEFAULT gen_random_uuid(),
    creative_id          UUID        NOT NULL REFERENCES creatives(id) ON DELETE CASCADE,
    user_id              TEXT        REFERENCES users(id),
    status               TEXT        NOT NULL CHECK (status IN ('pending', 'approved', 'rejected')),
    comment              TEXT,
    created_at           TIMESTAMPTZ DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_cah_creative_id ON creative_approval_history (creative_id);
CREATE INDEX IF NOT EXISTS idx_cah_status      ON creative_approval_history (status);
"""

try:
    token = credential.get_token(
        "https://token.postgres.cosmos.azure.com/.default"
    ).token

    conn = psycopg2.connect(
        host=os.getenv("PGHOST"),
        port=int(os.getenv("PGPORT", "5432")),
        dbname=os.getenv("PGDATABASE"),
        user=os.getenv("PGUSER"),
        password=token,
        sslmode="require",
    )
    conn.autocommit = True
    cur = conn.cursor()
    cur.execute(sql)
    print("Tables created successfully: users, projects, creatives, config, rate_limit_counters")
    cur.close()
    conn.close()
except Exception as e:
    print(f"Error: {e}")
    raise