"""
Example Script - Marketing API Usage
Demonstrates how to use the IndiGo Marketing Platform API
"""

import requests
import json
from pathlib import Path
import time

# API Base URL
API_BASE_URL = "http://localhost:8000/api/v1"

# Campaign configurations
CAMPAIGNS = {
    "summer_promo": {
        "instructions": "Create a promotional campaign for summer vacation packages with 30% discount on domestic flights and free meals",
        "platform": "whatsapp",
        "logo_path": "campaign_logo/indigo_air_delights_logo.png",
        "context_images_path": "campaign_images"
    },
    "business_class": {
        "instructions": "Launch new business class premium features including priority boarding, premium meals, and exclusive lounge access",
        "platform": "email",
        "logo_path": "campaign_logo/indigo_air_delights_logo.png",
        "context_images_path": "campaign_images"
    },
    "eco_initiative": {
        "instructions": "Promote IndiGo's sustainability initiatives and carbon-neutral aviation commitment with trendy, Gen-Z friendly content",
        "platform": "instagram",
        "logo_path": "campaign_logo/indigo_air_delights_logo.png",
        "context_images_path": "campaign_images"
    }
}


def test_text_generation():
    """Test text generation endpoints"""
    print("\n" + "="*70)
    print("TESTING TEXT GENERATION ENDPOINTS")
    print("="*70)
    
    platforms = {
        "whatsapp": f"{API_BASE_URL}/generate/whatsapp/text",
        "email": f"{API_BASE_URL}/generate/email/text",
        "instagram": f"{API_BASE_URL}/generate/instagram/text"
    }
    
    for platform, url in platforms.items():
        print(f"\n🔄 Testing {platform.upper()} text generation...")
        
        campaign = CAMPAIGNS.get(platform, CAMPAIGNS["summer_promo"])
        
        payload = {
            "instructions": campaign["instructions"],
            "campaign_name": f"{platform}_test"
        }
        
        try:
            response = requests.post(url, json=payload, timeout=60)
            
            if response.status_code == 200:
                result = response.json()
                print(f"✅ {platform.upper()} Text Generated Successfully!")
                print(f"   Campaign: {result.get('campaign_name')}")
                
                # Print platform-specific content
                if platform == "whatsapp":
                    data = result.get("data", {})
                    print(f"   Message: {data.get('message')}")
                    print(f"   CTA: {data.get('cta_button')}")
                
                elif platform == "email":
                    data = result.get("data", {})
                    print(f"   Subject: {data.get('subject_line')}")
                    print(f"   CTA: {data.get('cta_text')}")
                
                elif platform == "instagram":
                    data = result.get("data", {})
                    caption = data.get('caption', '')
                    print(f"   Caption: {caption[:100]}...")
                    print(f"   Hashtags: {', '.join(data.get('hashtags', [])[:3])}")
                
                # Save result to file
                output_file = f"test_results/{platform}_text.json"
                Path("test_results").mkdir(exist_ok=True)
                with open(output_file, 'w') as f:
                    json.dump(result, f, indent=2)
                print(f"   Saved to: {output_file}")
            else:
                print(f"❌ Error: {response.status_code}")
                print(f"   Response: {response.text}")
        
        except Exception as e:
            print(f"❌ Error testing {platform}: {str(e)}")
        
        time.sleep(2)  # Rate limiting


def test_image_generation():
    """Test image generation endpoints"""
    print("\n" + "="*70)
    print("TESTING IMAGE GENERATION ENDPOINTS")
    print("="*70)
    
    # First, generate text to get image descriptions
    print("\n🔄 Getting image descriptions from text generation...")
    
    platforms = {
        "whatsapp": f"{API_BASE_URL}/generate/whatsapp/text",
        "email": f"{API_BASE_URL}/generate/email/text",
        "instagram": f"{API_BASE_URL}/generate/instagram/text"
    }
    
    image_descriptions = {}
    
    for platform, text_url in platforms.items():
        campaign = CAMPAIGNS.get(platform, CAMPAIGNS["summer_promo"])
        
        payload = {
            "instructions": campaign["instructions"],
            "campaign_name": f"{platform}_images"
        }
        
        try:
            response = requests.post(text_url, json=payload, timeout=60)
            if response.status_code == 200:
                result = response.json()
                image_desc = result.get("data", {}).get("image_description", "")
                image_descriptions[platform] = image_desc
                print(f"✅ Got description for {platform}")
            else:
                print(f"❌ Failed to get description for {platform}")
        except Exception as e:
            print(f"❌ Error: {str(e)}")
        
        time.sleep(2)
    
    # Now generate images using descriptions
    print("\n🔄 Generating images...")
    
    image_urls = {
        "whatsapp": f"{API_BASE_URL}/generate/whatsapp/image",
        "email": f"{API_BASE_URL}/generate/email/image",
        "instagram": f"{API_BASE_URL}/generate/instagram/image"
    }
    
    for platform, image_url in image_urls.items():
        if platform not in image_descriptions:
            print(f"⏭️  Skipping {platform}: no image description")
            continue
        
        print(f"\n🎨 Generating {platform.upper()} image...")
        
        campaign = CAMPAIGNS.get(platform, CAMPAIGNS["summer_promo"])
        
        payload = {
            "image_description": image_descriptions[platform],
            "campaign_name": f"{platform}_campaign",
            "image_count": 1
        }
        
        params = {
            "logo_path": campaign.get("logo_path"),
            "context_images_path": campaign.get("context_images_path")
        }
        
        try:
            response = requests.post(image_url, json=payload, params=params, timeout=120)
            
            if response.status_code == 200:
                result = response.json()
                print(f"✅ {platform.upper()} Image Generated!")
                print(f"   Images: {len(result.get('images', []))} generated")
                for img_path in result.get('images', []):
                    print(f"   - {img_path}")
                
                # Save result
                output_file = f"test_results/{platform}_images.json"
                Path("test_results").mkdir(exist_ok=True)
                with open(output_file, 'w') as f:
                    json.dump(result, f, indent=2)
            else:
                print(f"❌ Error: {response.status_code}")
                print(f"   Response: {response.text[:500]}")
        
        except Exception as e:
            print(f"❌ Error generating {platform} image: {str(e)}")
        
        time.sleep(5)  # Allow time for image generation


def test_combined_campaigns():
    """Test combined campaign generation (text + images)"""
    print("\n" + "="*70)
    print("TESTING COMBINED CAMPAIGN GENERATION")
    print("="*70)
    
    campaign_urls = {
        "whatsapp": f"{API_BASE_URL}/generate/campaign/whatsapp",
        "email": f"{API_BASE_URL}/generate/campaign/email",
        "instagram": f"{API_BASE_URL}/generate/campaign/instagram"
    }
    
    for platform, url in campaign_urls.items():
        print(f"\n🚀 Generating complete {platform.upper()} campaign...")
        
        campaign = CAMPAIGNS.get(platform, CAMPAIGNS["summer_promo"])
        
        payload = {
            "instructions": campaign["instructions"],
            "campaign_name": f"{platform}_complete"
        }
        
        params = {
            "logo_path": campaign.get("logo_path"),
            "context_images_path": campaign.get("context_images_path")
        }
        
        try:
            response = requests.post(url, json=payload, params=params, timeout=180)
            
            if response.status_code == 200:
                result = response.json()
                print(f"✅ Complete {platform.upper()} Campaign Generated!")
                print(f"   Status: {result.get('status')}")
                print(f"   Images: {len(result.get('images', []))} generated")
                
                # Save result
                output_file = f"test_results/{platform}_campaign.json"
                Path("test_results").mkdir(exist_ok=True)
                with open(output_file, 'w') as f:
                    json.dump(result, f, indent=2)
                print(f"   Saved to: {output_file}")
            else:
                print(f"❌ Error: {response.status_code}")
                print(f"   Response: {response.text[:500]}")
        
        except Exception as e:
            print(f"❌ Error generating {platform} campaign: {str(e)}")
        
        time.sleep(10)  # Allow time between requests


def main():
    """Run all tests"""
    print("\n" + "="*70)
    print("🎯 IndiGo Marketing Platform API - Test Suite")
    print("="*70)
    
    # Check if API is running
    print("\n🔍 Checking API health...")
    try:
        response = requests.get(f"{API_BASE_URL.replace('/api/v1', '')}/", timeout=5)
        if response.status_code == 200:
            print("✅ API is running!")
        else:
            print("❌ API returned non-200 status code")
            return
    except Exception as e:
        print(f"❌ Cannot connect to API: {str(e)}")
        print("Make sure the API server is running: uvicorn marketing_api.main:app --reload")
        return
    
    # Run tests
    test_text_generation()
    test_image_generation()
    test_combined_campaigns()
    
    print("\n" + "="*70)
    print("✅ Test Suite Complete!")
    print("="*70)
    print("\nResults saved in test_results/ directory")
    print("Review the JSON files for detailed API responses")


if __name__ == "__main__":
    main()
