"""
SETUP GUIDE
IndiGo Marketing Platform API - Installation & Configuration
"""

# ============================================================================
# INSTALLATION GUIDE
# ============================================================================

## STEP 1: Install Dependencies

Navigate to the project directory and install required packages:

```bash
cd "c:\Users\Hariprasath.x.V\Desktop\Marketing Platform"
pip install -r marketing_api/requirements.txt
```

Verify installation:
```bash
pip list | grep -E "fastapi|google-genai|openai|pillow"
```

## STEP 2: Configure Environment Variables

The system uses the existing .env file. Ensure it contains:

```env
nano_banana_api_key=your-gemini-api-key
AZURE_OPENAI_ENDPOINT=https://openai-lab37-slm-poc.openai.azure.com/openai/deployments/gpt-4o/chat/completions?api-version=2025-01-01-preview
AZURE_OPENAI_KEY=your-azure-key
AZURE_OPENAI_DEPLOYMENT=gpt-4o
API_BASE_URL=https://lab37-marketing-campaign.azurewebsites.net
```

**Environment Variables:**
- `nano_banana_api_key`: Gemini API key for image generation
- `AZURE_OPENAI_*`: Azure OpenAI configuration for text generation
- `API_BASE_URL`: Base URL for the API (used by frontend config endpoint)

Current .env status: ✅ Already configured


## STEP 3: Prepare Asset Directories

The system expects these directories to exist:

```
campaign_logo/
├── indigo_air_delights_logo.png

campaign_images/
├── indigo_campaign_*.png
```

These are already created from previous campaign generation!
Location: c:\Users\Hariprasath.x.V\Desktop\Marketing Platform\


## STEP 4: Verify Project Structure

```bash
# Check if all files are in place
ls -la marketing_api/
ls -la marketing_api/prompts/
ls -la marketing_api/services/
ls -la marketing_api/utils/
```

Expected structure:
✅ marketing_api/__init__.py
✅ marketing_api/main.py
✅ marketing_api/requirements.txt
✅ marketing_api/README.md
✅ marketing_api/prompts/__init__.py
✅ marketing_api/prompts/whatsapp.py
✅ marketing_api/prompts/email.py
✅ marketing_api/prompts/instagram.py
✅ marketing_api/services/__init__.py
✅ marketing_api/services/azure_openai_service.py
✅ marketing_api/services/gemini_image_service.py
✅ marketing_api/services/whatsapp_service.py
✅ marketing_api/services/email_service.py
✅ marketing_api/services/instagram_service.py
✅ marketing_api/utils/__init__.py
✅ marketing_api/utils/image_processor.py
✅ marketing_api/models/__init__.py
✅ marketing_api/api/__init__.py


# ============================================================================
# RUNNING THE API SERVER
# ============================================================================

## Option 1: Development Mode (with auto-reload)

```bash
cd "c:\Users\Hariprasath.x.V\Desktop\Marketing Platform"

# Windows PowerShell
python -m uvicorn marketing_api.main:app --reload --host 0.0.0.0 --port 8000

# Or direct command
uvicorn marketing_api.main:app --reload --host 0.0.0.0 --port 8000
```

Expected output:
```
INFO:     Uvicorn running on http://0.0.0.0:8000
INFO:     Application startup complete
```

## Option 2: Production Mode

```bash
# Single worker
uvicorn marketing_api.main:app --host 0.0.0.0 --port 8000

# Multiple workers (recommended for production)
uvicorn marketing_api.main:app --host 0.0.0.0 --port 8000 --workers 4
```

## Option 3: Background Execution

```bash
# Windows PowerShell - Start in background
$process = Start-Process python -ArgumentList "-m uvicorn marketing_api.main:app --reload" -NoNewWindow -PassThru

# Get process ID
$process.Id

# Later, stop the server
Stop-Process -Id <process_id>
```


# ============================================================================
# ACCESSING THE API
# ============================================================================

Once the server is running, access it at:

1. **Interactive API Docs (Swagger UI)**
   URL: http://localhost:8000/docs
   - Browse all endpoints
   - Try requests directly
   - See request/response examples

2. **Alternative API Docs (ReDoc)**
   URL: http://localhost:8000/redoc
   - Read-only documentation
   - Better for reference

3. **API Base URL**
   http://localhost:8000/api/v1

4. **Health Check**
   ```bash
   curl http://localhost:8000/
   # Response: {"status":"running","app":"IndiGo Marketing Platform API","version":"1.0.0"}
   ```


# ============================================================================
# TESTING THE API
# ============================================================================

## Method 1: Using the Interactive Swagger UI

1. Open http://localhost:8000/docs
2. Click on any endpoint (green for POST)
3. Click "Try it out"
4. Fill in the request body
5. Click "Execute"
6. See the response

## Method 2: Using Python Requests

```python
import requests

# Generate WhatsApp text
response = requests.post(
    "http://localhost:8000/api/v1/generate/whatsapp/text",
    json={
        "instructions": "Promote discounted flight tickets",
        "campaign_name": "summer_promo"
    }
)

print(response.json())
```

## Method 3: Using cURL

```bash
# Generate WhatsApp text
curl -X POST "http://localhost:8000/api/v1/generate/whatsapp/text" \
  -H "Content-Type: application/json" \
  -d '{
    "instructions": "Promote discounted flight tickets",
    "campaign_name": "summer_promo"
  }'

# Generate complete WhatsApp campaign
curl -X POST "http://localhost:8000/api/v1/generate/campaign/whatsapp" \
  -H "Content-Type: application/json" \
  -d '{
    "instructions": "Promote discounted flight tickets",
    "campaign_name": "summer_promo"
  }' \
  --data-urlencode 'logo_path=campaign_logo/indigo_air_delights_logo.png' \
  --data-urlencode 'context_images_path=campaign_images'
```

## Method 4: Using the Included Test Suite

```bash
python test_marketing_api.py
```

The test suite will:
- Test all text generation endpoints
- Test all image generation endpoints
- Test combined campaign generation
- Save results to test_results/ directory


# ============================================================================
# QUICK TEST SCENARIOS
# ============================================================================

### Scenario 1: Generate WhatsApp Message Only

```bash
curl -X POST "http://localhost:8000/api/v1/generate/whatsapp/text" \
  -H "Content-Type: application/json" \
  -d '{
    "instructions": "Special offer on business class bookings with 25% discount",
    "campaign_name": "business_upgrade"
  }'
```

Expected output includes:
- WhatsApp message (concise, with emoji)
- CTA button text
- Image description for visual direction

### Scenario 2: Generate Email Campaign

```bash
curl -X POST "http://localhost:8000/api/v1/generate/email/text" \
  -H "Content-Type: application/json" \
  -d '{
    "instructions": "Newsletter about new premium lounge access benefits",
    "campaign_name": "lounge_benefits"
  }'
```

Expected output includes:
- Subject line
- Preview text
- Email body
- CTA details
- Footer note
- Image description

### Scenario 3: Generate Instagram Post

```bash
curl -X POST "http://localhost:8000/api/v1/generate/instagram/text" \
  -H "Content-Type: application/json" \
  -d '{
    "instructions": "Create trending content about weekend travel goals",
    "campaign_name": "weekend_getaway"
  }'
```

Expected output includes:
- Instagram caption with emoji
- Relevant hashtags
- CTA text
- Image description

### Scenario 4: Complete Campaign with Images

```bash
curl -X POST "http://localhost:8000/api/v1/generate/campaign/whatsapp" \
  -H "Content-Type: application/json" \
  -d '{
    "instructions": "Launch new meal packages on flights with special dietary options",
    "campaign_name": "meal_packages"
  }' \
  --data-urlencode 'logo_path=campaign_logo/indigo_air_delights_logo.png' \
  --data-urlencode 'context_images_path=campaign_images'

# This will:
# 1. Generate WhatsApp message text (3-5 sec)
# 2. Extract image description
# 3. Generate image using Gemini (10-15 sec)
# 4. Save image to campaign_assets/
# 5. Return text + image paths
```


# ============================================================================
# MONITORING API PERFORMANCE
# ============================================================================

## Check Response Times

Add timing to requests:

```bash
# Using curl with timing
curl -w "\nTotal time: %{time_total}s\n" \
  -X POST "http://localhost:8000/api/v1/generate/whatsapp/text" \
  -H "Content-Type: application/json" \
  -d '{"instructions":"test","campaign_name":"test"}'
```

## Monitor Server Logs

```bash
# Windows PowerShell - See real-time logs
Get-Content -Path "log_file.txt" -Tail 20 -Wait

# Or capture logs to file
uvicorn marketing_api.main:app --reload > server.log 2>&1
```

## Expected Performance

- Text Generation: 3-5 seconds
- Image Generation: 10-15 seconds
- Combined: 15-25 seconds


# ============================================================================
# TROUBLESHOOTING
# ============================================================================

### Issue: "Module not found: marketing_api"

**Solution:**
```bash
# Make sure you're in the correct directory
cd "c:\Users\Hariprasath.x.V\Desktop\Marketing Platform"

# Check if __init__.py files exist
ls marketing_api/__init__.py
ls marketing_api/prompts/__init__.py
ls marketing_api/services/__init__.py
ls marketing_api/utils/__init__.py

# If missing, create them
touch marketing_api/__init__.py
```

### Issue: "AZURE_OPENAI_KEY not found"

**Solution:**
```bash
# Verify .env file exists and has correct content
cat .env

# Check that file is in project root, not in subdirectory
ls -la | grep .env

# Ensure variables are correctly named:
# - AZURE_OPENAI_KEY (not OPENAI_KEY)
# - nano_banana_api_key (exact name)
```

### Issue: "Connection refused" on http://localhost:8000

**Solution:**
```bash
# Check if server is actually running
# Make sure you see "Uvicorn running on http://0.0.0.0:8000"

# Try a different port if 8000 is in use
uvicorn marketing_api.main:app --reload --port 8001

# Check if port is already in use
netstat -ano | findstr :8000
```

### Issue: "Image not found at campaign_logo/..."

**Solution:**
```bash
# Verify logo file exists
ls campaign_logo/
ls campaign_logo/indigo_air_delights_logo.png

# Use absolute path if needed
# Example: "C:/Users/Hariprasath.x.V/Desktop/Marketing Platform/campaign_logo/indigo_air_delights_logo.png"

# Or provide full path
curl ... --data-urlencode 'logo_path=campaign_logo/indigo_air_delights_logo.png'
```

### Issue: "Timeout waiting for image generation"

**Solution:**
```bash
# Increase timeout in API call
# Default is 120 seconds, some images might take longer

# If using Python requests:
response = requests.post(url, json=data, timeout=180)

# If using curl:
curl --max-time 180 ...
```

### Issue: "API Rate Limit Exceeded"

**Solution:**
```bash
# Add delay between requests
import time
time.sleep(2)

# Or use the test script which implements rate limiting
python test_marketing_api.py
```


# ============================================================================
# NEXT STEPS
# ============================================================================

1. ✅ Install dependencies
2. ✅ Verify .env configuration
3. ✅ Run the API server
4. ✅ Test endpoints via Swagger UI
5. ✅ Review generated campaign assets
6. 📊 Analyze performance metrics
7. 🔧 Customize prompts as needed
8. 🚀 Plan deployment strategy

For detailed API documentation, see: marketing_api/README.md
For architecture overview, see: ARCHITECTURE.md
For quick examples, see: QUICKSTART.md


# ============================================================================
# SUPPORT & RESOURCES
# ============================================================================

Problem?
1. Check TROUBLESHOOTING section above
2. Review logs and error messages
3. Check FastAPI docs: https://fastapi.tiangolo.com/
4. Review code comments in marketing_api/
5. Contact development team

Want to customize?
1. See marketing_api/README.md for API details
2. See ARCHITECTURE.md for system overview
3. Edit prompts in marketing_api/prompts/
4. Modify services in marketing_api/services/
5. Test with test_marketing_api.py
