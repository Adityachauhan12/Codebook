# Marketing API Package
"""
IndiGo Marketing Platform Backend API
For generating marketing campaigns across multiple platforms with text and image generation
"""

__version__ = "1.0.0"
