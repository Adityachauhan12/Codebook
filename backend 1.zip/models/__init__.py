# Models package
from pydantic import BaseModel
from typing import Optional, List


class CampaignInput(BaseModel):
    """Base model for campaign input"""
    instructions: str
    campaign_name: Optional[str] = "Campaign"


class TextGenerationResponse(BaseModel):
    """Response from text generation APIs"""
    platform: str
    generated_text: dict
    image_description: str
    

class ImageGenerationRequest(BaseModel):
    """Request for image generation with context images"""
    image_description: str
    logo_path: Optional[str] = None
    context_images_path: Optional[str] = None
    image_count: int = 1
    campaign_name: str = "campaign"


class ImageGenerationResponse(BaseModel):
    """Response from image generation API"""
    status: str
    generated_images: List[str]
    image_paths: List[str]


class CampaignAssets(BaseModel):
    """Complete campaign assets"""
    campaign_name: str
    platform: str
    text: dict
    images: List[str]
    image_descriptions: str
