# IndiGo Marketing Platform API

FastAPI backend for generating IndiGo marketing copy and campaign visuals across WhatsApp, Email, Instagram, Facebook, and Twitter.

The API uses:
- Azure OpenAI for platform-specific text generation
- Google Gemini for image generation
- Local image processing for resizing, format conversion, and context-image preparation

## Features

- Text generation for 5 platforms: WhatsApp, Email, Instagram, Facebook, Twitter
- Image generation for all 5 platforms
- Combined campaign endpoints that generate text and images in one call
- Optional logo and campaign context images for visual consistency
- Automatic image resizing and PNG conversion before Gemini requests
- Support for up to 14 input images per image-generation request

## Project Structure

```text
marketing_api/
|-- main.py
|-- README.md
|-- requirements.txt
|-- prompts/
|   |-- whatsapp.py
|   |-- email.py
|   |-- instagram.py
|   |-- facebook.py
|   `-- twitter.py
|-- services/
|   |-- azure_openai_service.py
|   |-- gemini_image_service.py
|   |-- whatsapp_service.py
|   |-- email_service.py
|   |-- instagram_service.py
|   |-- facebook_service.py
|   `-- twitter_service.py
`-- utils/
    `-- image_processor.py
```

## Requirements

- Python environment with dependencies from `marketing_api/requirements.txt`
- Azure OpenAI credentials
- Gemini API key in `nano_banana_api_key`

## Environment Variables

Create `marketing_api/.env` with:

```env
AZURE_OPENAI_ENDPOINT=https://your-endpoint.openai.azure.com/openai/deployments/gpt-4o/chat/completions?api-version=2025-01-01-preview
AZURE_OPENAI_KEY=your-azure-openai-api-key
AZURE_OPENAI_DEPLOYMENT=gpt-4o
nano_banana_api_key=your-gemini-api-key
```

## Run Locally

From the project root:

```bash
pip install -r marketing_api/requirements.txt
uvicorn marketing_api.main:app --reload --host 0.0.0.0 --port 8000
```

Docs:
- Swagger UI: `http://localhost:8000/docs`
- ReDoc: `http://localhost:8000/redoc`

## Run With Docker

Build the image from the project root:

```bash
docker build -t marketing-api ./marketing_api
```

Run the container with the app environment file:

```bash
docker run --env-file ./marketing_api/.env -p 8000:8000 marketing-api
```

The container starts the API with:

```bash
uvicorn main:app --host 0.0.0.0 --port 8000
```

## Request Models

### CampaignInput

Used by text-generation and combined campaign endpoints.

```json
{
  "instructions": "Promote weekend getaway packages",
  "campaign_name": "weekend_special"
}
```

Fields:
- `instructions`: required campaign brief
- `campaign_name`: optional label for output folders, defaults to `"campaign"`

### ImageGenerationRequest

Used by image-generation endpoints.

```json
{
  "image_description": "Create a bright square social media promo for discounted fares",
  "campaign_name": "summer_sale",
  "logo_path": "assets/indigo_logo.png",
  "context_images_path": "campaign_assets/summer_sale/images",
  "image_count": 1
}
```

Fields:
- `image_description`: required prompt for image generation
- `campaign_name`: optional output folder label
- `logo_path`: required logo file path
- `context_images_path`: required directory of reference images
- `image_count`: number of output images to generate

## Endpoints

### Health

- `GET /`

### Text Generation

- `POST /api/v1/generate/whatsapp/text`
- `POST /api/v1/generate/email/text`
- `POST /api/v1/generate/instagram/text`
- `POST /api/v1/generate/facebook/text`
- `POST /api/v1/generate/twitter/text`

### Image Generation

- `POST /api/v1/generate/whatsapp/image`
- `POST /api/v1/generate/email/image`
- `POST /api/v1/generate/instagram/image`
- `POST /api/v1/generate/facebook/image`
- `POST /api/v1/generate/twitter/image`

### Combined Campaigns

- `POST /api/v1/generate/campaign/whatsapp`
- `POST /api/v1/generate/campaign/email`
- `POST /api/v1/generate/campaign/instagram`
- `POST /api/v1/generate/campaign/facebook`
- `POST /api/v1/generate/campaign/twitter`

Combined campaign endpoints accept:
- JSON body: `CampaignInput`
- Required query params: `logo_path`, `context_images_path`
- Optional query param: `additional_instructions`

## Example Responses

### WhatsApp Text

```json
{
  "status": "success",
  "campaign_name": "summer_sale",
  "platform": "whatsapp",
  "data": {
    "platform": "whatsapp",
    "message": "Fly for less this summer with limited-time fares.",
    "cta_button": "Book Now",
    "image_description": "Create a vibrant square promo image featuring aircraft, travel energy, and IndiGo branding."
  }
}
```

### Email Text

```json
{
  "status": "success",
  "campaign_name": "business_class_launch",
  "platform": "email",
  "data": {
    "platform": "email",
    "subject_line": "Upgrade to a More Comfortable Journey",
    "preview_text": "Discover premium comfort with IndiGo.",
    "email_body": "Dear traveler, ...",
    "cta_text": "Upgrade Now",
    "cta_url": "https://goIndiGo.in/premium",
    "footer_note": "Terms apply.",
    "image_description": "Create a clean horizontal email header image with premium travel cues."
  }
}
```

### Instagram Text

```json
{
  "status": "success",
  "campaign_name": "eco_friendly",
  "platform": "instagram",
  "data": {
    "platform": "instagram",
    "caption": "Flying smarter starts here.",
    "hashtags": ["#IndiGo", "#Travel", "#SustainableAviation"],
    "cta_text": "Learn More",
    "image_description": "Create a bold square Instagram visual focused on sustainable travel."
  }
}
```

### Facebook Text

```json
{
  "status": "success",
  "campaign_name": "family_offer",
  "platform": "facebook",
  "data": {
    "platform": "facebook",
    "post_text": "Plan your next family getaway with special fares from IndiGo.",
    "cta_button": "Book Now",
    "cta_text": "See fares and plan your trip today.",
    "image_description": "Create a Facebook-friendly travel promo visual showing family trip energy."
  }
}
```

### Twitter Text

```json
{
  "status": "success",
  "campaign_name": "flash_sale",
  "platform": "twitter",
  "data": {
    "platform": "twitter",
    "tweet": "Limited-time fares are live. Book your next trip with IndiGo.",
    "thread": ["More routes. Better value.", "Book before the sale ends."],
    "hashtags": ["#IndiGo", "#TravelDeals"],
    "cta_hook": "Tap in now.",
    "image_description": "Create a sharp, high-energy social image for a flash fare announcement."
  }
}
```

### Image Response

```json
{
  "status": "success",
  "platform": "instagram",
  "campaign_name": "eco_friendly",
  "image_count": 2,
  "images": [
    "campaign_assets/eco_friendly/instagram_20260324_120000/instagram_post_1.png",
    "campaign_assets/eco_friendly/instagram_20260324_120000/instagram_post_2.png"
  ]
}
```

## Context Images and Limits

The API reads image files from `context_images_path` and prepares them before calling Gemini.

Current behavior:
- Supported input formats: `png`, `jpg`, `jpeg`, `webp`
- The API keeps only the first 14 images from the directory
- If the directory contains more than 14 images, it logs:

```text
Count exceeded! only picking top 14 images in directory
```

- Images are resized and converted to PNG before being sent to Gemini
- `logo_path` is required and passed separately from the directory images

## Output Layout

Generated images are saved under `campaign_assets/<campaign_name>/`.

Examples:

```text
campaign_assets/
`-- summer_sale/
    |-- whatsapp_20260324_120000/
    |   `-- whatsapp_1.png
    |-- email_20260324_120500/
    |   `-- email_header_1.png
    |-- instagram_20260324_121000/
    |   |-- instagram_post_1.png
    |   `-- instagram_post_2.png
    |-- facebook_20260324_121500/
    |   `-- facebook_post_1.png
    `-- twitter_20260324_122000/
        `-- twitter_post_1.png
```

## Example Usage

### cURL

```bash
curl -X POST "http://localhost:8000/api/v1/generate/campaign/twitter?logo_path=assets/indigo_logo.png&context_images_path=campaign_assets/flash_sale/images&additional_instructions=Keep%20the%20tone%20urgent%20but%20premium" \
  -H "Content-Type: application/json" \
  -d '{
    "instructions": "Announce a limited-time flash fare campaign",
    "campaign_name": "flash_sale"
  }'
```

### Python

```python
import requests

response = requests.post(
    "http://localhost:8000/api/v1/generate/campaign/whatsapp",
    json={
        "instructions": "Promote weekend getaway packages",
        "campaign_name": "weekend_special",
    },
    params={
        "logo_path": "assets/indigo_logo.png",
        "context_images_path": "campaign_assets/weekend_special/images",
        "additional_instructions": "Make it mobile-first and upbeat.",
    },
    timeout=180,
)

print(response.json())
```

## Error Handling

The API raises `500` errors for downstream generation failures and returns FastAPI validation errors such as `422` for malformed requests.

Example:

```json
{
  "detail": "Error generating Twitter campaign: [specific error message]"
}
```

## Notes

- Text generation uses the Azure OpenAI deployment from `AZURE_OPENAI_DEPLOYMENT`
- Azure OpenAI client version is configured with `2025-01-01-preview`
- Image generation uses the `gemini-3-pro-image-preview` model
- Image generation time scales with `image_count`

## Related Docs

- `marketing_api/QUICKSTART.md`
- `marketing_api/API_REFERENCE.md`
- `marketing_api/ARCHITECTURE.md`
- `marketing_api/SETUP_GUIDE.md`
