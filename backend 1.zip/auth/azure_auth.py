"""
Azure AD JWT validation module.

Validates Bearer tokens issued by Azure AD (Microsoft Entra ID) on every
protected API request.  The JWKS (public signing keys) are fetched once and
cached in-memory; the cache is automatically invalidated when a key-ID is not
found so that Azure key rotations are handled transparently.
"""

import datetime
import hashlib
import json
import logging
import os
import time
from typing import Any, Dict, Optional

import jwt  # PyJWT
from fastapi import Depends, HTTPException, status
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer
from jwt.algorithms import RSAAlgorithm

from db.connection import get_db

logger = logging.getLogger(__name__)

# Only @goindigo.in accounts are permitted.
_ALLOWED_EMAIL_DOMAIN = "@goindigo.in"

# JWKS cache TTL in seconds (1 hour).  Azure may rotate keys at any time, but
# the on-miss refresh below handles that case without waiting for TTL expiry.
_JWKS_CACHE_TTL: float = 3600.0

_jwks_cache: Dict[str, Any] = {}
_jwks_cache_time: float = 0.0

# FastAPI HTTP Bearer scheme — extracts the token from "Authorization: Bearer …"
_bearer_scheme = HTTPBearer(auto_error=True)


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------

def _tenant_id() -> str:
    value = os.getenv("AZURE_TENANT_ID", "").strip()
    if not value:
        raise RuntimeError("AZURE_TENANT_ID environment variable is not set")
    return value


def _client_id() -> str:
    value = os.getenv("AZURE_CLIENT_ID", "").strip()
    if not value:
        raise RuntimeError("AZURE_CLIENT_ID environment variable is not set")
    return value


def _fetch_jwks_from_uri(uri: str) -> Dict[str, Any]:
    """Fetch JWKS from a given URI with proper TLS/proxy config."""
    import httpx
    from utils.network_config import _httpx_verify_enabled
    import certifi
    verify = certifi.where() if _httpx_verify_enabled() else False
    with httpx.Client(verify=verify, trust_env=True, timeout=10.0) as client:
        response = client.get(uri)
        response.raise_for_status()
        return response.json()


def _fetch_jwks(tenant_id: str) -> Dict[str, Any]:
    """Fetch JWKS from Azure AD, returning the cached version when still fresh."""
    global _jwks_cache, _jwks_cache_time

    now = time.monotonic()
    if _jwks_cache and (now - _jwks_cache_time) < _JWKS_CACHE_TTL:
        return _jwks_cache

    # Try tenant-specific v2 first, then /common v2 as fallback.
    # IMPORTANT: when the app has a SAML certificate configured, Azure AD signs
    # ID tokens with an app-specific key.  That key is ONLY available at the
    # ?appid= variant of the endpoint — it will not appear in the generic JWKS.
    client_id = _client_id()
    uris = [
        f"https://login.microsoftonline.com/{tenant_id}/discovery/v2.0/keys?appid={client_id}",
        f"https://login.microsoftonline.com/{tenant_id}/discovery/v2.0/keys",
        "https://login.microsoftonline.com/common/discovery/v2.0/keys",
    ]

    merged_keys: list = []
    seen_kids: set = set()
    last_error: Optional[Exception] = None

    for uri in uris:
        try:
            data = _fetch_jwks_from_uri(uri)
            for k in data.get("keys", []):
                kid = k.get("kid")
                if kid and kid not in seen_kids:
                    merged_keys.append(k)
                    seen_kids.add(kid)
            logger.debug(
                "JWKS fetched from %s — %d key(s): %s",
                uri,
                len(data.get("keys", [])),
                [k.get("kid") for k in data.get("keys", [])],
            )
        except Exception as exc:
            last_error = exc
            logger.warning("Failed to fetch JWKS from %s: %s", uri, exc)

    if not merged_keys:
        if last_error:
            raise last_error
        raise RuntimeError("No JWKS keys could be fetched from Azure AD")

    jwks = {"keys": merged_keys}
    _jwks_cache = jwks
    _jwks_cache_time = now
    logger.info(
        "Azure AD JWKS combined — %d total key(s): %s",
        len(merged_keys),
        list(seen_kids),
    )
    return jwks


def _get_public_key(tenant_id: str, kid: str):
    """
    Return the RSA public key matching *kid*.

    On a cache miss the cache is invalidated and JWKS is re-fetched once to
    handle transparent Azure key rotation.
    """
    global _jwks_cache_time

    for attempt in range(2):
        jwks = _fetch_jwks(tenant_id)
        for key_data in jwks.get("keys", []):
            if key_data.get("kid") == kid:
                return RSAAlgorithm.from_jwk(json.dumps(key_data))

        if attempt == 0:
            # Key not found in cache — force a refresh and try once more.
            logger.debug("kid %r not found in JWKS cache; forcing refresh", kid)
            _jwks_cache_time = 0.0

    return None


# ---------------------------------------------------------------------------
# Token revocation helpers
# ---------------------------------------------------------------------------

def _token_jti(claims: Dict[str, Any], raw_token: str) -> str:
    """Stable unique ID for a token: jti claim, then uti, then SHA-256 of raw bytes."""
    jti = claims.get("jti") or claims.get("uti")
    if jti:
        return str(jti)
    return hashlib.sha256(raw_token.encode()).hexdigest()


def revoke_token(raw_token: str, claims: Dict[str, Any]) -> None:
    """Persist the token JTI to the revoked_tokens table. Never raises."""
    jti = _token_jti(claims, raw_token)
    exp_ts = claims.get("exp")
    expires_at = (
        datetime.datetime.fromtimestamp(float(exp_ts), tz=datetime.timezone.utc)
        if exp_ts
        else datetime.datetime.now(tz=datetime.timezone.utc) + datetime.timedelta(hours=1)
    )
    try:
        with get_db() as conn:
            with conn.cursor() as cur:
                cur.execute(
                    """
                    INSERT INTO revoked_tokens (jti, user_id, expires_at)
                    VALUES (%s, %s, %s)
                    ON CONFLICT (jti) DO NOTHING
                    """,
                    (jti, claims.get("oid"), expires_at),
                )
            conn.commit()
        logger.info("Token revoked: jti=%s", jti)
    except Exception as exc:
        logger.warning("revoke_token failed for jti=%s: %s", jti, exc)


def _is_token_revoked(jti: str) -> bool:
    """Return True if the JTI is present in the revoked_tokens table."""
    try:
        with get_db() as conn:
            with conn.cursor() as cur:
                cur.execute(
                    "SELECT 1 FROM revoked_tokens WHERE jti = %s AND expires_at > NOW()",
                    (jti,),
                )
                return cur.fetchone() is not None
    except Exception as exc:
        logger.warning("_is_token_revoked check failed: %s", exc)
        return False  # fail-open: don't block requests on DB errors


def ensure_revoked_tokens_table() -> None:
    """Idempotent migration: create revoked_tokens if it doesn't exist yet."""
    try:
        with get_db() as conn:
            with conn.cursor() as cur:
                cur.execute(
                    """
                    CREATE TABLE IF NOT EXISTS revoked_tokens (
                        jti        TEXT        PRIMARY KEY,
                        user_id    TEXT,
                        revoked_at TIMESTAMPTZ DEFAULT NOW(),
                        expires_at TIMESTAMPTZ NOT NULL
                    )
                    """
                )
                cur.execute(
                    "CREATE INDEX IF NOT EXISTS idx_revoked_tokens_expires "
                    "ON revoked_tokens (expires_at)"
                )
            conn.commit()
    except Exception as exc:
        logger.warning("ensure_revoked_tokens_table failed: %s", exc)


def cleanup_expired_tokens() -> int:
    """Delete all revoked_tokens rows whose expires_at has passed. Returns deleted count."""
    try:
        with get_db() as conn:
            with conn.cursor() as cur:
                cur.execute("DELETE FROM revoked_tokens WHERE expires_at < NOW()")
                deleted = cur.rowcount
            conn.commit()
        logger.info("Token cleanup: removed %d expired revoked_tokens row(s)", deleted)
        return deleted
    except Exception as exc:
        logger.warning("cleanup_expired_tokens failed: %s", exc)
        return 0


# ---------------------------------------------------------------------------
# Public interface
# ---------------------------------------------------------------------------

def validate_token(token: str) -> Dict[str, Any]:
    """
    Fully validate an Azure AD JWT access token.

    Checks (in order):
      1. Token is parseable and contains a kid header.
      2. Signature matches a key published by IndiGo's Azure AD tenant.
      3. Token has not expired.
      4. Audience matches this application's client ID.
      5. Issuer matches IndiGo's Azure AD tenant.
      6. The upn / preferred_username / email claim ends with @goindigo.in.

    Returns the decoded claims dict on success.
    Raises HTTPException(401) or HTTPException(403) on any failure.
    """
    tenant_id = _tenant_id()
    client_id = _client_id()

    # --- Step 1: decode header without verification to get kid ---
    try:
        header = jwt.get_unverified_header(token)
    except jwt.exceptions.DecodeError:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid token format",
            headers={"WWW-Authenticate": "Bearer"},
        )

    kid: Optional[str] = header.get("kid")
    if not kid:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Token header is missing the kid field",
            headers={"WWW-Authenticate": "Bearer"},
        )

    # --- Step 2: retrieve the matching public key ---
    try:
        public_key = _get_public_key(tenant_id, kid)
    except Exception as exc:
        logger.error("Failed to fetch Azure AD JWKS: %s", exc)
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Unable to retrieve Azure AD signing keys",
            headers={"WWW-Authenticate": "Bearer"},
        )

    if public_key is None:
        try:
            known_kids = [k.get("kid") for k in _fetch_jwks(tenant_id).get("keys", [])]
        except Exception:
            known_kids = []
        logger.error(
            "Token kid=%r not found in Azure AD JWKS. "
            "Known kids: %s",
            kid,
            known_kids,
        )
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Token signed with an unknown key",
            headers={"WWW-Authenticate": "Bearer"},
        )

    # --- Steps 3–5: verify signature, expiry, audience, issuer ---
    # Accept both v2.0 (preferred) and v1.0 issuer formats so the validator works
    # regardless of the app manifest's accessTokenAcceptedVersion setting.
    expected_issuers = [
        f"https://login.microsoftonline.com/{tenant_id}/v2.0",
        f"https://sts.windows.net/{tenant_id}/",
    ]
    # Also accept app-only audience variants (api://<client_id>)
    accepted_audiences = [client_id, f"api://{client_id}"]

    last_exc: Optional[Exception] = None
    claims: Optional[Dict[str, Any]] = None
    try:
        for issuer in expected_issuers:
            for audience in accepted_audiences:
                try:
                    claims = jwt.decode(
                        token,
                        public_key,
                        algorithms=["RS256"],
                        audience=audience,
                        issuer=issuer,
                        options={"verify_exp": True},
                    )
                    break  # success
                except (jwt.InvalidAudienceError, jwt.InvalidIssuerError) as exc:
                    last_exc = exc
                except (jwt.ExpiredSignatureError, jwt.exceptions.DecodeError):
                    raise  # these are definitive failures, no point retrying
            if claims is not None:
                break
    except jwt.ExpiredSignatureError:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Token has expired",
            headers={"WWW-Authenticate": "Bearer"},
        )
    except jwt.exceptions.DecodeError:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Token signature is invalid",
            headers={"WWW-Authenticate": "Bearer"},
        )

    if claims is None:
        # Decode without verification to get the actual aud/iss for logging
        try:
            unverified = jwt.decode(token, options={"verify_signature": False})
            logger.error(
                "Token audience/issuer mismatch. "
                "Token aud=%r iss=%r; accepted audiences=%r issuers=%r",
                unverified.get("aud"),
                unverified.get("iss"),
                accepted_audiences,
                expected_issuers,
            )
        except Exception:
            pass
        if isinstance(last_exc, jwt.InvalidAudienceError):
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Token audience does not match this application",
                headers={"WWW-Authenticate": "Bearer"},
            )
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Token issuer does not match IndiGo's Azure AD tenant",
            headers={"WWW-Authenticate": "Bearer"},
        )

    # --- Step 6: enforce @goindigo.in email domain ---
    email: str = (
        claims.get("preferred_username")
        or claims.get("upn")
        or claims.get("email")
        or ""
    )
    if not email.lower().endswith(_ALLOWED_EMAIL_DOMAIN):
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail=f"Access is restricted to {_ALLOWED_EMAIL_DOMAIN} accounts",
        )

    # --- Step 7: reject explicitly revoked tokens ---
    jti = _token_jti(claims, token)
    if _is_token_revoked(jti):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Token has been revoked. Please log in again.",
            headers={"WWW-Authenticate": "Bearer"},
        )

    return claims


def _sync_user(claims: Dict[str, Any]) -> None:
    """Upsert the authenticated user into the users table. Errors are logged but never block the request."""
    from psycopg2.extras import RealDictCursor

    azure_oid = claims.get("oid") or ""
    email = claims.get("preferred_username") or claims.get("upn") or claims.get("email") or ""
    name = claims.get("name") or ""
    if not azure_oid or not email:
        return
    try:
        with get_db() as conn:
            with conn.cursor(cursor_factory=RealDictCursor) as cur:
                cur.execute(
                    """
                    INSERT INTO users (id, email, name)
                    VALUES (%s, %s, %s)
                    ON CONFLICT (id) DO UPDATE SET
                        email = EXCLUDED.email,
                        name  = EXCLUDED.name
                    RETURNING id, department, sub_department
                    """,
                    (azure_oid, email, name),
                )
                row = dict(cur.fetchone())
            conn.commit()
    except Exception as exc:
        logger.warning("_sync_user failed for oid=%s: %s", azure_oid, exc)
        return

    # Call SF only when department or sub_department is missing — avoids overhead on every request
    if not row.get("department") or not row.get("sub_department"):
        _sync_sf_department(azure_oid, email)


def _sync_sf_department(azure_oid: str, email: str) -> None:
    """Fetch department/sub_department from SuccessFactors and update users + creatives. Never raises."""
    try:
        from services.successfactors_service import get_employee_department
        dept, sub_dept = get_employee_department(email)
        if not dept and not sub_dept:
            return
        with get_db() as conn:
            with conn.cursor() as cur:
                cur.execute(
                    """
                    UPDATE users
                    SET department     = COALESCE(department, %s),
                        sub_department = COALESCE(sub_department, %s)
                    WHERE id = %s
                    """,
                    (dept, sub_dept, azure_oid),
                )
                cur.execute(
                    """
                    UPDATE creatives
                    SET department     = COALESCE(department, %s),
                        sub_department = COALESCE(sub_department, %s)
                    WHERE user_id = %s
                    """,
                    (dept, sub_dept, azure_oid),
                )
            conn.commit()
        logger.info("_sync_sf_department: updated dept=%r sub=%r for oid=%s", dept, sub_dept, azure_oid)
    except Exception as exc:
        logger.warning("_sync_sf_department failed for oid=%s: %s", azure_oid, exc)


def require_auth(
    credentials: HTTPAuthorizationCredentials = Depends(_bearer_scheme),
) -> Dict[str, Any]:
    """
    FastAPI dependency injected into every protected endpoint.

    Usage::

        @app.post("/api/v1/...", dependencies=[Depends(require_auth)])
        def my_endpoint(...):
            ...
    """
    claims = validate_token(credentials.credentials)
    _sync_user(claims)
    return claims


def require_analytics_role(
    claims: Dict[str, Any] = Depends(require_auth),
) -> Dict[str, Any]:
    """
    FastAPI dependency that restricts access to users who have been assigned
    the 'Analytics.View' app role in Azure AD.

    Roles are injected by Azure AD into the token automatically — no
    hardcoded emails or lists are needed anywhere in the code.
    """
    roles: list = claims.get("roles") or []
    if "Analytics.View" not in roles:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Analytics access requires the 'Analytics.View' role.",
        )
    return claims


# ---------------------------------------------------------------------------
# Maker-Checker: Product & Marketplaces access control helpers
# ---------------------------------------------------------------------------


def _pnm_sub_department() -> str:
    """Configured P&M sub-department value (env override supported)."""
    return os.getenv("PNM_SUB_DEPARTMENT", "Product & Marketplaces").strip()


def is_pm_user(user_row: dict) -> bool:
    """Return True if the user belongs to Product & Marketplaces sub-department."""
    return user_row.get("sub_department") == _pnm_sub_department()


def require_pm_user(
    claims: Dict[str, Any] = Depends(require_auth),
) -> Dict[str, Any]:
    """FastAPI dependency: raises 403 if caller is not a P&M sub-department user."""
    from psycopg2.extras import RealDictCursor

    oid = claims.get("oid")
    with get_db() as conn:
        with conn.cursor(cursor_factory=RealDictCursor) as cur:
            cur.execute("SELECT sub_department FROM users WHERE id = %s", (oid,))
            row = cur.fetchone()
    if not row or (row.get("sub_department") != _pnm_sub_department()):
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Access restricted to Product & Marketplaces users",
        )
    return claims


def require_pm_approver(
    claims: Dict[str, Any] = Depends(require_auth),
) -> Dict[str, Any]:
    """FastAPI dependency: raises 403 if caller is not in the P&M approvers Azure AD group."""
    group_id = os.getenv("PNM_APPROVERS_GROUP_ID","")
    if not group_id:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="P&M approvers group not configured",
        )
    if group_id not in claims.get("groups", []):
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Access restricted to P&M approvers",
        )
    return claims
