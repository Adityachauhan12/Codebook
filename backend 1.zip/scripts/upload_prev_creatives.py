"""
One-time script: upload previous creatives to blob storage and seed the prev_creatives table.

Usage:
    python scripts/upload_prev_creatives.py --folder /path/to/images

What it does:
1. Creates the `prev-creatives` blob container (if not exists).
2. Creates the `prev_creatives` DB table (if not exists).
3. For each image in the folder, uploads it to blob and inserts a row.

Skips files that already have a row in prev_creatives (by title) so it's safe to re-run.
"""

import argparse
import mimetypes
import os
import sys
import uuid
from pathlib import Path

import psycopg2
from azure.identity import ClientSecretCredential
from azure.storage.blob import BlobServiceClient, ContentSettings
from dotenv import load_dotenv

load_dotenv()

CONTAINER = "prev-creatives"
SUPPORTED_EXTENSIONS = {".png", ".jpg", ".jpeg", ".webp", ".gif"}

# ---------------------------------------------------------------------------
# Credentials
# ---------------------------------------------------------------------------

_credential = ClientSecretCredential(
    tenant_id=os.getenv("AZURE_TENANT_ID", ""),
    client_id=os.getenv("AZURE_CLIENT_ID", ""),
    client_secret=os.getenv("AZURE_CLIENT_SECRET", ""),
)
_account_name = os.getenv("AZURE_STORAGE_ACCOUNT_NAME", "")


def _blob_client() -> BlobServiceClient:
    return BlobServiceClient(
        account_url=f"https://{_account_name}.blob.core.windows.net",
        credential=_credential,
    )


def _db_connect() -> psycopg2.extensions.connection:
    token = _credential.get_token(
        "https://token.postgres.cosmos.azure.com/.default"
    ).token
    return psycopg2.connect(
        host=os.getenv("PGHOST"),
        port=int(os.getenv("PGPORT", "5432")),
        dbname=os.getenv("PGDATABASE"),
        user=os.getenv("PGUSER"),
        password=token,
        sslmode="require",
    )


# ---------------------------------------------------------------------------
# Setup
# ---------------------------------------------------------------------------

def ensure_container(svc: BlobServiceClient) -> None:
    container = svc.get_container_client(CONTAINER)
    if not container.exists():
        container.create_container()
        print(f"Created blob container: {CONTAINER}")
    else:
        print(f"Blob container already exists: {CONTAINER}")


def ensure_table(conn: psycopg2.extensions.connection) -> None:
    with conn.cursor() as cur:
        cur.execute("""
            CREATE TABLE IF NOT EXISTS prev_creatives (
                id         UUID        PRIMARY KEY DEFAULT gen_random_uuid(),
                title      TEXT        NOT NULL,
                image_url  TEXT        NOT NULL,
                created_at TIMESTAMPTZ DEFAULT NOW()
            );
        """)
    conn.commit()
    print("Table prev_creatives ready.")


# ---------------------------------------------------------------------------
# Upload loop
# ---------------------------------------------------------------------------

def already_uploaded(cur, title: str) -> bool:
    cur.execute("SELECT 1 FROM prev_creatives WHERE title = %s LIMIT 1", (title,))
    return cur.fetchone() is not None


def upload_image(svc: BlobServiceClient, file_path: Path) -> str:
    """Upload image bytes to blob, return bare blob URL."""
    mime, _ = mimetypes.guess_type(str(file_path))
    mime = mime or "image/jpeg"
    blob_name = f"{uuid.uuid4()}{file_path.suffix.lower()}"
    blob_client = svc.get_blob_client(container=CONTAINER, blob=blob_name)
    blob_client.upload_blob(
        file_path.read_bytes(),
        overwrite=True,
        content_settings=ContentSettings(content_type=mime),
    )
    return blob_client.url


def run(folder: str) -> None:
    folder_path = Path(folder).resolve()
    if not folder_path.is_dir():
        print(f"ERROR: folder not found: {folder_path}")
        sys.exit(1)

    image_files = sorted(
        f for f in folder_path.iterdir()
        if f.is_file() and f.suffix.lower() in SUPPORTED_EXTENSIONS
    )
    if not image_files:
        print("No supported image files found in folder.")
        return

    print(f"Found {len(image_files)} image(s) in {folder_path}")

    svc = _blob_client()
    conn = _db_connect()

    try:
        ensure_container(svc)
        ensure_table(conn)

        uploaded = 0
        skipped = 0
        failed = 0

        with conn.cursor() as cur:
            for i, file_path in enumerate(image_files, 1):
                title = file_path.name
                print(f"[{i}/{len(image_files)}] {title}", end=" ... ")

                if already_uploaded(cur, title):
                    print("skipped (already in DB)")
                    skipped += 1
                    continue

                try:
                    image_url = upload_image(svc, file_path)
                    cur.execute(
                        "INSERT INTO prev_creatives (title, image_url) VALUES (%s, %s)",
                        (title, image_url),
                    )
                    conn.commit()
                    print("done")
                    uploaded += 1
                except Exception as exc:
                    conn.rollback()
                    print(f"FAILED — {exc}")
                    failed += 1

        print(f"\nComplete: {uploaded} uploaded, {skipped} skipped, {failed} failed.")
    finally:
        conn.close()


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Upload previous creatives to blob + DB.")
    parser.add_argument("--folder", required=True, help="Path to the folder containing images.")
    args = parser.parse_args()
    run(args.folder)
