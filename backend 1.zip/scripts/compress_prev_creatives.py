"""
One-time script: compress all images in the prev-creatives blob container in-place.

- Resizes to max 1920px on the longest side (preserves aspect ratio).
- Re-encodes as JPEG at 85% quality regardless of original format
  (campaign images have no transparency; JPEG is far smaller than PNG).
- Overwrites the same blob, so image_url in the DB stays valid.

Usage:
    python scripts/compress_prev_creatives.py
"""

import io
import os
import sys

from azure.identity import ClientSecretCredential
from azure.storage.blob import BlobServiceClient, ContentSettings
from dotenv import load_dotenv
from PIL import Image

load_dotenv()

CONTAINER = "prev-creatives"
MAX_DIMENSION = 800
JPEG_QUALITY = 85


# ---------------------------------------------------------------------------
# Client
# ---------------------------------------------------------------------------

def _blob_service() -> BlobServiceClient:
    credential = ClientSecretCredential(
        tenant_id=os.getenv("AZURE_TENANT_ID", ""),
        client_id=os.getenv("AZURE_CLIENT_ID", ""),
        client_secret=os.getenv("AZURE_CLIENT_SECRET", ""),
    )
    account_name = os.getenv("AZURE_STORAGE_ACCOUNT_NAME", "")
    return BlobServiceClient(
        account_url=f"https://{account_name}.blob.core.windows.net",
        credential=credential,
    )


# ---------------------------------------------------------------------------
# Compress
# ---------------------------------------------------------------------------

def compress(raw: bytes) -> bytes:
    """Resize to MAX_DIMENSION on longest side, re-encode as JPEG at JPEG_QUALITY."""
    img = Image.open(io.BytesIO(raw))

    # Flatten transparency onto white background before JPEG conversion
    if img.mode in ("RGBA", "LA", "P"):
        bg = Image.new("RGB", img.size, (255, 255, 255))
        if img.mode == "P":
            img = img.convert("RGBA")
        bg.paste(img, mask=img.split()[-1] if img.mode in ("RGBA", "LA") else None)
        img = bg
    elif img.mode != "RGB":
        img = img.convert("RGB")

    # Resize if larger than MAX_DIMENSION on either side
    w, h = img.size
    if max(w, h) > MAX_DIMENSION:
        scale = MAX_DIMENSION / max(w, h)
        img = img.resize((int(w * scale), int(h * scale)), Image.LANCZOS)

    out = io.BytesIO()
    img.save(out, format="JPEG", quality=JPEG_QUALITY, optimize=True)
    return out.getvalue()


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def run() -> None:
    svc = _blob_service()
    container_client = svc.get_container_client(CONTAINER)

    if not container_client.exists():
        print(f"Container '{CONTAINER}' does not exist. Run upload_prev_creatives.py first.")
        sys.exit(1)

    blobs = list(container_client.list_blobs())
    if not blobs:
        print("No blobs found in container.")
        return

    print(f"Found {len(blobs)} blob(s). Compressing...")

    compressed = 0
    skipped = 0
    failed = 0
    total_before = 0
    total_after = 0

    for i, blob in enumerate(blobs, 1):
        print(f"[{i}/{len(blobs)}] {blob.name}", end=" ... ")
        try:
            blob_client = container_client.get_blob_client(blob.name)
            raw = blob_client.download_blob().readall()
            size_before = len(raw)

            compressed_bytes = compress(raw)
            size_after = len(compressed_bytes)

            # Only overwrite if we actually made it smaller
            if size_after >= size_before:
                print(f"skipped (already small: {size_before // 1024} KB)")
                skipped += 1
                continue

            blob_client.upload_blob(
                compressed_bytes,
                overwrite=True,
                content_settings=ContentSettings(content_type="image/jpeg"),
            )

            total_before += size_before
            total_after += size_after
            saving_pct = (1 - size_after / size_before) * 100
            print(f"{size_before // 1024} KB → {size_after // 1024} KB ({saving_pct:.0f}% smaller)")
            compressed += 1

        except Exception as exc:
            print(f"FAILED — {exc}")
            failed += 1

    print(f"\nDone: {compressed} compressed, {skipped} skipped, {failed} failed.")
    if total_before:
        overall_saving = (1 - total_after / total_before) * 100
        print(
            f"Total size: {total_before // (1024*1024)} MB → "
            f"{total_after // (1024*1024)} MB ({overall_saving:.0f}% reduction)"
        )


if __name__ == "__main__":
    run()
