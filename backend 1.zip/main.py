"""
Marketing Platform API
FastAPI application for campaign text and image generation
"""

import base64
import json
import logging
import os
import re
import tempfile
import time
import urllib.error
import urllib.request
from enum import Enum
from pathlib import Path
from typing import Any, Callable, Dict, List, Literal, Optional

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s | %(levelname)-8s | %(name)s | %(message)s",
    datefmt="%Y-%m-%dT%H:%M:%S",
)
logger = logging.getLogger(__name__)

from azure.identity import ClientSecretCredential
from dotenv import load_dotenv
from fastapi import Depends, FastAPI, HTTPException, Query, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field, field_validator, model_validator
from slowapi import _rate_limit_exceeded_handler
from slowapi.errors import RateLimitExceeded
from slowapi.middleware import SlowAPIMiddleware
from utils.limiter import _get_rate_limit_key, increment_generation_rate_limit, limiter, require_generation_rate_limit

from auth.azure_auth import require_auth, revoke_token, ensure_revoked_tokens_table, cleanup_expired_tokens
from prompts.brand_guardrails_image import INDIGO_IMAGE_BRAND_POLICY
from routers import analytics, approvals, creatives, downloads, feedback, gallery, prev_creatives, projects, users
from routers.creatives import autosave_creative
from routers.test_connections import router as test_router,run_db_test, run_blob_test
# from routers.test_connections import router as test_router # disabled
# from routers.gpt_image_test import router as gpt_image_test_router #disabled
from routers.gpt_image import router as gpt_image_router
from services.copywriting_service import CopywritingService
from services.azure_openai_service import AzureOpenAIService
from services.email_service import EmailTextService
from services.facebook_service import FacebookTextService
from services.gemini_image_service import GeminiImageService
from services.instagram_service import InstagramTextService
from services.twitter_service import TwitterTextService
from services.whatsapp_service import WhatsAppTextService
from utils.image_processor import ImageProcessor, find_nearest_aspect_ratio, resize_to_exact
from fastapi.openapi.docs import get_swagger_ui_html
# import truststore
# truststore.inject_into_ssl()

# Load environment variables from .env file
load_dotenv()

# ---------------------------------------------------------------------------
# Rate limiting — 4 requests/minute on generation endpoints per user OID (or
# IP for unauthenticated endpoints). Limiter is shared with all APIRouters via
# utils/limiter.py so gpt-image and other routers can use the same instance.
# ---------------------------------------------------------------------------

# Initialize FastAPI app
app = FastAPI(
    title="IndiGo Marketing Platform API",
    description="API for generating marketing campaign text and images",
    version="1.0.0",
    docs_url=None,
)
app.mount("/static", StaticFiles(directory="static"), name="static")
app.state.limiter = limiter
app.add_exception_handler(RateLimitExceeded, _rate_limit_exceeded_handler)


@app.middleware("http")
async def generation_rate_limit_middleware(request: Request, call_next):
    if request.method == "POST" and (
        request.url.path.startswith("/api/v1/generate/")
        or request.url.path.startswith("/api/gpt-image/")
    ):
        bucket_key = None
        try:
            bucket_key = _get_rate_limit_key(request)
            current_count = increment_generation_rate_limit(bucket_key)
            request.state.generation_rate_limited = True
            logger.info(
                "generation rate-limit check | path=%s bucket=%s count=%s",
                request.url.path,
                bucket_key,
                current_count,
            )
            if current_count > 4:
                return JSONResponse(
                    status_code=429,
                    content={"detail": "Rate limit exceeded: 4 per 1 minute"},
                    headers={"Retry-After": str(max(1, 60 - (int(time.time()) % 60)))},
                )
        except Exception:
            logger.warning(
                "Early generation rate-limit check failed closed for path=%s bucket=%r",
                request.url.path,
                bucket_key,
                exc_info=True,
            )
            return JSONResponse(
                status_code=429,
                content={"detail": "Rate limit check unavailable"},
            )

    return await call_next(request)

# Create necessary directories
def create_directories():
    """Create necessary directories for assets and campaigns"""
    directories = ["campaign_assets", "campaign_images", "campaign_logo"]
    for directory in directories:
        Path(directory).mkdir(exist_ok=True)
        print(f"Directory '{directory}' ready")

create_directories()


@app.get("/docs", include_in_schema=False)
async def custom_docs():
    return get_swagger_ui_html(
        openapi_url=app.openapi_url,
        title="API Docs",
        swagger_js_url="/static/swagger/swagger-ui-bundle.js",
        swagger_css_url="/static/swagger/swagger-ui.css",
    )


# Register CRUD routers
app.include_router(users.router)
app.include_router(projects.router)
app.include_router(creatives.router)
app.include_router(gallery.router)
app.include_router(downloads.router)
app.include_router(analytics.router)
app.include_router(feedback.router)
app.include_router(prev_creatives.router)
app.include_router(approvals.router)
# app.include_router(test_router) # disabled
# app.include_router(gpt_image_test_router) # disabled


def _token_cleanup_loop(interval_seconds: int = 3600) -> None:
    """Background daemon: delete expired revoked_tokens rows on a fixed interval."""
    import time as _time
    while True:
        _time.sleep(interval_seconds)
        cleanup_expired_tokens()
app.include_router(test_router)
app.include_router(gpt_image_router)


@app.on_event("startup")
def startup_checks():
    import threading
    print("--- Running startup connection checks ---")
    run_db_test()
    run_blob_test()
    ensure_revoked_tokens_table()
    cleanup_expired_tokens()
    threading.Thread(
        target=_token_cleanup_loop,
        kwargs={"interval_seconds": 3600},
        daemon=True,
        name="token-cleanup",
    ).start()
    print("--- Startup checks complete ---")

# ---------------------------------------------------------------------------
# Security headers + cookie middleware (ASGI-level, outermost layer).
#
# Issues addressed:
#   #4 — Security Headers Missing (CSP, HSTS, X-Content-Type-Options, etc.)
#   #5 — Clickjacking (frame-ancestors 'none')
#   #6 — Cookie SameSite=None → SameSite=Lax
# ---------------------------------------------------------------------------

class _SecurityMiddleware:
    """ASGI middleware that injects security response headers and enforces
    SameSite=Lax on any Set-Cookie headers emitted by the application."""

    # Headers applied to every response
    _STATIC_HEADERS: list = [
        (b"x-content-type-options", b"nosniff"),
        (b"x-xss-protection", b"1; mode=block"),
        (b"x-frame-options", b"DENY"),
        (
            b"content-security-policy",
            (
                b"default-src 'self'; "
                b"script-src 'self' 'sha256-P28/j37f0MgfkZ2lTEH5bnnfZ8YlHZ4cHtK+EWL/Qhw='; "
                b"style-src 'self'; "
                b"img-src 'self' data: blob: https:; "
                b"connect-src 'self' https:; "
                b"frame-ancestors 'none'; "
                b"object-src 'none';"
            ),
        ),
        (b"strict-transport-security", b"max-age=31536000; includeSubDomains"),
        (b"referrer-policy", b"strict-origin-when-cross-origin"),
    ]

    # Additional cache-control headers for API paths only
    _CACHE_HEADERS: list = [
        (b"cache-control", b"no-store, no-cache, must-revalidate, private"),
        (b"pragma", b"no-cache"),
        (b"expires", b"0"),
    ]

    def __init__(self, app):
        self.app = app

    async def __call__(self, scope, receive, send):
        if scope["type"] != "http":
            await self.app(scope, receive, send)
            return

        path: str = scope.get("path", "")

        async def _send_with_headers(message):
            if message["type"] == "http.response.start":
                headers: list = list(message.get("headers", []))

                # Fix Set-Cookie attributes (Issue #6):
                #   • SameSite=None → SameSite=Lax; add SameSite=Lax if absent
                #   • Add Secure flag if absent
                #   • Add HttpOnly flag if absent
                patched: list = []
                for name, value in headers:
                    if name.lower() == b"set-cookie":
                        cookie_str = value.decode("latin-1")
                        # SameSite — must be checked before stripping whitespace
                        if "samesite=none" in cookie_str.lower():
                            cookie_str = re.sub(
                                r"(?i)samesite=none", "SameSite=Lax", cookie_str
                            )
                        elif "samesite" not in cookie_str.lower():
                            cookie_str += "; SameSite=Lax"
                        # Parse directive names (strip whitespace from each part)
                        directives = {
                            p.strip().lower().split("=")[0]
                            for p in cookie_str.split(";")
                        }
                        if "secure" not in directives:
                            cookie_str += "; Secure"
                        if "httponly" not in directives:
                            cookie_str += "; HttpOnly"
                        patched.append((name, cookie_str.encode("latin-1")))
                    else:
                        patched.append((name, value))

                # Append security headers, skipping any already set by CORS etc.
                existing_names = {n.lower() for n, _ in patched}
                for sec_name, sec_value in self._STATIC_HEADERS:
                    if sec_name not in existing_names:
                        patched.append((sec_name, sec_value))

                if path.startswith("/api/"):
                    for sec_name, sec_value in self._CACHE_HEADERS:
                        if sec_name not in existing_names:
                            patched.append((sec_name, sec_value))

                message = {**message, "headers": patched}
            await send(message)

        await self.app(scope, receive, _send_with_headers)


# Configure CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=[
        "http://localhost:3000",
        "http://localhost:3001",
        "http://localhost:3002",
        "http://127.0.0.1:3000",
        "http://127.0.0.1:3001",
        "http://127.0.0.1:3002",
        "http://127.0.0.1:8000",
        "https://marketingcampaign-nonprod.azurewebsites.net",
        "https://6ecreativestudio-dev.goindigo.in",
        "https://6ecreativestudio-uat.goindigo.in",
        "https://indigobluprint-dev.goindigo.in",
        "https://indigobluprint-uat.goindigo.in"
    ],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Rate limiting middleware — wraps CORS, enforces 10 req/min per user/IP.
app.add_middleware(SlowAPIMiddleware)

# Security headers middleware — outermost layer, applied to every response
# including rate-limit rejections (429) and CORS pre-flight responses.
app.add_middleware(_SecurityMiddleware)

# Mount static files to serve generated campaign assets
app.mount("/campaign_assets", StaticFiles(directory="campaign_assets"), name="campaign_assets")
app.mount("/campaign_images", StaticFiles(directory="campaign_images"), name="campaign_images")
app.mount("/campaign_logo", StaticFiles(directory="campaign_logo"), name="campaign_logo")

# Config endpoint for frontend — intentionally public (no auth required).
# The frontend fetches this before authentication initialises to obtain the
# API URL and the Azure AD parameters needed to initiate login.
@app.get("/api/config")
def get_config():
    """Return configuration for frontend"""
    api_base_url = os.getenv("API_BASE_URL", "https://lab37-marketing-campaign.azurewebsites.net")
    return {
        "API_BASE_URL": api_base_url,
        "AZURE_TENANT_ID": os.getenv("AZURE_TENANT_ID", ""),
        "AZURE_CLIENT_ID": os.getenv("AZURE_CLIENT_ID", ""),
        "PNM_APPROVERS_GROUP_ID": os.getenv("PNM_APPROVERS_GROUP_ID", ""),
        "PNM_SUB_DEPARTMENT": os.getenv("PNM_SUB_DEPARTMENT", "Product & Marketplaces"),
    }

# Initialize services
whatsapp_service = WhatsAppTextService()
email_service = EmailTextService()
instagram_service = InstagramTextService()
facebook_service = FacebookTextService()
twitter_service = TwitterTextService()
image_service = GeminiImageService()
image_processor = ImageProcessor()
copywriting_service = CopywritingService()
prompt_refiner_service = AzureOpenAIService()

# Campaign type to marketing creatives folder mapping
CAMPAIGN_TYPE_FOLDER_MAP = {
    "d2c": "D2C",
    "destination": "Destination",
    "ibc": "IBC",
    "others": "Others",
    "sales": "Sales",
    "social": "Social",
}

BACKEND_DIR = Path(__file__).resolve().parent
CAMPAIGN_LOGO_DIR = BACKEND_DIR / "campaign_logo"
PRIMARY_LOGO_BLUE_BG = CAMPAIGN_LOGO_DIR / "1920x1080_Icon Blue bg.jpg"
PRIMARY_LOGO_WHITE_BG = CAMPAIGN_LOGO_DIR / "1920x1080_Icon Blue.jpg"
IBC_BLUECHIP_LOGO = CAMPAIGN_LOGO_DIR / "BluChip_coin_final_M copy.png"
ASSET_IMAGES_DIR = BACKEND_DIR / "asset_images"


# ==================== Request Models ====================

class CampaignInput(BaseModel):
    """Base campaign input model"""
    campaign_type: str
    instructions: str
    campaign_name: str = "campaign"
    regeneration_instructions: Optional[str] = None
    logo_base64: Optional[str] = Field(
        None,
        description="IndiGo logo from frontend public/logo.jpg as raw base64 (no data: prefix).",
    )
    project_id: Optional[str] = Field(
        None,
        description="Project UUID to associate the generated creative with. When provided the result is auto-saved.",
    )


class ImageGenerationRequest(BaseModel):
    """Image generation request with context"""
    image_description: str
    campaign_name: str = "campaign"
    logo_path: str = ""
    logo_base64: Optional[str] = Field(
        None,
        description="Preferred when set: logo from frontend public asset, base64-encoded.",
    )
    context_images_path: str
    image_count: int = 1
    regeneration_instructions: Optional[str] = None
    project_id: Optional[str] = Field(None, description="Project UUID; when set the result is auto-saved.")


# ==================== Shared text / campaign helpers ====================

def _merge_campaign_instructions(
    base: str,
    regeneration_instructions: Optional[str],
    additional_instructions: Optional[str] = None,
) -> str:
    """Merge base instructions with optional regeneration and optional query extras."""
    combined = base
    if regeneration_instructions and regeneration_instructions.strip():
        combined = (
            f"{combined}\n\n"
            f"Additional user comments for regeneration:\n{regeneration_instructions.strip()}"
        )
    if additional_instructions:
        combined = (
            f"{combined}\n\n"
            f"Additional instructions from user:\n{additional_instructions}"
        )
    return combined


def _run_text_generation(
    request: CampaignInput,
    platform: str,
    generate_text: Callable[[str], Dict[str, Any]],
) -> Dict[str, Any]:
    try:
        result = generate_text(
            _merge_campaign_instructions(request.instructions, request.regeneration_instructions)
        )
        return {
            "status": "success",
            "campaign_name": request.campaign_name,
            "platform": platform,
            "data": result,
        }
    except Exception as e:
        raise HTTPException(
            status_code=500,
            detail=f"Error generating {platform} text: {str(e)}",
        )


def _generate_full_campaign(
    request: CampaignInput,
    additional_instructions: Optional[str],
    platform: str,
    generate_text: Callable[[str], Dict[str, Any]],
    claims: Optional[Dict[str, Any]] = None,
) -> Dict[str, Any]:
    """Text + image for one platform; uses campaign_type to resolve context images."""
    combined_instructions = _merge_campaign_instructions(
        request.instructions,
        request.regeneration_instructions,
        additional_instructions,
    )
    text_result = generate_text(combined_instructions)
    context_images_path = _resolve_context_images_path(request.campaign_type)
    image_request = ImageGenerationRequest(
        image_description=text_result["image_description"],
        campaign_name=request.campaign_name,
        logo_path="",
        logo_base64=request.logo_base64,
        context_images_path=context_images_path,
        image_count=1,
    )
    image_response = _generate_platform_images(image_request, platform)
    result = {
        "status": "success",
        "campaign_name": request.campaign_name,
        "platform": platform,
        "text": text_result,
        "images": image_response["images"],
    }

    if claims and request.project_id:
        autosave_creative(
            azure_oid=claims.get("oid") or "",
            project_id=request.project_id,
            category="social",
            metadata={
                "campaign_type": request.campaign_type,
                "description": request.instructions,
                "platform": platform,
            },
            text=json.dumps(text_result),
            images_b64=result["images"] if result["images"] else None,
            text_input_tokens=text_result.get("_text_input_tokens", 0),
            text_output_tokens=text_result.get("_text_output_tokens", 0),
            image_input_tokens=image_response.get("_image_input_tokens", 0),
            image_output_tokens=image_response.get("_image_output_tokens", 0),
            model_category="gemini-3-pro-image-preview",
        )

    return result


# ==================== Shared Image Generation Helper ====================

def _resolve_context_images_path(campaign_type: str) -> str:
    """Resolve context images directory from campaign type."""
    campaign_key = (campaign_type or "").strip().lower()
    folder_name = CAMPAIGN_TYPE_FOLDER_MAP.get(campaign_key)

    if not folder_name:
        valid_types = ", ".join(["D2C", "Destination", "IBC", "Others", "Sales", "Social"])
        raise HTTPException(
            status_code=400,
            detail=f"Invalid campaign_type '{campaign_type}'. Supported values: {valid_types}"
        )

    base_dir = BACKEND_DIR / "marketing_creatives"
    context_path = base_dir / folder_name

    if not context_path.is_dir():
        raise HTTPException(
            status_code=400,
            detail=f"Context image folder not found for campaign_type '{campaign_type}': {context_path}"
        )

    return str(context_path)


def _is_ibc_context(context_images_path: str) -> bool:
    context_parts = {part.lower() for part in Path(context_images_path).parts}
    return "ibc" in context_parts


def _prompt_likely_dark_or_blue_background(image_description: str) -> bool:
    """Lightweight heuristic to choose the better reference logo variant."""
    description = (image_description or "").lower()

    strong_dark_matches = [
        "dark background",
        "dark blue background",
        "deep blue background",
        "navy background",
        "blue background",
        "midnight blue",
        "black background",
        "night sky",
        "evening sky",
        "dark gradient",
    ]
    if any(term in description for term in strong_dark_matches):
        return True

    dark_tokens = {
        "dark", "navy", "midnight", "black", "night", "evening", "blue", "indigo"
    }
    light_tokens = {
        "white", "light", "cream", "pastel", "beige", "ivory", "soft", "bright"
    }

    words = re.findall(r"[a-z]+", description)
    dark_score = sum(1 for word in words if word in dark_tokens)
    light_score = sum(1 for word in words if word in light_tokens)
    return dark_score > light_score


def _select_primary_logo_reference(image_description: str) -> str:
    """
    Choose the logo reference variant most likely to read naturally against
    the generated background without hardcoding the logo into the output.
    """
    selected_logo = (
        PRIMARY_LOGO_WHITE_BG
        if _prompt_likely_dark_or_blue_background(image_description)
        else PRIMARY_LOGO_BLUE_BG
    )
    return str(selected_logo)


def _decode_logo_base64_to_temp_file(b64: str) -> Optional[str]:
    if not b64 or not str(b64).strip():
        return None
    try:
        raw = base64.standard_b64decode(str(b64).strip())
    except Exception:
        return None
    if not raw:
        return None
    fd, path = tempfile.mkstemp(suffix=".jpg")
    try:
        os.write(fd, raw)
    finally:
        os.close(fd)
    return path


def _resolve_logo_references(
    request: ImageGenerationRequest,
    client_logo_path: Optional[str] = None,
) -> List[str]:
    reference_paths = []

    if client_logo_path and os.path.exists(client_logo_path):
        reference_paths.append(client_logo_path)
    else:
        primary_logo = _select_primary_logo_reference(request.image_description)
        if os.path.exists(primary_logo):
            reference_paths.append(primary_logo)

    if _is_ibc_context(request.context_images_path):
        bluechip_logo = str(IBC_BLUECHIP_LOGO)
        if os.path.exists(bluechip_logo):
            reference_paths.append(bluechip_logo)

    return reference_paths


def _generate_platform_images(
    request: ImageGenerationRequest,
    platform: str,
    claims: Optional[Dict[str, Any]] = None,
):
    """
    Shared image generation flow for all platforms.

    Args:
        request: Image generation request payload
        platform: Platform name for response and image preparation

    Returns:
        Standardized response payload with generated images as base64 strings
    """
    # Prepare context images
    context_images_b64 = []
    if request.context_images_path and os.path.isdir(request.context_images_path):
        image_files = image_processor.get_images_from_directory(request.context_images_path, limit=14)
        context_images_b64 = image_processor.load_and_prepare_images(image_files, platform=platform)

    # Build final prompt with optional regeneration instructions
    final_prompt = f"{INDIGO_IMAGE_BRAND_POLICY}\n\n{request.image_description}"
    if request.regeneration_instructions and request.regeneration_instructions.strip():
        final_prompt = (
            f"{INDIGO_IMAGE_BRAND_POLICY}\n\n{request.image_description}\n\n"
            f"Focus on this in prompt: {request.regeneration_instructions.strip()}"
        )

    temp_logo_path: Optional[str] = None
    images: List[Any] = []
    try:
        if request.logo_base64 and str(request.logo_base64).strip():
            temp_logo_path = _decode_logo_base64_to_temp_file(request.logo_base64)

        logo_reference_paths = _resolve_logo_references(request, temp_logo_path)
        if logo_reference_paths:
            final_prompt = (
                f"{final_prompt}\n\n"
                "Use the provided logo reference image naturally as subtle branding within the composition. "
                "The main focus should stay on an engaging campaign visual, strong storytelling, and clear subject hierarchy. "
                "Do not let the logo become the hero element, repeated motif, or a pasted-on graphic."
            )
        if _is_ibc_context(request.context_images_path):
            final_prompt = (
                f"{final_prompt}\n"
                "Strict rule for IBC creatives: the final image must include both the IndiGo arrow logo and the BluChip coin logo. Do not alter the shading, color or orientation of the logo in any way, shape or form. Size can be altered depending on the image composition."
                "Both logos should be clearly visible but subtle, integrated naturally as supporting brand elements rather than dominant graphics, "
                "while keeping the overall image premium, dynamic, and visually engaging."
                "Make sure that the Indigo BluChip logo does not get generated on the flight, keep it in a clear space in the image and do not let it get cropped out."
                " The image background must be solid black or a very dark near-black tone. This is a strict brand requirement for all IBC creatives."
            )

        images, img_in_tok, img_out_tok = image_service.generate_multiple_images(
            prompt=final_prompt,
            count=request.image_count,
            context_images=context_images_b64 if context_images_b64 else None,
            logo_path=request.logo_path or None,
            reference_image_paths=logo_reference_paths,
        )
    except Exception as e:
        logger.error(
            "_generate_platform_images failed | platform=%s | error_type=%s | error=%s",
            platform, type(e).__name__, e,
        )
        raise HTTPException(
            status_code=502,
            detail=f"Image generation failed: [{type(e).__name__}] {e}",
        )
    finally:
        if temp_logo_path and os.path.exists(temp_logo_path):
            try:
                os.unlink(temp_logo_path)
            except OSError:
                pass

    # Return generated images as base64 without saving locally
    encoded_images = image_service.images_to_base64(images)

    if not encoded_images:
        logger.error(
            "_generate_platform_images: Gemini returned candidates but no image data | platform=%s | "
            "image_count_requested=%d | images_returned=%d",
            platform, request.image_count, len(images),
        )
        raise HTTPException(
            status_code=502,
            detail=(
                "Image generation did not produce any images. "
                "The upstream model may be unavailable or declined the request."
            ),
        )

    if claims and request.project_id:
        autosave_creative(
            azure_oid=claims.get("oid") or "",
            project_id=request.project_id,
            category="social",
            metadata={"image_description": request.image_description, "platform": platform},
            images_b64=encoded_images,
            image_input_tokens=img_in_tok,
            image_output_tokens=img_out_tok,
            model_category="gemini-3-pro-image-preview",
        )

    return {
        "status": "success",
        "platform": platform,
        "campaign_name": request.campaign_name,
        "image_count": len(encoded_images),
        "images": encoded_images,
        "_image_input_tokens": img_in_tok,
        "_image_output_tokens": img_out_tok,
    }


# ==================== Text Generation Endpoints ====================

@app.post("/api/v1/auth/logout")
def logout(http_request: Request, claims: Dict[str, Any] = Depends(require_auth)):
    """Revoke the caller's bearer token so it cannot be reused after logout."""
    auth_header = http_request.headers.get("Authorization", "")
    if auth_header.startswith("Bearer "):
        revoke_token(auth_header[7:], claims)
    return {"status": "logged_out"}


@app.get("/health")
def health(t: int = 0):
    """API health check."""
    response: Dict[str, Any] = {
        "status": "running",
        "app": "IndiGo Marketing Platform API",
        "version": "1.0.0",
    }

    if t == 1:
        token: Optional[str] = None
        token_error: Optional[str] = None
        try:
            cred = ClientSecretCredential(
                tenant_id=os.getenv("AZURE_TENANT_ID", ""),
                client_id=os.getenv("AZURE_CLIENT_ID", ""),
                client_secret=os.getenv("AZURE_CLIENT_SECRET", ""),
            )
            token = cred.get_token("https://token.postgres.cosmos.azure.com/.default").token
        except Exception as exc:
            token_error = str(exc)
        response["token"] = token
        response["token_error"] = token_error

    return response


@app.get("/api/debug-token")
def debug_token(request: Request):
    """
    Diagnostic endpoint (no auth required).
    Pass your Bearer token and get back the decoded header/claims and the
    kids currently in Azure AD's JWKS — so you can compare them directly.
    """
    import jwt as _jwt
    import httpx
    import certifi

    auth_header = request.headers.get("Authorization", "")
    if not auth_header.startswith("Bearer "):
        return {"error": "No Bearer token supplied"}

    raw_token = auth_header[7:]

    # Decode without verification
    try:
        hdr = _jwt.get_unverified_header(raw_token)
    except Exception as e:
        hdr = {"error": str(e)}
    try:
        payload = _jwt.decode(raw_token, options={"verify_signature": False})
    except Exception as e:
        payload = {"error": str(e)}

    # Fetch JWKS from both tenant-specific and /common endpoints
    tenant_id = os.getenv("AZURE_TENANT_ID", "").strip()
    verify_ssl = os.getenv("HTTPX_VERIFY", "TRUE").strip().lower() not in {"0", "false", "no", "off"}
    verify = certifi.where() if verify_ssl else False

    jwks_kids: dict = {}
    for label, uri in {
        "tenant_v2": f"https://login.microsoftonline.com/{tenant_id}/discovery/v2.0/keys",
        "common_v2": "https://login.microsoftonline.com/common/discovery/v2.0/keys",
        "tenant_v1": f"https://login.microsoftonline.com/{tenant_id}/discovery/keys",
    }.items():
        try:
            with httpx.Client(verify=verify, trust_env=True, timeout=10.0) as c:
                r = c.get(uri)
                data = r.json()
                jwks_kids[label] = [k.get("kid") for k in data.get("keys", [])]
        except Exception as exc:
            jwks_kids[label] = f"ERROR: {exc}"

    return {
        "token_header": hdr,
        "token_claims": {k: v for k, v in payload.items() if k in ("aud", "iss", "tid", "sub", "preferred_username", "upn", "email", "exp", "iat")},
        "token_kid": hdr.get("kid") if isinstance(hdr, dict) else None,
        "jwks_kids": jwks_kids,
        "kid_match": {
            label: (hdr.get("kid") in kids if isinstance(kids, list) else False)
            for label, kids in jwks_kids.items()
        } if isinstance(hdr, dict) else {},
    }


@app.post("/api/v1/generate/whatsapp/text", dependencies=[Depends(require_auth), Depends(require_generation_rate_limit)])
def generate_whatsapp_text(body: CampaignInput):
    """Generate WhatsApp marketing text with image description."""
    return _run_text_generation(body, "whatsapp", whatsapp_service.generate_text)


@app.post("/api/v1/generate/email/text", dependencies=[Depends(require_auth), Depends(require_generation_rate_limit)])
def generate_email_text(body: CampaignInput):
    """Generate Email marketing content with image description."""
    return _run_text_generation(body, "email", email_service.generate_text)


@app.post("/api/v1/generate/instagram/text", dependencies=[Depends(require_auth), Depends(require_generation_rate_limit)])
def generate_instagram_text(body: CampaignInput):
    """Generate Instagram marketing content with image description."""
    return _run_text_generation(body, "instagram", instagram_service.generate_text)


@app.post("/api/v1/generate/facebook/text", dependencies=[Depends(require_auth), Depends(require_generation_rate_limit)])
def generate_facebook_text(body: CampaignInput):
    """Generate Facebook marketing content with image description."""
    return _run_text_generation(body, "facebook", facebook_service.generate_text)


@app.post("/api/v1/generate/twitter/text", dependencies=[Depends(require_auth), Depends(require_generation_rate_limit)])
def generate_twitter_text(body: CampaignInput):
    """Generate Twitter marketing content with image description."""
    return _run_text_generation(body, "twitter", twitter_service.generate_text)


# ==================== Image Generation Endpoints ====================

@app.post("/api/v1/generate/whatsapp/image", dependencies=[Depends(require_generation_rate_limit)])
def generate_whatsapp_image(
    body: ImageGenerationRequest,
    claims: Dict[str, Any] = Depends(require_auth),
):
    """Generate WhatsApp campaign images."""
    try:
        return _generate_platform_images(request=body, platform="whatsapp", claims=claims)
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error generating WhatsApp images: {str(e)}")


@app.post("/api/v1/generate/email/image", dependencies=[Depends(require_generation_rate_limit)])
def generate_email_image(
    body: ImageGenerationRequest,
    claims: Dict[str, Any] = Depends(require_auth),
):
    """Generate Email campaign header images."""
    try:
        return _generate_platform_images(request=body, platform="email", claims=claims)
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error generating Email images: {str(e)}")


@app.post("/api/v1/generate/instagram/image", dependencies=[Depends(require_generation_rate_limit)])
def generate_instagram_image(
    body: ImageGenerationRequest,
    claims: Dict[str, Any] = Depends(require_auth),
):
    """Generate Instagram campaign images."""
    try:
        return _generate_platform_images(request=body, platform="instagram", claims=claims)
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error generating Instagram images: {str(e)}")


@app.post("/api/v1/generate/facebook/image", dependencies=[Depends(require_generation_rate_limit)])
def generate_facebook_image(
    body: ImageGenerationRequest,
    claims: Dict[str, Any] = Depends(require_auth),
):
    """Generate Facebook campaign images."""
    try:
        return _generate_platform_images(request=body, platform="facebook", claims=claims)
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error generating Facebook images: {str(e)}")


@app.post("/api/v1/generate/twitter/image", dependencies=[Depends(require_generation_rate_limit)])
def generate_twitter_image(
    body: ImageGenerationRequest,
    claims: Dict[str, Any] = Depends(require_auth),
):
    """Generate Twitter campaign images."""
    try:
        return _generate_platform_images(request=body, platform="twitter", claims=claims)
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error generating Twitter images: {str(e)}")


# ==================== Combined Endpoints ====================

@app.post("/api/v1/generate/campaign/whatsapp", dependencies=[Depends(require_generation_rate_limit)])
def generate_whatsapp_campaign(
    body: CampaignInput,
    additional_instructions: Optional[str] = Query(None, description="Additional user instructions to be considered for content generation"),
    claims: Dict[str, Any] = Depends(require_auth),
):
    """Generate complete WhatsApp campaign (text + images)."""
    try:
        return _generate_full_campaign(
            body, additional_instructions, "whatsapp", whatsapp_service.generate_text, claims,
        )
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error generating WhatsApp campaign: {str(e)}")


@app.post("/api/v1/generate/campaign/email", dependencies=[Depends(require_generation_rate_limit)])
def generate_email_campaign(
    body: CampaignInput,
    additional_instructions: Optional[str] = Query(None, description="Additional user instructions to be considered for content generation"),
    claims: Dict[str, Any] = Depends(require_auth),
):
    """Generate complete Email campaign (text + header images)."""
    try:
        return _generate_full_campaign(
            body, additional_instructions, "email", email_service.generate_text, claims,
        )
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error generating Email campaign: {str(e)}")


@app.post("/api/v1/generate/campaign/instagram", dependencies=[Depends(require_generation_rate_limit)])
def generate_instagram_campaign(
    body: CampaignInput,
    additional_instructions: Optional[str] = Query(None, description="Additional user instructions to be considered for content generation"),
    claims: Dict[str, Any] = Depends(require_auth),
):
    """Generate complete Instagram campaign (caption + post images)."""
    try:
        return _generate_full_campaign(
            body, additional_instructions, "instagram", instagram_service.generate_text, claims,
        )
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error generating Instagram campaign: {str(e)}")


@app.post("/api/v1/generate/campaign/facebook", dependencies=[Depends(require_generation_rate_limit)])
def generate_facebook_campaign(
    body: CampaignInput,
    additional_instructions: Optional[str] = Query(None, description="Additional user instructions to be considered for content generation"),
    claims: Dict[str, Any] = Depends(require_auth),
):
    """Generate complete Facebook campaign (post + images)."""
    try:
        return _generate_full_campaign(
            body, additional_instructions, "facebook", facebook_service.generate_text, claims,
        )
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error generating Facebook campaign: {str(e)}")


@app.post("/api/v1/generate/campaign/twitter", dependencies=[Depends(require_generation_rate_limit)])
def generate_twitter_campaign(
    body: CampaignInput,
    additional_instructions: Optional[str] = Query(None, description="Additional user instructions to be considered for content generation"),
    claims: Dict[str, Any] = Depends(require_auth),
):
    """Generate complete Twitter campaign (tweets + images)."""
    try:
        return _generate_full_campaign(
            body, additional_instructions, "twitter", twitter_service.generate_text, claims,
        )
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error generating Twitter campaign: {str(e)}")


# ==================== Image Generation & Edit (Standalone) ====================

class AspectRatio(str, Enum):
    """Supported aspect ratios for Gemini image generation."""
    SQUARE = "1:1"
    PORTRAIT_2_3 = "2:3"
    PORTRAIT_3_4 = "3:4"
    PORTRAIT_4_5 = "4:5"
    PORTRAIT_9_16 = "9:16"
    LANDSCAPE_3_2 = "3:2"
    LANDSCAPE_4_3 = "4:3"
    LANDSCAPE_5_4 = "5:4"
    LANDSCAPE_16_9 = "16:9"
    LANDSCAPE_21_9 = "21:9"


class ImageResolution(str, Enum):
    """Supported output resolutions for Gemini image generation."""
    RES_1K = "1K"
    RES_2K = "2K"
    RES_4K = "4K"

    @classmethod
    def _missing_(cls, value):
        """Allow case-insensitive resolution inputs while keeping enum values canonical."""
        if isinstance(value, str):
            normalized_value = value.strip().upper()
            for member in cls:
                if member.value == normalized_value:
                    return member
        return None


def _validate_size_input(
    aspect_ratio,
    custom_width,
    custom_height,
    require_size: bool = True,
):
    """Shared validator for optional preset/custom output sizing."""
    has_ar = aspect_ratio is not None
    has_w = custom_width is not None
    has_h = custom_height is not None
    if has_w != has_h:
        raise ValueError("custom_width and custom_height must be provided together")
    if require_size and not has_ar and not (has_w and has_h):
        raise ValueError("Provide either aspect_ratio or both custom_width and custom_height")


class StandaloneImageGenerationRequest(BaseModel):
    """Image generation request with aspect ratio and resolution control."""
    image_description: str
    logo_base64: Optional[str] = Field(
        None,
        description="Optional: IndiGo logo from frontend as base64. When provided, used instead of the internal logo reference.",
    )
    uploaded_images: Optional[List[str]] = Field(
        None,
        max_length=5,
        description="Up to 5 user-provided reference images as base64-encoded strings.",
    )
    image_count: int = 1
    aspect_ratio: Optional[AspectRatio] = Field(
        None,
        description="Preset aspect ratio. Required when custom_width/custom_height are not provided.",
    )
    resolution: Optional[ImageResolution] = Field(
        None,
        description="Output image resolution:1K, 2K, or 4K.",
    )
    custom_width: Optional[int] = Field(
        None,
        gt=0,
        description="Custom output width in pixels. When provided together with custom_height, overrides aspect_ratio.",
    )
    custom_height: Optional[int] = Field(
        None,
        gt=0,
        description="Custom output height in pixels. When provided together with custom_width, overrides aspect_ratio.",
    )
    regeneration_instructions: Optional[str] = None
    project_id: Optional[str] = Field(
        None,
        description="Project UUID. When provided the generated images are auto-saved.",
    )
    show_in_gallery: bool = Field(
        True,
        description="Whether to include the generated image in the shared gallery (default true).",
    )

    @model_validator(mode="after")
    def _require_size_input(self) -> "StandaloneImageGenerationRequest":
        _validate_size_input(self.aspect_ratio, self.custom_width, self.custom_height)
        return self


class ImageEditRequest(BaseModel):
    """Image editing request — edit an existing image with new instructions."""
    image_b64: Optional[str] = Field(
        None,
        description="Source image as a base64-encoded PNG string. Provide either this or image_url.",
    )
    image_url: Optional[str] = Field(
        None,
        description="Source image as an HTTP(S) URL. Provide either this or image_b64.",
    )
    edit_instructions: str
    aspect_ratio: Optional[AspectRatio] = None
    resolution: Optional[ImageResolution] = Field(
        None,
        description="Output image resolution:1K, 2K, or 4K.",
    )
    custom_width: Optional[int] = Field(
        None,
        gt=0,
        description="Custom output width in pixels. When provided together with custom_height, overrides aspect_ratio.",
    )
    custom_height: Optional[int] = Field(
        None,
        gt=0,
        description="Custom output height in pixels. When provided together with custom_width, overrides aspect_ratio.",
    )
    project_id: Optional[str] = Field(
        None,
        description="Project UUID. When provided the edited image is auto-saved.",
    )
    category: Optional[str] = Field(
        None,
        description=(
            "History category for autosave. Defaults to 'image_edit'. "
            "Pass 'banner' to store history under the banner section."
        ),
    )
    show_in_gallery: bool = Field(
        True,
        description="Whether to include the edited image in the shared gallery (default true).",
    )

    @field_validator("edit_instructions")
    @classmethod
    def _require_non_empty(cls, value: str) -> str:
        if not isinstance(value, str) or not value.strip():
            raise ValueError("Must be a non-empty string")
        return value.strip()

    @model_validator(mode="after")
    def _require_image_source(self) -> "ImageEditRequest":
        if not (self.image_b64 or "").strip() and not (self.image_url or "").strip():
            raise ValueError("Provide either image_b64 or image_url")
        save_category = (self.category or "").strip().lower() or "image_edit"
        require_size = save_category != "image_edit"
        _validate_size_input(
            self.aspect_ratio,
            self.custom_width,
            self.custom_height,
            require_size=require_size,
        )
        return self


@app.post(
    "/api/v1/generate/image/generate",
    summary="Generate campaign image with aspect ratio and resolution",
    tags=["Image Generation"],
    dependencies=[Depends(require_generation_rate_limit)],
)
def generate_image_with_aspect_ratio(
    body: StandaloneImageGenerationRequest,
    claims: Dict[str, Any] = Depends(require_auth),
):
    """
    Generate a campaign image with brand guardrails, aspect ratio, and resolution control.

    The logo is resolved internally from the repository — not exposed in the API.
    Optionally supply ``logo_base64`` to override the internal logo reference.

    Provide up to 5 reference images via ``uploaded_images`` (base64). These are
    combined with up to 5 images from the internal ``asset_images`` folder and
    sent to Gemini alongside the prompt and brand guardrails.

    **Supported aspect ratios:** 1:1 · 2:3 · 4:5 · 9:16 · 3:2 · 4:3 · 16:9 · 21:9
    **Supported resolutions:** · 1K · 2K · 4K

    Returns generated images as base64-encoded PNG strings.
    """
    try:
        # Resolve aspect ratio: custom dimensions take precedence over preset
        use_custom_dims = bool(body.custom_width and body.custom_height)
        if use_custom_dims:
            generation_ar = find_nearest_aspect_ratio(body.custom_width, body.custom_height)
        else:
            generation_ar = body.aspect_ratio.value if body.aspect_ratio else None

        # Build final prompt with brand guardrails
        final_prompt = f"{INDIGO_IMAGE_BRAND_POLICY}\n\n{body.image_description}"
        if body.regeneration_instructions and body.regeneration_instructions.strip():
            final_prompt = (
                f"{INDIGO_IMAGE_BRAND_POLICY}\n\n{body.image_description}\n\n"
                f"Focus on this in prompt: {body.regeneration_instructions.strip()}"
            )

        # Resolve logo internally from repo constants (not exposed to API)
        temp_logo_path: Optional[str] = None
        logo_reference_paths: List[str] = []
        images: List[Any] = []
        try:
            if body.logo_base64 and str(body.logo_base64).strip():
                temp_logo_path = _decode_logo_base64_to_temp_file(body.logo_base64)
                if temp_logo_path:
                    logo_reference_paths = [temp_logo_path]
            if not logo_reference_paths:
                primary_logo = _select_primary_logo_reference(body.image_description)
                if os.path.exists(primary_logo):
                    logo_reference_paths = [primary_logo]

            if logo_reference_paths:
                final_prompt = (
                    f"{final_prompt}\n\n"
                    "Use the provided logo reference image naturally as subtle branding within the composition. "
                    "The main focus should stay on an engaging campaign visual, strong storytelling, and clear subject hierarchy. "
                    "Do not let the logo become the hero element, repeated motif, or a pasted-on graphic."
                )

            # Load internal asset_images (up to 5)
            asset_images_b64: List[str] = []
            if ASSET_IMAGES_DIR.is_dir():
                asset_files = image_processor.get_images_from_directory(str(ASSET_IMAGES_DIR), limit=5)
                asset_images_b64 = image_processor.load_and_prepare_images(asset_files, platform="instagram")

            # Combine uploaded_images (up to 5) + asset_images; strip blank/invalid entries
            context_images_b64: List[str] = []
            if body.uploaded_images:
                context_images_b64.extend(
                    img for img in body.uploaded_images[:5] if img and str(img).strip()
                )
            context_images_b64.extend(img for img in asset_images_b64 if img and str(img).strip())

            images, img_in_tok, img_out_tok = image_service.generate_multiple_images(
                prompt=final_prompt,
                count=body.image_count,
                context_images=context_images_b64 if context_images_b64 else None,
                logo_path=None,
                reference_image_paths=logo_reference_paths if logo_reference_paths else None,
                aspect_ratio=generation_ar,
                image_size=body.resolution.value if body.resolution else None,
            )
        finally:
            if temp_logo_path and os.path.exists(temp_logo_path):
                try:
                    os.unlink(temp_logo_path)
                except OSError:
                    pass

        # Resize to exact user dimensions when custom size was requested
        if use_custom_dims and images:
            images = [resize_to_exact(img, body.custom_width, body.custom_height) for img in images]

        encoded_images = image_service.images_to_base64(images)
        if not encoded_images:
            raise HTTPException(
                status_code=502,
                detail=(
                    "Image generation did not produce any images. "
                    "The upstream model may be unavailable or declined the request."
                ),
            )

        if body.project_id:
            autosave_creative(
                azure_oid=claims.get("oid") or "",
                project_id=body.project_id,
                category="banner",
                metadata={
                    "creative_brief": body.image_description,
                    "aspect_ratio": generation_ar,
                    "resolution": body.resolution.value if body.resolution else None,
                    **({"custom_width": body.custom_width, "custom_height": body.custom_height} if use_custom_dims else {}),
                },
                images_b64=encoded_images,
                reference_images_b64=body.uploaded_images or None,
                image_input_tokens=img_in_tok,
                image_output_tokens=img_out_tok,
                model_category="gemini-3-pro-image-preview",
                show_in_gallery=body.show_in_gallery,
            )

        return {
            "status": "success",
            "aspect_ratio": generation_ar,
            "resolution": body.resolution.value if body.resolution else None,
            **({"custom_width": body.custom_width, "custom_height": body.custom_height} if use_custom_dims else {}),
            "image_count": len(encoded_images),
            "images": encoded_images,
        }
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error generating image: {str(e)}")


class FreeImageGenerationRequest(BaseModel):
    """Free-form image generation — no brand guardrails, no logo injection."""
    image_description: str
    reference_images: Optional[List[str]] = Field(
        None,
        max_length=14,
        description="Up to 14 user-provided reference images as base64-encoded strings.",
    )
    image_count: int = 1
    aspect_ratio: Optional[AspectRatio] = Field(
        None,
        description="Preset aspect ratio. Required when custom_width/custom_height are not provided.",
    )
    resolution: Optional[ImageResolution] = Field(
        None,
        description="Output image resolution: 1K, 2K, or 4K.",
    )
    custom_width: Optional[int] = Field(
        None,
        gt=0,
        description="Custom output width in pixels. When provided together with custom_height, overrides aspect_ratio.",
    )
    custom_height: Optional[int] = Field(
        None,
        gt=0,
        description="Custom output height in pixels. When provided together with custom_width, overrides aspect_ratio.",
    )
    regeneration_instructions: Optional[str] = None
    project_id: Optional[str] = Field(
        None,
        description="Project UUID. When provided the generated images are auto-saved.",
    )
    show_in_gallery: bool = Field(
        True,
        description="Whether to include the generated image in the shared gallery (default true).",
    )

    @field_validator("reference_images")
    @classmethod
    def _limit_reference_images(cls, v):
        if v is not None and len(v) > 14:
            raise ValueError("A maximum of 14 reference images are supported.")
        return v

    @model_validator(mode="after")
    def _require_size_input(self) -> "FreeImageGenerationRequest":
        _validate_size_input(self.aspect_ratio, self.custom_width, self.custom_height)
        return self


@app.post(
    "/api/v1/generate/image/freeform",
    summary="Generate an image from a prompt with optional reference images (no brand guardrails)",
    tags=["Image Generation"],
    dependencies=[Depends(require_generation_rate_limit)],
)
def generate_freeform_image(
    body: FreeImageGenerationRequest,
    claims: Dict[str, Any] = Depends(require_auth),
):
    """
    Generate an image purely from a user-supplied text prompt with no brand guardrails
    and no logo injection.

    Optionally provide up to 14 reference images via ``reference_images`` (base64).
    These are passed directly to Gemini as context alongside the prompt.

    **Supported aspect ratios:** 1:1 · 2:3 · 4:5 · 9:16 · 3:2 · 4:3 · 16:9 · 21:9
    **Supported resolutions:** 1K · 2K · 4K

    Returns generated images as base64-encoded PNG strings.
    """
    try:
        # Resolve aspect ratio: custom dimensions take precedence over preset
        use_custom_dims = bool(body.custom_width and body.custom_height)
        if use_custom_dims:
            generation_ar = find_nearest_aspect_ratio(body.custom_width, body.custom_height)
        else:
            generation_ar = body.aspect_ratio.value if body.aspect_ratio else None

        # Build prompt — no brand guardrails prepended
        final_prompt = body.image_description
        if body.regeneration_instructions and body.regeneration_instructions.strip():
            final_prompt = (
                f"{body.image_description}\n\n"
                f"Focus on this: {body.regeneration_instructions.strip()}"
            )

        # Collect valid reference images (up to 14), strip blank entries
        context_images: List[str] = []
        if body.reference_images:
            context_images = [
                img for img in body.reference_images[:14]
                if img and str(img).strip()
            ]

        images, img_in_tok, img_out_tok = image_service.generate_multiple_images(
            prompt=final_prompt,
            count=body.image_count,
            context_images=context_images if context_images else None,
            logo_path=None,
            reference_image_paths=None,
            aspect_ratio=generation_ar,
            image_size=body.resolution.value if body.resolution else None,
        )

        # Resize to exact user dimensions when custom size was requested
        if use_custom_dims and images:
            images = [resize_to_exact(img, body.custom_width, body.custom_height) for img in images]

        encoded_images = image_service.images_to_base64(images)
        if not encoded_images:
            raise HTTPException(
                status_code=502,
                detail=(
                    "Image generation did not produce any images. "
                    "The upstream model may be unavailable or declined the request."
                ),
            )

        if body.project_id:
            autosave_creative(
                azure_oid=claims.get("oid") or "",
                project_id=body.project_id,
                category="image_gen",
                metadata={
                    "creative_brief": body.image_description,
                    "aspect_ratio": generation_ar,
                    "resolution": body.resolution.value if body.resolution else None,
                    **({"custom_width": body.custom_width, "custom_height": body.custom_height} if use_custom_dims else {}),
                },
                images_b64=encoded_images,
                reference_images_b64=body.reference_images or None,
                image_input_tokens=img_in_tok,
                image_output_tokens=img_out_tok,
                model_category="gemini-3-pro-image-preview",
                show_in_gallery=body.show_in_gallery,
            )

        return {
            "status": "success",
            "aspect_ratio": generation_ar,
            "resolution": body.resolution.value if body.resolution else None,
            **({"custom_width": body.custom_width, "custom_height": body.custom_height} if use_custom_dims else {}),
            "image_count": len(encoded_images),
            "images": encoded_images,
        }
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error generating image: {str(e)}")


@app.post(
    "/api/v1/generate/image/edit",
    summary="Edit an existing campaign image",
    tags=["Image Generation"],
    dependencies=[Depends(require_generation_rate_limit)],
)
def edit_campaign_image(
    body: ImageEditRequest,
    claims: Dict[str, Any] = Depends(require_auth),
):
    """
    Edit an existing campaign image using natural-language instructions.

    Provide the source image as a base64-encoded string via ``image_b64`` and
    describe the desired changes via ``edit_instructions``.
    No logo references are injected — this endpoint is purely for user-driven edits.

    Optionally pass ``aspect_ratio`` and ``resolution`` to control output dimensions.

    **Supported aspect ratios:** 1:1 · 2:3 · 4:5 · 9:16 · 3:2 · 4:3 · 16:9 · 21:9
    **Supported resolutions:** · 1K · 2K · 4K

    Returns the edited image as a base64-encoded PNG string.
    """
    try:
        # Resolve aspect ratio: custom dimensions take precedence over preset
        use_custom_dims = bool(body.custom_width and body.custom_height)
        if use_custom_dims:
            generation_ar = find_nearest_aspect_ratio(body.custom_width, body.custom_height)
        else:
            generation_ar = body.aspect_ratio.value if body.aspect_ratio else None

        final_edit_prompt = body.edit_instructions
        image_size_value = body.resolution.value if body.resolution else None

        # Resolve image source: prefer explicit b64; fall back to fetching from URL.
        if (body.image_b64 or "").strip():
            source_b64 = body.image_b64.strip()
        else:
            url = (body.image_url or "").strip()
            try:
                with urllib.request.urlopen(url, timeout=30) as resp:
                    source_b64 = base64.b64encode(resp.read()).decode()
            except urllib.error.URLError as exc:
                raise HTTPException(
                    status_code=422,
                    detail=f"Could not fetch image from image_url: {exc.reason}",
                )

        edited_image, img_in_tok, img_out_tok = image_service.edit_image(
            image_b64=source_b64,
            edit_prompt=final_edit_prompt,
            reference_image_paths=None,
            aspect_ratio=generation_ar,
            image_size=image_size_value,
        )

        if edited_image is None:
            raise HTTPException(
                status_code=502,
                detail=(
                    "Image editing did not produce an output. "
                    "The upstream model may be unavailable or declined the request."
                ),
            )

        # Resize to exact user dimensions when custom size was requested
        if use_custom_dims:
            edited_image = resize_to_exact(edited_image, body.custom_width, body.custom_height)

        encoded = image_service.images_to_base64([edited_image])

        save_category = (body.category or "").strip() or "image_edit"

        if body.project_id:
            autosave_creative(
                azure_oid=claims.get("oid") or "",
                project_id=body.project_id,
                category=save_category,
                metadata={
                    "edit_instructions": body.edit_instructions,
                    "aspect_ratio": generation_ar,
                    "resolution": image_size_value,
                    **({"custom_width": body.custom_width, "custom_height": body.custom_height} if use_custom_dims else {}),
                },
                images_b64=[encoded[0]],
                image_input_tokens=img_in_tok,
                image_output_tokens=img_out_tok,
                model_category="gemini-3-pro-image-preview",
                show_in_gallery=body.show_in_gallery,
            )

        return {
            "status": "success",
            "aspect_ratio": generation_ar,
            "resolution": image_size_value,
            **({"custom_width": body.custom_width, "custom_height": body.custom_height} if use_custom_dims else {}),
            "image": encoded[0],
        }
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error editing image: {str(e)}")


# ==================== Copywriting ====================

class CopywritingRequest(BaseModel):
    """Request model for the unified copywriting endpoint."""
    channel: str = Field(
        ...,
        description=(
            "Target channel. Supported values: print_ad, outdoors, campaign_kv, "
            "films, email, twitter, facebook, instagram, whatsapp, generic."
        ),
    )
    brief: str = Field(..., description="Campaign brief / instructions for the copy.")
    project_id: Optional[str] = Field(
        None,
        description="Project UUID. When provided the generated copy is auto-saved.",
    )


class PromptUpgradeRequest(BaseModel):
    """Request model for AI prompt refinement for image workflows."""

    mode: Literal["banner", "image_edit"] = Field(
        ...,
        description="Prompt context. Supported values: banner, image_edit.",
    )
    prompt: str = Field(..., description="Existing prompt to refine.")


def _build_prompt_upgrade_instruction(mode: str, prompt: str) -> str:
    context_line = (
        "You are improving a website banner generation prompt."
        if mode == "banner"
        else "You are improving an image editing instruction prompt."
    )
    mode_specific_line = (
        "For banner prompts, include a short witty headline direction (4-8 words) and indicate clear headline placement."
        if mode == "banner"
        else "For image-edit prompts, preserve existing layout intent and describe only targeted edits."
    )
    return (
        "You are an expert visual prompt writer for marketing creatives for indigo airlines.\n"
        f"{context_line}\n"
        f"{mode_specific_line}\n"
        "Rewrite the user prompt so it is clearer, more specific, and production-ready.\n"
        "Keep intent unchanged and do not invent business claims.\n"
        "Never include airplanes, aircraft, plane cabins, or visible flight hardware in the creative description unless the user explicitly asks for it in the original prompt.\n"
        "Apply IndiGo brand guidelines: clean minimal layout, premium-but-approachable tone, high legibility, blue-and-white-forward palette, and uncluttered composition with generous negative space.\n"
        "Prefer concrete visual details: composition, lighting, mood, color direction, and brand-safe tone.\n"
        "Always use Bauhaus Std Medium font for text as per IndiGo Airlines Guidelines.\n"
        "Return only the improved prompt text with no markdown, no bullets, and no explanation.\n\n"
        f"Original prompt:\n{prompt.strip()}"
    )


def _clean_upgraded_prompt(value: str) -> str:
    cleaned = value.strip()
    if cleaned.startswith("```"):
        cleaned = re.sub(r"^```[a-zA-Z0-9_-]*\n?", "", cleaned)
        cleaned = re.sub(r"\n?```$", "", cleaned).strip()
    if (cleaned.startswith('"') and cleaned.endswith('"')) or (
        cleaned.startswith("'") and cleaned.endswith("'")
    ):
        cleaned = cleaned[1:-1].strip()
    return cleaned


@app.post(
    "/api/v1/generate/image/prompt/upgrade",
    dependencies=[Depends(require_generation_rate_limit)],
)
def upgrade_image_prompt_with_ai(
    body: PromptUpgradeRequest,
    _claims: Dict[str, Any] = Depends(require_auth),
):
    """Upgrade a banner/edit prompt with AI and return the revised prompt."""
    refined_source = body.prompt.strip()
    if not refined_source:
        raise HTTPException(status_code=400, detail="Prompt is required.")
    try:
        instruction = _build_prompt_upgrade_instruction(body.mode, refined_source)
        upgraded = prompt_refiner_service.generate_text(
            prompt=instruction,
            temperature=0.35,
            max_tokens=700,
        )
        cleaned = _clean_upgraded_prompt(upgraded)
        if not cleaned:
            raise HTTPException(status_code=502, detail="Prompt refinement returned an empty response.")
        return {
            "status": "success",
            "upgraded_prompt": cleaned,
        }
    except HTTPException:
        raise
    except Exception as exc:
        raise HTTPException(status_code=500, detail=f"Error refining prompt: {str(exc)}")


@app.post("/api/v1/generate/copywriting/generate", dependencies=[Depends(require_generation_rate_limit)])
def generate_copywriting(
    body: CopywritingRequest,
    claims: Dict[str, Any] = Depends(require_auth),
):
    """
    Generate 3 copywriting options (headline + body) for the given channel and brief.

    Supported channels:
    - print_ad       → Print Advertisement
    - outdoors       → Out-of-Home / Outdoors
    - campaign_kv    → Campaign Key Visual
    - films          → Films / Video
    - email          → Email
    - twitter        → Twitter / X
    - facebook       → Facebook
    - instagram      → Instagram
    - whatsapp       → WhatsApp
    - generic        → Generic (multi-channel)

    Returns three options, each with a distinct creative angle:
    ```json
    {
        "status": "success",
        "channel": "twitter",
        "channel_display_name": "Twitter / X",
        "options": [
            { "option_number": 1, "headline": "...", "body": "..." },
            { "option_number": 2, "headline": "...", "body": "..." },
            { "option_number": 3, "headline": "...", "body": "..." }
        ]
    }
    ```
    """
    try:
        result = copywriting_service.generate(
            channel=body.channel,
            brief=body.brief,
        )

        if body.project_id:
            autosave_creative(
                azure_oid=claims.get("oid") or "",
                project_id=body.project_id,
                category="copywriting",
                metadata={
                    "Channel": body.channel,
                    "brief": body.brief,
                },
                text=json.dumps(result.get("options", result)),
                text_input_tokens=result.get("_text_input_tokens", 0),
                text_output_tokens=result.get("_text_output_tokens", 0),
            )

        return {"status": "success", **result}
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc))
    except Exception as exc:
        raise HTTPException(
            status_code=500,
            detail=f"Error generating copywriting: {str(exc)}",
        )


_FRONTEND_BUILD = Path(__file__).resolve().parent.parent / "frontend" / "dist"

if _FRONTEND_BUILD.is_dir():
    from fastapi.responses import FileResponse

    # SPA catch-all: serve index.html for any path that isn't a real static file.
    # Real static assets (JS/CSS/images) are served by the StaticFiles mount below;
    # this route only fires for SPA navigation paths like /projects, /explore, etc.
    @app.get("/{full_path:path}", include_in_schema=False)
    def spa_fallback(full_path: str):
        candidate = _FRONTEND_BUILD / full_path
        if candidate.is_file():
            return FileResponse(str(candidate))
        index = _FRONTEND_BUILD / "index.html"
        return FileResponse(str(index))

    app.mount(
        "/",
        StaticFiles(directory=str(_FRONTEND_BUILD), html=True),
        name="frontend",
    )
else:
    @app.get("/")
    def root_api_only():
        return {
            "status": "running",
            "app": "IndiGo Marketing Platform API",
            "version": "1.0.0",
            "detail": "No frontend build at frontend/dist; run `npm run build` in the frontend directory.",
        }


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="127.0.0.1", port=8000)
