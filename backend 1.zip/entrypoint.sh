#!/bin/sh
python db/create_tables.py
python db/create_containers.py
python db/migrate_departments.py
exec uvicorn main:app --host 0.0.0.0 --port 8000
