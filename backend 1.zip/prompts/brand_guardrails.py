"""
IndiGo Airlines Brand Guardrails
Single source of truth for brand policy rules shared across all platforms.

The platform-specific prompt templates live in:
  - prompts/platform_text_prompt.py  (PlatformTextPrompt enum)
  - prompts/platform_image_prompt.py (PlatformImagePrompt enum)
"""


INDIGO_BRAND_POLICY = """
HARD RULES:
- Logo (IndiGo Airlines) has 20 dots and must always appear in correct proportion
- Logo always used in correct proportion and in correct direction
- Wordmark should always be used from the master file, and should not be typed
- URL should always be written as goIndiGo.in (I and G must be upper case)
- Typeface: Bauhaus Medium
- Always use sentence case. Never use ALL CAPS (looks odd in Bauhaus). Title case only for names, properties, and assets
- Never say anything negative about IndiGo
- Always be polite and professional
- Always include overlay text on images
- Never place logo on an aircraft tail; place it in a corner that suits the composition

SOFT RULES:
- Black background → white logo; dark blue or light blue background → white logo
- Arrow-plane logo can be used creatively (e.g., arranged in circles or patterns)
- Arrow-plane placement is flexible — choose whichever position looks visually better
- When a logo appears near a building, start it from the building rather than overlapping it
- Primary colour: Dark Blue (Pantone 2738 C); Secondary colour: Light Blue (Pantone 291 C)
- Simple, eye-catching, non-controversial subject that is easy to adapt to various sizes
- Soft colours, balanced composition, simple designs
- Avoid vector graphics and illustrations for digital placements
- Integrate pop culture and modern trends where appropriate
"""
