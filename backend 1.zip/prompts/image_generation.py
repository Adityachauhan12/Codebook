"""
Prompt suffixes for Gemini image generation — brand rules are applied here (not via post-processing).
IndiGo rules apply to every creative; BluChip rules apply only when campaign_type is IBC.
"""

from typing import Optional

# Shown on every image generation call (all campaign types / media).
INDIGO_LOGO_IMAGE_PROMPT_SUFFIX = """
BRAND — IndiGo logo (always include in this creative):
- The final image must clearly show the official IndiGo wordmark/logo in correct proportion, orientation, and 20-dot design.
- Use the IndiGo logo reference images supplied with this request to match the master artwork; do not redraw, approximate, or substitute a different mark.
- Place the logo in a clean corner or open area that fits the composition (never on an aircraft tail); it must read crisply against the background—use the light-background or dark-background variant that best matches the scene.
- Blend the logo naturally into the layout (lighting, scale, and spacing) so it feels intentional and premium, not pasted-on.
"""

# Only when campaign_type is IBC.
IBC_BLUCHIP_IMAGE_PROMPT_SUFFIX = """
BRAND — IBC / BluChip (this campaign is IBC):
- Also include the BluChip coin/partner mark in the same creative, integrated with the scene so it feels cohesive with the IndiGo branding.
- Use the BluChip reference image supplied with this request for accurate shape, color, and proportions; place it where it balances with the IndiGo logo (e.g. opposite corner or paired lockup) without crowding the focal subject.
- Both IndiGo and BluChip should be legible and on-brand; keep partner co-branding tasteful and campaign-appropriate.
"""


def extend_image_prompt_for_brand(base_prompt: str, campaign_type: Optional[str]) -> str:
    """Append IndiGo rules to every image prompt; append BluChip rules only for IBC."""
    parts = [base_prompt.strip(), INDIGO_LOGO_IMAGE_PROMPT_SUFFIX.strip()]
    if (campaign_type or "").strip().lower() == "ibc":
        parts.append(IBC_BLUCHIP_IMAGE_PROMPT_SUFFIX.strip())
    return "\n\n".join(parts)
