"""
Unified Copywriting Prompts
Channel-specific prompt rules for the /api/copywriting/generate endpoint.

Prompts are informed by proven copywriting frameworks (AIDA, PAS, FAB)
Each channel entry defines:
  - Headline constraints
  - Body structure with sentence-level purpose guidance
  - Proven creative angles to explore across the 3 options
  - Tone and format rules
"""

from typing import Dict

# ---------------------------------------------------------------------------
# Channel display names (used in prompts and API responses)
# ---------------------------------------------------------------------------

CHANNEL_DISPLAY_NAMES: Dict[str, str] = {
    "print_ad":     "Print Ad",
    "outdoors":     "Outdoors / Out-of-Home (OOH)",
    "campaign_kv":  "Campaign Key Visual (KV)",
    "films":        "Films / Video",
    "email":        "Email",
    "twitter":      "Twitter / X",
    "facebook":     "Facebook",
    "instagram":    "Instagram",
    "whatsapp":     "WhatsApp",
    "generic":      "Generic (multi-channel)",
}

# ---------------------------------------------------------------------------
# Copywriting craft reference — injected into the base prompt
# ---------------------------------------------------------------------------

COPYWRITING_CRAFT_REFERENCE = """\
========================
COPYWRITING CRAFT REFERENCE
========================

You are writing in the tradition of the world's best advertising copywriters.
Apply these principles to every option you generate:

PROVEN FRAMEWORKS
-----------------
- AIDA: Attention (headline) → Interest (open with a hook that amplifies the headline) →
  Desire (build benefits, emotion, and reason-to-believe) → Action (close with CTA).
- PAS: Problem (name the tension or pain point) → Agitate (make the reader feel it) →
  Solution (IndiGo resolves it effortlessly, with wit).
- FAB: Feature → Advantage → Benefit. Never stop at the feature. Always land on the benefit
  the reader actually feels.

BODY COPY STRUCTURE (apply to every option)
--------------------------------------------
Sentence 1 — HOOK / AMPLIFIER: Directly amplify the headline's promise. Do not restate it;
  extend it into a vivid thought, a surprising twist, or a relatable moment.
Sentence 2 — INTEREST BUILDER: Deepen curiosity or desire. Add a specific detail, a
  concrete image, or an unexpected angle that keeps the reader moving forward.
Sentence 3 — CORE BENEFIT: State the single most compelling benefit. Use "benefits over
  features" — do not say what IndiGo does; say what it does FOR the reader.
Sentence 4 — EMOTIONAL DIMENSION / PROOF POINT: Connect emotionally. Use sensory language,
  a relatable human moment, or a credibility-building detail. This is what makes copy
  memorable (see: De Beers "A Diamond is Forever", KLM "To More Memories Together").
Sentence 5 — TENSION OR CONTRAST (where relevant): Great copy creates productive tension.
  A small contrast, a self-aware wink, or an honest admission builds far more trust than
  superlatives (see: Avis "We Try Harder", VW "Think Small").
Sentence 6 — CALL TO ACTION: Specific, direct, low-threat where appropriate. Use action
  verbs. Make it feel like the obvious next step, not a demand.

Additional paragraphs may be added for longer-form channels (email, campaign KV, films).

CREATIVE ANGLE DIVERSITY (one per option)
------------------------------------------
Option 1 — INSIGHT-LED: Find an unexpected truth about travel, destinations, or the reader's
  life and anchor the entire option around it. (Technique: lateral thinking, cultural
  observation, category insight.)
Option 2 — EMOTION-LED: Lead with a feeling — wanderlust, relief, anticipation, joy, or
  belonging. Build the copy around that emotional experience. (Technique: narrative empathy,
  sensory language, emotional anchoring.)
Option 3 — WIT-LED: Use IndiGo's smart, restrained wit to reframe the ordinary as
  extraordinary, or find the absurdity in the everyday travel experience. Never forced;
  always earns the smile. (Technique: subversion, understatement, clever juxtaposition.)

ABSOLUTE RULES FOR BODY COPY
------------------------------
- Every sentence must be fully written, specific, and publish-ready. No placeholders.
- No sentence should simply repeat what the previous one said in different words.
- Benefits over features, always.
- British English spellings. Sentence case throughout.
- Never frame IndiGo as cheap, discounted, or budget. Low-cost should never feel cheap.
- Copy should leave the reader with a subtle smile and a clear next step.
"""

# ---------------------------------------------------------------------------
# Per-channel copywriting rules injected into the base prompt
# ---------------------------------------------------------------------------

CHANNEL_COPY_RULES: Dict[str, str] = {

    "print_ad": """\
CHANNEL: Print Advertisement
=================================

HEADLINE
- 3–8 words. Insight-driven, witty, works without the visual.
- Model to follow: VW "Think Small" (honesty as disarming insight),
  Avis "We Try Harder" (turning a limitation into a virtue),
  De Beers "A Diamond is Forever" (emotional truth as brand anchor).
- One sharp idea. No sub-clauses, no fluff.

BODY COPY
- 5–7 fully written, publish-ready sentences following the AIDA / craft structure above.
- Sentence 1: Amplify the headline — extend the idea into a vivid, specific thought.
- Sentence 2: Deepen curiosity with a concrete detail, image, or unexpected observation.
- Sentence 3: Deliver the core benefit for the reader (not a feature list).
- Sentence 4: Add an emotional dimension — a relatable human moment or sensory detail that
  makes this copy stick in memory.
- Sentence 5: A tension or contrast beat — an honest, self-aware line that builds trust
  rather than over-promising (IndiGo's wit lives here).
- Sentence 6: Clear, compelling CTA — an action verb, a destination, a sense of ease.
- Copy must stand alone: no visual context available. The words carry the full weight.
- Tone: confident, crisp, clever. Never loud or promotional.
""",

    "outdoors": """\
CHANNEL: Outdoors / Out-of-Home (OOH)
=================================

HEADLINE
- Maximum 5 words. Readable in under 3 seconds at 80 km/h.
- Communicate ONE idea, evoke ONE emotion. That's it.
- Think: British Airways "Look Up." — three words, infinite possibility.
- No sub-clauses, no qualifiers, no puns that require thinking.

BODY COPY
- 3–4 fully written sentences. Short, punchy — but each one must earn its place.
- Sentence 1: One concrete, specific extension of the headline idea. Not a restatement —
  a new angle on the same thought, delivered in 10 words or fewer.
- Sentence 2: The single most compelling reason-to-act or reason-to-believe. One benefit,
  clearly stated, zero waffle.
- Sentence 3: Urgency or specificity — a date, a route, a feeling of now.
- Sentence 4: CTA or URL. Short. Direct. Action verb.
- Total body word count: aim for 25–40 words across the 3–4 sentences.
- Tone: bold, direct, immediate. Zero sub-clauses. Every word works.
""",

    "campaign_kv": """\
CHANNEL: Campaign Key Visual (KV)
=================================

HEADLINE
- 4–10 words. The campaign's anchor line — ownable, memorable, versatile.
- This line must be able to live on every downstream asset (outdoor, social, film, email)
  without modification. Test it: does it still work as a billboard? As a film end-frame?
- Model: Emirates "Hello Tomorrow" (aspirational territory-setting),
  Virgin Atlantic "See the World Differently" (empowering, values-driven),
  Delta "The World Is Your Kaleidoscope" (emotional, expansive).

BODY COPY
- 6–8 fully written sentences forming the campaign manifesto / narrative.
- Paragraph 1 (sentences 1–3): Establish the core insight — the human truth that the
  campaign is rooted in. Make it specific to travel, to India, to IndiGo's world.
  This is not a product description; it is an emotional and cultural observation.
- Paragraph 2 (sentences 4–5): Bring the campaign idea to life. Paint the emotional
  territory it will own. What does this campaign make people feel? What behaviour does
  it change? Use vivid, evocative language — no corporate speak.
- Paragraph 3 (sentences 6–8): Articulate the IndiGo brand promise that underpins this
  campaign. Connect it to effortless travel, on-time reliability, and the idea that
  low-cost should never feel cheap. Close with a line that could double as a tagline.
- Tone: campaign-defining, emotionally resonant, intelligent. This is the brief that
  briefs all other briefs — it must be rich, directional, and inspiring.
""",

    "films": """\
CHANNEL: Films / Video
=================================

HEADLINE
- 5–12 words. The film's end-frame super or closing tagline.
- This is what the viewer carries with them after the screen goes dark.
- Model: KLM "To More Memories Together" (multigenerational, emotional legacy),
  Nike "If You Let Me Play" (escalating emotional intensity),
  Air New Zealand "We See You" (direct audience acknowledgment).

BODY COPY
- 5–7 fully written sentences forming a concise creative treatment (not a full script).
- Sentence 1 — OPENING VISUAL / HOOK: Describe the film's opening image or scene. What
  does the viewer see in the first 3 seconds? Make it specific and cinematic.
- Sentence 2 — EMOTIONAL SETUP: Establish the emotional world of the film. What feeling
  is the audience in? What human truth is being surfaced?
- Sentence 3 — STORY BEAT / TURNING POINT: The moment the film shifts — a discovery,
  a reunion, a decision, a journey taken. This is the heart of the narrative.
- Sentence 4 — ESCALATION OR ASPIRATION: How does the emotion build toward the peak?
  What does the film's world look like at its most vivid and alive?
- Sentence 5 — BRAND LANDING: How does IndiGo's role in the story become clear — not
  through product placement, but through what it enabled? (The journey, the arrival,
  the connection.)
- Sentence 6 — CLOSING FEELING + TAGLINE LINK: The final image or emotion before the
  end-frame. How does it connect to the headline tagline?
- Tone: cinematic, storytelling-led, evocative. Let silence and space do some of the work.
""",

    "email": """\
CHANNEL: Email
=================================

HEADLINE (SUBJECT LINE)
- Maximum 50 characters. Earns the open without trickery.
- Use curiosity, specificity, or wit — never vague promises.
- Model approaches: JetBlue's specificity ("1,750 points waiting for you"),
  Skyscanner's anticipation ("Spotlight on… Barcelona"), Kimpton's wordplay
  ("Chill without the chill"). Pick the approach that fits the brief.

BODY COPY
- 6–8 fully written sentences, structured for scannability and conversion.
- Sentence 1 — PERSONALISED OPENER: Address the reader as if you know them.
  Virgin Holidays technique: place the reader inside the experience immediately
  ("Imagine landing in [destination] while the city is still waking up…").
- Sentence 2 — HOOK EXTENSION: Deepen the opening with a specific, vivid detail
  that makes the proposition feel real and desirable, not abstract.
- Sentence 3 — VALUE PROPOSITION: State clearly what IndiGo is offering and why
  it matters. Concrete, not vague. Specific benefit over generic claim.
- Sentence 4 — PROOF POINT OR SUPPORTING BENEFIT: One additional reason to believe
  or act — a route detail, a convenience feature, a limited-time element.
- Sentence 5 — EMOTIONAL RESONANCE: Connect the offer to a feeling or life moment
  (reunion, holiday, adventure, relief of a well-earned trip). This is what turns
  a promotional email into something the reader actually wants to read.
- Sentence 6 — URGENCY (where relevant): A specific deadline, seat count, or
  availability window. Genuine scarcity, never manufactured.
- Sentence 7 — CTA: Direct, action-verb-led. One action only. Make it feel like
  the obvious and easy next step, not a hard sell.
- Tone: friendly, professional, slightly personalised. Conversational rhythm.
""",

    "twitter": """\
CHANNEL: Twitter / X
=================================

HEADLINE (OPENING HOOK)
- Maximum 80 characters. The line that earns the retweet before the "more" cut.
- Must deliver immediate value — a surprising fact, a witty observation, a
  provocative question, or a statement that makes the reader stop mid-scroll.
- Model: Air New Zealand "We See You" tone — direct, warm, slightly knowing.

BODY COPY
- The full tweet text, including the opening hook: maximum 280 characters total.
- Despite the character limit, the body must be fully formed and meaningful:
  Beat 1 (hook): The opening hook itself — already counted in 280 chars.
  Beat 2: One sentence that extends the hook with a specific detail, wit, or payoff.
  Beat 3: The IndiGo benefit or action — concrete and direct.
  Beat 4: CTA (book now, tap the link, etc.) + 3–5 tightly relevant hashtags.
- Use emoji sparingly — only where it adds rhythm or meaning, not decoration.
- The tweet must feel like something a smart, warm person wrote — not a brand account.
- Tone: punchy, conversation-starting, confident without being corporate.
- British English spellings. Sentence case throughout.
""",

    "facebook": """\
CHANNEL: Facebook
=================================

HEADLINE (OPENING HOOK)
- 1–2 sentences that stop the scroll. Conversational, not headline-y.
- Opens a door rather than making a proclamation — invite the reader in.
- Uses the "scroll-stop" technique: a surprising stat, a relatable confession,
  a bold question, or a vivid scene-setting line.

BODY COPY
- 6–8 fully written sentences forming a complete, engaging Facebook post.
- Sentence 1 (hook — same as or extending the headline): Deepen the opening
  with a relatable or evocative detail. Facebook rewards human stories.
- Sentence 2: Set the scene or context. Who is this for? What moment in life
  does this speak to? Ground the copy in a real, specific human situation.
- Sentence 3: Introduce the IndiGo benefit — but through the reader's experience,
  not a product list. "You land on time, collect your bag, and still make
  the dinner reservation" is more powerful than "we have a 95% OTP rate."
- Sentence 4: Add a second benefit or an emotional amplifier. What else does
  this enable in the reader's life?
- Sentence 5: A moment of IndiGo personality — wit, warmth, or a knowing aside
  that makes the brand feel human, not corporate.
- Sentence 6: Social proof element or cultural relevance (optional but powerful).
- Sentence 7: CTA — conversational, action-verb-led. Include 1–2 relevant emoji.
- End with: CTA button label suggestion in brackets, e.g. [Book Now].
- Tone: warm, conversational, engaging. Like a recommendation from a friend.
""",

    "instagram": """\
CHANNEL: Instagram
=================================

HEADLINE (CAPTION OPENER — FIRST 125 CHARACTERS)
- Must hook before the "more" cut-off. Every word must earn its place.
- Airbnb technique: fresh, quirky wordplay that sparks curiosity.
- Alternative: open with a vivid sensory image that drops the reader into the scene.
- Never start with the brand name or a generic greeting.

BODY COPY
- 6–9 fully written sentences forming a complete, rich Instagram caption.
- Sentence 1 (same as or directly extending the headline hook): Pull the reader
  past the "more" cut with an immediate payoff — a twist, a detail, a feeling.
- Sentence 2: Deepen the scene or story. Use sensory language — what does it
  look, feel, sound, or smell like? Instagram is visual; the caption adds texture.
- Sentence 3: The core IndiGo message — expressed through the reader's experience,
  not a brand claim. What does this flight, route, or offer actually unlock for them?
- Sentence 4: An aspirational beat — what's possible now? Where could they be?
  Build the desire. This is the "desire" moment in AIDA.
- Sentence 5: A human, relatable moment — a travel truth, a small joy, an IndiGo
  personality beat. This is what gets saved and shared.
- Sentence 6: CTA — direct, specific, action-verb-led. Link in bio is standard.
- Line break, then: 5–8 tightly relevant hashtags (mix of broad travel tags and
  IndiGo/India-specific tags). Hashtags on their own line for clean presentation.
- Use emoji naturally throughout — rhythm, not decoration.
- Tone: visual-first storytelling. Aspirational but grounded. Trendy but never try-hard.
""",

    "whatsapp": """\
CHANNEL: WhatsApp
=================================

HEADLINE (OPENING MESSAGE LINE)
- Maximum 80 characters. Reads like a message from a trusted friend, not a brand.
- Creates immediate relevance — the reader should feel "this is for me."
- Use the reader's situation, aspiration, or a specific detail from the brief.
- No corporate framing. No "Dear valued customer." Warm, direct, human.

BODY COPY
- 4–6 fully written sentences. Conversational rhythm; short paragraphs for
  mobile readability (1–2 sentences per paragraph, with line breaks between).
- Sentence 1: Extend the opening with the key detail or offer — specific, concrete,
  not vague. What exactly is IndiGo offering and why does it matter right now?
- Sentence 2: The core benefit in the reader's life. Not features — the actual
  outcome the reader gets (time saved, money in pocket, experience unlocked).
- Sentence 3: A second benefit or a proof point — something that adds credibility
  or sweetens the proposition.
- Sentence 4: Gentle urgency — a deadline, a limited availability, or a season-
  specific hook. Genuine, not manufactured pressure.
- Sentence 5: CTA — short, direct, action-verb-led. Followed by a CTA button label
  suggestion in brackets, e.g. [Book Now] or [See Flights].
- Use 2–4 emoji naturally — at the start of lines or after key phrases, not mid-sentence.
- Make the message easily forwardable: a friend should be able to forward it
  to another friend and it will still make perfect sense.
- Tone: warm, friendly, chat-appropriate. Like a message from someone who just
  found a great deal and is sharing it because they genuinely want you to benefit.
""",

    "generic": """\
CHANNEL: Generic (Multi-Channel Adaptable)
=================================

HEADLINE
- 4–10 words. Platform-agnostic — must work on a billboard, in an email subject
  line, as a social post opener, and on a print ad without modification.
- Model: Apple "Think Different" — philosophy over product, vast creative territory.
- Anchor it in a human truth about travel, aspiration, or the IndiGo experience.

BODY COPY
- 5–7 fully written, publish-ready sentences following the full craft structure.
- Sentence 1: Amplify the headline — a vivid, specific extension of the core idea.
- Sentence 2: Build interest with a concrete detail or unexpected observation.
- Sentence 3: Core benefit — through the reader's experience, not IndiGo's features.
- Sentence 4: Emotional dimension — a relatable human moment, a sensory detail,
  or an aspirational image that creates genuine desire.
- Sentence 5: Tension or contrast beat — a self-aware, honest line that builds
  trust (IndiGo wit lives here: confident, never arrogant; warm, never cheesy).
- Sentence 6: CTA — direct, specific, action-verb-led.
- No platform-specific formatting: no hashtags, no emoji, no subject-line
  length constraints. Pure, adaptable copy.
- Tone: balanced, intelligent, warm. Firmly IndiGo: effortless, on-time, smart.
""",
}

# ---------------------------------------------------------------------------
# Base prompt template — channel rules and brief are injected at call time
# ---------------------------------------------------------------------------

COPYWRITING_BASE_PROMPT = """\
{policy}

{craft_reference}

{channel_rules}

Campaign Brief:
{brief}

========================
YOUR TASK
========================

You are a senior IndiGo Airlines copywriter with 15 years of experience writing for
the brand. You understand that IndiGo's voice is smart, warm, witty, and effortlessly
confident — and that low-cost should never feel cheap.

Working from the campaign brief above, generate exactly 3 distinct, publish-ready
copywriting options for the {channel_display_name} channel.

MANDATORY requirements:
1. Follow the channel rules and body copy structure guidance precisely.
2. Each option MUST use a different creative technique from the three angles defined
   in the craft reference (Option 1: insight-led, Option 2: emotion-led, Option 3: wit-led).
3. Write every body field in full — complete sentences, full paragraphs, no placeholders,
   no truncation, no skeleton copy. The body must be ready to hand to a designer today.
4. Every sentence in the body must add new value — no repetition, no padding, no filler.
5. Apply the IndiGo brand policy strictly throughout.

Respond ONLY in valid JSON with no additional commentary or markdown fences:
{{
    "options": [
        {{
            "option_number": 1,
            "headline": "<headline for option 1>",
            "body": "<full, complete body copy for option 1 — multiple sentences, fully written>"
        }},
        {{
            "option_number": 2,
            "headline": "<headline for option 2>",
            "body": "<full, complete body copy for option 2 — multiple sentences, fully written>"
        }},
        {{
            "option_number": 3,
            "headline": "<headline for option 3>",
            "body": "<full, complete body copy for option 3 — multiple sentences, fully written>"
        }}
    ]
}}
"""


def build_copywriting_prompt(channel: str, brief: str, policy: str) -> str:
    """
    Build the full prompt for the given channel and brief.

    Args:
        channel:  Normalised channel key (e.g. "twitter", "print_ad").
        brief:    Campaign brief / instructions from the user.
        policy:   Brand guardrails text (INDIGO_TEXT_BRAND_POLICY).

    Returns:
        Fully assembled prompt string ready to send to the LLM.

    Raises:
        ValueError: If the channel key is not recognised.
    """
    channel_key = channel.strip().lower()
    if channel_key not in CHANNEL_COPY_RULES:
        valid = ", ".join(CHANNEL_COPY_RULES.keys())
        raise ValueError(
            f"Unsupported channel '{channel}'. Supported values: {valid}"
        )

    return COPYWRITING_BASE_PROMPT.format(
        policy=policy,
        craft_reference=COPYWRITING_CRAFT_REFERENCE,
        channel_rules=CHANNEL_COPY_RULES[channel_key],
        brief=brief,
        channel_display_name=CHANNEL_DISPLAY_NAMES[channel_key],
    )