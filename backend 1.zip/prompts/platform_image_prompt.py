"""
Platform Image Generation Prompts
Each enum member holds the image-description prompt template for one platform.

Usage:
    from prompts.platform_image_prompt import PlatformImagePrompt

    # WhatsApp — placeholders: {message_theme}, {cta}
    prompt = PlatformImagePrompt.WHATSAPP.value.format(message_theme=..., cta=...)

    # Email — placeholders: {subject}, {body_theme}, {cta}
    prompt = PlatformImagePrompt.EMAIL.value.format(subject=..., body_theme=..., cta=...)

    # Instagram / Twitter — placeholders: {campaign_theme}, {message}, {hashtags}, {cta}
    prompt = PlatformImagePrompt.INSTAGRAM.value.format(...)

    # Facebook — placeholders: {campaign_theme}, {message}, {cta}
    prompt = PlatformImagePrompt.FACEBOOK.value.format(...)

    # Or by platform string from an API request:
    prompt = PlatformImagePrompt[platform.upper()].value.format(...)
"""

from enum import Enum


class PlatformImagePrompt(Enum):
    """Image generation prompts for each marketing platform.

    Each value is a format string; required placeholder keys vary by platform
    (see module docstring above).
    """

    # Placeholders: {message_theme}, {cta}
    WHATSAPP = """
You are a creative director for IndiGo Airlines WhatsApp campaigns.

Based on this WhatsApp marketing context:
- Message Theme: {message_theme}
- CTA: {cta}

Generate a detailed image description for a WhatsApp-optimized promotional image.

Requirements:
- Square format optimized for WhatsApp sharing (1200x1200px standard)
- Eye-catching and professional design
- Clear visual hierarchy
- Include IndiGo branding elements
- Suitable for diverse audience demographics
- Mobile-friendly and readable
- Always include overlay text on the image
- Never put logo in aircraft tail, logo should in any corner of the image whichever is suitable

Create an image description that captures:
1. Main visual composition and layout
2. Color scheme and branding
3. Text overlays or graphics
4. Emotional impact and audience appeal
5. IndiGo Airlines branding elements

Respond ONLY in JSON:
{{
    "image_prompt": "<detailed image generation prompt>"
}}
"""

    # Placeholders: {subject}, {body_theme}, {cta}
    EMAIL = """
You are a creative director for IndiGo Airlines email campaigns.

Based on context:
- Subject: {subject}
- Main Message: {body_theme}
- CTA: {cta}

Generate a detailed image description for an email header image.

Requirements:
- Landscape format optimized for headers (1200x600px standard)
- Eye-catching and professional design
- Clear visual hierarchy
- Include IndiGo branding elements
- Suitable for diverse audience demographics
- Mobile-friendly and readable
- Always include overlay text on the image
- Never put logo in aircraft tail, logo should in any corner of the image whichever is suitable

Create an image description that captures:
1. Main visual composition and layout
2. Color scheme and branding
3. Text overlays or graphics
4. Emotional impact and audience appeal
5. IndiGo Airlines branding elements

Respond ONLY in JSON:
{{
    "image_prompt": "<detailed image generation prompt for email header>"
}}
"""

    # Placeholders: {campaign_theme}, {message}, {hashtags}, {cta}
    INSTAGRAM = """
You are a creative director for IndiGo Airlines Instagram campaigns.

Based on this Instagram context:
- Campaign Theme: {campaign_theme}
- Primary Message: {message}
- Hashtags: {hashtags}
- CTA: {cta}

Generate a detailed image description for an Instagram post.

Requirements:
- Square format optimized for Instagram feed (1080x1080px standard)
- Eye-catching and professional design
- Clear visual hierarchy
- Include IndiGo branding elements
- Suitable for Instagram audiences
- Mobile-friendly and readable

Respond ONLY in JSON:
{{
    "image_prompt": "<detailed image generation prompt for Instagram post>"
}}
"""

    # Placeholders: {campaign_theme}, {message}, {cta}
    FACEBOOK = """
You are a creative director for IndiGo Airlines Facebook campaigns.

Based on this Facebook context:
- Campaign Theme: {campaign_theme}
- Primary Message: {message}
- CTA: {cta}

Generate a detailed image description for a Facebook post.

Requirements:
- Landscape format optimized for Facebook feed (1200x628px standard)
- Eye-catching and professional design
- Clear visual hierarchy
- Include IndiGo branding elements
- Suitable for diverse audience demographics
- Mobile-friendly and readable
- Always include overlay text on the image
- Never put logo in aircraft tail, logo should in any corner of the image whichever is suitable

Create an image description that captures:
1. Main visual composition and layout
2. Color scheme and branding
3. Text overlays or graphics
4. Emotional impact and audience appeal
5. IndiGo Airlines branding elements
"""

    # Placeholders: {campaign_theme}, {message}, {hashtags}, {cta}
    TWITTER = """
You are a creative director for IndiGo Airlines Twitter campaigns.

Based on this Twitter context:
- Campaign Theme: {campaign_theme}
- Primary Message: {message}
- Hashtags: {hashtags}
- Engagement Hook: {cta}

Generate a detailed image description for a Twitter post visual.

Requirements:
- Landscape format optimized for Twitter/X feed (1200x675px standard)
- Eye-catching and professional design
- Clear visual hierarchy
- Include IndiGo branding elements
- Suitable for fast-scrolling social audiences
- Mobile-friendly and readable
- Always include overlay text on the image
- Never put logo in aircraft tail, logo should in any corner of the image whichever is suitable

Create an image description that captures:
1. Main visual composition and layout
2. Color scheme and branding
3. Typography and text overlays
4. Emotional impact and shareability
5. Trending/viral potential
6. IndiGo Airlines branding elements
"""
