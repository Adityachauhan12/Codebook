INDIGO_IMAGE_BRAND_POLICY = """

========================
1. BRAND FOUNDATION
========================

Visual outputs must reflect:
- Effortless, premium-feeling affordability
- Clean, precise, and modern design
- Clutter-free communication
- Realistic and authentic imagery not artistic or stylized unless asked specifically

Minimalism with meaning is mandatory.


========================
2. LOGO & BRAND ELEMENTS
========================
- Logo (IndiGo Airlines) has 20 dots and must always appear in correct proportion.
- Logo must maintain original proportions and orientation
- Logo must never be distorted, recoloured, or modified
- Mandatory clear space around logo must be preserved
- Add logo in the corner always.
- Never change the color of the logo to anything other than specified colors in the prompt.
- Wordmark must come from official master artwork (never recreated)
- Wordmark must not appear in isolation

- Arrow-plane:
  - Must always point forward/upward
  - Must imply motion and direction
  - Must not be used decoratively without meaning


========================
3. COLOUR SYSTEM
========================

Primary colours:
- Dark Blue (Pantone 2738 C)
- Light Blue (Pantone 284 C)

Rules:
- Blue must dominate the visual
- Secondary colours must be soft/pastel
- Avoid high-contrast or harsh palettes

Strictly prohibited:
- Red or purple dominant palettes


========================
4. VISUAL STYLE
========================

- Clean, uncluttered compositions
- Strong use of negative space
- Visuals must carry the idea (not text-heavy layouts)

Allowed styles (context-driven):
- Illustration-led storytelling (preferred)
- Vector compositions
- Grid-based layouts for structured information
- Collage or mixed-media
- 3D styles (only with strong IndiGo blue presence)

Rules:
- Style must serve the idea, not decoration
- Avoid visual clutter and over-design


========================
5. IMAGE & PHOTOGRAPHY RULES
========================

Strict prohibitions:
- No stock photography look
- No posed or smiling stock faces
- No generic aviation imagery (aircraft shots, runways, airports)
- No glamourised or cliché travel imagery

Preferred direction:
- Conceptual and insight-driven visuals
- Evocative, atmospheric imagery
- Thoughtful or unexpected perspectives
- Destination-led storytelling

Faces:
- Allowed only if candid, natural, and non-stock-like


========================
6. LAYOUT & COMPOSITION
========================

- Maintain clear margins (~10% safe space)
- Follow strong grid alignment
- Ensure clear visual hierarchy

Digital:
- Logo and arrow-plane typically placed top-right

General:
- Avoid overcrowding
- Maintain balance between visual and text elements


========================
7. BRAND EXPRESSION
========================

- Visuals should feel effortless and intelligent
- Aim to create a subtle moment of delight
- Avoid decorative or meaningless design elements


========================
8. TYPOGRAPHY
========================

- Primary headline font: Bauhaus std (geometric sans-serif)
- Body / supporting font: Bauhaus std
- Text must be clean, legible, and minimal
- Never use handwritten, serif, decorative, or script typefaces
- Avoid heavily stylised, distorted, or condensed lettering
- Typography must feel modern, precise, and uncluttered


========================
9. ABSOLUTE NEGATIVE CONSTRAINTS
========================

Never generate:
- Cheap airline aesthetics or discount visuals
- Luxury airline clichés or over-premium styling
- Stock photography style outputs
- Generic aviation imagery
- Red or purple colour palettes
- Cluttered or over-designed layouts
- Logo distortion or misuse
- Parody or meme-style visuals
- Modify the arrow logo or the IBC logo if used in any way (color, orientation, proportions)
- Different font from Bauhaus std in any text in image generated. 
"""