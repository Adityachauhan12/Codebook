import io
import json
import re
import zipfile
from datetime import datetime, timezone
from typing import Optional, Dict, Any, List

from fastapi import APIRouter, Depends, HTTPException, Query
from fastapi.responses import StreamingResponse
from pydantic import BaseModel, field_validator
from psycopg2.extras import RealDictCursor

from auth.azure_auth import require_auth
from db.connection import get_db
from services.blob_service import apply_sas_urls, download_blob_bytes

router = APIRouter(prefix="/api/v1/projects", tags=["Projects"])


def _strip_html(value: Optional[str]) -> Optional[str]:
    """Remove HTML tags from user-supplied text to prevent stored XSS."""
    if value is None:
        return None
    return re.sub(r"<[^>]+>", "", value).strip()


class ProjectCreate(BaseModel):
    name: str
    description: Optional[str] = None

    @field_validator("name", "description", mode="before")
    @classmethod
    def sanitize_html(cls, v):
        return _strip_html(v) if isinstance(v, str) else v


class ProjectUpdate(BaseModel):
    name: Optional[str] = None
    description: Optional[str] = None

    @field_validator("name", "description", mode="before")
    @classmethod
    def sanitize_html(cls, v):
        return _strip_html(v) if isinstance(v, str) else v


# ---------------------------------------------------------------------------
# Helper
# ---------------------------------------------------------------------------

def _require_owns_project(project_id: str, user_id: str) -> Dict[str, Any]:
    """Fetch a project that belongs to user_id, raising 404 if not found."""
    with get_db() as conn:
        with conn.cursor(cursor_factory=RealDictCursor) as cur:
            cur.execute(
                "SELECT * FROM projects WHERE id = %s AND user_id = %s",
                (project_id, user_id),
            )
            project = cur.fetchone()
    if not project:
        raise HTTPException(status_code=404, detail="Project not found")
    return dict(project)


# ---------------------------------------------------------------------------
# Routes
# ---------------------------------------------------------------------------

_PROJECT_STATS_QUERY = """
    SELECT
        p.*,
        COALESCE(s.total_images_created, 0) AS total_images_created,
        ROUND(
            -- Gemini rows
            COALESCE(s.gemini_text_input_tokens,   0) / 1000000.0 * cfg.text_input_tokens_cost
          + COALESCE(s.gemini_text_output_tokens,  0) / 1000000.0 * cfg.text_output_tokens_cost
          + COALESCE(s.gemini_image_input_tokens,  0) / 1000000.0 * cfg.image_input_tokens_cost
          + COALESCE(s.gemini_image_output_tokens, 0) / 1000000.0 * cfg.image_output_tokens_cost
            -- GPT-image-2 rows
          + COALESCE(s.gpt2_text_input_tokens,     0) / 1000000.0 * cfg.text2_input_tokens_cost
          + COALESCE(s.gpt2_image_input_tokens,    0) / 1000000.0 * cfg.image2_input_tokens_cost
          + COALESCE(s.gpt2_image_output_tokens,   0) / 1000000.0 * cfg.image2_output_tokens_cost,
        4) AS total_cost_of_images_created
    FROM projects p
    LEFT JOIN (
        SELECT
            project_id,
            COUNT(image_url) AS total_images_created,
            SUM(CASE WHEN model_category IS DISTINCT FROM 'gpt-image-2' THEN text_input_tokens  ELSE 0 END) AS gemini_text_input_tokens,
            SUM(CASE WHEN model_category IS DISTINCT FROM 'gpt-image-2' THEN text_output_tokens ELSE 0 END) AS gemini_text_output_tokens,
            SUM(CASE WHEN model_category IS DISTINCT FROM 'gpt-image-2' THEN image_input_tokens  ELSE 0 END) AS gemini_image_input_tokens,
            SUM(CASE WHEN model_category IS DISTINCT FROM 'gpt-image-2' THEN image_output_tokens ELSE 0 END) AS gemini_image_output_tokens,
            SUM(CASE WHEN model_category = 'gpt-image-2' THEN text_input_tokens  ELSE 0 END) AS gpt2_text_input_tokens,
            SUM(CASE WHEN model_category = 'gpt-image-2' THEN image_input_tokens  ELSE 0 END) AS gpt2_image_input_tokens,
            SUM(CASE WHEN model_category = 'gpt-image-2' THEN image_output_tokens ELSE 0 END) AS gpt2_image_output_tokens
        FROM creatives
        WHERE show_in_gallery = TRUE
        GROUP BY project_id
    ) s ON s.project_id = p.id
    CROSS JOIN (SELECT * FROM config WHERE id = 1) cfg
"""


@router.get("", summary="List all projects for the current user")
def list_projects(claims: Dict[str, Any] = Depends(require_auth)):
    oid = claims.get("oid") or ""
    with get_db() as conn:
        with conn.cursor(cursor_factory=RealDictCursor) as cur:
            cur.execute(
                "SELECT * FROM projects WHERE user_id = %s ORDER BY COALESCE(updated_at, created_at) DESC",
                (oid,),
            )
            projects = [dict(p) for p in cur.fetchall()]

            cur.execute(
                """
                SELECT
                    COUNT(c.image_url) AS total_images_created,
                    ROUND(
                        COALESCE(SUM(CASE WHEN c.model_category IS DISTINCT FROM 'gpt-image-2' THEN c.text_input_tokens  ELSE 0 END), 0) / 1000000.0 * MAX(cfg.text_input_tokens_cost)
                      + COALESCE(SUM(CASE WHEN c.model_category IS DISTINCT FROM 'gpt-image-2' THEN c.text_output_tokens ELSE 0 END), 0) / 1000000.0 * MAX(cfg.text_output_tokens_cost)
                      + COALESCE(SUM(CASE WHEN c.model_category IS DISTINCT FROM 'gpt-image-2' THEN c.image_input_tokens  ELSE 0 END), 0) / 1000000.0 * MAX(cfg.image_input_tokens_cost)
                      + COALESCE(SUM(CASE WHEN c.model_category IS DISTINCT FROM 'gpt-image-2' THEN c.image_output_tokens ELSE 0 END), 0) / 1000000.0 * MAX(cfg.image_output_tokens_cost)
                      + COALESCE(SUM(CASE WHEN c.model_category = 'gpt-image-2' THEN c.text_input_tokens  ELSE 0 END), 0) / 1000000.0 * MAX(cfg.text2_input_tokens_cost)
                      + COALESCE(SUM(CASE WHEN c.model_category = 'gpt-image-2' THEN c.image_input_tokens  ELSE 0 END), 0) / 1000000.0 * MAX(cfg.image2_input_tokens_cost)
                      + COALESCE(SUM(CASE WHEN c.model_category = 'gpt-image-2' THEN c.image_output_tokens ELSE 0 END), 0) / 1000000.0 * MAX(cfg.image2_output_tokens_cost),
                    4) AS total_cost_usd
                FROM creatives c
                CROSS JOIN (SELECT * FROM config WHERE id = 1) cfg
                WHERE c.user_id = %s AND c.show_in_gallery = TRUE
                """,
                (oid,),
            )
            stats = dict(cur.fetchone())

    return {
        "total_projects": len(projects),
        "total_images_created": stats["total_images_created"],
        "total_cost_usd": stats["total_cost_usd"],
        "projects": projects,
    }


@router.post("", summary="Create a new project", status_code=201)
def create_project(
    request: ProjectCreate,
    claims: Dict[str, Any] = Depends(require_auth),
):
    oid = claims.get("oid") or ""
    with get_db() as conn:
        with conn.cursor(cursor_factory=RealDictCursor) as cur:
            cur.execute(
                """
                INSERT INTO projects (user_id, name, description)
                VALUES (%s, %s, %s)
                RETURNING *
                """,
                (oid, request.name, request.description),
            )
            project = dict(cur.fetchone())
        conn.commit()
    return project


@router.get("/{project_id}", summary="Get a single project")
def get_project(
    project_id: str,
    claims: Dict[str, Any] = Depends(require_auth),
):
    oid = claims.get("oid") or ""
    with get_db() as conn:
        with conn.cursor(cursor_factory=RealDictCursor) as cur:
            cur.execute(
                _PROJECT_STATS_QUERY
                + "WHERE p.id = %s AND p.user_id = %s",
                (project_id, oid),
            )
            project = cur.fetchone()
    if not project:
        raise HTTPException(status_code=404, detail="Project not found")
    return dict(project)


@router.put("/{project_id}", summary="Update project name or description")
def update_project(
    project_id: str,
    request: ProjectUpdate,
    claims: Dict[str, Any] = Depends(require_auth),
):
    oid = claims.get("oid") or ""
    with get_db() as conn:
        with conn.cursor(cursor_factory=RealDictCursor) as cur:
            cur.execute(
                """
                UPDATE projects
                SET name        = COALESCE(%s, name),
                    description = COALESCE(%s, description),
                    updated_at  = NOW()
                WHERE id = %s AND user_id = %s
                RETURNING *
                """,
                (request.name, request.description, project_id, oid),
            )
            project = cur.fetchone()
        conn.commit()
    if not project:
        raise HTTPException(status_code=404, detail="Project not found")
    return dict(project)


@router.delete("/{project_id}", summary="Delete a project and all its creatives")
def delete_project(
    project_id: str,
    claims: Dict[str, Any] = Depends(require_auth),
):
    oid = claims.get("oid") or ""
    with get_db() as conn:
        with conn.cursor() as cur:
            cur.execute(
                "UPDATE creatives SET show_in_gallery = FALSE WHERE project_id = %s",
                (project_id,),
            )
            cur.execute(
                "DELETE FROM projects WHERE id = %s AND user_id = %s RETURNING id",
                (project_id, oid),
            )
            deleted = cur.fetchone()
        conn.commit()
    if not deleted:
        raise HTTPException(status_code=404, detail="Project not found")
    return {"status": "deleted", "project_id": project_id}


@router.get("/{project_id}/history", summary="List creatives for a project (history view)")
def get_project_history(
    project_id: str,
    category: Optional[str] = Query(None, description="Filter by category (social, copywriting, banner, image_edit, image_gen)"),
    claims: Dict[str, Any] = Depends(require_auth),
) -> List[Dict[str, Any]]:
    oid = claims.get("oid") or ""
    # Verify the project belongs to this user; raises 404 if not.
    _require_owns_project(project_id, oid)

    conditions = ["project_id = %s", "show_in_gallery = TRUE"]
    params: List[Any] = [project_id]

    if category:
        conditions.append("category = %s")
        params.append(category)

    query = (
        f"SELECT * FROM creatives WHERE {' AND '.join(conditions)} ORDER BY created_at DESC"
    )

    with get_db() as conn:
        with conn.cursor(cursor_factory=RealDictCursor) as cur:
            cur.execute(query, params)
            return [apply_sas_urls(dict(c)) for c in cur.fetchall()]


@router.get("/{project_id}/export", summary="Export all creatives for a project as a ZIP")
def export_project(
    project_id: str,
    category: Optional[str] = Query(None, description="Filter by category"),
    claims: Dict[str, Any] = Depends(require_auth),
):
    oid = claims.get("oid") or ""
    project = _require_owns_project(project_id, oid)

    conditions = ["project_id = %s", "show_in_gallery = TRUE"]
    params: List[Any] = [project_id]
    if category:
        conditions.append("category = %s")
        params.append(category)

    with get_db() as conn:
        with conn.cursor(cursor_factory=RealDictCursor) as cur:
            cur.execute(
                f"SELECT * FROM creatives WHERE {' AND '.join(conditions)} ORDER BY created_at DESC",
                params,
            )
            creatives = [dict(c) for c in cur.fetchall()]

    if not creatives:
        raise HTTPException(status_code=404, detail="No creatives found for this project")

    zip_buffer = io.BytesIO()
    manifest = []

    with zipfile.ZipFile(zip_buffer, mode="w", compression=zipfile.ZIP_DEFLATED) as zf:
        image_counters: Dict[str, int] = {}

        for creative in creatives:
            cat = creative.get("category") or "unknown"
            creative_id = str(creative.get("id", ""))[:8]
            created_at = str(creative.get("created_at", ""))[:10]

            # -- image --
            image_url = creative.get("image_url")
            if image_url:
                image_counters[cat] = image_counters.get(cat, 0) + 1
                filename = f"images/{cat}_{created_at}_{creative_id}.png"
                image_bytes = download_blob_bytes(image_url)
                if image_bytes:
                    zf.writestr(filename, image_bytes)

            # -- text --
            text = creative.get("text")
            if text:
                filename = f"text/{cat}_{created_at}_{creative_id}.txt"
                zf.writestr(filename, text)

            manifest.append({
                "id": creative.get("id"),
                "category": cat,
                "created_at": created_at,
                "has_image": bool(image_url),
                "has_text": bool(text),
                "metadata": creative.get("metadata"),
            })

        zf.writestr("manifest.json", json.dumps(manifest, indent=2, default=str))

    zip_buffer.seek(0)
    project_name = (project.get("name") or project_id).replace(" ", "_")
    timestamp = datetime.now(timezone.utc).strftime("%Y%m%d_%H%M%S")
    filename = f"{project_name}_{timestamp}.zip"

    return StreamingResponse(
        zip_buffer,
        media_type="application/zip",
        headers={"Content-Disposition": f'attachment; filename="{filename}"'},
    )