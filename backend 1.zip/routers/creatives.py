import logging
from fastapi import APIRouter, Depends, HTTPException, Query
from pydantic import BaseModel
from typing import Optional, Dict, Any, List
from psycopg2.extras import RealDictCursor, Json

from auth.azure_auth import is_pm_user, require_auth
from db.connection import get_db
from services.blob_service import (
    apply_sas_urls,
    upload_creative_image,
    upload_reference_images,
)

router = APIRouter(prefix="/api/v1/creatives", tags=["Creatives"])
logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Request model (used by the explicit frontend save endpoint)
# ---------------------------------------------------------------------------

class CreativeSaveRequest(BaseModel):
    project_id: str
    text: Optional[str] = None
    image_b64: Optional[str] = None
    reference_images_b64: Optional[List[str]] = None
    category: Optional[str] = None
    metadata: Optional[Dict[str, Any]] = None


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------

def _get_user(azure_oid: str) -> Dict[str, Any]:
    """Fetch user row by id (= azure_oid). Raises 404 if not found."""
    with get_db() as conn:
        with conn.cursor(cursor_factory=RealDictCursor) as cur:
            cur.execute(
                "SELECT id, email, name, department, sub_department FROM users WHERE id = %s",
                (azure_oid,),
            )
            user = cur.fetchone()
    if not user:
        raise HTTPException(status_code=404, detail="User not found")
    return dict(user)


def _insert_creative(
    *,
    project_id: str,
    user_id: str,               # users.id = azure_oid (TEXT)
    text: Optional[str],
    image_b64: Optional[str],
    department: Optional[str],
    sub_department: Optional[str],
    category: Optional[str],
    metadata: Dict[str, Any],
    user_email: str,
    user_name: str,
    reference_images_b64: Optional[List[str]] = None,
    text_input_tokens: int = 0,
    text_output_tokens: int = 0,
    image_input_tokens: int = 0,
    image_output_tokens: int = 0,
    model_category: Optional[str] = None,
    show_in_gallery: bool = True,
) -> Dict[str, Any]:
    """Upload images then insert one creative row. Returns the created record."""
    if reference_images_b64:
        ref_urls = upload_reference_images(user_id, reference_images_b64)
        metadata["reference_image_urls"] = ref_urls

    image_url: Optional[str] = None
    if image_b64:
        image_url = upload_creative_image(user_id, image_b64)

    with get_db() as conn:
        with conn.cursor(cursor_factory=RealDictCursor) as cur:
            cur.execute(
                """
                INSERT INTO creatives
                    (project_id, user_id, text, image_url,
                     department, sub_department, category, metadata,
                     user_email, user_name,
                     text_input_tokens, text_output_tokens,
                     image_input_tokens, image_output_tokens,
                     model_category, show_in_gallery)
                VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
                RETURNING *
                """,
                (
                    project_id,
                    user_id,
                    text,
                    image_url,
                    department,
                    sub_department,
                    category,
                    Json(metadata) if metadata else None,
                    user_email,
                    user_name,
                    text_input_tokens,
                    text_output_tokens,
                    image_input_tokens,
                    image_output_tokens,
                    model_category,
                    show_in_gallery,
                ),
            )
            creative = dict(cur.fetchone())
        conn.commit()
    return creative


# ---------------------------------------------------------------------------
# Auto-save — called by generation endpoints, never raises
# ---------------------------------------------------------------------------

def autosave_creative(
    *,
    azure_oid: str,
    project_id: str,
    category: str,
    metadata: Dict[str, Any],
    text: Optional[str] = None,
    images_b64: Optional[List[str]] = None,
    reference_images_b64: Optional[List[str]] = None,
    text_input_tokens: int = 0,
    text_output_tokens: int = 0,
    image_input_tokens: int = 0,
    image_output_tokens: int = 0,
    model_category: Optional[str] = None,
    show_in_gallery: bool = True,
) -> None:
    """
    Persist generated output to the creatives table after a successful generation.

    One row is inserted per generated image (or one text-only row when there are
    no images, e.g. copywriting).  All failures are logged and swallowed so a DB /
    blob hiccup never blocks the generation response returned to the frontend.
    """
    try:
        user = _get_user(azure_oid)
    except HTTPException:
        return  # User not yet registered; skip silently
    except Exception as exc:
        logger.warning("autosave_creative: user lookup failed: %s", exc)
        return

    try:
        image_list: List[Optional[str]] = list(images_b64) if images_b64 else [None]
        for idx, image_b64 in enumerate(image_list):
            meta = dict(metadata)
            # Only pass reference images for the first row to avoid duplicate uploads.
            ref_imgs = reference_images_b64 if idx == 0 else None
            _insert_creative(
                project_id=project_id,
                user_id=azure_oid,   # users.id IS the azure_oid
                text=text,
                image_b64=image_b64,
                department=user.get("department"),
                sub_department=user.get("sub_department"),
                category=category,
                metadata=meta,
                user_email=user["email"],
                user_name=user["name"],
                reference_images_b64=ref_imgs,
                text_input_tokens=text_input_tokens,
                text_output_tokens=text_output_tokens,
                image_input_tokens=image_input_tokens // len(image_list) if image_list else 0,
                image_output_tokens=image_output_tokens // len(image_list) if image_list else 0,
                model_category=model_category,
                show_in_gallery=show_in_gallery,
            )
    except Exception as exc:
        logger.warning("autosave_creative: save failed for category=%s: %s", category, exc)


# ---------------------------------------------------------------------------
# Routes
# ---------------------------------------------------------------------------

@router.post("", summary="Save a creative after generation")
def save_creative(
    request: CreativeSaveRequest,
    claims: Dict[str, Any] = Depends(require_auth),
):
    azure_oid = claims.get("oid") or ""
    user = _get_user(azure_oid)
    metadata = dict(request.metadata) if request.metadata else {}
    creative = _insert_creative(
        project_id=request.project_id,
        user_id=azure_oid,
        text=request.text,
        image_b64=request.image_b64,
        department=user["department"],
        sub_department=user.get("sub_department"),
        category=request.category,
        metadata=metadata,
        user_email=user["email"],
        user_name=user["name"],
        reference_images_b64=request.reference_images_b64,
    )
    return apply_sas_urls(creative)


@router.get("", summary="List creatives for the current user")
def list_creatives(
    project_id: Optional[str] = Query(None, description="Filter by project UUID"),
    category: Optional[str] = Query(None, description="Filter by category (tab name)"),
    claims: Dict[str, Any] = Depends(require_auth),
):
    azure_oid = claims.get("oid") or ""
    user = _get_user(azure_oid)  # 404 if not registered

    conditions: List[str] = ["user_id = %s", "show_in_gallery = TRUE", "image_url IS NOT NULL"]
    params: List[Any] = [azure_oid]

    if project_id:
        conditions.append("project_id = %s")
        params.append(project_id)
    if category:
        conditions.append("category = %s")
        params.append(category)

    query = (
        f"SELECT * FROM creatives WHERE {' AND '.join(conditions)} ORDER BY created_at DESC"
    )

    with get_db() as conn:
        with conn.cursor(cursor_factory=RealDictCursor) as cur:
            cur.execute(query, params)
            creatives = [apply_sas_urls(dict(c)) for c in cur.fetchall()]

        if is_pm_user(user) and creatives:
            creative_ids = [c["id"] for c in creatives]
            with conn.cursor(cursor_factory=RealDictCursor) as cur:
                cur.execute(
                    """
                    SELECT DISTINCT ON (creative_id)
                        cah.creative_id,
                        cah.approval_request_id,
                        cah.status,
                        cah.comment,
                        cah.created_at,
                        u.name AS approver_name
                    FROM creative_approval_history cah
                    LEFT JOIN users u ON u.id = cah.user_id
                    WHERE creative_id = ANY(%s::uuid[])
                    ORDER BY cah.creative_id, cah.created_at DESC
                    """,
                    (creative_ids,),
                )
                approval_map = {
                    str(r["creative_id"]): {
                        "approval_request_id": str(r["approval_request_id"]),
                        "status": r["status"],
                        "comment": r["comment"],
                        "approver_name": r.get("approver_name"),
                        "created_at": r["created_at"].isoformat() if r["created_at"] else None,
                    }
                    for r in cur.fetchall()
                }
            for creative in creatives:
                creative["approval"] = approval_map.get(str(creative["id"]))

    return creatives


@router.get("/{creative_id}", summary="Get a single creative")
def get_creative(
    creative_id: str,
    claims: Dict[str, Any] = Depends(require_auth),
):
    azure_oid = claims.get("oid") or ""
    with get_db() as conn:
        with conn.cursor(cursor_factory=RealDictCursor) as cur:
            cur.execute(
                "SELECT * FROM creatives WHERE id = %s AND user_id = %s AND show_in_gallery = TRUE",
                (creative_id, azure_oid),
            )
            creative = cur.fetchone()
    if not creative:
        raise HTTPException(status_code=404, detail="Creative not found")
    return apply_sas_urls(dict(creative))


@router.patch("/{creative_id}/toggle-hide", summary="Hide or unhide a creative in the gallery")
def set_creative_visibility(
    creative_id: str,
    hide: bool = Query(..., description="True to hide from gallery, False to unhide"),
    claims: Dict[str, Any] = Depends(require_auth),
):
    with get_db() as conn:
        with conn.cursor() as cur:
            cur.execute(
                "UPDATE creatives SET show_in_gallery = %s WHERE id = %s RETURNING id",
                (not hide, creative_id),
            )
            updated = cur.fetchone()
        conn.commit()
    if not updated:
        raise HTTPException(status_code=404, detail="Creative not found")
    return {"creative_id": creative_id, "visible": not hide}


@router.delete("/{creative_id}", summary="Soft-delete a creative")
def delete_creative(
    creative_id: str,
    claims: Dict[str, Any] = Depends(require_auth),
):
    azure_oid = claims.get("oid") or ""
    with get_db() as conn:
        with conn.cursor() as cur:
            cur.execute(
                """
                UPDATE creatives SET show_in_gallery = FALSE
                WHERE id = %s AND user_id = %s AND show_in_gallery = TRUE
                RETURNING id
                """,
                (creative_id, azure_oid),
            )
            updated = cur.fetchone()
        conn.commit()
    if not updated:
        raise HTTPException(status_code=404, detail="Creative not found")
    return {"status": "deleted", "creative_id": creative_id}