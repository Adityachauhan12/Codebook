import re
from typing import Any, Dict, List, Optional

from fastapi import APIRouter, Depends, HTTPException
from psycopg2.extras import RealDictCursor
from pydantic import BaseModel, field_validator

from auth.azure_auth import require_analytics_role, require_auth
from db.connection import get_db
from services.blob_service import apply_sas_urls

router = APIRouter(prefix="/api/v1/feedback", tags=["Feedback"])


def _strip_html(value: Optional[str]) -> Optional[str]:
    """Remove HTML tags from user-supplied text to prevent stored XSS."""
    if value is None:
        return None
    return re.sub(r"<[^>]+>", "", value).strip()


class FeedbackRequest(BaseModel):
    creative_id: str
    reaction: Optional[str] = None  # "like" | "dislike" | null to clear
    comment: Optional[str] = None

    @field_validator("reaction")
    @classmethod
    def _validate_reaction(cls, v):
        if v is not None and v not in ("like", "dislike"):
            raise ValueError("reaction must be 'like', 'dislike', or null")
        return v

    @field_validator("comment", mode="before")
    @classmethod
    def sanitize_comment(cls, v):
        return _strip_html(v) if isinstance(v, str) else v


@router.post("", summary="Submit or update feedback for a creative")
def upsert_feedback(
    request: FeedbackRequest,
    claims: Dict[str, Any] = Depends(require_auth),
):
    user_id = claims.get("oid") or ""
    with get_db() as conn:
        with conn.cursor(cursor_factory=RealDictCursor) as cur:
            cur.execute(
                """
                INSERT INTO creative_feedback (creative_id, user_id, reaction, comment)
                VALUES (%s, %s, %s, %s)
                ON CONFLICT (creative_id, user_id) DO UPDATE SET
                    reaction   = EXCLUDED.reaction,
                    comment    = EXCLUDED.comment,
                    created_at = NOW()
                RETURNING *
                """,
                (request.creative_id, user_id, request.reaction, request.comment),
            )
            row = cur.fetchone()
        conn.commit()
    return dict(row)


@router.get("/admin/all", summary="Get all feedback entries for admin review")
def get_all_feedback_for_admin(
    claims: Dict[str, Any] = Depends(require_analytics_role),
):
    with get_db() as conn:
        with conn.cursor(cursor_factory=RealDictCursor) as cur:
            cur.execute(
                """
                SELECT
                    f.id,
                    f.creative_id,
                    f.user_id,
                    f.reaction,
                    f.comment,
                    f.created_at,
                    u.name AS user_name,
                    u.email AS user_email,
                    c.project_id,
                    c.category,
                    c.image_url,
                    c.text
                FROM creative_feedback f
                LEFT JOIN users u ON u.id = f.user_id
                LEFT JOIN creatives c ON c.id = f.creative_id
                WHERE f.reaction IS NOT NULL OR COALESCE(TRIM(f.comment), '') <> ''
                ORDER BY f.created_at DESC
                """
            )
            rows = [apply_sas_urls(dict(r)) for r in cur.fetchall()]

    return {
        "total_feedback": len(rows),
        "feedback": rows,
    }


@router.get("/{creative_id}", summary="Get all feedback for a creative")
def get_feedback(
    creative_id: str,
    claims: Dict[str, Any] = Depends(require_auth),
):
    with get_db() as conn:
        with conn.cursor(cursor_factory=RealDictCursor) as cur:
            cur.execute(
                """
                SELECT f.id, f.creative_id, f.user_id, f.reaction, f.comment, f.created_at,
                       u.name AS user_name, u.email AS user_email
                FROM creative_feedback f
                LEFT JOIN users u ON u.id = f.user_id
                WHERE f.creative_id = %s
                ORDER BY f.created_at DESC
                """,
                (creative_id,),
            )
            rows = [dict(r) for r in cur.fetchall()]

            cur.execute(
                "SELECT reaction, COUNT(*) AS count FROM creative_feedback WHERE creative_id = %s GROUP BY reaction",
                (creative_id,),
            )
            counts = {r["reaction"]: r["count"] for r in cur.fetchall()}

    return {
        "creative_id": creative_id,
        "likes": counts.get("like", 0),
        "dislikes": counts.get("dislike", 0),
        "feedback": rows,
    }


@router.get("/me/{creative_id}", summary="Get current user's feedback for a creative")
def get_my_feedback(
    creative_id: str,
    claims: Dict[str, Any] = Depends(require_auth),
):
    user_id = claims.get("oid") or ""
    with get_db() as conn:
        with conn.cursor(cursor_factory=RealDictCursor) as cur:
            cur.execute(
                "SELECT * FROM creative_feedback WHERE creative_id = %s AND user_id = %s",
                (creative_id, user_id),
            )
            row = cur.fetchone()
    return dict(row) if row else {"creative_id": creative_id, "reaction": None, "comment": None}
