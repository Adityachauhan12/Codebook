"""
Previous Creatives API
GET /api/prev-creatives — full list of all prev_creatives rows with SAS image URLs.
"""

import logging
from typing import Any, Dict, List

from fastapi import APIRouter, Depends, HTTPException

from auth.azure_auth import require_auth
from db.connection import get_db
from services.blob_service import generate_sas_url

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/prev-creatives", tags=["Prev Creatives"])


@router.get("", summary="List all previous creatives")
def list_prev_creatives(
    claims: Dict[str, Any] = Depends(require_auth),
) -> Dict:
    try:
        with get_db() as conn:
            with conn.cursor() as cur:
                cur.execute(
                    """
                    SELECT id, title, image_url, created_at
                    FROM prev_creatives
                    ORDER BY created_at DESC
                    """
                )
                rows = cur.fetchall()

        items: List[Dict] = [
            {
                "id": str(row[0]),
                "title": row[1],
                "image_url": generate_sas_url(row[2]),
                "created_at": row[3].isoformat() if row[3] else None,
            }
            for row in rows
        ]

        return {
            "total": len(items),
            "items": items,
        }
    except Exception as exc:
        logger.exception("list_prev_creatives failed: %s", exc)
        raise HTTPException(status_code=500, detail="Failed to fetch previous creatives.")
