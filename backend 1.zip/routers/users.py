from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel
from typing import Optional, Dict, Any
from psycopg2.extras import RealDictCursor

from auth.azure_auth import require_auth
from db.connection import get_db

router = APIRouter(prefix="/api/v1/users", tags=["Users"])


class UserUpsertRequest(BaseModel):
    department: Optional[str] = None


def _claims_to_user_fields(claims: Dict[str, Any]) -> tuple:
    email = claims.get("preferred_username") or claims.get("upn") or claims.get("email") or ""
    name = claims.get("name") or ""
    azure_oid = claims.get("oid") or ""
    return email, name, azure_oid


@router.post("/me", summary="Upsert user on first login")
def upsert_user(
    request: UserUpsertRequest,
    claims: Dict[str, Any] = Depends(require_auth),
):
    email, name, azure_oid = _claims_to_user_fields(claims)
    with get_db() as conn:
        with conn.cursor(cursor_factory=RealDictCursor) as cur:
            cur.execute(
                """
                INSERT INTO users (id, email, name, department)
                VALUES (%s, %s, %s, %s)
                ON CONFLICT (id) DO UPDATE SET
                    email      = EXCLUDED.email,
                    name       = EXCLUDED.name,
                    department = COALESCE(EXCLUDED.department, users.department)
                RETURNING *
                """,
                (azure_oid, email, name, request.department),
            )
            user = dict(cur.fetchone())
        conn.commit()
    return user


@router.get("/me", summary="Get current user profile")
def get_current_user(claims: Dict[str, Any] = Depends(require_auth)):
    _, _, azure_oid = _claims_to_user_fields(claims)
    with get_db() as conn:
        with conn.cursor(cursor_factory=RealDictCursor) as cur:
            cur.execute("SELECT * FROM users WHERE id = %s", (azure_oid,))
            user = cur.fetchone()
    if not user:
        raise HTTPException(
            status_code=404,
            detail="User not found. Call POST /api/v1/users/me first.",
        )
    return dict(user)