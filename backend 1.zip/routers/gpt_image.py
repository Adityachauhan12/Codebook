"""
GPT Image 2 endpoints (Azure OpenAI gpt-image-2 deployment).

Endpoints:
  POST /api/gpt-image/freeform  — freeform text-to-image, optional reference images
  POST /api/gpt-image/banner    — brand guardrails + logo + asset images from backend
  POST /api/gpt-image/edit      — image editing, 1-10 source images required
"""

import base64
import logging
from pathlib import Path
from typing import Annotated, Any, Dict, List, Optional

from fastapi import APIRouter, Depends, File, Form, HTTPException, UploadFile

from auth.azure_auth import require_auth
from utils.limiter import require_generation_rate_limit
from prompts.brand_guardrails_image import INDIGO_IMAGE_BRAND_POLICY
from routers.creatives import autosave_creative
from utils.image_processor import resize_to_exact

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/gpt-image", tags=["GPT Image 2"])

_BACKEND_DIR = Path(__file__).resolve().parent.parent
_CAMPAIGN_LOGO_DIR = _BACKEND_DIR / "campaign_logo"
_PRIMARY_LOGO_BLUE_BG = _CAMPAIGN_LOGO_DIR / "1920x1080_Icon Blue bg.jpg"
_PRIMARY_LOGO_WHITE_BG = _CAMPAIGN_LOGO_DIR / "1920x1080_Icon Blue.jpg"
_ASSET_IMAGES_DIR = _BACKEND_DIR / "asset_images"

_MODEL_CATEGORY = "gpt-image-2"

# ---------------------------------------------------------------------------
# Lazy service init
# ---------------------------------------------------------------------------

_service = None


def _get_service():
    global _service
    if _service is None:
        from services.gpt_image_service import GptImageService
        _service = GptImageService()
    return _service


def _load_brand_images() -> List[bytes]:
    """Load logo + up to 5 asset images as bytes."""
    images: List[bytes] = []

    logo_path = _PRIMARY_LOGO_BLUE_BG if _PRIMARY_LOGO_BLUE_BG.exists() else _PRIMARY_LOGO_WHITE_BG
    if logo_path.exists():
        images.append(logo_path.read_bytes())

    if _ASSET_IMAGES_DIR.is_dir():
        supported = {".png", ".jpg", ".jpeg", ".webp"}
        asset_files = sorted(
            f for f in _ASSET_IMAGES_DIR.iterdir()
            if f.suffix.lower() in supported
        )[:5]
        for f in asset_files:
            images.append(f.read_bytes())

    return images


def _bytes_to_b64(image_bytes_list: List[bytes]) -> List[str]:
    return [base64.standard_b64encode(b).decode() for b in image_bytes_list]


def _validate_custom_dimensions(custom_width: Optional[int], custom_height: Optional[int]) -> None:
    has_w = custom_width is not None
    has_h = custom_height is not None
    if has_w != has_h:
        raise HTTPException(status_code=422, detail="custom_width and custom_height must be provided together")


def _nearest_gpt_size_for_dimensions(custom_width: Optional[int], custom_height: Optional[int], fallback_size: str) -> str:
    if custom_width is None or custom_height is None:
        return fallback_size

    target_ratio = custom_width / custom_height
    gpt_size_ratios = {
        "1024x1024": 1.0,
        "1536x1024": 1536 / 1024,
        "1024x1536": 1024 / 1536,
    }
    return min(gpt_size_ratios.items(), key=lambda item: abs(item[1] - target_ratio))[0]


def _with_custom_size_prompt(prompt: str, custom_width: Optional[int], custom_height: Optional[int]) -> str:
    if custom_width is None or custom_height is None:
        return prompt
    return (
        f"{prompt}\n\n"
        f"Output size requirement: produce content optimized for exactly {custom_width}x{custom_height} pixels. "
        f"Ensure composition, framing, typography scale, and safe margins fit this exact canvas size."
    )


# ---------------------------------------------------------------------------
# Endpoints
# ---------------------------------------------------------------------------

@router.post(
    "/freeform",
    summary="GPT Image 2 — freeform text-to-image",
    description=(
        "Generate an image from a text prompt with no brand guardrails. "
        "Optionally upload up to 10 reference images. "
        "Supported sizes: 1024x1024 (square), 1536x1024 (landscape), 1024x1536 (portrait), auto. "
        "Supported quality: low | medium | high."
    ),
    dependencies=[Depends(require_generation_rate_limit)],
)
async def gpt_image_freeform(
    prompt: Annotated[str, Form(description="Image description / generation prompt")],
    size: Annotated[Optional[str], Form(description="1024x1024 | 1536x1024 | 1024x1536 | auto")] = "1024x1024",
    quality: Annotated[Optional[str], Form(description="low | medium | high")] = None,
    custom_width: Annotated[Optional[int], Form(description="Custom output width in pixels")]=None,
    custom_height: Annotated[Optional[int], Form(description="Custom output height in pixels")]=None,
    project_id: Annotated[Optional[str], Form(description="Project ID to save the creative under")] = None,
    show_in_gallery: Annotated[bool, Form(description="Include in shared gallery (default true)")] = True,
    images: Optional[List[UploadFile]] = File(default=None, description="Optional reference images (up to 10)"),
    claims: Dict[str, Any] = Depends(require_auth),
):
    user_oid = claims.get("oid", "unknown")

    reference_bytes: Optional[List[bytes]] = None
    if images:
        if len(images) > 10:
            raise HTTPException(status_code=422, detail="Maximum 10 reference images allowed")
        reference_bytes = [await img.read() for img in images]

    _validate_custom_dimensions(custom_width, custom_height)
    effective_size = _nearest_gpt_size_for_dimensions(custom_width, custom_height, size or "1024x1024")
    prompt_with_size = _with_custom_size_prompt(prompt, custom_width, custom_height)

    logger.info(
        "gpt_image_freeform | user=%s requested_size=%s effective_size=%s quality=%s custom_width=%s custom_height=%s reference_images=%d prompt_snippet=%r",
        user_oid, size, effective_size, quality, custom_width, custom_height, len(reference_bytes) if reference_bytes else 0, prompt[:200],
    )

    try:
        svc = _get_service()
        image, txt_in, img_in, img_out = svc.generate_image(
            prompt=prompt_with_size,
            size=effective_size,
            quality=quality,
            reference_images=reference_bytes,
        )
        if custom_width and custom_height:
            image = resize_to_exact(image, custom_width, custom_height)
        logger.info(
            "gpt_image_freeform success | user=%s requested_size=%s effective_size=%s quality=%s custom_width=%s custom_height=%s dims=%s "
            "text_input_tokens=%d image_input_tokens=%d image_output_tokens=%d",
            user_oid, size, effective_size, quality, custom_width, custom_height, image.size, txt_in, img_in, img_out,
        )

        image_b64 = svc.to_base64(image)

        if project_id:
            autosave_creative(
                azure_oid=user_oid,
                project_id=project_id,
                category="freeform",
                metadata={
                    "prompt": prompt,
                    "size": size,
                    "effective_size": effective_size,
                    "quality": quality,
                    **({"custom_width": custom_width, "custom_height": custom_height} if custom_width and custom_height else {}),
                },
                images_b64=[image_b64],
                reference_images_b64=_bytes_to_b64(reference_bytes) if reference_bytes else None,
                text_input_tokens=txt_in,
                image_input_tokens=img_in,
                image_output_tokens=img_out,
                model_category=_MODEL_CATEGORY,
                show_in_gallery=show_in_gallery,
            )

        return {
            "status": "success",
            "size": size,
            "effective_size": effective_size,
            **({"custom_width": custom_width, "custom_height": custom_height} if custom_width and custom_height else {}),
            "image_count": 1,
            "images": [image_b64],
        }
    except HTTPException:
        raise
    except Exception as e:
        logger.exception(
            "gpt_image_freeform failed | user=%s size=%s quality=%s error_type=%s error=%s",
            user_oid, size, quality, type(e).__name__, e,
        )
        raise HTTPException(status_code=500, detail=f"GPT Image generation failed: {e}")


@router.post(
    "/banner",
    summary="GPT Image 2 — banner (brand guardrails + backend logo/assets)",
    description=(
        "Generate an image using IndiGo brand guardrails, logo, and asset images injected from the backend. "
        "Optionally upload up to 4 additional reference images. "
        "Supported sizes: 1024x1024 (square), 1536x1024 (landscape), 1024x1536 (portrait), auto. "
        "Supported quality: low | medium | high."
    ),
    dependencies=[Depends(require_generation_rate_limit)],
)
async def gpt_image_banner(
    prompt: Annotated[str, Form(description="Image description / generation prompt")],
    size: Annotated[Optional[str], Form(description="1024x1024 | 1536x1024 | 1024x1536 | auto")] = "1024x1024",
    quality: Annotated[Optional[str], Form(description="low | medium | high")] = None,
    custom_width: Annotated[Optional[int], Form(description="Custom output width in pixels")]=None,
    custom_height: Annotated[Optional[int], Form(description="Custom output height in pixels")]=None,
    project_id: Annotated[Optional[str], Form(description="Project ID to save the creative under")] = None,
    show_in_gallery: Annotated[bool, Form(description="Include in shared gallery (default true)")] = True,
    images: Optional[List[UploadFile]] = File(default=None, description="Optional user images (up to 4)"),
    claims: Dict[str, Any] = Depends(require_auth),
):
    user_oid = claims.get("oid", "unknown")

    if images and len(images) > 4:
        raise HTTPException(status_code=422, detail="Maximum 4 images allowed for banner")

    _validate_custom_dimensions(custom_width, custom_height)
    effective_size = _nearest_gpt_size_for_dimensions(custom_width, custom_height, size or "1024x1024")

    brand_prompt = f"{INDIGO_IMAGE_BRAND_POLICY}\n\n{prompt}"
    brand_prompt_with_size = _with_custom_size_prompt(brand_prompt, custom_width, custom_height)

    brand_images = _load_brand_images()
    if not brand_images:
        logger.warning("gpt_image_banner: no brand images found in logo/asset dirs")

    user_image_bytes: List[bytes] = [await img.read() for img in images] if images else []
    all_images = brand_images + user_image_bytes

    logger.info(
        "gpt_image_banner | user=%s requested_size=%s effective_size=%s quality=%s custom_width=%s custom_height=%s brand_image_count=%d user_image_count=%d",
        user_oid, size, effective_size, quality, custom_width, custom_height, len(brand_images), len(user_image_bytes),
    )

    try:
        svc = _get_service()
        image, txt_in, img_in, img_out = svc.generate_image(
            prompt=brand_prompt_with_size,
            size=effective_size,
            quality=quality,
            reference_images=all_images if all_images else None,
        )
        if custom_width and custom_height:
            image = resize_to_exact(image, custom_width, custom_height)
        logger.info(
            "gpt_image_banner success | user=%s requested_size=%s effective_size=%s quality=%s custom_width=%s custom_height=%s dims=%s "
            "text_input_tokens=%d image_input_tokens=%d image_output_tokens=%d",
            user_oid, size, effective_size, quality, custom_width, custom_height, image.size, txt_in, img_in, img_out,
        )

        image_b64 = svc.to_base64(image)

        if project_id:
            autosave_creative(
                azure_oid=user_oid,
                project_id=project_id,
                category="banner",
                metadata={
                    "prompt": prompt,
                    "size": size,
                    "effective_size": effective_size,
                    "quality": quality,
                    **({"custom_width": custom_width, "custom_height": custom_height} if custom_width and custom_height else {}),
                },
                images_b64=[image_b64],
                reference_images_b64=_bytes_to_b64(user_image_bytes) if user_image_bytes else None,
                text_input_tokens=txt_in,
                image_input_tokens=img_in,
                image_output_tokens=img_out,
                model_category=_MODEL_CATEGORY,
                show_in_gallery=show_in_gallery,
            )

        return {
            "status": "success",
            "size": size,
            "effective_size": effective_size,
            **({"custom_width": custom_width, "custom_height": custom_height} if custom_width and custom_height else {}),
            "image_count": 1,
            "images": [image_b64],
        }
    except HTTPException:
        raise
    except Exception as e:
        logger.exception(
            "gpt_image_banner failed | user=%s size=%s quality=%s error_type=%s error=%s",
            user_oid, size, quality, type(e).__name__, e,
        )
        raise HTTPException(status_code=500, detail=f"GPT Image banner generation failed: {e}")


@router.post(
    "/edit",
    summary="GPT Image 2 — image editing",
    description=(
        "Edit images using natural-language instructions via the Azure gpt-image-2 edits endpoint. "
        "Upload 1-10 source images as multipart files. "
        "Supported sizes: 1024x1024, 1536x1024, 1024x1536, auto. "
        "Supported quality: low | medium | high."
    ),
    dependencies=[Depends(require_generation_rate_limit)],
)
async def gpt_image_edit(
    prompt: Annotated[str, Form(description="Natural-language editing instructions")],
    images: List[UploadFile] = File(description="Source images (1-10 required)"),
    size: Annotated[Optional[str], Form(description="1024x1024 | 1536x1024 | 1024x1536 | auto")] = "1024x1024",
    quality: Annotated[Optional[str], Form(description="low | medium | high")] = None,
    custom_width: Annotated[Optional[int], Form(description="Custom output width in pixels")]=None,
    custom_height: Annotated[Optional[int], Form(description="Custom output height in pixels")]=None,
    project_id: Annotated[Optional[str], Form(description="Project ID to save the creative under")] = None,
    show_in_gallery: Annotated[bool, Form(description="Include in shared gallery (default true)")] = True,
    claims: Dict[str, Any] = Depends(require_auth),
):
    user_oid = claims.get("oid", "unknown")

    if not images:
        raise HTTPException(status_code=422, detail="At least one image is required for editing")
    if len(images) > 10:
        raise HTTPException(status_code=422, detail="Maximum 10 images allowed")

    _validate_custom_dimensions(custom_width, custom_height)
    effective_size = _nearest_gpt_size_for_dimensions(custom_width, custom_height, size or "1024x1024")
    prompt_with_size = _with_custom_size_prompt(prompt, custom_width, custom_height)

    image_bytes_list = [await img.read() for img in images]

    logger.info(
        "gpt_image_edit | user=%s requested_size=%s effective_size=%s quality=%s custom_width=%s custom_height=%s image_count=%d prompt_snippet=%r",
        user_oid, size, effective_size, quality, custom_width, custom_height, len(image_bytes_list), prompt[:200],
    )

    try:
        svc = _get_service()
        image, txt_in, img_in, img_out = svc.edit_image(
            image_bytes_list=image_bytes_list,
            prompt=prompt_with_size,
            size=effective_size,
            quality=quality,
        )
        if custom_width and custom_height:
            image = resize_to_exact(image, custom_width, custom_height)
        logger.info(
            "gpt_image_edit success | user=%s requested_size=%s effective_size=%s quality=%s custom_width=%s custom_height=%s image_count=%d dims=%s "
            "text_input_tokens=%d image_input_tokens=%d image_output_tokens=%d",
            user_oid, size, effective_size, quality, custom_width, custom_height, len(image_bytes_list), image.size, txt_in, img_in, img_out,
        )

        image_b64 = svc.to_base64(image)

        if project_id:
            autosave_creative(
                azure_oid=user_oid,
                project_id=project_id,
                category="edit",
                metadata={
                    "prompt": prompt,
                    "size": size,
                    "effective_size": effective_size,
                    "quality": quality,
                    "source_image_count": len(image_bytes_list),
                    **({"custom_width": custom_width, "custom_height": custom_height} if custom_width and custom_height else {}),
                },
                images_b64=[image_b64],
                text_input_tokens=txt_in,
                image_input_tokens=img_in,
                image_output_tokens=img_out,
                model_category=_MODEL_CATEGORY,
                show_in_gallery=show_in_gallery,
            )

        return {
            "status": "success",
            "size": size,
            "effective_size": effective_size,
            **({"custom_width": custom_width, "custom_height": custom_height} if custom_width and custom_height else {}),
            "image_count": 1,
            "images": [image_b64],
        }
    except HTTPException:
        raise
    except Exception as e:
        logger.exception(
            "gpt_image_edit failed | user=%s size=%s quality=%s "
            "image_count=%d error_type=%s error=%s",
            user_oid, size, quality, len(image_bytes_list), type(e).__name__, e,
        )
        raise HTTPException(status_code=500, detail=f"GPT Image editing failed: {e}")
