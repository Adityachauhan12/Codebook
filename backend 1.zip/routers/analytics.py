from datetime import date, datetime, timezone
from typing import Any, Dict, List, Optional

from fastapi import APIRouter, Depends, HTTPException, Query
from psycopg2.extras import RealDictCursor

from auth.azure_auth import require_analytics_role
from db.connection import get_db

router = APIRouter(prefix="/api/v1/analytics", tags=["Analytics"])
APP_LAUNCH_DATE = date(2026, 4, 23)

# SQL fragment that splits token sums by model_category for correct cost attribution.
_SPLIT_TOKENS_SQL = """
    COALESCE(SUM(CASE WHEN model_category IS DISTINCT FROM 'gpt-image-2' THEN text_input_tokens  ELSE 0 END), 0) AS gemini_text_input_tokens,
    COALESCE(SUM(CASE WHEN model_category IS DISTINCT FROM 'gpt-image-2' THEN text_output_tokens ELSE 0 END), 0) AS gemini_text_output_tokens,
    COALESCE(SUM(CASE WHEN model_category IS DISTINCT FROM 'gpt-image-2' THEN image_input_tokens  ELSE 0 END), 0) AS gemini_image_input_tokens,
    COALESCE(SUM(CASE WHEN model_category IS DISTINCT FROM 'gpt-image-2' THEN image_output_tokens ELSE 0 END), 0) AS gemini_image_output_tokens,
    COALESCE(SUM(CASE WHEN model_category = 'gpt-image-2' THEN text_input_tokens  ELSE 0 END), 0) AS gpt2_text_input_tokens,
    COALESCE(SUM(CASE WHEN model_category = 'gpt-image-2' THEN image_input_tokens  ELSE 0 END), 0) AS gpt2_image_input_tokens,
    COALESCE(SUM(CASE WHEN model_category = 'gpt-image-2' THEN image_output_tokens ELSE 0 END), 0) AS gpt2_image_output_tokens,
    COALESCE(SUM(text_input_tokens),  0) AS text_input_tokens,
    COALESCE(SUM(text_output_tokens), 0) AS text_output_tokens,
    COALESCE(SUM(image_input_tokens), 0) AS image_input_tokens,
    COALESCE(SUM(image_output_tokens),0) AS image_output_tokens
"""


def _load_cost_rates(cur) -> Dict[str, float]:
    cur.execute("SELECT * FROM config WHERE id = 1")
    row = cur.fetchone()
    if not row:
        return {
            "text_input": 2.00,
            "text_output": 8.00,
            "image_input": 2.00,
            "image_output": 120.00,
            "text2_input": 5.00,
            "image2_input": 8.00,
            "image2_output": 30.00,
        }
    return {
        "text_input": float(row["text_input_tokens_cost"]),
        "text_output": float(row["text_output_tokens_cost"]),
        "image_input": float(row["image_input_tokens_cost"]),
        "image_output": float(row["image_output_tokens_cost"]),
        "text2_input": float(row["text2_input_tokens_cost"]),
        "image2_input": float(row["image2_input_tokens_cost"]),
        "image2_output": float(row["image2_output_tokens_cost"]),
    }


def _compute_cost_split(row: Dict[str, Any], rates: Dict[str, float]) -> float:
    """
    Compute cost from a row that has pre-split token columns by model category.
    Gemini/null rows use standard rates; gpt-image-2 rows use text2/image2 rates.
    """
    gemini = (
        (row.get("gemini_text_input_tokens") or 0) / 1_000_000 * rates["text_input"]
        + (row.get("gemini_text_output_tokens") or 0) / 1_000_000 * rates["text_output"]
        + (row.get("gemini_image_input_tokens") or 0) / 1_000_000 * rates["image_input"]
        + (row.get("gemini_image_output_tokens") or 0) / 1_000_000 * rates["image_output"]
    )
    gpt2 = (
        (row.get("gpt2_text_input_tokens") or 0) / 1_000_000 * rates["text2_input"]
        + (row.get("gpt2_image_input_tokens") or 0) / 1_000_000 * rates["image2_input"]
        + (row.get("gpt2_image_output_tokens") or 0) / 1_000_000 * rates["image2_output"]
    )
    return round(gemini + gpt2, 4)


@router.get("", summary="Token usage, image counts, and generation trends by date range")
def get_analytics(
    from_date: Optional[date] = Query(None, description="Start date inclusive (YYYY-MM-DD)"),
    to_date: Optional[date] = Query(None, description="End date inclusive (YYYY-MM-DD)"),
    claims: Dict[str, Any] = Depends(require_analytics_role),
):
    # Default: lifetime since app launch date
    if not to_date:
        to_date = date.today()
    if not from_date:
        from_date = APP_LAUNCH_DATE

    if from_date > to_date:
        raise HTTPException(status_code=400, detail="from_date must be on or before to_date")

    from_dt = datetime(from_date.year, from_date.month, from_date.day, tzinfo=timezone.utc)
    to_dt = datetime(to_date.year, to_date.month, to_date.day, 23, 59, 59, tzinfo=timezone.utc)

    with get_db() as conn:
        with conn.cursor(cursor_factory=RealDictCursor) as cur:
            rates = _load_cost_rates(cur)

            # ------------------------------------------------------------------
            # 1. Overall summary
            # ------------------------------------------------------------------
            cur.execute(
                f"""
                SELECT
                    COUNT(DISTINCT user_id)  AS total_users,
                    COUNT(*)                 AS total_creatives,
                    COUNT(image_url)         AS total_images_generated,
                    {_SPLIT_TOKENS_SQL}
                FROM creatives
                WHERE created_at BETWEEN %s AND %s
                  AND show_in_gallery = TRUE
                """,
                (from_dt, to_dt),
            )
            summary_row = dict(cur.fetchone())
            summary = {
                "total_users": summary_row["total_users"],
                "total_creatives": summary_row["total_creatives"],
                "total_images_generated": summary_row["total_images_generated"],
                "total_text_input_tokens": summary_row["text_input_tokens"],
                "total_text_output_tokens": summary_row["text_output_tokens"],
                "total_image_input_tokens": summary_row["image_input_tokens"],
                "total_image_output_tokens": summary_row["image_output_tokens"],
                "total_cost_usd": _compute_cost_split(summary_row, rates),
            }

            # ------------------------------------------------------------------
            # 2. Overall daily trend
            # ------------------------------------------------------------------
            cur.execute(
                f"""
                SELECT
                    DATE(created_at AT TIME ZONE 'UTC') AS date,
                    COUNT(*) AS count,
                    {_SPLIT_TOKENS_SQL}
                FROM creatives
                WHERE created_at BETWEEN %s AND %s
                  AND show_in_gallery = TRUE
                GROUP BY DATE(created_at AT TIME ZONE 'UTC')
                ORDER BY date
                """,
                (from_dt, to_dt),
            )
            daily_trend: List[Dict] = [
                {
                    "date": str(r["date"]),
                    "count": r["count"],
                    "text_input_tokens": r["text_input_tokens"],
                    "text_output_tokens": r["text_output_tokens"],
                    "image_input_tokens": r["image_input_tokens"],
                    "image_output_tokens": r["image_output_tokens"],
                    "cost_usd": _compute_cost_split(dict(r), rates),
                }
                for r in cur.fetchall()
            ]

            # ------------------------------------------------------------------
            # 3. Category-wise summary
            # ------------------------------------------------------------------
            cur.execute(
                f"""
                SELECT
                    category,
                    COUNT(DISTINCT user_id)  AS total_users,
                    COUNT(*)                 AS total_creatives,
                    COUNT(image_url)         AS total_images_generated,
                    {_SPLIT_TOKENS_SQL}
                FROM creatives
                WHERE created_at BETWEEN %s AND %s
                  AND show_in_gallery = TRUE
                GROUP BY category
                """,
                (from_dt, to_dt),
            )
            cat_summary: Dict[str, Any] = {
                r["category"]: {
                    "total_users": r["total_users"],
                    "total_creatives": r["total_creatives"],
                    "total_images_generated": r["total_images_generated"],
                    "total_text_input_tokens": r["text_input_tokens"],
                    "total_text_output_tokens": r["text_output_tokens"],
                    "total_image_input_tokens": r["image_input_tokens"],
                    "total_image_output_tokens": r["image_output_tokens"],
                    "total_cost_usd": _compute_cost_split(dict(r), rates),
                    "daily_trend": [],
                }
                for r in cur.fetchall()
            }

            # ------------------------------------------------------------------
            # 4. Category-wise daily trend
            # ------------------------------------------------------------------
            cur.execute(
                f"""
                SELECT
                    category,
                    DATE(created_at AT TIME ZONE 'UTC') AS date,
                    COUNT(*) AS count,
                    {_SPLIT_TOKENS_SQL}
                FROM creatives
                WHERE created_at BETWEEN %s AND %s
                  AND show_in_gallery = TRUE
                GROUP BY category, DATE(created_at AT TIME ZONE 'UTC')
                ORDER BY category, date
                """,
                (from_dt, to_dt),
            )
            for r in cur.fetchall():
                cat = r["category"]
                if cat in cat_summary:
                    cat_summary[cat]["daily_trend"].append(
                        {
                            "date": str(r["date"]),
                            "count": r["count"],
                            "text_input_tokens": r["text_input_tokens"],
                            "text_output_tokens": r["text_output_tokens"],
                            "image_input_tokens": r["image_input_tokens"],
                            "image_output_tokens": r["image_output_tokens"],
                            "cost_usd": _compute_cost_split(dict(r), rates),
                        }
                    )

            # ------------------------------------------------------------------
            # 5. Sub-department breakdown
            # ------------------------------------------------------------------
            cur.execute(
                f"""
                SELECT
                    COALESCE(sub_department, 'Unknown') AS sub_department,
                    COALESCE(department, 'Unknown')     AS department,
                    COUNT(image_url)                    AS total_images,
                    COUNT(CASE WHEN image_url IS NULL AND text IS NOT NULL THEN 1 END) AS total_text,
                    {_SPLIT_TOKENS_SQL}
                FROM creatives
                WHERE created_at BETWEEN %s AND %s
                  AND show_in_gallery = TRUE
                GROUP BY COALESCE(sub_department, 'Unknown'), COALESCE(department, 'Unknown')
                """,
                (from_dt, to_dt),
            )
            sub_dept_breakdown: List[Dict] = sorted(
                [
                    {
                        "sub_department": r["sub_department"],
                        "department": r["department"],
                        "total_images": r["total_images"],
                        "total_text": r["total_text"],
                        "total_tokens": r["text_input_tokens"] + r["text_output_tokens"] + r["image_input_tokens"] + r["image_output_tokens"],
                        "total_cost_usd": _compute_cost_split(dict(r), rates),
                    }
                    for r in cur.fetchall()
                ],
                key=lambda x: x["total_cost_usd"],
                reverse=True,
            )

            # ------------------------------------------------------------------
            # 6. Top users by cost
            # ------------------------------------------------------------------
            cur.execute(
                f"""
                SELECT
                    u.id,
                    u.name,
                    u.email,
                    u.department,
                    u.sub_department,
                    COUNT(CASE WHEN c.image_url IS NOT NULL THEN 1 END) AS total_images,
                    {_SPLIT_TOKENS_SQL}
                FROM creatives c
                JOIN users u ON u.id = c.user_id
                WHERE c.created_at BETWEEN %s AND %s
                  AND c.show_in_gallery = TRUE
                GROUP BY u.id, u.name, u.email, u.department, u.sub_department
                """,
                (from_dt, to_dt),
            )
            top_users: List[Dict] = sorted(
                [
                    {
                        "id": r["id"],
                        "name": r["name"],
                        "email": r["email"],
                        "department": r["department"],
                        "sub_department": r["sub_department"],
                        "text_input_tokens": r["text_input_tokens"],
                        "text_output_tokens": r["text_output_tokens"],
                        "image_input_tokens": r["image_input_tokens"],
                        "image_output_tokens": r["image_output_tokens"],
                        "total_tokens": r["text_input_tokens"] + r["text_output_tokens"] + r["image_input_tokens"] + r["image_output_tokens"],
                        "total_images": r["total_images"],
                        "total_amount_usd": _compute_cost_split(dict(r), rates),
                    }
                    for r in cur.fetchall()
                ],
                key=lambda x: x["total_amount_usd"],
                reverse=True,
            )

    return {
        "period": {"from": str(from_date), "to": str(to_date)},
        "summary": summary,
        "daily_trend": daily_trend,
        "categories": cat_summary,
        "sub_department_breakdown": sub_dept_breakdown,
        "top_users": top_users,
    }
