import logging
from typing import Any, Dict, List, Optional

from fastapi import APIRouter, Depends, HTTPException, Query
from psycopg2.extras import RealDictCursor
from pydantic import BaseModel

from auth.azure_auth import require_pm_approver, require_pm_user
from db.connection import get_db
from services.blob_service import apply_sas_urls

router = APIRouter(prefix="/api/v1/approvals", tags=["Approvals"])
logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Request models
# ---------------------------------------------------------------------------

class SendForApprovalRequest(BaseModel):
    creative_id: str
    comment: Optional[str] = None


class UpdateApprovalStatusRequest(BaseModel):
    status: str
    comment: Optional[str] = None


# ---------------------------------------------------------------------------
# Endpoints
# ---------------------------------------------------------------------------

@router.post("/send", summary="Send a creative for approval (P&M users only)")
def send_for_approval(
    request: SendForApprovalRequest,
    claims: Dict[str, Any] = Depends(require_pm_user),
):
    oid = claims.get("oid")

    with get_db() as conn:
        with conn.cursor(cursor_factory=RealDictCursor) as cur:
            # Verify the creative belongs to the caller.
            cur.execute(
                "SELECT id FROM creatives WHERE id = %s AND user_id = %s",
                (request.creative_id, oid),
            )
            if not cur.fetchone():
                raise HTTPException(status_code=403, detail="Creative not found or does not belong to you")

            # Reject if there is already an open pending row.
            cur.execute(
                """
                SELECT 1 FROM creative_approval_history
                WHERE creative_id = %s AND status = 'pending'
                LIMIT 1
                """,
                (request.creative_id,),
            )
            if cur.fetchone():
                raise HTTPException(
                    status_code=409,
                    detail="A pending approval request already exists for this creative",
                )

            comment = request.comment or "request was raised"
            cur.execute(
                """
                INSERT INTO creative_approval_history (creative_id, user_id, status, comment)
                VALUES (%s, NULL, 'pending', %s)
                RETURNING approval_request_id, creative_id, status, comment, created_at
                """,
                (request.creative_id, comment),
            )
            row = dict(cur.fetchone())
        conn.commit()

    return {
        "approval_request_id": str(row["approval_request_id"]),
        "creative_id": str(row["creative_id"]),
        "status": row["status"],
        "created_at": row["created_at"].isoformat(),
    }


@router.get("", summary="List all approval requests (P&M approvers only)")
def list_approvals(
    status: Optional[str] = Query(None, description="Filter by status: pending / approved / rejected"),
    claims: Dict[str, Any] = Depends(require_pm_approver),
):
    if status and status not in ("pending", "approved", "rejected"):
        raise HTTPException(status_code=422, detail="status must be pending, approved, or rejected")

    with get_db() as conn:
        with conn.cursor(cursor_factory=RealDictCursor) as cur:
            query = """
                SELECT DISTINCT ON (cah.creative_id)
                    cah.approval_request_id,
                    cah.creative_id,
                    cah.status,
                    cah.comment,
                    cah.created_at           AS submitted_at,
                    c.image_url,
                    c.category,
                    c.text,
                    u.id                     AS submitter_user_id,
                    u.name                   AS submitter_name,
                    u.email                  AS submitter_email
                FROM creative_approval_history cah
                JOIN creatives c ON c.id = cah.creative_id
                JOIN users u     ON u.id = c.user_id
                WHERE 1=1
            """
            params: List[Any] = []

            if status:
                query += " AND cah.status = %s"
                params.append(status)

            query += " ORDER BY cah.creative_id, cah.created_at DESC"

            cur.execute(query, params)
            rows = cur.fetchall()

    approvals = []
    for r in rows:
        resolved = apply_sas_urls({"image_url": r["image_url"]})
        approvals.append({
            "approval_request_id": str(r["approval_request_id"]),
            "creative_id": str(r["creative_id"]),
            "status": r["status"],
            "comment": r["comment"],
            "submitted_at": r["submitted_at"].isoformat() if r["submitted_at"] else None,
            "creative": {
                "image_url": resolved["image_url"],
                "category": r["category"],
                "text": r["text"],
            },
            "submitter": {
                "user_id": r["submitter_user_id"],
                "name": r["submitter_name"],
                "email": r["submitter_email"],
            },
        })

    return {"total": len(approvals), "approvals": approvals}


@router.post("/{creative_id}/update", summary="Approve or reject a creative (P&M approvers only)")
def update_approval_status(
    creative_id: str,
    request: UpdateApprovalStatusRequest,
    claims: Dict[str, Any] = Depends(require_pm_approver),
):
    if request.status not in ("approved", "rejected"):
        raise HTTPException(status_code=422, detail="status must be 'approved' or 'rejected'")

    if request.status == "rejected" and not request.comment:
        raise HTTPException(status_code=422, detail="comment is required when rejecting a creative")

    approver_oid = claims.get("oid")

    with get_db() as conn:
        with conn.cursor(cursor_factory=RealDictCursor) as cur:
            # Confirm there is an open pending row.
            cur.execute(
                """
                SELECT 1 FROM creative_approval_history
                WHERE creative_id = %s AND status = 'pending'
                LIMIT 1
                """,
                (creative_id,),
            )
            if not cur.fetchone():
                raise HTTPException(
                    status_code=404,
                    detail="No pending approval request found for this creative",
                )

            cur.execute(
                """
                INSERT INTO creative_approval_history (creative_id, user_id, status, comment)
                VALUES (%s, %s, %s, %s)
                RETURNING approval_request_id, creative_id, user_id, status, comment, created_at
                """,
                (creative_id, approver_oid, request.status, request.comment),
            )
            row = dict(cur.fetchone())
        conn.commit()

    return {
        "approval_request_id": str(row["approval_request_id"]),
        "creative_id": str(row["creative_id"]),
        "status": row["status"],
        "comment": row["comment"],
        "actioned_by": row["user_id"],
        "created_at": row["created_at"].isoformat(),
    }
