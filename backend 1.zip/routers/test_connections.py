import json
import os
from typing import Any, Dict

from fastapi import APIRouter, Depends, Query
from psycopg2.extras import RealDictCursor
from azure.storage.blob import BlobServiceClient
from azure.identity import DefaultAzureCredential

from auth.azure_auth import require_auth
from db.connection import get_db

router = APIRouter(prefix="/api/test", tags=["Connection Tests"])

_TEST_BLOB_CONTAINER = "test-connection"
_TEST_BLOB_NAME = "test.txt"
_TEST_BLOB_CONTENT = b"blob connection ok"


# ── DB ──────────────────────────────────────────────────────────────────────

def run_db_test() -> dict:
    try:
        with get_db() as conn:
            with conn.cursor(cursor_factory=RealDictCursor) as cur:
                cur.execute("""
                    CREATE TABLE IF NOT EXISTS _conn_test (
                        id   SERIAL PRIMARY KEY,
                        val  TEXT,
                        ts   TIMESTAMPTZ DEFAULT NOW()
                    )
                """)
                cur.execute(
                    "INSERT INTO _conn_test (val) VALUES (%s) RETURNING *",
                    ("ping",),
                )
                inserted = dict(cur.fetchone())
                cur.execute("SELECT * FROM _conn_test")
                rows = [dict(r) for r in cur.fetchall()]
                cur.execute("DROP TABLE _conn_test")
            conn.commit()
        print(f"[test/db] OK — inserted: {inserted}, all rows: {rows}")
        return {"status": "ok", "inserted": inserted, "rows": rows}
    except Exception as e:
        print(f"[test/db] FAILED — {e}")
        return {"status": "error", "detail": str(e)}


@router.get("/db", summary="Test PostgreSQL connectivity")
def test_db():
    return run_db_test()


# ── Blob ─────────────────────────────────────────────────────────────────────

def run_blob_test() -> dict:
    try:
        account_url = (
            f"https://{os.getenv('AZURE_STORAGE_ACCOUNT_NAME')}.blob.core.windows.net"
        )
        client = BlobServiceClient(
            account_url=account_url, credential=DefaultAzureCredential()
        )

        container_client = client.get_container_client(_TEST_BLOB_CONTAINER)
        if not container_client.exists():
            container_client.create_container()
            print(f"[test/blob] Created container '{_TEST_BLOB_CONTAINER}'")

        # Upload
        blob_client = client.get_blob_client(
            container=_TEST_BLOB_CONTAINER, blob=_TEST_BLOB_NAME
        )
        blob_client.upload_blob(_TEST_BLOB_CONTENT, overwrite=True)

        # Download and verify
        downloaded = blob_client.download_blob().readall()
        assert downloaded == _TEST_BLOB_CONTENT, "Content mismatch after download"

        blob_url = blob_client.url

        # Cleanup
        blob_client.delete_blob()
        container_client.delete_container()

        print(f"[test/blob] OK — uploaded and verified '{_TEST_BLOB_NAME}' at {blob_url}")
        return {
            "status": "ok",
            "container": _TEST_BLOB_CONTAINER,
            "blob": _TEST_BLOB_NAME,
            "url": blob_url,
            "content_verified": True,
        }
    except Exception as e:
        print(f"[test/blob] FAILED — {e}")
        return {"status": "error", "detail": str(e)}


@router.get("/blob", summary="Test Azure Blob Storage connectivity")
def test_blob():
    return run_blob_test()


# ── SuccessFactors ────────────────────────────────────────────────────────────

@router.get("/sf", summary="Test SuccessFactors API — fetch employee details by email")
def test_sf(
    email: str = Query(..., description="Employee email address, e.g. john.doe@goindigo.in"),
    claims: Dict[str, Any] = Depends(require_auth),
):
    from services.successfactors_service import (
        _SF_EMPLOYEE_URL, _SF_USER_KEY, _SF_COMPANY_CODE,
        _get_access_token, _extract_department,
    )
    from utils.network_config import build_http_client

    result: Dict[str, Any] = {"email": email}

    # Step 1: token
    try:
        token = _get_access_token()
        result["token_status"] = "ok"
    except Exception as exc:
        result["token_status"] = "error"
        result["token_error"] = str(exc)
        return result

    # Step 2: employee detail — return raw response + parsed fields
    try:
        with build_http_client(timeout=15.0) as client:
            resp = client.request(
                "GET",
                _SF_EMPLOYEE_URL,
                headers={
                    "user_key": _SF_USER_KEY,
                    "Content-Type": "application/json",
                    "Authorization": f"Bearer {token}",
                },
                content=json.dumps({"EmailId": email, "CompanyCode": _SF_COMPANY_CODE}),
            )
            result["http_status"] = resp.status_code
            raw = resp.json()
            result["raw_response"] = raw

        data = raw[0] if isinstance(raw, list) and raw else (raw if isinstance(raw, dict) else {})
        dept, sub_dept = _extract_department(data)
        result["parsed"] = {"department": dept, "sub_department": sub_dept}
        result["employee_status"] = "ok"
    except Exception as exc:
        result["employee_status"] = "error"
        result["employee_error"] = str(exc)

    return result
