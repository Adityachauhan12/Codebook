import mimetypes
import os
from urllib.parse import urlparse

import requests as http_requests
from fastapi import APIRouter, Depends, HTTPException, Query
from fastapi.responses import Response
from typing import Any, Dict, List, Optional
from psycopg2.extras import RealDictCursor

from auth.azure_auth import require_auth
from db.connection import get_db
from services.blob_service import apply_sas_urls

router = APIRouter(prefix="/api/v1/gallery", tags=["Gallery"])


@router.get("/departments", summary="List departments that have gallery images, with counts and a preview image")
def get_departments(
    claims: Dict[str, Any] = Depends(require_auth),
):
    sql = """
        WITH dept_counts AS (
            SELECT department, COUNT(*) AS count
            FROM creatives
            WHERE show_in_gallery = TRUE
              AND image_url IS NOT NULL
              AND department IS NOT NULL
            GROUP BY department
        ),
        dept_preview AS (
            SELECT DISTINCT ON (department) department, image_url
            FROM creatives
            WHERE show_in_gallery = TRUE
              AND image_url IS NOT NULL
              AND department IS NOT NULL
            ORDER BY department, created_at DESC
        )
        SELECT dc.department, dc.count, dp.image_url AS preview_image_url
        FROM dept_counts dc
        JOIN dept_preview dp ON dp.department = dc.department
        ORDER BY dc.count DESC
    """
    with get_db() as conn:
        with conn.cursor(cursor_factory=RealDictCursor) as cur:
            cur.execute(sql)
            rows = [dict(r) for r in cur.fetchall()]

    for row in rows:
        if row.get("preview_image_url"):
            tmp = apply_sas_urls({"image_url": row["preview_image_url"]})
            row["preview_image_url"] = tmp["image_url"]

    return {"departments": rows}


@router.get("", summary="Browse shared gallery with optional filters")
def get_gallery(
    department: Optional[str] = Query(None, description="Filter by department"),
    campaign_type: Optional[str] = Query(None, description="Filter by campaign type (from metadata)"),
    show_my: Optional[bool] = Query(None, description="When true, return only the current user's creatives"),
    claims: Dict[str, Any] = Depends(require_auth),
):
    conditions: List[str] = ["show_in_gallery = TRUE"]
    params: List[Any] = []

    if show_my:
        conditions.append("user_id = %s")
        params.append(claims.get("oid") or "")
    if department:
        conditions.append("department = %s")
        params.append(department)
    if campaign_type:
        conditions.append("metadata->>'campaign_type' ILIKE %s")
        params.append(campaign_type)

    query = f"SELECT * FROM creatives WHERE {' AND '.join(conditions)} ORDER BY created_at DESC"

    with get_db() as conn:
        with conn.cursor(cursor_factory=RealDictCursor) as cur:
            cur.execute(query, params)
            items = [apply_sas_urls(dict(c)) for c in cur.fetchall()]

            cur.execute("SELECT COUNT(*) FROM creatives WHERE image_url IS NOT NULL")
            total_images = cur.fetchone()["count"]

            sub_conditions = ["show_in_gallery = TRUE", "sub_department IS NOT NULL"]
            sub_params: List[Any] = []
            if department:
                sub_conditions.append("department = %s")
                sub_params.append(department)

            cur.execute(
                f"""
                SELECT DISTINCT sub_department
                FROM creatives
                WHERE {' AND '.join(sub_conditions)}
                ORDER BY sub_department
                """,
                sub_params,
            )
            subdepartments = [r["sub_department"] for r in cur.fetchall()]

    return {"total_images": total_images, "subdepartments": subdepartments, "creatives": items}


@router.get("/download", summary="Proxy-download a blob image through the server")
def download_creative_image(
    url: str = Query(..., description="SAS URL of the image"),
    filename: str = Query("image", description="Suggested file name for the download"),
    claims: Dict[str, Any] = Depends(require_auth),
):
    try:
        r = http_requests.get(url, timeout=30)
        r.raise_for_status()
    except Exception as exc:
        raise HTTPException(status_code=502, detail=f"Could not fetch image: {exc}")

    ext = os.path.splitext(urlparse(url.split("?")[0]).path)[1] or ".png"
    if not filename.endswith(ext):
        filename = filename + ext
    media_type = mimetypes.guess_type(filename)[0] or r.headers.get("Content-Type", "application/octet-stream")
    return Response(
        content=r.content,
        media_type=media_type,
        headers={"Content-Disposition": f'attachment; filename="{filename}"'},
    )
