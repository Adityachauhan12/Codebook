import base64
import io
from typing import Any, Dict, Literal, Optional

import requests as http_requests
from fastapi import APIRouter, Depends, HTTPException
from fastapi.responses import Response
from PIL import Image
from psd_tools import PSDImage
from pydantic import BaseModel

from auth.azure_auth import require_auth

router = APIRouter(prefix="/api/v1/download", tags=["Downloads"])

_FORMAT_CONFIG = {
    "png":  {"mime": "image/png",                  "ext": ".png"},
    "jpg": {"mime": "image/jpg",                 "ext": ".jpg"},
    "tiff": {"mime": "image/tiff",                 "ext": ".tiff"},
    "webp": {"mime": "image/webp",                 "ext": ".webp"},
    "svg":  {"mime": "image/svg+xml",              "ext": ".svg"},
    "psd":  {"mime": "image/vnd.adobe.photoshop",  "ext": ".psd"},
}


class ConvertRequest(BaseModel):
    source_base64: Optional[str] = None
    source_url: Optional[str] = None
    format: Literal["png", "jpg", "tiff", "webp", "svg", "psd"] = "png"
    filename: str = "image"


def _fetch_raw(req: ConvertRequest) -> bytes:
    if req.source_base64:
        try:
            return base64.b64decode(req.source_base64)
        except Exception:
            raise HTTPException(status_code=400, detail="Invalid base64 data")
    if req.source_url:
        try:
            r = http_requests.get(req.source_url, timeout=30)
            r.raise_for_status()
            return r.content
        except Exception as exc:
            raise HTTPException(status_code=502, detail=f"Could not fetch image: {exc}")
    raise HTTPException(status_code=400, detail="Provide source_base64 or source_url")


def _to_rgb(img: Image.Image) -> Image.Image:
    """Flatten alpha onto white background and return RGB."""
    if img.mode in ("RGBA", "LA"):
        bg = Image.new("RGB", img.size, (255, 255, 255))
        bg.paste(img, mask=img.split()[-1])
        return bg
    if img.mode == "P":
        img = img.convert("RGBA")
        bg = Image.new("RGB", img.size, (255, 255, 255))
        bg.paste(img, mask=img.split()[-1])
        return bg
    return img.convert("RGB")


@router.post("/convert", summary="Convert and download image in the requested open format")
def convert_image(
    req: ConvertRequest,
    claims: Dict[str, Any] = Depends(require_auth),
):
    raw = _fetch_raw(req)
    cfg = _FORMAT_CONFIG[req.format]
    filename = req.filename if req.filename.endswith(cfg["ext"]) else req.filename + cfg["ext"]

    # ── SVG: embed raster inside an SVG envelope ─────────────────────────────
    if req.format == "svg":
        img = Image.open(io.BytesIO(raw))
        w, h = img.size
        buf = io.BytesIO()
        img.save(buf, format="PNG")
        b64_inner = base64.b64encode(buf.getvalue()).decode()
        svg = (
            '<?xml version="1.0" encoding="UTF-8"?>\n'
            f'<svg xmlns="http://www.w3.org/2000/svg" '
            f'xmlns:xlink="http://www.w3.org/1999/xlink" '
            f'width="{w}" height="{h}" viewBox="0 0 {w} {h}">\n'
            f'  <image x="0" y="0" width="{w}" height="{h}" '
            f'xlink:href="data:image/png;base64,{b64_inner}" '
            f'preserveAspectRatio="none"/>\n'
            "</svg>"
        )
        return Response(
            content=svg.encode("utf-8"),
            media_type=cfg["mime"],
            headers={"Content-Disposition": f'attachment; filename="{filename}"'},
        )

    # ── PSD / PSB via psd-tools ───────────────────────────────────────────────
    if req.format == "psd":
        img = Image.open(io.BytesIO(raw))
        # psd-tools accepts RGB or RGBA; other modes need conversion
        if img.mode not in ("RGB", "RGBA", "L"):
            img = img.convert("RGBA")
        try:
            psd = PSDImage.frompil(img)
            buf = io.BytesIO()
            psd.save(buf)
        except Exception as exc:
            raise HTTPException(status_code=500, detail=f"PSD conversion failed: {exc}")
        return Response(
            content=buf.getvalue(),
            media_type=cfg["mime"],
            headers={"Content-Disposition": f'attachment; filename="{filename}"'},
        )

    # ── Raster formats via Pillow ─────────────────────────────────────────────
    img = Image.open(io.BytesIO(raw))

    save_kwargs: dict = {}

    if req.format == "jpg":
        img = _to_rgb(img)          # JPEG has no alpha channel
        save_kwargs["quality"] = 95
        save_kwargs["subsampling"] = 0  # 4:4:4 — best chroma quality

    elif req.format == "tiff":
        img = _to_rgb(img)          # composite alpha onto white for broadest viewer compat
        save_kwargs["compression"] = "lzw"

    elif req.format == "webp":
        save_kwargs["quality"] = 90
        save_kwargs["method"] = 6

    # PNG needs no special handling — Pillow preserves RGBA

    pil_format_map = {"png": "PNG", "jpg": "JPEG", "tiff": "TIFF", "webp": "WEBP"}
    out = io.BytesIO()
    img.save(out, format=pil_format_map[req.format], **save_kwargs)

    return Response(
        content=out.getvalue(),
        media_type=cfg["mime"],
        headers={"Content-Disposition": f'attachment; filename="{filename}"'},
    )
