"""
IndiGo Marketing API - Quick Start Guide
"""

# QUICK START

## 1. Setup

```bash
# Install dependencies
pip install -r marketing_api/requirements.txt

# Ensure .env file has:
# - AZURE_OPENAI_ENDPOINT
# - AZURE_OPENAI_KEY
# - AZURE_OPENAI_DEPLOYMENT
# - nano_banana_api_key
```

## 2. Run API Server

```bash
uvicorn marketing_api.main:app --reload --port 8000
```

## 3. Test Individual Endpoints

### Generate WhatsApp Text
```bash
curl -X POST "http://localhost:8000/api/v1/generate/whatsapp/text" \
  -H "Content-Type: application/json" \
  -d '{
    "instructions": "Promote discounted meals on flights",
    "campaign_name": "meal_discount"
  }'
```

### Generate Email Text
```bash
curl -X POST "http://localhost:8000/api/v1/generate/email/text" \
  -H "Content-Type: application/json" \
  -d '{
    "instructions": "New business class premium features",
    "campaign_name": "business_class"
  }'
```

### Generate Instagram Text
```bash
curl -X POST "http://localhost:8000/api/v1/generate/instagram/text" \
  -H "Content-Type: application/json" \
  -d '{
    "instructions": "Travel tips for budget conscious travelers",
    "campaign_name": "travel_tips"
  }'
```

## 4. Generate Complete Campaign

```bash
# This generates text + images in one call
curl -X POST "http://localhost:8000/api/v1/generate/campaign/whatsapp" \
  -H "Content-Type: application/json" \
  -d '{
    "instructions": "Summer flight sale with 40% discount",
    "campaign_name": "summer_sale"
  }' \
  --data-urlencode 'logo_path=path/to/indigo_logo.png' \
  --data-urlencode 'context_images_path=campaign_assets/previous_campaigns'
```

## 5. Access Interactive Docs

Visit: http://localhost:8000/docs

## File Structure

marketing_api/
├── prompts/                    # Platform-specific prompts
│   ├── whatsapp.py
│   ├── email.py
│   └── instagram.py
├── services/                   # Business logic
│   ├── azure_openai_service.py  # Text generation
│   ├── gemini_image_service.py  # Image generation
│   ├── whatsapp_service.py
│   ├── email_service.py
│   └── instagram_service.py
├── models/                     # Data models
│   └── __init__.py
├── utils/                      # Helpers
│   └── image_processor.py
├── main.py                     # FastAPI app + routes
├── requirements.txt
└── README.md

## Key Concepts

### Separation of Concerns
- **Prompts**: Brand guidelines + platform-specific instructions
- **Services**: Text & image generation logic
- **Utils**: Image processing and transformation
- **Models**: Request/response data structures

### API Flow

1. Client sends campaign instructions
2. Azure OpenAI generates platform-specific text
3. Text includes image description
4. Python extracts image description
5. Gemini generates images using description + context images
6. Images are saved to campaign_assets/
7. Paths returned to client

### Image Processing Pipeline

Input Images → Load → Resize → Convert Format → Encode Base64 → Send to Gemini → Get Generated Image → Save to Disk → Return Path

## Important Notes

⚠️ **Image Limits**
- Max 14 images per API call (logo + 13 context images)
- Recommended: 10 context images for better results

🔒 **API Keys**
- Store in .env file
- Never commit .env to version control
- Keep keys confidential

📊 **Performance**
- Text generation: 3-5 seconds
- Image generation: 10-15 seconds
- Plan accordingly for production use

## Troubleshooting

**Issue: "no module named marketing_api"**
Solution: Run from project root directory

**Issue: "AZURE_OPENAI_KEY not found"**
Solution: Check .env file in project root

**Issue: "Image not found"**
Solution: Use absolute paths or ensure relative paths are correct

**Issue: API timeout**
Solution: Increase uvicorn timeout or use background tasks for production

## Next Steps

1. Review README.md for full documentation
2. Customize prompts in prompts/ directory
3. Test with different campaign instructions
4. Monitor generated assets in campaign_assets/
5. Integrate with frontend or CMS as needed
