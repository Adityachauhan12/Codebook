"""
API REFERENCE
IndiGo Marketing Platform - Complete API Reference Guide
"""

# ============================================================================
# API BASE URL
# ============================================================================

Development: http://localhost:8000
Production: https://your-production-domain.com

API Version: v1
Base Path: /api/v1


# ============================================================================
# HEALTH CHECK
# ============================================================================

GET /
──────────────────────────────────────────────────────────────────────────

Check if API is running

Request:
  curl http://localhost:8000/

Response (200 OK):
  {
    "status": "running",
    "app": "IndiGo Marketing Platform API",
    "version": "1.0.0"
  }


# ============================================================================
# TEXT GENERATION ENDPOINTS
# ============================================================================

## 1. Generate WhatsApp Text

POST /api/v1/generate/whatsapp/text
──────────────────────────────────────────────────────────────────────────

Generate a WhatsApp marketing message with call-to-action and image description.

Request:
  curl -X POST "http://localhost:8000/api/v1/generate/whatsapp/text" \
    -H "Content-Type: application/json" \
    -d '{
      "instructions": "Create promotion for discounted flight tickets this summer",
      "campaign_name": "summer_flight_sale"
    }'

Request Body:
  {
    "instructions": "string (required)",  // Campaign brief/details
    "campaign_name": "string (optional)"  // Campaign identifier
  }

Response (200 OK):
  {
    "status": "success",
    "campaign_name": "summer_flight_sale",
    "platform": "whatsapp",
    "data": {
      "platform": "whatsapp",
      "message": "✈️ Fly for less! Get up to 30% off on domestic flights this summer. Limited time offer! 🎉",
      "cta_button": "Book Now",
      "image_description": "Create a vibrant WhatsApp-optimized promotional image featuring..."
    }
  }


## 2. Generate Email Text

POST /api/v1/generate/email/text
──────────────────────────────────────────────────────────────────────────

Generate email newsletter content with subject, body, and image description.

Request:
  curl -X POST "http://localhost:8000/api/v1/generate/email/text" \
    -H "Content-Type: application/json" \
    -d '{
      "instructions": "New premium business class features with priority boarding and exclusive meals",
      "campaign_name": "business_class_launch"
    }'

Request Body:
  {
    "instructions": "string (required)",
    "campaign_name": "string (optional)"
  }

Response (200 OK):
  {
    "status": "success",
    "campaign_name": "business_class_launch",
    "platform": "email",
    "data": {
      "platform": "email",
      "subject_line": "Elevate Your Journey With Premium Business Class",
      "preview_text": "Experience luxury redefined...",
      "email_body": "Dear valued traveler, We're excited to introduce...",
      "cta_text": "Upgrade Now",
      "cta_url": "https://goIndiGo.in/premium-business-class",
      "footer_note": "Unsubscribe | Privacy Policy",
      "image_description": "Create a professional email header image..."
    }
  }


## 3. Generate Instagram Text

POST /api/v1/generate/instagram/text
──────────────────────────────────────────────────────────────────────────

Generate Instagram caption with hashtags and image description.

Request:
  curl -X POST "http://localhost:8000/api/v1/generate/instagram/text" \
    -H "Content-Type: application/json" \
    -d '{
      "instructions": "Promote new sustainable aviation initiatives and carbon-neutral operations",
      "campaign_name": "eco_sustainability"
    }'

Request Body:
  {
    "instructions": "string (required)",
    "campaign_name": "string (optional)"
  }

Response (200 OK):
  {
    "status": "success",
    "campaign_name": "eco_sustainability",
    "platform": "instagram",
    "data": {
      "platform": "instagram",
      "caption": "🌍 Flying green is the future! IndiGo is committed to carbon-neutral operations... #SustainableAviation #EcoFriendly #GreenTravel",
      "hashtags": [
        "#IndiGo",
        "#SustainableAviation",
        "#GreenTravel",
        "#EcoFriendly",
        "#ClimateAction"
      ],
      "cta_text": "Learn More",
      "image_description": "Create an eye-catching Instagram square format image..."
    }
  }


# ============================================================================
# IMAGE GENERATION ENDPOINTS
# ============================================================================

## 4. Generate WhatsApp Images

POST /api/v1/generate/whatsapp/image
──────────────────────────────────────────────────────────────────────────

Generate WhatsApp promotional images (1200x1200px square).

Request:
  curl -X POST "http://localhost:8000/api/v1/generate/whatsapp/image" \
    -H "Content-Type: application/json" \
    -d '{
      "image_description": "Vibrant promotional image with flight deals...",
      "campaign_name": "summer_promo",
      "image_count": 1
    }' \
    --data-urlencode 'logo_path=campaign_logo/indigo_air_delights_logo.png' \
    --data-urlencode 'context_images_path=campaign_images'

Request Body:
  {
    "image_description": "string (required)",
    "campaign_name": "string",
    "logo_path": "string (optional)",
    "context_images_path": "string (optional)",
    "image_count": "integer (default: 1)"
  }

Query Parameters:
  logo_path: path/to/logo.png          (optional)
  context_images_path: path/to/images  (optional)

Response (200 OK):
  {
    "status": "success",
    "platform": "whatsapp",
    "campaign_name": "summer_promo",
    "image_count": 1,
    "images": [
      "campaign_assets/summer_promo/whatsapp_20240324_103045/whatsapp_1.png"
    ]
  }


## 5. Generate Email Images

POST /api/v1/generate/email/image
──────────────────────────────────────────────────────────────────────────

Generate email header images (1200x400px horizontal).

Request:
  curl -X POST "http://localhost:8000/api/v1/generate/email/image" \
    -H "Content-Type: application/json" \
    -d '{
      "image_description": "Professional email header design...",
      "campaign_name": "business_class",
      "image_count": 1
    }' \
    --data-urlencode 'logo_path=campaign_logo/indigo_air_delights_logo.png' \
    --data-urlencode 'context_images_path=campaign_images'

Response (200 OK):
  {
    "status": "success",
    "platform": "email",
    "campaign_name": "business_class",
    "image_count": 1,
    "images": [
      "campaign_assets/business_class/email_20240324_103045/email_header_1.png"
    ]
  }


## 6. Generate Instagram Images

POST /api/v1/generate/instagram/image
──────────────────────────────────────────────────────────────────────────

Generate Instagram post images (1080x1080px square).

Request:
  curl -X POST "http://localhost:8000/api/v1/generate/instagram/image" \
    -H "Content-Type: application/json" \
    -d '{
      "image_description": "Trendy Instagram post design...",
      "campaign_name": "eco_friendly",
      "image_count": 3
    }' \
    --data-urlencode 'logo_path=campaign_logo/indigo_air_delights_logo.png' \
    --data-urlencode 'context_images_path=campaign_images'

Response (200 OK):
  {
    "status": "success",
    "platform": "instagram",
    "campaign_name": "eco_friendly",
    "image_count": 3,
    "images": [
      "campaign_assets/eco_friendly/instagram_20240324_103045/instagram_post_1.png",
      "campaign_assets/eco_friendly/instagram_20240324_103045/instagram_post_2.png",
      "campaign_assets/eco_friendly/instagram_20240324_103045/instagram_post_3.png"
    ]
  }


# ============================================================================
# COMBINED CAMPAIGN ENDPOINTS
# ============================================================================

## 7. Generate Complete WhatsApp Campaign

POST /api/v1/generate/campaign/whatsapp
──────────────────────────────────────────────────────────────────────────

Generate complete WhatsApp campaign (text + image in single request).

Request:
  curl -X POST "http://localhost:8000/api/v1/generate/campaign/whatsapp" \
    -H "Content-Type: application/json" \
    -d '{
      "instructions": "Summer vacation packages with 30% discount",
      "campaign_name": "summer_vacation"
    }' \
    --data-urlencode 'logo_path=campaign_logo/indigo_air_delights_logo.png' \
    --data-urlencode 'context_images_path=campaign_images'

Request Body:
  {
    "instructions": "string (required)",
    "campaign_name": "string"
  }

Query Parameters:
  logo_path: path/to/logo.png          (optional)
  context_images_path: path/to/images  (optional)

Response (200 OK):
  {
    "status": "success",
    "campaign_name": "summer_vacation",
    "platform": "whatsapp",
    "text": {
      "platform": "whatsapp",
      "message": "✈️ Beat the heat! 30% off on vacation packages...",
      "cta_button": "Book Now",
      "image_description": "..."
    },
    "images": [
      "campaign_assets/summer_vacation/whatsapp_20240324_103045/whatsapp_1.png"
    ]
  }

Timeline:
  - Step 1: Generate text (3-5 sec)
  - Step 2: Generate image (10-15 sec)
  - Total: ~15-25 seconds


## 8. Generate Complete Email Campaign

POST /api/v1/generate/campaign/email
──────────────────────────────────────────────────────────────────────────

Generate complete email campaign (content + header image).

Request:
  curl -X POST "http://localhost:8000/api/v1/generate/campaign/email" \
    -H "Content-Type: application/json" \
    -d '{
      "instructions": "Announce new business class premium features",
      "campaign_name": "business_premium"
    }' \
    --data-urlencode 'logo_path=campaign_logo/indigo_air_delights_logo.png' \
    --data-urlencode 'context_images_path=campaign_images'

Response (200 OK):
  {
    "status": "success",
    "campaign_name": "business_premium",
    "platform": "email",
    "text": {
      "platform": "email",
      "subject_line": "Premium Business Class Upgrade Available",
      "preview_text": "Experience luxury redefined...",
      "email_body": "...",
      "cta_text": "Upgrade",
      "cta_url": "https://goIndiGo.in/premium",
      "footer_note": "...",
      "image_description": "..."
    },
    "images": [
      "campaign_assets/business_premium/email_20240324_103045/email_header_1.png"
    ]
  }


## 9. Generate Complete Instagram Campaign

POST /api/v1/generate/campaign/instagram
──────────────────────────────────────────────────────────────────────────

Generate complete Instagram campaign (caption + post images).

Request:
  curl -X POST "http://localhost:8000/api/v1/generate/campaign/instagram" \
    -H "Content-Type: application/json" \
    -d '{
      "instructions": "Travel tips and stories from our destinations",
      "campaign_name": "travel_tips"
    }' \
    --data-urlencode 'logo_path=campaign_logo/indigo_air_delights_logo.png' \
    --data-urlencode 'context_images_path=campaign_images'

Response (200 OK):
  {
    "status": "success",
    "campaign_name": "travel_tips",
    "platform": "instagram",
    "text": {
      "platform": "instagram",
      "caption": "🌍 Pack light, travel smart! Top 5 packing tips...",
      "hashtags": ["#TravelTips", "#PackingHacks", "#IndiGo"],
      "cta_text": "Save This",
      "image_description": "..."
    },
    "images": [
      "campaign_assets/travel_tips/instagram_20240324_103045/instagram_post_1.png"
    ]
  }


# ============================================================================
# ERROR RESPONSES
# ============================================================================

## Error Response Format

Status: 500 Internal Server Error

Response:
  {
    "detail": "Error generating WhatsApp campaign: [specific error message]"
  }

## Common Errors

### Missing Required Field
Status: 422 Unprocessable Entity

  {
    "detail": [
      {
        "loc": ["body", "instructions"],
        "msg": "field required",
        "type": "value_error.missing"
      }
    ]
  }

### API Timeout
Status: 504 Gateway Timeout

  {
    "detail": "Request timeout: Image generation took longer than expected"
  }

### Invalid Image Path
Status: 400 Bad Request

  {
    "detail": "Error generating images: Image not found at path/to/image.png"
  }

### Rate Limit Exceeded
Status: 429 Too Many Requests

  {
    "detail": "API rate limit exceeded. Please try again later."
  }


# ============================================================================
# REQUEST EXAMPLES
# ============================================================================

## Python Requests Library

```python
import requests
import json

API_URL = "http://localhost:8000/api/v1"

# Generate WhatsApp text
response = requests.post(
    f"{API_URL}/generate/whatsapp/text",
    json={
        "instructions": "Promote summer flight sales",
        "campaign_name": "summer_sale"
    }
)
print(json.dumps(response.json(), indent=2))

# Generate complete WhatsApp campaign
response = requests.post(
    f"{API_URL}/generate/campaign/whatsapp",
    json={
        "instructions": "Promote summer flight sales",
        "campaign_name": "summer_sale"
    },
    params={
        "logo_path": "campaign_logo/indigo_air_delights_logo.png",
        "context_images_path": "campaign_images"
    }
)
print(json.dumps(response.json(), indent=2))

# Generate multiple Instagram images
response = requests.post(
    f"{API_URL}/generate/instagram/image",
    json={
        "image_description": "Create 3 different Instagram post designs...",
        "campaign_name": "instagram_series",
        "image_count": 3
    },
    params={
        "logo_path": "campaign_logo/indigo_air_delights_logo.png",
        "context_images_path": "campaign_images"
    }
)
print(json.dumps(response.json(), indent=2))
```

## JavaScript Fetch API

```javascript
const API_URL = "http://localhost:8000/api/v1";

// Generate Email text
fetch(`${API_URL}/generate/email/text`, {
  method: "POST",
  headers: {
    "Content-Type": "application/json",
  },
  body: JSON.stringify({
    instructions: "New premium lounge access",
    campaign_name: "lounge_access"
  })
})
.then(response => response.json())
.then(data => console.log(JSON.stringify(data, null, 2)))
.catch(error => console.error("Error:", error));

// Generate complete campaign
const params = new URLSearchParams({
  logo_path: "campaign_logo/indigo_air_delights_logo.png",
  context_images_path: "campaign_images"
});

fetch(`${API_URL}/generate/campaign/instagram?${params}`, {
  method: "POST",
  headers: {
    "Content-Type": "application/json",
  },
  body: JSON.stringify({
    instructions: "Travel inspiration and stories",
    campaign_name: "travel_stories"
  })
})
.then(response => response.json())
.then(data => console.log(JSON.stringify(data, null, 2)))
.catch(error => console.error("Error:", error));
```


# ============================================================================
# RESPONSE TIME EXPECTATIONS
# ============================================================================

Text Generation Only:        3-5 seconds
Image Generation Only:       10-15 seconds per image
Combined Campaign:           15-25 seconds
Multiple Images (3x):        30-50 seconds total

Factors affecting timing:
- Network latency
- API provider load
- Image complexity
- Number of context images


# ============================================================================
# RATE LIMITING & QUOTAS
# ============================================================================

Recommended Request Intervals:
- Between requests: 2-5 seconds
- Between campaigns: 5-10 seconds
- Between different platforms: 2 seconds

API Provider Limits:
- Azure OpenAI: Per subscription quota
- Google Gemini: Per API key quota
- Max context images: 14 per request

Best Practices:
- Implement request queuing for bulk operations
- Add exponential backoff for retries
- Monitor API usage and costs
- Batch similar requests when possible


# ============================================================================
# TESTING THE API
# ============================================================================

## Using Swagger UI

1. Start the API: uvicorn marketing_api.main:app --reload
2. Open: http://localhost:8000/docs
3. Click on endpoint to expand
4. Click "Try it out"
5. Fill in request parameters
6. Click "Execute"

## Using cURL

See detailed examples in QUICKSTART.md file

## Using Python Test Suite

```bash
python test_marketing_api.py
```

This runs comprehensive tests on all endpoints.


# ============================================================================
# SUPPORT & DOCUMENTATION
# ============================================================================

Interactive API Docs:     http://localhost:8000/docs
ReDoc Documentation:      http://localhost:8000/redoc
API README:               marketing_api/README.md
Architecture Guide:       ARCHITECTURE.md
Setup Instructions:       SETUP_GUIDE.md
Quick Start Guide:        QUICKSTART.md
Test Suite:              test_marketing_api.py
