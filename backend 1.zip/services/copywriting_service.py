"""
Unified Copywriting Service
Generates 3 headline+body options for any supported channel using a single API call.
"""

from typing import Any, Dict, List

from prompts.brand_guardrails_text import INDIGO_TEXT_BRAND_POLICY
from prompts.copywriting_prompt import (
    CHANNEL_COPY_RULES,
    CHANNEL_DISPLAY_NAMES,
    build_copywriting_prompt,
)
from services.azure_openai_service import AzureOpenAIService


class CopywritingService:
    """Generate channel-specific copywriting options (headline + body) for IndiGo campaigns."""

    SUPPORTED_CHANNELS: List[str] = list(CHANNEL_COPY_RULES.keys())

    def __init__(self) -> None:
        self.azure_service = AzureOpenAIService()

    def generate(self, channel: str, brief: str) -> Dict[str, Any]:
        """
        Generate 3 copywriting options for the given channel and brief.

        Args:
            channel: One of the supported channel keys (e.g. "twitter", "print_ad").
            brief:   Campaign brief / instructions from the user.

        Returns:
            Dict with keys:
                - channel (str): normalised channel key
                - channel_display_name (str): human-readable channel name
                - options (list[dict]): list of 3 dicts, each with
                    option_number (int), headline (str), body (str)

        Raises:
            ValueError:  If the channel is not supported.
            Exception:   If the LLM call or JSON parsing fails.
        """
        channel_key = channel.strip().lower()
        if channel_key not in CHANNEL_COPY_RULES:
            valid = ", ".join(self.SUPPORTED_CHANNELS)
            raise ValueError(
                f"Unsupported channel '{channel}'. Supported values: {valid}"
            )

        prompt = build_copywriting_prompt(
            channel=channel_key,
            brief=brief,
            policy=INDIGO_TEXT_BRAND_POLICY,
        )

        response_text, in_tok, out_tok = self.azure_service.generate_text_with_usage(
            prompt=prompt,
            temperature=0.8,   # slightly higher for creative variety across 3 options
            max_tokens=3500,
        )
        parsed = self.azure_service.parse_json_response(response_text)

        options = self._normalise_options(parsed.get("options", []))

        return {
            "channel": channel_key,
            "channel_display_name": CHANNEL_DISPLAY_NAMES[channel_key],
            "options": options,
            "_text_input_tokens": in_tok,
            "_text_output_tokens": out_tok,
        }

    # ------------------------------------------------------------------
    # Private helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _normalise_options(raw_options: List[Any]) -> List[Dict[str, Any]]:
        """
        Ensure each option has exactly option_number, headline, and body keys.
        Fills in empty strings for any missing fields so the response is always
        structurally consistent for the frontend.
        """
        normalised: List[Dict[str, Any]] = []
        for i, opt in enumerate(raw_options[:3], start=1):
            if not isinstance(opt, dict):
                opt = {}
            normalised.append(
                {
                    "option_number": opt.get("option_number", i),
                    "headline": str(opt.get("headline", "")),
                    "body": str(opt.get("body", "")),
                }
            )
        # Pad to 3 if the model returned fewer options
        while len(normalised) < 3:
            normalised.append(
                {
                    "option_number": len(normalised) + 1,
                    "headline": "",
                    "body": "",
                }
            )
        return normalised
