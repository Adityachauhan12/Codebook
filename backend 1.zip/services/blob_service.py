import base64
import logging
import os
import threading
import uuid
from datetime import datetime, timedelta, timezone
from typing import Any, Dict, Optional
from urllib.parse import urlparse

from azure.identity import ClientSecretCredential
from azure.storage.blob import (
    BlobSasPermissions,
    BlobServiceClient,
    ContentSettings,
    generate_blob_sas,
)
from dotenv import load_dotenv

load_dotenv()

logger = logging.getLogger(__name__)

_credential = ClientSecretCredential(
    tenant_id=os.getenv("AZURE_TENANT_ID", ""),
    client_id=os.getenv("AZURE_CLIENT_ID", ""),
    client_secret=os.getenv("AZURE_CLIENT_SECRET", ""),
)
_account_name: str = os.getenv("AZURE_STORAGE_ACCOUNT_NAME", "")
_client: BlobServiceClient = BlobServiceClient(
    account_url=f"https://{_account_name}.blob.core.windows.net",
    credential=_credential,
)

CONTAINER_CREATIVES = "creatives"
CONTAINER_REFERENCES = "references"

# ---------------------------------------------------------------------------
# Upload helpers
# ---------------------------------------------------------------------------

def _upload(container: str, folder: str, image_b64: str) -> str:
    """Upload a base64-encoded image, return its bare blob URL (no SAS)."""
    image_bytes = base64.b64decode(image_b64)
    blob_name = f"{folder}/{uuid.uuid4()}.png"
    blob_client = _client.get_blob_client(container=container, blob=blob_name)
    blob_client.upload_blob(
        image_bytes,
        overwrite=True,
        content_settings=ContentSettings(content_type="image/png"),
    )
    return blob_client.url


def upload_creative_image(user_id: str, image_b64: str) -> str:
    """Upload a generated output image to the creatives container."""
    return _upload(CONTAINER_CREATIVES, user_id, image_b64)


def upload_reference_images(user_id: str, images_b64: list[str]) -> list[str]:
    """Upload one or more reference images to the references container, return bare URLs."""
    return [_upload(CONTAINER_REFERENCES, user_id, img) for img in images_b64]


# ---------------------------------------------------------------------------
# SAS URL generation  (User Delegation Key — uses the app's managed identity)
#
# The managed identity / service principal must hold the
# "Storage Blob Delegator" role on the storage account so it can obtain a
# User Delegation Key (in addition to "Storage Blob Data Contributor" for
# uploads).
# ---------------------------------------------------------------------------

_udk_lock = threading.Lock()
_udk_cache: Optional[tuple] = None   # (UserDelegationKey, expiry: datetime)
_SAS_EXPIRY_HOURS = 1
_UDK_REFRESH_BUFFER_MINUTES = 10     # refresh the key this many minutes before it expires


def _get_user_delegation_key():
    """Return a cached User Delegation Key, refreshing when close to expiry."""
    global _udk_cache
    with _udk_lock:
        now = datetime.now(timezone.utc)
        if _udk_cache is not None:
            key, expiry = _udk_cache
            if now < expiry - timedelta(minutes=_UDK_REFRESH_BUFFER_MINUTES):
                return key
        start = now
        # Key lifetime is slightly longer than individual SAS tokens so that a
        # key fetched moments before an SAS is generated doesn't expire first.
        expiry = now + timedelta(hours=_SAS_EXPIRY_HOURS + 1)
        key = _client.get_user_delegation_key(
            key_start_time=start,
            key_expiry_time=expiry,
        )
        _udk_cache = (key, expiry)
        return key


def generate_sas_url(blob_url: str) -> str:
    """
    Return a short-lived (1 h) read-only SAS URL for a private blob.

    The bare blob URL stored in the DB has the form:
        https://<account>.blob.core.windows.net/<container>/<blob_path>
    We parse that to derive container and blob name, then attach a SAS token
    signed with the app's User Delegation Key.

    On any failure the original URL is returned unchanged so callers are never broken.
    """
    parsed = urlparse(blob_url)
    path_parts = parsed.path.lstrip("/").split("/", 1)
    if len(path_parts) != 2:
        return blob_url

    container_name, blob_name = path_parts
    now = datetime.now(timezone.utc)

    try:
        udk = _get_user_delegation_key()
        sas_token = generate_blob_sas(
            account_name=_account_name,
            container_name=container_name,
            blob_name=blob_name,
            user_delegation_key=udk,
            permission=BlobSasPermissions(read=True),
            start=now - timedelta(minutes=5),  # small clock-skew buffer
            expiry=now + timedelta(hours=_SAS_EXPIRY_HOURS),
        )
        return f"{blob_url}?{sas_token}"
    except Exception as exc:
        logger.warning("generate_sas_url failed for %s: %s", blob_url, exc)
        return blob_url


def download_blob_bytes(blob_url: str) -> Optional[bytes]:
    """Download a blob by its bare URL and return the raw bytes. Returns None on failure."""
    try:
        parsed = urlparse(blob_url)
        path_parts = parsed.path.lstrip("/").split("/", 1)
        if len(path_parts) != 2:
            return None
        container_name, blob_name = path_parts
        blob_client = _client.get_blob_client(container=container_name, blob=blob_name)
        return blob_client.download_blob().readall()
    except Exception as exc:
        logger.warning("download_blob_bytes failed for %s: %s", blob_url, exc)
        return None


def apply_sas_urls(creative: Dict[str, Any]) -> Dict[str, Any]:
    """
    Replace bare blob URLs on a creative dict with short-lived SAS URLs.
    Rewrites image_url and any reference_image_urls inside metadata.
    Mutates and returns the dict.
    """
    if creative.get("image_url"):
        creative["image_url"] = generate_sas_url(creative["image_url"])

    metadata = creative.get("metadata") or {}
    ref_urls = metadata.get("reference_image_urls")
    if isinstance(ref_urls, list):
        metadata["reference_image_urls"] = [generate_sas_url(u) for u in ref_urls]
        creative["metadata"] = metadata

    return creative