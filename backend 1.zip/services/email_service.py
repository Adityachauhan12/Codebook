"""
Email Marketing Text Generation Service
"""

from typing import Dict, Any
from services.azure_openai_service import AzureOpenAIService
from prompts.brand_guardrails_text import INDIGO_TEXT_BRAND_POLICY
from prompts.platform_text_prompt import PlatformTextPrompt
from prompts.platform_image_prompt import PlatformImagePrompt


class EmailTextService:
    """Service for Email text generation"""

    def __init__(self):
        self.azure_service = AzureOpenAIService()

    def generate_text(self, campaign_instructions: str) -> Dict[str, Any]:
        """
        Generate Email marketing content with image description.

        Args:
            campaign_instructions: Campaign details/instructions

        Returns:
            Dict with email content, CTA, and image description
        """
        try:
            prompt = PlatformTextPrompt.EMAIL.value.format(
                policy=INDIGO_TEXT_BRAND_POLICY,
                instructions=campaign_instructions,
            )
            response_text, in_tok, out_tok = self.azure_service.generate_text_with_usage(prompt=prompt, temperature=0.7, max_tokens=800)
            result = self.azure_service.parse_json_response(response_text)

            return {
                "platform": "email",
                "subject_line": result.get("subject_line", ""),
                "preview_text": result.get("preview_text", ""),
                "email_body": result.get("email_body", ""),
                "cta_text": result.get("cta_text", ""),
                "cta_url": result.get("cta_url", ""),
                "footer_note": result.get("footer_note", ""),
                "image_description": result.get("image_description", ""),
                "_text_input_tokens": in_tok,
                "_text_output_tokens": out_tok,
            }
        except Exception as e:
            print(f"Error generating Email text: {e}")
            raise

    def generate_image_prompt(self, subject: str, body_theme: str, cta: str) -> str:
        """
        Generate detailed image generation prompt for Email header.

        Args:
            subject: Email subject line
            body_theme: Main message theme
            cta: Call-to-action text

        Returns:
            Prompt for image generation
        """
        try:
            prompt = PlatformImagePrompt.EMAIL.value.format(
                subject=subject,
                body_theme=body_theme,
                cta=cta,
            )
            response_text = self.azure_service.generate_text(prompt=prompt, temperature=0.7, max_tokens=500)
            result = self.azure_service.parse_json_response(response_text)
            return result.get("image_prompt", "")
        except Exception as e:
            print(f"Error generating Email image prompt: {e}")
            raise
