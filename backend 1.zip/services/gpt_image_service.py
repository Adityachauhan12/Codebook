"""
GPT Image 2 Service
Handles image generation and editing via Azure OpenAI gpt-image-2 deployment.
"""

import base64
import logging
import os
from io import BytesIO
from typing import Any, Dict, List, Optional, Tuple

from openai import AzureOpenAI
from PIL import Image
from dotenv import load_dotenv
from utils.network_config import build_http_client

logger = logging.getLogger(__name__)

load_dotenv()


class GptImageService:
    """Azure OpenAI gpt-image-2 image generation and editing via SDK."""

    def __init__(self):
        self.api_key = os.getenv("GPT_IMAGE_API_KEY")
        self.endpoint = os.getenv("GPT_IMAGE_BASE_URL", "").rstrip("/")
        self.deployment = os.getenv("GPT_IMAGE_DEPLOYMENT_NAME", "gpt-image-2").strip()
        self.api_version = os.getenv("GPT_IMAGE_API_VERSION", "2024-02-01").strip()

        if not self.api_key or not self.endpoint:
            raise ValueError("GPT_IMAGE_API_KEY and GPT_IMAGE_BASE_URL must be set")

        self.client = AzureOpenAI(
            api_key=self.api_key,
            azure_endpoint=self.endpoint,
            api_version=self.api_version,
            http_client=build_http_client(timeout=200.0),
            max_retries = 0,
        )

    # ------------------------------------------------------------------
    # Generate
    # ------------------------------------------------------------------

    def generate_image(
        self,
        prompt: str,
        size: Optional[str] = "1024x1024",
        quality: Optional[str] = None,
        background: Optional[str] = None,
        reference_images: Optional[List[bytes]] = None,
    ) -> Tuple[Image.Image, int, int, int]:
        """
        Generate an image from a text prompt.

        If reference_images are provided, routes to the edits endpoint so the
        model can use them as visual context. Otherwise uses the generations endpoint.

        Returns:
            (image, text_input_tokens, image_input_tokens, image_output_tokens)
        """
        logger.info(
            "gpt_image generate | deployment=%s size=%s quality=%s background=%s "
            "reference_image_count=%d prompt_snippet=%r",
            self.deployment, size, quality, background,
            len(reference_images) if reference_images else 0,
            prompt[:200],
        )
        try:
            if reference_images:
                image, txt_in, img_in, img_out = self._call_edits(reference_images, prompt, size, quality)
            else:
                image, txt_in, img_in, img_out = self._call_generations(prompt, size, quality, background)
            logger.info(
                "gpt_image generate success | deployment=%s size=%s dims=%s "
                "text_input_tokens=%d image_input_tokens=%d image_output_tokens=%d",
                self.deployment, size, image.size, txt_in, img_in, img_out,
            )
            return image, txt_in, img_in, img_out
        except Exception as exc:
            logger.exception(
                "gpt_image generate failed | deployment=%s size=%s quality=%s "
                "error_type=%s error=%s prompt_snippet=%r",
                self.deployment, size, quality, type(exc).__name__, exc, prompt[:200],
            )
            raise

    # ------------------------------------------------------------------
    # Edit
    # ------------------------------------------------------------------

    def edit_image(
        self,
        image_bytes_list: List[bytes],
        prompt: str,
        size: Optional[str] = "1024x1024",
        quality: Optional[str] = None,
    ) -> Tuple[Image.Image, int, int, int]:
        """
        Edit existing images using natural-language instructions.

        Returns:
            (image, text_input_tokens, image_input_tokens, image_output_tokens)
        """
        logger.info(
            "gpt_image edit | deployment=%s size=%s quality=%s image_count=%d prompt_snippet=%r",
            self.deployment, size, quality, len(image_bytes_list), prompt[:200],
        )
        try:
            image, txt_in, img_in, img_out = self._call_edits(image_bytes_list, prompt, size, quality)
            logger.info(
                "gpt_image edit success | deployment=%s size=%s dims=%s "
                "text_input_tokens=%d image_input_tokens=%d image_output_tokens=%d",
                self.deployment, size, image.size, txt_in, img_in, img_out,
            )
            return image, txt_in, img_in, img_out
        except Exception as exc:
            logger.exception(
                "gpt_image edit failed | deployment=%s size=%s quality=%s "
                "error_type=%s error=%s prompt_snippet=%r",
                self.deployment, size, quality, type(exc).__name__, exc, prompt[:200],
            )
            raise

    # ------------------------------------------------------------------
    # Internal SDK helpers
    # ------------------------------------------------------------------

    def _call_generations(
        self,
        prompt: str,
        size: Optional[str],
        quality: Optional[str],
        background: Optional[str],
    ) -> Tuple[Image.Image, int, int, int]:
        kwargs: Dict[str, Any] = {
            "model": self.deployment,
            "prompt": prompt,
            "n": 1,
            "size": size,
        }
        if quality:
            kwargs["quality"] = quality
        if background:
            kwargs["background"] = background

        response = self.client.images.generate(**kwargs)
        return self._decode_b64(response.data[0].b64_json), *self._extract_usage(response)

    def _call_edits(
        self,
        image_bytes_list: List[bytes],
        prompt: str,
        size: Optional[str],
        quality: Optional[str],
    ) -> Tuple[Image.Image, int, int, int]:
        sdk_images = [
            (f"image_{i}.png", img_bytes, "image/png")
            for i, img_bytes in enumerate(image_bytes_list)
        ]
        kwargs: Dict[str, Any] = {
            "model": self.deployment,
            "image": sdk_images if len(sdk_images) > 1 else sdk_images[0],
            "prompt": prompt,
            "n": 1,
            "size": size,
        }
        if quality:
            kwargs["quality"] = quality

        response = self.client.images.edit(**kwargs)
        return self._decode_b64(response.data[0].b64_json), *self._extract_usage(response)

    @staticmethod
    def _extract_usage(response) -> Tuple[int, int, int]:
        """Extract (text_input_tokens, image_input_tokens, image_output_tokens) from SDK response."""
        usage = getattr(response, "usage", None)
        if not usage:
            return 0, 0, 0
        details_in = getattr(usage, "input_tokens_details", None)
        details_out = getattr(usage, "output_tokens_details", None)
        txt_in = int(getattr(details_in, "text_tokens", 0) or 0) if details_in else 0
        img_in = int(getattr(details_in, "image_tokens", 0) or 0) if details_in else 0
        img_out = int(getattr(details_out, "image_tokens", 0) or 0) if details_out else 0
        return txt_in, img_in, img_out

    # ------------------------------------------------------------------
    # Utilities
    # ------------------------------------------------------------------

    @staticmethod
    def _decode_b64(b64: str) -> Image.Image:
        if not b64:
            raise RuntimeError("GPT Image API returned no image data")
        return Image.open(BytesIO(base64.b64decode(b64)))

    @staticmethod
    def to_base64(image: Image.Image) -> str:
        buf = BytesIO()
        image.save(buf, format="PNG")
        return base64.standard_b64encode(buf.getvalue()).decode()
