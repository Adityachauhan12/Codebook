"""
SuccessFactors integration — fetches Department and SubDepartment for an
IndiGo employee by email.

Two-step flow:
  1. POST token endpoint (client credentials) → access_token
  2. GET employee-detail endpoint with JSON body → Department, SubDepartment

The access token is cached in-process and refreshed automatically before it
expires.  All errors are swallowed and returned as (None, None) so that a
transient SF outage never blocks user authentication.
"""

import json
import logging
import os
import time
from typing import Optional, Tuple

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Config — override any value via environment variable
# ---------------------------------------------------------------------------

_SF_TOKEN_URL = os.getenv(
    "SF_TOKEN_URL",
    "https://successfactor-uat-3scale-apicast-production.apps.ocpnonprodcl01.goindigo.in/SuccessFactor-oAuth/oauth/token",
)
_SF_EMPLOYEE_URL = os.getenv(
    "SF_EMPLOYEE_URL",
    "https://successfactor-uat-3scale-apicast-production.apps.ocpnonprodcl01.goindigo.in/http/GetEmployeeBasicDetail_6eBreez",
)
_SF_USER_KEY = os.getenv("SF_USER_KEY", "ae8db6ebc53bbbb2dbd60f088b80a20f")
_SF_CLIENT_ID = os.getenv(
    "SF_CLIENT_ID",
    "sb-55bcdade-3dd1-41cf-a3c6-e1fc329786bb!b37834|it-rt-indigo-cpi-test-in-wsgqfy65!b148",
)
_SF_CLIENT_SECRET = os.getenv(
    "SF_CLIENT_SECRET",
    "b46e9a9b-91d8-482d-8fa6-97dc04683f53$cIJcoF1il17cTey5FP9gL7wDkcx42aMVdvBJl0rmTuE=",
)
_SF_COMPANY_CODE = os.getenv("SF_COMPANY_CODE", "1000")

# ---------------------------------------------------------------------------
# Token cache
# ---------------------------------------------------------------------------

_cached_token: Optional[str] = None
_token_expiry: float = 0.0


def _get_access_token() -> str:
    global _cached_token, _token_expiry

    if _cached_token and time.monotonic() < _token_expiry:
        return _cached_token

    from utils.network_config import build_http_client

    with build_http_client(timeout=15.0) as client:
        resp = client.post(
            _SF_TOKEN_URL,
            headers={
                "content-type": "application/x-www-form-urlencoded",
                "user_key": _SF_USER_KEY,
            },
            data={
                "grant_type": "client_credentials",
                "client_id": _SF_CLIENT_ID,
                "client_secret": _SF_CLIENT_SECRET,
            },
        )
        resp.raise_for_status()
        data = resp.json()

    _cached_token = data["access_token"]
    expires_in = int(data.get("expires_in", 3600))
    _token_expiry = time.monotonic() + expires_in - 60  # refresh 1 min early
    logger.info("SuccessFactors access token refreshed (expires_in=%d)", expires_in)
    return _cached_token


# ---------------------------------------------------------------------------
# Employee lookup
# ---------------------------------------------------------------------------

def _extract_department(data: dict) -> Tuple[Optional[str], Optional[str]]:
    """Pull department and sub_department out of the SF response dict."""
    # Try common field name variants returned by SAP CPI integrations
    dept = (
        data.get("Department")
        or data.get("department")
        or data.get("DepartmentName")
        or data.get("departmentName")
        or data.get("Dept")
    )
    sub_dept = (
        data.get("SubDepartment")
        or data.get("subDepartment")
        or data.get("sub_department")
        or data.get("SubDept")
        or data.get("Division")
        or data.get("division")
    )
    return (dept or None, sub_dept or None)


def get_employee_department(email: str) -> Tuple[Optional[str], Optional[str]]:
    """
    Returns (department, sub_department) for the given IndiGo email address.
    Returns (None, None) on any error so the caller is never blocked.
    """
    try:
        token = _get_access_token()
    except Exception as exc:
        logger.warning("SF token fetch failed for %s: %s", email, exc)
        return None, None

    try:
        from utils.network_config import build_http_client

        with build_http_client(timeout=15.0) as client:
            resp = client.request(
                "GET",
                _SF_EMPLOYEE_URL,
                headers={
                    "user_key": _SF_USER_KEY,
                    "Content-Type": "application/json",
                    "Authorization": f"Bearer {token}",
                },
                content=json.dumps({"EmailId": email, "CompanyCode": _SF_COMPANY_CODE}),
            )
            resp.raise_for_status()
            data = resp.json()

        logger.debug("SF employee response for %s: %s", email, data)

        # Response may be a list or a dict
        if isinstance(data, list):
            data = data[0] if data else {}

        dept, sub_dept = _extract_department(data)
        logger.info(
            "SF lookup for %s → department=%r sub_department=%r", email, dept, sub_dept
        )
        return dept, sub_dept

    except Exception as exc:
        logger.warning("SF employee lookup failed for %s: %s", email, exc)
        # If the token was rejected (401), invalidate it so next call retries
        global _cached_token, _token_expiry
        _cached_token = None
        _token_expiry = 0.0
        return None, None
