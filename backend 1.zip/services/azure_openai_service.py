"""
Azure OpenAI Service for Text Generation
Handles communication with Azure OpenAI GPT-4o for text generation
"""

import os
import json
from typing import Dict, Any
from openai import AzureOpenAI
from dotenv import load_dotenv
from utils.network_config import build_http_client

load_dotenv()


class AzureOpenAIService:
    """Service for Azure OpenAI API interactions"""
    
    def __init__(self):
        """Initialize Azure OpenAI client"""
        self.api_key = os.getenv("AZURE_OPENAI_KEY")
        self.endpoint = os.getenv("AZURE_OPENAI_BASE_URL")
        self.deployment = os.getenv("AZURE_OPENAI_DEPLOYMENT_NAME", "gpt-4o")
        self.api_version = os.getenv("AZURE_OPENAI_VERSION", "2025-01-01-preview").strip()

        if not self.api_key or not self.endpoint:
            raise ValueError("Azure OpenAI credentials not found in environment variables")

        self.client = AzureOpenAI(
            api_key=self.api_key,
            api_version=self.api_version,
            azure_endpoint=self.endpoint,
            http_client=build_http_client()
        )
    
    def generate_text_with_usage(self, prompt: str, temperature: float = 0.7, max_tokens: int = 1000):
        """Like generate_text but also returns (text, input_tokens, output_tokens)."""
        try:
            response = self.client.chat.completions.create(
                model=self.deployment,
                messages=[{"role": "user", "content": prompt}],
                temperature=temperature,
                max_tokens=max_tokens,
            )
            text = response.choices[0].message.content.strip()
            in_tok = response.usage.prompt_tokens if response.usage else 0
            out_tok = response.usage.completion_tokens if response.usage else 0
            return text, in_tok, out_tok
        except Exception as e:
            print(f"Error generating text: {e}")
            raise

    def generate_text(self, prompt: str, temperature: float = 0.7, max_tokens: int = 1000) -> str:
        text, _, _ = self.generate_text_with_usage(prompt, temperature, max_tokens)
        return text
    
    def parse_json_response(self, response_text: str) -> Dict[str, Any]:
        """
        Parse JSON from response text, handling markdown formatting
        
        Args:
            response_text: Raw response text that may contain markdown JSON
            
        Returns:
            Parsed JSON dictionary
        """
        try:
            # Remove markdown formatting if present
            cleaned = response_text
            if cleaned.startswith("```json"):
                cleaned = cleaned[7:-3].strip()
            elif cleaned.startswith("```"):
                cleaned = cleaned[3:-3].strip()
            
            return json.loads(cleaned)
        except json.JSONDecodeError as e:
            print(f"Error parsing JSON: {e}")
            print(f"Response text: {response_text}")
            raise
    
    def generate_and_parse(self, prompt: str, temperature: float = 0.7, max_tokens: int = 1000) -> Dict[str, Any]:
        """
        Generate text and parse JSON response
        
        Args:
            prompt: The prompt to send
            temperature: Creativity level (0-1)
            max_tokens: Maximum response tokens
            
        Returns:
            Parsed JSON response
        """
        raw_response = self.generate_text(prompt, temperature, max_tokens)
        return self.parse_json_response(raw_response)
