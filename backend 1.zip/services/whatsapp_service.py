"""
WhatsApp Marketing Text Generation Service
"""

from typing import Dict, Any
from services.azure_openai_service import AzureOpenAIService
from prompts.brand_guardrails_text import INDIGO_TEXT_BRAND_POLICY
from prompts.platform_text_prompt import PlatformTextPrompt
from prompts.platform_image_prompt import PlatformImagePrompt


class WhatsAppTextService:
    """Service for WhatsApp text generation"""

    def __init__(self):
        self.azure_service = AzureOpenAIService()

    def generate_text(self, campaign_instructions: str) -> Dict[str, Any]:
        """
        Generate WhatsApp marketing text with image description.

        Args:
            campaign_instructions: Campaign details/instructions

        Returns:
            Dict with WhatsApp message, CTA, and image description
        """
        try:
            prompt = PlatformTextPrompt.WHATSAPP.value.format(
                policy=INDIGO_TEXT_BRAND_POLICY,
                instructions=campaign_instructions,
            )
            response_text, in_tok, out_tok = self.azure_service.generate_text_with_usage(prompt=prompt, temperature=0.7, max_tokens=600)
            result = self.azure_service.parse_json_response(response_text)

            return {
                "platform": "whatsapp",
                "message": result.get("whatsapp_message", ""),
                "cta_button": result.get("cta_button", ""),
                "image_description": result.get("image_description", ""),
                "_text_input_tokens": in_tok,
                "_text_output_tokens": out_tok,
            }
        except Exception as e:
            print(f"Error generating WhatsApp text: {e}")
            raise

    def generate_image_prompt(self, message: str, cta: str) -> str:
        """
        Generate detailed image generation prompt for WhatsApp.

        Args:
            message: WhatsApp message content
            cta: Call-to-action text

        Returns:
            Prompt for image generation
        """
        try:
            prompt = PlatformImagePrompt.WHATSAPP.value.format(
                message_theme=message,
                cta=cta,
            )
            response_text = self.azure_service.generate_text(prompt=prompt, temperature=0.7, max_tokens=400)
            result = self.azure_service.parse_json_response(response_text)
            return result.get("image_prompt", "")
        except Exception as e:
            print(f"Error generating WhatsApp image prompt: {e}")
            raise
