"""
Gemini Image Generation Service
Handles image generation with gemini-3-pro-image-preview
Supports input images, logo placement, aspect ratio, and image editing
"""

import logging
import os
import random
import time
from typing import List, Optional, Dict
from io import BytesIO
import google.genai as genai
from google.genai.types import GenerateContentConfig, Modality
from PIL import Image
from dotenv import load_dotenv
from utils.network_config import clear_invalid_local_proxies

logger = logging.getLogger(__name__)

load_dotenv()
clear_invalid_local_proxies()

# Gemini request timeout in milliseconds (3 minutes — Google recommended ≥120 s)
_GEMINI_TIMEOUT_MS = int(os.getenv("GEMINI_TIMEOUT_MS", "180000"))

# Retry config for 503/capacity errors
_MAX_RETRIES = 3


def _is_retryable(exc: Exception) -> bool:
    """Return True for 503 / deadline / capacity errors that are worth retrying."""
    msg = str(exc).lower()
    return any(k in msg for k in ("503", "unavailable", "deadline", "timeout", "resource exhausted"))


def _call_with_retry(fn, max_retries: int = _MAX_RETRIES):
    """Call fn(), retrying on retryable errors with exponential backoff + jitter."""
    for attempt in range(max_retries + 1):
        try:
            return fn()
        except Exception as exc:
            if attempt == max_retries or not _is_retryable(exc):
                raise
            wait = (2 ** attempt) + random.uniform(0, 1)
            logger.warning(
                "Gemini retryable error on attempt %d/%d — retrying in %.1fs | %s: %s",
                attempt + 1, max_retries + 1, wait, type(exc).__name__, exc,
            )
            time.sleep(wait)


class GeminiImageService:
    """Service for Gemini image generation"""

    def __init__(self):
        """Initialize Gemini client"""
        self.api_key = os.getenv("GEMINI_IMAGE_API_KEY")

        if not self.api_key:
            raise ValueError("GEMINI_IMAGE_API_KEY not found in environment variables")

        self.client = genai.Client(
            api_key=self.api_key,
            http_options={"timeout": _GEMINI_TIMEOUT_MS},
        )
        self.model = os.getenv("GEMINI_IMAGE_MODEL_NAME", "gemini-3-pro-image-preview").strip()
        self.max_images = 14  # API limit for context images

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _build_generation_config(
        self,
        aspect_ratio: Optional[str] = None,
        image_size: Optional[str] = None,
    ) -> GenerateContentConfig:
        """Build a GenerateContentConfig, optionally including aspect ratio and image size."""
        config_kwargs: Dict = {"response_modalities": [Modality.IMAGE]}
        if aspect_ratio or image_size:
            from google.genai.types import ImageConfig
            img_cfg_kwargs: Dict = {}
            if aspect_ratio:
                img_cfg_kwargs["aspect_ratio"] = aspect_ratio
            if image_size:
                img_cfg_kwargs["image_size"] = image_size
            config_kwargs["image_config"] = ImageConfig(**img_cfg_kwargs)
        return GenerateContentConfig(**config_kwargs)

    # ------------------------------------------------------------------
    # Internal token helper
    # ------------------------------------------------------------------

    @staticmethod
    def _extract_usage(response) -> tuple:
        """Return (input_tokens, output_tokens) from a Gemini response."""
        try:
            usage = response.usage_metadata
            return (
                getattr(usage, "prompt_token_count", 0) or 0,
                getattr(usage, "candidates_token_count", 0) or 0,
            )
        except Exception:
            return 0, 0

    # ------------------------------------------------------------------
    # Text-to-image generation
    # ------------------------------------------------------------------

    def generate_image(
        self,
        prompt: str,
        aspect_ratio: Optional[str] = None,
        image_size: Optional[str] = None,
    ) -> tuple:
        """
        Generate a single image from a text prompt.

        Returns:
            (PIL Image or None, input_tokens, output_tokens)
        """
        try:
            cfg = self._build_generation_config(aspect_ratio, image_size)
            response = _call_with_retry(
                lambda: self.client.models.generate_content(
                    model=self.model, contents=prompt, config=cfg,
                )
            )
            in_tok, out_tok = self._extract_usage(response)

            if response.candidates and response.candidates[0].content.parts:
                for part in response.candidates[0].content.parts:
                    if part.inline_data is not None:
                        return Image.open(BytesIO(part.inline_data.data)), in_tok, out_tok

            # No image returned — log full response details for Google analysis
            candidate0 = response.candidates[0] if response.candidates else None
            finish_reason = getattr(candidate0, "finish_reason", "N/A") if candidate0 else "no candidates"
            safety_ratings = getattr(candidate0, "safety_ratings", []) if candidate0 else []
            text_parts = []
            if candidate0 and getattr(candidate0, "content", None):
                for part in getattr(candidate0.content, "parts", []):
                    if getattr(part, "text", None):
                        text_parts.append(part.text)
            logger.warning(
                "generate_image returned no image | model=%s | finish_reason=%s | "
                "safety_ratings=%s | text_response=%r | prompt_snippet=%r",
                self.model,
                finish_reason,
                safety_ratings,
                " | ".join(text_parts) if text_parts else "<none>",
                prompt[:200],
            )
            return None, in_tok, out_tok
        except Exception as e:
            logger.exception(
                "generate_image raised an exception | model=%s | error_type=%s | error=%s | prompt_snippet=%r",
                self.model, type(e).__name__, e, prompt[:200],
            )
            raise

    def generate_image_with_context(
        self,
        prompt: str,
        context_images: List[str],
        logo_path: Optional[str] = None,
        reference_image_paths: Optional[List[str]] = None,
        aspect_ratio: Optional[str] = None,
        image_size: Optional[str] = None,
    ) -> tuple:
        """
        Generate image with context/reference images and logo.

        Returns:
            (PIL Image or None, input_tokens, output_tokens)
        """
        try:
            contents = [prompt]

            resolved_reference_paths: List[str] = []
            if reference_image_paths:
                resolved_reference_paths.extend(
                    image_path for image_path in reference_image_paths if image_path and os.path.exists(image_path)
                )
            elif logo_path and os.path.exists(logo_path):
                resolved_reference_paths.append(logo_path)

            for image_path in resolved_reference_paths[:self.max_images]:
                reference_img = Image.open(image_path)
                reference_b64 = self._image_to_base64(reference_img)
                contents.append({
                    "inline_data": {"mime_type": "image/png", "data": reference_b64}
                })

            remaining_slots = max(self.max_images - len(resolved_reference_paths), 0)
            for b64_image in context_images[:remaining_slots]:
                if not b64_image or not str(b64_image).strip():
                    continue
                contents.append({
                    "inline_data": {"mime_type": "image/png", "data": b64_image}
                })

            cfg = self._build_generation_config(aspect_ratio, image_size)
            response = _call_with_retry(
                lambda: self.client.models.generate_content(
                    model=self.model, contents=contents, config=cfg,
                )
            )
            in_tok, out_tok = self._extract_usage(response)

            if response.candidates and response.candidates[0].content.parts:
                for part in response.candidates[0].content.parts:
                    if part.inline_data is not None:
                        return Image.open(BytesIO(part.inline_data.data)), in_tok, out_tok

            # No image returned — log full response details for Google analysis
            candidate0 = response.candidates[0] if response.candidates else None
            finish_reason = getattr(candidate0, "finish_reason", "N/A") if candidate0 else "no candidates"
            safety_ratings = getattr(candidate0, "safety_ratings", []) if candidate0 else []
            text_parts = []
            if candidate0 and getattr(candidate0, "content", None):
                for part in getattr(candidate0.content, "parts", []):
                    if getattr(part, "text", None):
                        text_parts.append(part.text)
            logger.warning(
                "generate_image_with_context returned no image | model=%s | finish_reason=%s | "
                "safety_ratings=%s | text_response=%r | context_image_count=%d | prompt_snippet=%r",
                self.model,
                finish_reason,
                safety_ratings,
                " | ".join(text_parts) if text_parts else "<none>",
                len(contents) - 1,
                prompt[:200],
            )
            return None, in_tok, out_tok
        except Exception as e:
            logger.exception(
                "generate_image_with_context raised an exception | model=%s | error_type=%s | "
                "error=%s | context_image_count=%d | prompt_snippet=%r",
                self.model, type(e).__name__, e, len(contents) - 1, prompt[:200],
            )
            raise

    def generate_multiple_images(
        self,
        prompt: str,
        count: int = 3,
        context_images: Optional[List[str]] = None,
        logo_path: Optional[str] = None,
        reference_image_paths: Optional[List[str]] = None,
        aspect_ratio: Optional[str] = None,
        image_size: Optional[str] = None,
    ) -> tuple:
        """
        Generate multiple images (requires multiple API calls).

        Returns:
            (List of PIL Images, total_input_tokens, total_output_tokens)
        """
        images = []
        total_in_tok = 0
        total_out_tok = 0
        last_exc: Optional[Exception] = None

        for i in range(count):
            try:
                if context_images or logo_path or reference_image_paths:
                    img, in_tok, out_tok = self.generate_image_with_context(
                        prompt,
                        context_images or [],
                        logo_path,
                        reference_image_paths,
                        aspect_ratio=aspect_ratio,
                        image_size=image_size,
                    )
                else:
                    img, in_tok, out_tok = self.generate_image(prompt, aspect_ratio=aspect_ratio, image_size=image_size)

                total_in_tok += in_tok
                total_out_tok += out_tok
                if img:
                    images.append(img)
                else:
                    logger.warning(
                        "generate_multiple_images: attempt %d/%d returned no image | model=%s",
                        i + 1, count, self.model,
                    )
            except Exception as e:
                last_exc = e
                logger.error(
                    "generate_multiple_images: attempt %d/%d failed | model=%s | error_type=%s | error=%s",
                    i + 1, count, self.model, type(e).__name__, e,
                )
                continue

        if not images and last_exc is not None:
            # All attempts failed — re-raise the last exception so the caller can return a proper error
            raise last_exc

        return images, total_in_tok, total_out_tok

    # ------------------------------------------------------------------
    # Image editing
    # ------------------------------------------------------------------

    def edit_image(
        self,
        image_b64: str,
        edit_prompt: str,
        reference_image_paths: Optional[List[str]] = None,
        aspect_ratio: Optional[str] = None,
        image_size: Optional[str] = None,
    ) -> Optional[Image.Image]:
        """
        Edit an existing image using a text prompt.

        Sends the source image together with the edit instructions so the model
        can add, remove, or modify elements, change styles, or adjust color grading.

        Args:
            image_b64: Base64-encoded source image (PNG)
            edit_prompt: Natural-language editing instructions
            reference_image_paths: Optional brand reference images (e.g. logos)
            aspect_ratio: Optional target aspect ratio for the output image
            image_size: Optional output resolution ("1K", "2K", "4K")

        Returns:
            Edited PIL Image or None if the model produced no image
        """
        try:
            contents = [
                edit_prompt,
                {
                    "inline_data": {
                        "mime_type": "image/png",
                        "data": image_b64,
                    }
                },
            ]

            # Append any reference / logo images
            if reference_image_paths:
                for ref_path in reference_image_paths:
                    if ref_path and os.path.exists(ref_path):
                        ref_img = Image.open(ref_path)
                        contents.append({
                            "inline_data": {
                                "mime_type": "image/png",
                                "data": self._image_to_base64(ref_img),
                            }
                        })

            cfg = self._build_generation_config(aspect_ratio, image_size)
            response = _call_with_retry(
                lambda: self.client.models.generate_content(
                    model=self.model, contents=contents, config=cfg,
                )
            )
            in_tok, out_tok = self._extract_usage(response)

            candidate0 = response.candidates[0] if response.candidates else None
            candidate0_parts = (
                candidate0.content.parts
                if candidate0
                and getattr(candidate0, "content", None)
                and getattr(candidate0.content, "parts", None)
                else None
            )
            if candidate0_parts:
                for part in candidate0_parts:
                    if part.inline_data is not None:
                        return Image.open(BytesIO(part.inline_data.data)), in_tok, out_tok

            # No image in the response — log everything we can to diagnose why.
            finish_reason = getattr(candidate0, "finish_reason", "N/A") if candidate0 else "no candidates"
            safety_ratings = getattr(candidate0, "safety_ratings", []) if candidate0 else []
            text_parts = []
            if candidate0_parts:
                for part in candidate0_parts:
                    if getattr(part, "text", None):
                        text_parts.append(part.text)
            logger.warning(
                "edit_image returned no image. finish_reason=%s safety_ratings=%s text_response=%r",
                finish_reason,
                safety_ratings,
                " | ".join(text_parts) if text_parts else "<none>",
            )
            return None, in_tok, out_tok
        except Exception as e:
            logger.exception(
                "edit_image raised an exception | model=%s | error_type=%s | error=%s",
                self.model, type(e).__name__, e,
            )
            raise

    # ------------------------------------------------------------------
    # Utility methods
    # ------------------------------------------------------------------

    @staticmethod
    def _image_to_base64(image: Image.Image) -> str:
        """Convert PIL Image to base64 string"""
        from io import BytesIO
        import base64

        buffer = BytesIO()
        image.save(buffer, format="PNG")
        buffer.seek(0)
        return base64.standard_b64encode(buffer.getvalue()).decode("utf-8")

    @classmethod
    def images_to_base64(cls, images: List[Image.Image]) -> List[str]:
        """Convert a list of PIL Images to base64 strings."""
        encoded_images = []
        for image in images:
            try:
                encoded_images.append(cls._image_to_base64(image))
            except Exception as e:
                logger.error("images_to_base64: failed to encode image | error_type=%s | error=%s", type(e).__name__, e)
                continue
        return encoded_images

    @staticmethod
    def save_images(images: List[Image.Image], output_dir: str, prefix: str = "generated") -> List[str]:
        """
        Save generated images to directory

        Args:
            images: List of PIL Images
            output_dir: Output directory path
            prefix: Filename prefix

        Returns:
            List of saved file paths
        """
        os.makedirs(output_dir, exist_ok=True)
        saved_paths = []

        for i, image in enumerate(images):
            try:
                filename = f"{prefix}_{i+1}.png"
                filepath = os.path.join(output_dir, filename)
                image.save(filepath)
                saved_paths.append(filepath)
            except Exception as e:
                logger.error("save_images: failed to save image %d | error_type=%s | error=%s", i + 1, type(e).__name__, e)

        return saved_paths
