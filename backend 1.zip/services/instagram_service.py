"""
Instagram Marketing Text Generation Service
"""

from typing import Dict, Any
from services.azure_openai_service import AzureOpenAIService
from prompts.brand_guardrails_text import INDIGO_TEXT_BRAND_POLICY
from prompts.platform_text_prompt import PlatformTextPrompt
from prompts.platform_image_prompt import PlatformImagePrompt


class InstagramTextService:
    """Service for Instagram text generation"""

    def __init__(self):
        self.azure_service = AzureOpenAIService()

    def generate_text(self, campaign_instructions: str) -> Dict[str, Any]:
        """
        Generate Instagram marketing content with image description.

        Args:
            campaign_instructions: Campaign details/instructions

        Returns:
            Dict with Instagram caption, hashtags, and image description
        """
        try:
            prompt = PlatformTextPrompt.INSTAGRAM.value.format(
                policy=INDIGO_TEXT_BRAND_POLICY,
                instructions=campaign_instructions,
            )
            response_text, in_tok, out_tok = self.azure_service.generate_text_with_usage(prompt=prompt, temperature=0.7, max_tokens=700)
            result = self.azure_service.parse_json_response(response_text)

            return {
                "platform": "instagram",
                "caption": result.get("caption", ""),
                "hashtags": result.get("hashtags", []),
                "cta_text": result.get("cta_text", ""),
                "image_description": result.get("image_description", ""),
                "_text_input_tokens": in_tok,
                "_text_output_tokens": out_tok,
            }
        except Exception as e:
            print(f"Error generating Instagram text: {e}")
            raise

    def generate_image_prompt(
        self, campaign_theme: str, message: str, hashtags: list, cta: str
    ) -> str:
        """
        Generate detailed image generation prompt for Instagram post.

        Args:
            campaign_theme: Campaign theme/topic
            message: Main message text
            hashtags: List of hashtags
            cta: Call-to-action text

        Returns:
            Prompt for image generation
        """
        try:
            hashtags_str = ", ".join(hashtags) if isinstance(hashtags, list) else hashtags
            prompt = PlatformImagePrompt.INSTAGRAM.value.format(
                campaign_theme=campaign_theme,
                message=message,
                hashtags=hashtags_str,
                cta=cta,
            )
            response_text = self.azure_service.generate_text(prompt=prompt, temperature=0.7, max_tokens=500)
            result = self.azure_service.parse_json_response(response_text)
            return result.get("image_prompt", "")
        except Exception as e:
            print(f"Error generating Instagram image prompt: {e}")
            raise
