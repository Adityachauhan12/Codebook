"""
Twitter Marketing Text Generation Service
"""

from typing import Dict, Any
from services.azure_openai_service import AzureOpenAIService
from prompts.brand_guardrails_text import INDIGO_TEXT_BRAND_POLICY
from prompts.platform_text_prompt import PlatformTextPrompt
from prompts.platform_image_prompt import PlatformImagePrompt


class TwitterTextService:
    """Service for Twitter text generation"""

    def __init__(self):
        self.azure_service = AzureOpenAIService()

    def generate_text(self, campaign_instructions: str) -> Dict[str, Any]:
        """
        Generate Twitter marketing content with image description.

        Args:
            campaign_instructions: Campaign details/instructions

        Returns:
            Dict with Twitter post, thread, hashtags, and image description
        """
        try:
            prompt = PlatformTextPrompt.TWITTER.value.format(
                policy=INDIGO_TEXT_BRAND_POLICY,
                instructions=campaign_instructions,
            )
            response_text, in_tok, out_tok = self.azure_service.generate_text_with_usage(prompt=prompt, temperature=0.7, max_tokens=900)
            result = self.azure_service.parse_json_response(response_text)

            return {
                "platform": "twitter",
                "tweet": result.get("tweet", ""),
                "thread": result.get("thread", []),
                "hashtags": result.get("hashtags", []),
                "cta_hook": result.get("cta_hook", ""),
                "image_description": result.get("image_description", ""),
                "_text_input_tokens": in_tok,
                "_text_output_tokens": out_tok,
            }
        except Exception as e:
            print(f"Error generating Twitter text: {e}")
            raise

    def generate_image_prompt(
        self, campaign_theme: str, message: str, hashtags: list, cta: str
    ) -> str:
        """
        Generate detailed image generation prompt for Twitter post.

        Args:
            campaign_theme: Theme/topic of campaign
            message: Main message from tweet
            hashtags: Hashtags from tweet
            cta: Engagement hook from tweet

        Returns:
            Detailed image generation prompt
        """
        try:
            prompt = PlatformImagePrompt.TWITTER.value.format(
                campaign_theme=campaign_theme,
                message=message,
                hashtags=", ".join(hashtags),
                cta=cta,
            )
            return self.azure_service.generate_text(prompt=prompt, temperature=0.7, max_tokens=600)
        except Exception as e:
            print(f"Error generating Twitter image prompt: {e}")
            raise
