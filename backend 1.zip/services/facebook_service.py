"""
Facebook Marketing Text Generation Service
"""

from typing import Dict, Any
from services.azure_openai_service import AzureOpenAIService
from prompts.brand_guardrails_text import INDIGO_TEXT_BRAND_POLICY
from prompts.platform_text_prompt import PlatformTextPrompt
from prompts.platform_image_prompt import PlatformImagePrompt


class FacebookTextService:
    """Service for Facebook text generation"""

    def __init__(self):
        self.azure_service = AzureOpenAIService()

    def generate_text(self, campaign_instructions: str) -> Dict[str, Any]:
        """
        Generate Facebook marketing content with image description.

        Args:
            campaign_instructions: Campaign details/instructions

        Returns:
            Dict with Facebook post text, CTA, and image description
        """
        try:
            prompt = PlatformTextPrompt.FACEBOOK.value.format(
                policy=INDIGO_TEXT_BRAND_POLICY,
                instructions=campaign_instructions,
            )
            response_text, in_tok, out_tok = self.azure_service.generate_text_with_usage(prompt=prompt, temperature=0.7, max_tokens=800)
            result = self.azure_service.parse_json_response(response_text)

            return {
                "platform": "facebook",
                "post_text": result.get("post_text", ""),
                "cta_button": result.get("cta_button", ""),
                "cta_text": result.get("cta_text", ""),
                "image_description": result.get("image_description", ""),
                "_text_input_tokens": in_tok,
                "_text_output_tokens": out_tok,
            }
        except Exception as e:
            print(f"Error generating Facebook text: {e}")
            raise

    def generate_image_prompt(self, campaign_theme: str, message: str, cta: str) -> str:
        """
        Generate detailed image generation prompt for Facebook post.

        Args:
            campaign_theme: Theme/topic of campaign
            message: Main message from post
            cta: Call to action from post

        Returns:
            Detailed image generation prompt
        """
        try:
            prompt = PlatformImagePrompt.FACEBOOK.value.format(
                campaign_theme=campaign_theme,
                message=message,
                cta=cta,
            )
            return self.azure_service.generate_text(prompt=prompt, temperature=0.7, max_tokens=600)
        except Exception as e:
            print(f"Error generating Facebook image prompt: {e}")
            raise
