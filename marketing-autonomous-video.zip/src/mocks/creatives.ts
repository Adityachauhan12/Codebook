export type CreativeScope = "community" | "org";

export type Creative = {
  id: string;
  seed: number;
  width: number;
  height: number;
  style: string;
  ratio: string;
  prompt: string;
  model: string;
  tags: string[];
  author: { name: string; org: string; initials: string; color: string };
  likes: number;
  remixes: number;
  savedAt: string;
  scope: CreativeScope;
  campaignId?: string;
  origin?: "Studio" | "Campaign" | "Draft";
  byMe?: boolean;
};

const STYLES = ["Photoreal", "Product", "Poster", "Illustration", "3D", "Cinematic"];
const RATIOS: [string, number, number][] = [
  ["1:1", 600, 600],
  ["4:5", 600, 750],
  ["3:4", 600, 800],
  ["16:9", 800, 450],
  ["9:16", 450, 800],
  ["2:3", 600, 900],
];
const MODELS = ["Nano Banana", "GPT-Image", "Flux"];
const PROMPTS = [
  "Minimalist ceramic mug on marble, morning light",
  "Summer sale hero, playful gradient, bold typography",
  "Portrait of a runner at golden hour, film grain",
  "Isometric 3D icon set for a fintech app",
  "Editorial poster, brutalist type, high contrast",
  "Skincare bottle on wet pebbles, macro photography",
  "Retro-futuristic city skyline at dusk",
  "Cozy interior with a golden retriever, natural light",
  "Sneaker floating over pastel background, studio",
  "Abstract fluid gradient, deep blues and violet",
  "Coffee shop menu board, hand-drawn illustrations",
  "Product still life for artisan chocolate bar",
];
const AUTHORS_COMMUNITY: Creative["author"][] = [
  { name: "Aria Chen", org: "Kite Studio", initials: "AC", color: "#E4405F" },
  { name: "Marco P.", org: "Northwind", initials: "MP", color: "#1877F2" },
  { name: "Jules Ito", org: "Loop", initials: "JI", color: "#34A853" },
  { name: "Sana K.", org: "Sundry", initials: "SK", color: "#F97316" },
  { name: "Devon R.", org: "Halide", initials: "DR", color: "#7C3AED" },
  { name: "Priya N.", org: "Foldwork", initials: "PN", color: "#0EA5E9" },
];
const AUTHORS_ORG: Creative["author"][] = [
  { name: "You", org: "Loom Team", initials: "YO", color: "#000099" },
  { name: "Alex Rivera", org: "Loom Team", initials: "AR", color: "#000099" },
  { name: "Sam Ortiz", org: "Loom Team", initials: "SO", color: "#000099" },
];
const ORIGINS: Creative["origin"][] = ["Studio", "Campaign", "Draft"];

function pick<T>(arr: T[], i: number): T {
  return arr[i % arr.length];
}

function build(scope: CreativeScope, count: number, seedBase: number): Creative[] {
  const authors = scope === "community" ? AUTHORS_COMMUNITY : AUTHORS_ORG;
  return Array.from({ length: count }, (_, i) => {
    const seed = seedBase + i;
    const [ratio, w, h] = pick(RATIOS, seed);
    const style = pick(STYLES, seed + 1);
    const author = pick(authors, seed);
    const origin = pick(ORIGINS, seed + 2)!;
    return {
      id: `${scope}-${seed}`,
      seed,
      width: w,
      height: h,
      style,
      ratio,
      prompt: pick(PROMPTS, seed + 3),
      model: pick(MODELS, seed + 4),
      tags: [style.toLowerCase(), ratio, pick(["hero", "social", "email", "banner"], seed)],
      author,
      likes: 20 + ((seed * 37) % 480),
      remixes: 2 + ((seed * 13) % 88),
      savedAt: pick(["2m ago", "1h ago", "yesterday", "2d ago", "1w ago"], seed),
      scope,
      origin: scope === "org" ? origin : undefined,
      campaignId: scope === "org" && origin === "Campaign" ? "live-1" : undefined,
      byMe: scope === "org" && author.name === "You",
    };
  });
}

export const COMMUNITY_CREATIVES: Creative[] = build("community", 32, 200);
export const ORG_CREATIVES: Creative[] = build("org", 24, 700);

type FetchArgs = {
  scope: CreativeScope;
  filter?: string;
  sort?: string;
  cursor?: number;
  pageSize?: number;
  search?: string;
};

export async function getCreatives({
  scope,
  filter = "All",
  sort = "Trending",
  cursor = 0,
  pageSize = 12,
  search = "",
}: FetchArgs): Promise<{ items: Creative[]; nextCursor: number | null }> {
  await new Promise((r) => setTimeout(r, 350));
  const base = scope === "community" ? COMMUNITY_CREATIVES : ORG_CREATIVES;

  let items = base.slice();

  if (filter !== "All") {
    const f = filter.toLowerCase();
    items = items.filter(
      (c) =>
        c.style.toLowerCase() === f ||
        c.ratio === filter ||
        c.origin?.toLowerCase() === f ||
        (filter === "By me" && c.byMe) ||
        (filter === "By team" && !c.byMe),
    );
  }
  if (search.trim()) {
    const q = search.toLowerCase();
    items = items.filter(
      (c) => c.prompt.toLowerCase().includes(q) || c.tags.some((t) => t.includes(q)),
    );
  }

  if (sort === "Newest" || sort === "Oldest") {
    items.sort((a, b) => (sort === "Newest" ? b.seed - a.seed : a.seed - b.seed));
  } else if (sort === "Most remixed" || sort === "Most used in campaigns") {
    items.sort((a, b) => b.remixes - a.remixes);
  } else {
    items.sort((a, b) => b.likes + b.remixes - (a.likes + a.remixes));
  }

  const slice = items.slice(cursor, cursor + pageSize);
  const nextCursor = cursor + pageSize < items.length ? cursor + pageSize : null;
  return { items: slice, nextCursor };
}
