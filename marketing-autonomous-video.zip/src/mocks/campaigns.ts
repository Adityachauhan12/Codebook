export type CampaignStatus = "Live" | "Draft" | "Paused" | "Ended";

export type MockCampaign = {
  id: string;
  name: string;
  status: CampaignStatus;
  objective: string;
  budget: number;
  spent: number;
  channels: string[];
  roas: string;
  ctr: string;
  startedAt: string;
};

export const MOCK_CAMPAIGNS: MockCampaign[] = [
  {
    id: "live-1",
    name: "Summer flights to Bali — Q3 push",
    status: "Live",
    objective: "Flight bookings",
    budget: 6000,
    spent: 2480,
    channels: ["Google Search", "Google PMax", "Meta Feed", "Meta Reels"],
    roas: "4.2x",
    ctr: "2.8%",
    startedAt: "Jul 12",
  },
  {
    id: "live-2",
    name: "Business Class upgrade — LHR ⇄ JFK",
    status: "Live",
    objective: "Upgrades",
    budget: 8500,
    spent: 5210,
    channels: ["LinkedIn", "Google Search", "Meta Feed"],
    roas: "3.6x",
    ctr: "2.1%",
    startedAt: "Jun 28",
  },
  {
    id: "paused-1",
    name: "Frequent flyer app installs — DE",
    status: "Paused",
    objective: "App installs",
    budget: 3200,
    spent: 1740,
    channels: ["TikTok", "Meta Reels", "Google PMax"],
    roas: "2.4x",
    ctr: "3.3%",
    startedAt: "Jun 10",
  },
  {
    id: "draft-1",
    name: "Winter escapes — brand lift",
    status: "Draft",
    objective: "Awareness",
    budget: 4000,
    spent: 0,
    channels: ["Meta Stories", "YouTube"],
    roas: "—",
    ctr: "—",
    startedAt: "—",
  },
  {
    id: "ended-1",
    name: "Easter getaway — Europe short-haul",
    status: "Ended",
    objective: "Flight bookings",
    budget: 5000,
    spent: 4912,
    channels: ["Meta Feed", "Google Search"],
    roas: "4.7x",
    ctr: "3.0%",
    startedAt: "Apr 04",
  },
];
