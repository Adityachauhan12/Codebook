import { Link, useRouterState } from "@tanstack/react-router";
import {
  LayoutDashboard,
  Sparkles,
  Megaphone,
  Palette,
  Settings,
  Compass,
  BarChart3,
  ShieldCheck,
  Film,
} from "lucide-react";
import type { ReactNode } from "react";

type NavItem = {
  to: string;
  label: string;
  icon: typeof LayoutDashboard;
  match?: (pathname: string) => boolean;
};

const NAV: NavItem[] = [
  { to: "/", label: "Dashboard", icon: LayoutDashboard, match: (p) => p === "/" },
  { to: "/studio", label: "AI Studio", icon: Sparkles, match: (p) => p.startsWith("/studio") },
  { to: "/video", label: "AI Video", icon: Film, match: (p) => p.startsWith("/video") },
  { to: "/explore", label: "Explore", icon: Compass, match: (p) => p.startsWith("/explore") },
  { to: "/campaigns", label: "Campaigns", icon: Megaphone, match: (p) => p.startsWith("/campaigns") },
  { to: "/editor", label: "Editor", icon: Palette, match: (p) => p.startsWith("/editor") },
  { to: "/approvals", label: "Approvals", icon: ShieldCheck, match: (p) => p.startsWith("/approvals") },
  { to: "/settings", label: "Settings", icon: Settings, match: (p) => p.startsWith("/settings") },
  { to: "/analytics", label: "Analytics", icon: BarChart3, match: (p) => p.startsWith("/analytics") },
];

export function AppShell({ children }: { children: ReactNode }) {
  const pathname = useRouterState({ select: (s) => s.location.pathname });

  return (
    <div className="flex min-h-screen flex-col bg-background">
      <header className="sticky top-0 z-30 h-14 border-b border-border bg-surface/80 backdrop-blur">
        <div className="h-full px-4 sm:px-6 flex items-center gap-6">
          <Link to="/" className="flex items-center gap-2 shrink-0">
            <div className="size-7 rounded-lg bg-white grid place-items-center text-primary-foreground">
              <img src="/logo.svg" alt="Logo" className="size-5 object-contain " />
            </div>
            <div className="font-display font-bold tracking-tight text-[15px]">Autonomous Marketing</div>
          </Link>

          <nav className="flex items-center gap-0.5 overflow-x-auto flex-1 min-w-0">
            {NAV.map((item) => {
              const active = item.match ? item.match(pathname) : pathname === item.to;
              const Icon = item.icon;
              return (
                <Link
                  key={item.to}
                  to={item.to}
                  className={`flex items-center gap-2 px-3 py-1.5 rounded-lg text-sm whitespace-nowrap transition-colors ${
                    active
                      ? "bg-accent text-foreground font-medium"
                      : "text-muted-foreground hover:bg-accent/60 hover:text-foreground"
                  }`}
                >
                  <Icon className="size-4" />
                  <span className="hidden sm:inline">{item.label}</span>
                </Link>
              );
            })}
          </nav>

          <div className="flex items-center gap-3 shrink-0">
            <div className="hidden md:flex items-center gap-1.5 text-xs px-2.5 py-1 rounded-full bg-accent">
              <Sparkles className="size-3 text-[var(--accent-ai)]" />
              <span className="font-medium">248 credits</span>
            </div>
            <div className="size-8 rounded-full bg-gradient-to-br from-primary to-[var(--accent-ai)]" />
          </div>
        </div>
      </header>

      <main className="flex-1 min-w-0">{children}</main>
    </div>
  );
}
