import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import {
  AlertTriangle,
  ArrowDownRight,
  ArrowUpRight,
  BarChart3,
  Building2,
  Clock,
  Crown,
  Download,
  Filter,
  Image as ImageIcon,
  Megaphone,
  ShieldCheck,
  Sparkles,
  TrendingUp,
  Users,
  Wand2,
  Zap,
} from "lucide-react";
import {
  Area,
  AreaChart,
  Bar,
  BarChart,
  CartesianGrid,
  Cell,
  Legend,
  Pie,
  PieChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";
import { AppShell } from "@/components/AppShell";

export const Route = createFileRoute("/analytics")({
  component: AnalyticsPage,
  head: () => ({
    meta: [
      { title: "Analytics — Loom" },
      { name: "description", content: "Workspace-wide analytics for superadmins." },
    ],
  }),
});

// ---- Mock data (airline org) ----

type Dept = {
  id: string;
  name: string;
  members: number;
  credits: number;
  generations: number;
  campaigns: number;
  spend: number;
  ctr: number;
  roas: number;
  trend: number; // % vs last period
};

const DEPARTMENTS: Dept[] = [
  { id: "brand",    name: "Brand & Marketing",    members: 24, credits: 4820, generations: 1240, campaigns: 42, spend: 128400, ctr: 3.4, roas: 4.8, trend: 12.4 },
  { id: "growth",   name: "Growth & Performance", members: 18, credits: 6340, generations: 980,  campaigns: 68, spend: 214300, ctr: 4.1, roas: 6.2, trend: 22.1 },
  { id: "loyalty",  name: "Loyalty (FlyMiles)",   members: 9,  credits: 1980, generations: 520,  campaigns: 21, spend: 54200,  ctr: 2.8, roas: 3.9, trend: -4.2 },
  { id: "cargo",    name: "Cargo & Freight",      members: 6,  credits: 890,  generations: 210,  campaigns: 11, spend: 22100,  ctr: 1.9, roas: 2.4, trend: 3.1 },
  { id: "inflight", name: "Inflight & Retail",    members: 11, credits: 2110, generations: 610,  campaigns: 18, spend: 41800,  ctr: 3.2, roas: 4.1, trend: 8.6 },
  { id: "corp",     name: "Corporate Travel",     members: 7,  credits: 1240, generations: 340,  campaigns: 14, spend: 61400,  ctr: 2.6, roas: 5.1, trend: 15.2 },
];

const USAGE_TREND = [
  { day: "Jul 01", generations: 210, campaigns: 12, credits: 640 },
  { day: "Jul 05", generations: 280, campaigns: 14, credits: 780 },
  { day: "Jul 09", generations: 320, campaigns: 18, credits: 910 },
  { day: "Jul 13", generations: 410, campaigns: 22, credits: 1120 },
  { day: "Jul 17", generations: 480, campaigns: 24, credits: 1340 },
  { day: "Jul 21", generations: 540, campaigns: 28, credits: 1520 },
];

const CHANNEL_SPLIT = [
  { name: "Google Ads",   value: 42, color: "#4285F4" },
  { name: "Meta Ads",     value: 31, color: "#1877F2" },
  { name: "YouTube",      value: 14, color: "#FF0000" },
  { name: "TikTok",       value: 8,  color: "#111827" },
  { name: "LinkedIn",     value: 5,  color: "#0A66C2" },
];

const TOP_USERS = [
  { name: "Ananya Rao",    dept: "Growth & Performance", credits: 812, generations: 214 },
  { name: "Kabir Mehta",   dept: "Brand & Marketing",    credits: 640, generations: 178 },
  { name: "Sara Iyer",     dept: "Growth & Performance", credits: 588, generations: 162 },
  { name: "Rohan Kapoor",  dept: "Loyalty (FlyMiles)",   credits: 421, generations: 128 },
  { name: "Meera Shah",    dept: "Inflight & Retail",    credits: 388, generations: 112 },
];

const ALERTS = [
  { level: "high",   msg: "Growth & Performance is at 92% of monthly credit quota (5,800 / 6,300)." },
  { level: "medium", msg: "12 campaigns launched without a brand-prompt override in the last 7 days." },
  { level: "low",    msg: "Cargo & Freight has 3 inactive members with paid seats." },
];

const RANGES = ["7d", "30d", "90d", "YTD", "Custom"] as const;

function isoDaysAgo(days: number) {
  const d = new Date();
  d.setDate(d.getDate() - days);
  return d.toISOString().slice(0, 10);
}
function todayIso() {
  return new Date().toISOString().slice(0, 10);
}

// ---- Page ----

function AnalyticsPage() {
  // Mock role gate — real app would use auth + user_roles table.
  // Default the current user to superadmin so the page renders in preview.
  const [isSuperadmin, setIsSuperadmin] = useState<boolean>(true);
  const [range, setRange] = useState<(typeof RANGES)[number]>("30d");
  const [customStart, setCustomStart] = useState<string>(isoDaysAgo(30));
  const [customEnd, setCustomEnd] = useState<string>(todayIso());
  const [deptFilter, setDeptFilter] = useState<string>("all");

  useEffect(() => {
    const role = localStorage.getItem("mock.role");
    if (role && role !== "superadmin") setIsSuperadmin(false);
  }, []);

  const totals = useMemo(() => {
    const list = deptFilter === "all" ? DEPARTMENTS : DEPARTMENTS.filter((d) => d.id === deptFilter);
    return {
      credits: list.reduce((a, d) => a + d.credits, 0),
      generations: list.reduce((a, d) => a + d.generations, 0),
      campaigns: list.reduce((a, d) => a + d.campaigns, 0),
      spend: list.reduce((a, d) => a + d.spend, 0),
      members: list.reduce((a, d) => a + d.members, 0),
    };
  }, [deptFilter]);

  if (isSuperadmin === null) {
    return (
      <AppShell>
        <div className="p-10 text-sm text-muted-foreground">Loading…</div>
      </AppShell>
    );
  }

  if (!isSuperadmin) {
    return (
      <AppShell>
        <div className="max-w-md mx-auto mt-24 rounded-2xl border border-border bg-surface p-8 text-center">
          <div className="size-12 rounded-full bg-amber-500/10 grid place-items-center mx-auto mb-4">
            <ShieldCheck className="size-6 text-amber-500" />
          </div>
          <h1 className="text-lg font-display font-bold tracking-tight">Superadmin only</h1>
          <p className="text-sm text-muted-foreground mt-2">
            The workspace analytics dashboard is restricted to superadmins. Ask your workspace owner
            for access.
          </p>
          <Link
            to="/"
            className="mt-6 inline-flex items-center gap-1.5 rounded-lg bg-primary text-primary-foreground px-4 py-2 text-sm font-medium hover:opacity-90"
          >
            Back to dashboard
          </Link>
        </div>
      </AppShell>
    );
  }

  const maxCredits = Math.max(...DEPARTMENTS.map((d) => d.credits));

  return (
    <AppShell>
      <div className="px-6 py-8 max-w-7xl mx-auto flex flex-col gap-6">
        {/* Header */}
        <div className="flex flex-col md:flex-row md:items-center gap-3">
          <div className="flex items-center gap-3 flex-1">
            <div className="size-10 rounded-xl bg-primary/10 text-primary grid place-items-center">
              <BarChart3 className="size-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-2xl font-display font-bold tracking-tight">Workspace analytics</h1>
                <span className="inline-flex items-center gap-1 text-[11px] font-medium px-1.5 py-0.5 rounded-full bg-primary/10 text-primary">
                  <Crown className="size-3" /> Superadmin
                </span>
              </div>
              <p className="text-sm text-muted-foreground">
                Cross-department view of AI usage, campaigns, and ad performance for Loomair.
              </p>
            </div>
          </div>
          <div className="flex items-center gap-2 flex-wrap">
            <div className="flex items-center rounded-lg border border-border p-0.5 bg-surface">
              {RANGES.map((r) => (
                <button
                  key={r}
                  onClick={() => setRange(r)}
                  className={`px-3 py-1 text-xs font-medium rounded-md transition-colors ${
                    range === r ? "bg-primary text-primary-foreground" : "text-muted-foreground hover:text-foreground"
                  }`}
                >
                  {r}
                </button>
              ))}
            </div>
            {range === "Custom" && (
              <div className="flex items-center gap-1.5 rounded-lg border border-border bg-surface px-2 py-1">
                <input
                  type="date"
                  value={customStart}
                  max={customEnd}
                  onChange={(e) => setCustomStart(e.target.value)}
                  className="bg-transparent text-xs outline-none"
                />
                <span className="text-muted-foreground text-xs">→</span>
                <input
                  type="date"
                  value={customEnd}
                  min={customStart}
                  max={todayIso()}
                  onChange={(e) => setCustomEnd(e.target.value)}
                  className="bg-transparent text-xs outline-none"
                />
              </div>
            )}
            <button className="inline-flex items-center gap-1.5 rounded-lg border border-border px-3 py-2 text-sm font-medium hover:bg-accent">
              <Download className="size-4" /> Export
            </button>
          </div>
        </div>

        {/* Dept filter */}
        <div className="flex items-center gap-2 overflow-x-auto pb-1">
          <Filter className="size-4 text-muted-foreground shrink-0" />
          <button
            onClick={() => setDeptFilter("all")}
            className={`px-3 py-1.5 rounded-full text-xs font-medium whitespace-nowrap ${
              deptFilter === "all"
                ? "bg-primary text-primary-foreground"
                : "bg-accent text-muted-foreground hover:text-foreground"
            }`}
          >
            All departments
          </button>
          {DEPARTMENTS.map((d) => (
            <button
              key={d.id}
              onClick={() => setDeptFilter(d.id)}
              className={`px-3 py-1.5 rounded-full text-xs font-medium whitespace-nowrap ${
                deptFilter === d.id
                  ? "bg-primary text-primary-foreground"
                  : "bg-accent text-muted-foreground hover:text-foreground"
              }`}
            >
              {d.name}
            </button>
          ))}
        </div>

        {/* KPI grid */}
        <div className="grid grid-cols-2 lg:grid-cols-5 gap-3">
          <Kpi icon={Zap}       label="Credits used"    value={totals.credits.toLocaleString()} delta={+14.2} tint="#000099" />
          <Kpi icon={Sparkles}  label="AI generations"  value={totals.generations.toLocaleString()} delta={+22.8} tint="#7C3AED" />
          <Kpi icon={Megaphone} label="Campaigns live"  value={totals.campaigns.toString()} delta={+6.1} tint="#F97316" />
          <Kpi icon={TrendingUp}label="Ad spend"        value={`$${(totals.spend / 1000).toFixed(1)}k`} delta={+9.3} tint="#10B981" />
          <Kpi icon={Users}     label="Active members"  value={totals.members.toString()} delta={-2.1} tint="#0EA5E9" />
        </div>

        {/* Charts row */}
        <div className="grid lg:grid-cols-3 gap-4">
          <Panel title="Usage over time" icon={Clock} className="lg:col-span-2">
            <div className="h-64">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={USAGE_TREND}>
                  <defs>
                    <linearGradient id="gCredits" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="0%" stopColor="#000099" stopOpacity={0.35} />
                      <stop offset="100%" stopColor="#000099" stopOpacity={0} />
                    </linearGradient>
                    <linearGradient id="gGen" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="0%" stopColor="#7C3AED" stopOpacity={0.35} />
                      <stop offset="100%" stopColor="#7C3AED" stopOpacity={0} />
                    </linearGradient>
                  </defs>
                  <CartesianGrid stroke="hsl(var(--border))" strokeDasharray="3 3" vertical={false} />
                  <XAxis dataKey="day" fontSize={11} stroke="hsl(var(--muted-foreground))" />
                  <YAxis fontSize={11} stroke="hsl(var(--muted-foreground))" />
                  <Tooltip contentStyle={{ fontSize: 12, borderRadius: 8, border: "1px solid hsl(var(--border))" }} />
                  <Legend wrapperStyle={{ fontSize: 12 }} />
                  <Area type="monotone" dataKey="credits" stroke="#000099" strokeWidth={2} fill="url(#gCredits)" />
                  <Area type="monotone" dataKey="generations" stroke="#7C3AED" strokeWidth={2} fill="url(#gGen)" />
                </AreaChart>
              </ResponsiveContainer>
            </div>
          </Panel>

          <Panel title="Ad channel split" icon={Megaphone}>
            <div className="h-64">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie data={CHANNEL_SPLIT} dataKey="value" nameKey="name" innerRadius={45} outerRadius={80} paddingAngle={2}>
                    {CHANNEL_SPLIT.map((c) => (
                      <Cell key={c.name} fill={c.color} />
                    ))}
                  </Pie>
                  <Tooltip contentStyle={{ fontSize: 12, borderRadius: 8 }} />
                </PieChart>
              </ResponsiveContainer>
            </div>
            <div className="flex flex-col gap-1.5 mt-2">
              {CHANNEL_SPLIT.map((c) => (
                <div key={c.name} className="flex items-center gap-2 text-xs">
                  <span className="size-2.5 rounded-sm" style={{ background: c.color }} />
                  <span className="flex-1">{c.name}</span>
                  <span className="text-muted-foreground tabular-nums">{c.value}%</span>
                </div>
              ))}
            </div>
          </Panel>
        </div>

        {/* Dept breakdown */}
        <Panel title="Departments" icon={Building2} desc="Credits, generations, campaigns, and ROAS per team.">
          <div className="h-56 mb-4">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={DEPARTMENTS} margin={{ left: -10 }}>
                <CartesianGrid stroke="hsl(var(--border))" strokeDasharray="3 3" vertical={false} />
                <XAxis
                  dataKey="name"
                  fontSize={10}
                  stroke="hsl(var(--muted-foreground))"
                  tickFormatter={(v: string) => v.split(" ")[0]}
                />
                <YAxis fontSize={11} stroke="hsl(var(--muted-foreground))" />
                <Tooltip contentStyle={{ fontSize: 12, borderRadius: 8 }} />
                <Bar dataKey="credits" fill="#000099" radius={[6, 6, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="text-left text-xs uppercase tracking-wider text-muted-foreground border-b border-border">
                  <th className="py-2 pr-4 font-medium">Department</th>
                  <th className="py-2 pr-4 font-medium">Members</th>
                  <th className="py-2 pr-4 font-medium">Credits</th>
                  <th className="py-2 pr-4 font-medium">Generations</th>
                  <th className="py-2 pr-4 font-medium">Campaigns</th>
                  <th className="py-2 pr-4 font-medium">Spend</th>
                  <th className="py-2 pr-4 font-medium">CTR</th>
                  <th className="py-2 pr-4 font-medium">ROAS</th>
                  <th className="py-2 pr-4 font-medium">Trend</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-border">
                {DEPARTMENTS.map((d) => (
                  <tr key={d.id} className="hover:bg-accent/40">
                    <td className="py-3 pr-4 font-medium">{d.name}</td>
                    <td className="py-3 pr-4 tabular-nums text-muted-foreground">{d.members}</td>
                    <td className="py-3 pr-4">
                      <div className="flex items-center gap-2">
                        <span className="tabular-nums w-12">{d.credits.toLocaleString()}</span>
                        <div className="flex-1 min-w-[80px] h-1.5 rounded-full bg-accent overflow-hidden">
                          <div
                            className="h-full bg-primary"
                            style={{ width: `${(d.credits / maxCredits) * 100}%` }}
                          />
                        </div>
                      </div>
                    </td>
                    <td className="py-3 pr-4 tabular-nums">{d.generations.toLocaleString()}</td>
                    <td className="py-3 pr-4 tabular-nums">{d.campaigns}</td>
                    <td className="py-3 pr-4 tabular-nums">${(d.spend / 1000).toFixed(1)}k</td>
                    <td className="py-3 pr-4 tabular-nums">{d.ctr}%</td>
                    <td className="py-3 pr-4 tabular-nums font-medium">{d.roas}x</td>
                    <td className="py-3 pr-4">
                      <span
                        className={`inline-flex items-center gap-0.5 text-xs font-medium ${
                          d.trend >= 0 ? "text-emerald-600" : "text-rose-600"
                        }`}
                      >
                        {d.trend >= 0 ? <ArrowUpRight className="size-3" /> : <ArrowDownRight className="size-3" />}
                        {Math.abs(d.trend)}%
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </Panel>

        {/* Bottom row */}
        <div className="grid lg:grid-cols-2 gap-4">
          <Panel title="Top users this cycle" icon={Wand2}>
            <div className="flex flex-col divide-y divide-border">
              {TOP_USERS.map((u, i) => (
                <div key={u.name} className="flex items-center gap-3 py-2.5 first:pt-0 last:pb-0">
                  <div className="size-8 rounded-full bg-gradient-to-br from-primary to-[var(--accent-ai)] text-white grid place-items-center text-xs font-bold">
                    {u.name.split(" ").map((n) => n[0]).join("")}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="text-sm font-medium truncate">{u.name}</div>
                    <div className="text-xs text-muted-foreground truncate">{u.dept}</div>
                  </div>
                  <div className="text-right">
                    <div className="text-sm font-display font-bold tabular-nums">{u.credits}</div>
                    <div className="text-[11px] text-muted-foreground">{u.generations} gens</div>
                  </div>
                  {i === 0 && <Crown className="size-4 text-amber-500 shrink-0" />}
                </div>
              ))}
            </div>
          </Panel>

          <Panel title="Governance alerts" icon={AlertTriangle} desc="Things a superadmin should review.">
            <div className="flex flex-col gap-2">
              {ALERTS.map((a, i) => {
                const color =
                  a.level === "high" ? "rose" : a.level === "medium" ? "amber" : "sky";
                return (
                  <div
                    key={i}
                    className={`flex items-start gap-3 rounded-xl border p-3 ${
                      color === "rose"
                        ? "border-rose-200 bg-rose-50 text-rose-900 dark:border-rose-900/40 dark:bg-rose-950/30 dark:text-rose-200"
                        : color === "amber"
                        ? "border-amber-200 bg-amber-50 text-amber-900 dark:border-amber-900/40 dark:bg-amber-950/30 dark:text-amber-200"
                        : "border-sky-200 bg-sky-50 text-sky-900 dark:border-sky-900/40 dark:bg-sky-950/30 dark:text-sky-200"
                    }`}
                  >
                    <AlertTriangle className="size-4 mt-0.5 shrink-0" />
                    <div className="text-sm">{a.msg}</div>
                  </div>
                );
              })}
            </div>
          </Panel>
        </div>

        <div className="flex items-center gap-2 text-xs text-muted-foreground pt-2">
          <ImageIcon className="size-3.5" />
          Data shown is mock analytics for UI preview. Wire to API when backend is connected.
        </div>
      </div>
    </AppShell>
  );
}

function Kpi({
  icon: Icon,
  label,
  value,
  delta,
  tint,
}: {
  icon: typeof Zap;
  label: string;
  value: string;
  delta: number;
  tint: string;
}) {
  const positive = delta >= 0;
  return (
    <div className="rounded-xl border border-border bg-surface p-4">
      <div className="flex items-center gap-2 text-xs text-muted-foreground">
        <span className="size-6 rounded-md grid place-items-center text-white" style={{ background: tint }}>
          <Icon className="size-3.5" />
        </span>
        {label}
      </div>
      <div className="text-2xl font-display font-bold tracking-tight mt-2">{value}</div>
      <div
        className={`text-[11px] font-medium mt-1 inline-flex items-center gap-0.5 ${
          positive ? "text-emerald-600" : "text-rose-600"
        }`}
      >
        {positive ? <ArrowUpRight className="size-3" /> : <ArrowDownRight className="size-3" />}
        {Math.abs(delta)}% vs prev
      </div>
    </div>
  );
}

function Panel({
  title,
  desc,
  icon: Icon,
  className = "",
  children,
}: {
  title: string;
  desc?: string;
  icon: typeof Zap;
  className?: string;
  children: React.ReactNode;
}) {
  return (
    <section className={`rounded-2xl border border-border bg-surface p-5 ${className}`}>
      <div className="flex items-center gap-2 mb-4">
        <Icon className="size-4 text-muted-foreground" />
        <h2 className="text-sm font-display font-bold uppercase tracking-tight">{title}</h2>
        {desc && <span className="text-xs text-muted-foreground hidden md:inline">· {desc}</span>}
      </div>
      {children}
    </section>
  );
}
