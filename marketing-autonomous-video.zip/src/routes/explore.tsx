import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import {
  Bookmark,
  Compass,
  Download,
  Heart,
  Loader2,
  MoreHorizontal,
  Plus,
  Repeat,
  Search,
  Sparkles,
  X,
} from "lucide-react";
import { AppShell } from "@/components/AppShell";
import {
  getCreatives,
  type Creative,
  type CreativeScope,
} from "@/mocks/creatives";

export const Route = createFileRoute("/explore")({
  component: ExplorePage,
  head: () => ({
    meta: [
      { title: "Explore — Loom" },
      {
        name: "description",
        content:
          "Browse creatives from other teams and your organization's history. Remix any of them in Studio.",
      },
      { property: "og:title", content: "Explore — Loom" },
      {
        property: "og:description",
        content: "A Pinterest-style feed of AI creatives from the Loom community and your team.",
      },
    ],
  }),
});

const COMMUNITY_FILTERS = [
  "All",
  "Product",
  "Poster",
  "Photoreal",
  "Illustration",
  "3D",
  "Cinematic",
];
const ORG_FILTERS = ["All", "Studio", "Campaign", "Draft", "By me", "By team"];

const COMMUNITY_SORTS = ["Trending", "Newest", "Most remixed"];
const ORG_SORTS = ["Newest", "Oldest", "Most used in campaigns"];

function img(seed: number, w: number, h: number) {
  return `https://picsum.photos/seed/${seed}/${w}/${h}`;
}

function ExplorePage() {
  const navigate = useNavigate();
  const [scope, setScope] = useState<CreativeScope>("community");
  const [filter, setFilter] = useState("All");
  const [sort, setSort] = useState("Trending");
  const [search, setSearch] = useState("");
  const [items, setItems] = useState<Creative[]>([]);
  const [cursor, setCursor] = useState<number | null>(0);
  const [loading, setLoading] = useState(false);
  const [active, setActive] = useState<Creative | null>(null);
  const [saved, setSaved] = useState<Record<string, boolean>>({});
  const sentinelRef = useRef<HTMLDivElement>(null);

  const filters = scope === "community" ? COMMUNITY_FILTERS : ORG_FILTERS;
  const sorts = scope === "community" ? COMMUNITY_SORTS : ORG_SORTS;

  // Reset when scope / filter / sort / search changes
  useEffect(() => {
    setItems([]);
    setCursor(0);
  }, [scope, filter, sort, search]);

  useEffect(() => {
    if (!sorts.includes(sort)) setSort(sorts[0]);
    if (!filters.includes(filter)) setFilter("All");
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [scope]);

  const loadMore = useCallback(async () => {
    if (cursor === null || loading) return;
    setLoading(true);
    const res = await getCreatives({
      scope,
      filter,
      sort,
      cursor,
      search,
    });
    setItems((prev) => (cursor === 0 ? res.items : [...prev, ...res.items]));
    setCursor(res.nextCursor);
    setLoading(false);
  }, [cursor, loading, scope, filter, sort, search]);

  useEffect(() => {
    if (cursor === 0) loadMore();
  }, [cursor, loadMore]);

  useEffect(() => {
    const el = sentinelRef.current;
    if (!el) return;
    const io = new IntersectionObserver(
      (entries) => {
        if (entries[0].isIntersecting) loadMore();
      },
      { rootMargin: "600px 0px" },
    );
    io.observe(el);
    return () => io.disconnect();
  }, [loadMore]);

  function remix(c: Creative) {
    try {
      sessionStorage.setItem(
        "loom.studio.remix",
        JSON.stringify({ prompt: c.prompt, style: c.style, ratio: c.ratio }),
      );
    } catch {}
    navigate({ to: "/studio" });
  }

  const orgCount = useMemo(
    () => (scope === "org" ? items.length : null),
    [items, scope],
  );

  return (
    <AppShell>
      <div className="max-w-[1400px] mx-auto px-4 sm:px-6 py-6">
        {/* Header */}
        <div className="grid grid-cols-[minmax(0,1fr)_auto] items-start gap-4 sm:flex sm:flex-wrap sm:items-center sm:justify-between mb-6">
          <div className="flex min-w-0 items-center gap-3">
            <div className="size-10 shrink-0 rounded-xl bg-primary/10 grid place-items-center">
              <Compass className="size-5 text-primary" />
            </div>
            <div className="min-w-0">
              <h1 className="text-2xl font-display font-bold tracking-tight truncate">
                Explore
              </h1>
              <p className="text-sm text-muted-foreground">
                Discover what other teams ship and remix your own.
              </p>
            </div>
          </div>
          <button
            onClick={() => navigate({ to: "/studio" })}
            className="inline-flex items-center gap-2 px-4 py-2 rounded-xl bg-primary text-primary-foreground text-sm font-medium hover:opacity-90 shrink-0"
          >
            <Plus className="size-4" />
            New in Studio
          </button>
        </div>

        {/* Sticky sub-header */}
        <div className="sticky top-14 z-20 -mx-4 sm:-mx-6 px-4 sm:px-6 py-3 bg-background/85 backdrop-blur border-b border-border">
          <div className="flex items-center gap-3 flex-wrap">
            {/* Scope toggle */}
            <div className="flex items-center gap-1 bg-accent/60 rounded-xl p-1">
              {(
                [
                  { id: "community", label: "Community" },
                  { id: "org", label: "Your organization" },
                ] as { id: CreativeScope; label: string }[]
              ).map((s) => (
                <button
                  key={s.id}
                  onClick={() => setScope(s.id)}
                  className={`px-3 py-1.5 text-xs rounded-lg transition-colors whitespace-nowrap ${
                    scope === s.id
                      ? "bg-surface text-foreground font-medium shadow-sm"
                      : "text-muted-foreground hover:text-foreground"
                  }`}
                >
                  {s.label}
                </button>
              ))}
            </div>

            {/* Search */}
            <div className="relative flex-1 min-w-[180px] max-w-sm">
              <Search className="size-4 text-muted-foreground absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                placeholder="Search prompts, tags…"
                className="w-full pl-9 pr-3 py-1.5 rounded-xl border border-border bg-surface text-sm outline-none focus:border-primary/60"
              />
            </div>

            {/* Sort */}
            <select
              value={sort}
              onChange={(e) => setSort(e.target.value)}
              className="text-xs rounded-xl border border-border bg-surface px-2.5 py-1.5 outline-none focus:border-primary/60"
            >
              {sorts.map((s) => (
                <option key={s} value={s}>
                  Sort: {s}
                </option>
              ))}
            </select>
          </div>

          {/* Filter chips */}
          <div className="mt-3 flex items-center gap-1.5 overflow-x-auto pb-1 -mb-1 scrollbar-thin">
            {filters.map((f) => (
              <button
                key={f}
                onClick={() => setFilter(f)}
                className={`shrink-0 px-3 py-1 rounded-full text-xs border transition-colors ${
                  filter === f
                    ? "bg-foreground text-background border-foreground"
                    : "bg-surface border-border text-muted-foreground hover:text-foreground"
                }`}
              >
                {f}
              </button>
            ))}
            {scope === "org" && orgCount !== null && (
              <span className="ml-auto shrink-0 text-[11px] text-muted-foreground">
                {orgCount} loaded
              </span>
            )}
          </div>
        </div>

        {/* Masonry */}
        <div className="mt-5">
          {items.length === 0 && !loading ? (
            <EmptyState scope={scope} onNew={() => navigate({ to: "/studio" })} />
          ) : (
            <div className="columns-2 sm:columns-3 lg:columns-4 xl:columns-5 gap-3 [column-fill:_balance]">
              {items.map((c) => (
                <CreativeCard
                  key={c.id}
                  c={c}
                  saved={!!saved[c.id]}
                  onSave={() => setSaved((s) => ({ ...s, [c.id]: !s[c.id] }))}
                  onOpen={() => setActive(c)}
                  onRemix={() => remix(c)}
                />
              ))}
              {loading &&
                Array.from({ length: 6 }).map((_, i) => (
                  <div
                    key={`sk-${i}`}
                    className="mb-3 break-inside-avoid rounded-xl bg-accent animate-pulse"
                    style={{ height: 160 + ((i * 47) % 220) }}
                  />
                ))}
            </div>
          )}
          <div ref={sentinelRef} className="h-10" />
          {cursor === null && items.length > 0 && (
            <div className="text-center text-xs text-muted-foreground py-8">
              You've reached the end · {items.length} creatives
            </div>
          )}
        </div>
      </div>

      {/* Detail drawer */}
      {active && (
        <DetailDrawer
          creative={active}
          onClose={() => setActive(null)}
          onRemix={() => {
            remix(active);
            setActive(null);
          }}
          saved={!!saved[active.id]}
          onSave={() =>
            setSaved((s) => ({ ...s, [active.id]: !s[active.id] }))
          }
        />
      )}
    </AppShell>
  );
}

function CreativeCard({
  c,
  saved,
  onSave,
  onOpen,
  onRemix,
}: {
  c: Creative;
  saved: boolean;
  onSave: () => void;
  onOpen: () => void;
  onRemix: () => void;
}) {
  return (
    <div className="mb-3 break-inside-avoid group relative rounded-xl overflow-hidden border border-border bg-surface">
      <button
        onClick={onOpen}
        className="block w-full text-left"
        style={{ aspectRatio: `${c.width} / ${c.height}` }}
      >
        <img
          src={img(c.seed, c.width, c.height)}
          alt={c.prompt}
          loading="lazy"
          className="w-full h-full object-cover"
        />
      </button>

      {/* Top-right actions */}
      <div className="absolute top-2 right-2 flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
        <button
          onClick={(e) => {
            e.stopPropagation();
            onSave();
          }}
          className={`size-7 grid place-items-center rounded-full backdrop-blur border transition-colors ${
            saved
              ? "bg-primary text-primary-foreground border-primary"
              : "bg-black/50 text-white border-transparent hover:bg-black/70"
          }`}
          aria-label="Save"
        >
          <Bookmark className={`size-3.5 ${saved ? "fill-current" : ""}`} />
        </button>
        <button
          onClick={(e) => e.stopPropagation()}
          className="size-7 grid place-items-center rounded-full bg-black/50 text-white backdrop-blur hover:bg-black/70"
          aria-label="More"
        >
          <MoreHorizontal className="size-3.5" />
        </button>
      </div>

      {/* Bottom overlay */}
      <div className="pointer-events-none absolute inset-x-0 bottom-0 p-2.5 bg-gradient-to-t from-black/85 via-black/40 to-transparent opacity-0 group-hover:opacity-100 transition-opacity">
        <div className="flex items-end justify-between gap-2 pointer-events-auto">
          <div className="min-w-0 flex items-center gap-2">
            <div
              className="size-6 shrink-0 rounded-full grid place-items-center text-[10px] font-bold text-white"
              style={{ background: c.author.color }}
            >
              {c.author.initials}
            </div>
            <div className="min-w-0">
              <div className="text-[11px] font-medium text-white truncate">
                {c.author.name}
              </div>
              <div className="text-[10px] text-white/70 truncate">
                {c.scope === "org" ? c.origin : c.author.org}
              </div>
            </div>
          </div>
          <button
            onClick={(e) => {
              e.stopPropagation();
              onRemix();
            }}
            className="shrink-0 inline-flex items-center gap-1 rounded-lg bg-primary text-primary-foreground px-2 py-1 text-[11px] font-medium hover:opacity-90"
          >
            <Repeat className="size-3" />
            Remix
          </button>
        </div>
      </div>

      {/* Badges (always visible, subtle) */}
      <div className="absolute top-2 left-2 flex items-center gap-1">
        <span className="text-[10px] px-1.5 py-0.5 rounded-full bg-black/55 text-white backdrop-blur">
          {c.ratio}
        </span>
        {c.scope === "org" && c.origin === "Campaign" && (
          <span className="text-[10px] px-1.5 py-0.5 rounded-full bg-primary text-primary-foreground">
            Campaign
          </span>
        )}
      </div>
    </div>
  );
}

function DetailDrawer({
  creative: c,
  onClose,
  onRemix,
  saved,
  onSave,
}: {
  creative: Creative;
  onClose: () => void;
  onRemix: () => void;
  saved: boolean;
  onSave: () => void;
}) {
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => e.key === "Escape" && onClose();
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [onClose]);

  return (
    <div className="fixed inset-0 z-50 flex">
      <button
        aria-label="Close"
        onClick={onClose}
        className="flex-1 bg-background/70 backdrop-blur-sm"
      />
      <aside className="w-full max-w-md h-full bg-surface border-l border-border overflow-y-auto flex flex-col">
        <div className="flex items-center justify-between px-5 py-3 border-b border-border sticky top-0 bg-surface z-10">
          <div className="flex items-center gap-2">
            <Sparkles className="size-4 text-[var(--accent-ai)]" />
            <div className="text-xs font-medium uppercase tracking-wider text-muted-foreground">
              Creative
            </div>
          </div>
          <button
            onClick={onClose}
            className="size-8 grid place-items-center rounded-lg hover:bg-accent text-muted-foreground"
          >
            <X className="size-4" />
          </button>
        </div>

        <div className="p-5 flex flex-col gap-4">
          <div
            className="rounded-xl overflow-hidden bg-accent border border-border"
            style={{ aspectRatio: `${c.width} / ${c.height}` }}
          >
            <img
              src={img(c.seed, c.width * 2, c.height * 2)}
              alt={c.prompt}
              className="w-full h-full object-cover"
            />
          </div>

          <div className="flex items-center gap-2 flex-wrap">
            <span className="text-[10px] px-2 py-0.5 rounded-full bg-accent">
              {c.style}
            </span>
            <span className="text-[10px] px-2 py-0.5 rounded-full bg-accent">
              {c.ratio}
            </span>
            <span className="text-[10px] px-2 py-0.5 rounded-full bg-accent">
              {c.model}
            </span>
            {c.origin && (
              <span className="text-[10px] px-2 py-0.5 rounded-full bg-primary/10 text-primary">
                {c.origin}
              </span>
            )}
          </div>

          <div>
            <div className="text-[11px] uppercase tracking-wider text-muted-foreground mb-1">
              Prompt
            </div>
            <p className="text-sm leading-relaxed">{c.prompt}</p>
          </div>

          <div className="flex items-center gap-3 pt-2 border-t border-border">
            <div
              className="size-9 rounded-full grid place-items-center text-xs font-bold text-white"
              style={{ background: c.author.color }}
            >
              {c.author.initials}
            </div>
            <div className="flex-1 min-w-0">
              <div className="text-sm font-medium truncate">{c.author.name}</div>
              <div className="text-xs text-muted-foreground truncate">
                {c.author.org} · {c.savedAt}
              </div>
            </div>
            <div className="flex items-center gap-3 text-xs text-muted-foreground">
              <span className="inline-flex items-center gap-1">
                <Heart className="size-3.5" /> {c.likes}
              </span>
              <span className="inline-flex items-center gap-1">
                <Repeat className="size-3.5" /> {c.remixes}
              </span>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-2 mt-2">
            <button
              onClick={onRemix}
              className="col-span-2 inline-flex items-center justify-center gap-1.5 rounded-xl bg-primary text-primary-foreground px-4 py-2.5 text-sm font-medium hover:opacity-90"
            >
              <Repeat className="size-4" />
              Remix in Studio
            </button>
            <button
              onClick={onSave}
              className={`inline-flex items-center justify-center gap-1.5 rounded-xl border px-3 py-2 text-sm ${
                saved ? "border-primary text-primary" : "border-border hover:bg-accent"
              }`}
            >
              <Bookmark className={`size-4 ${saved ? "fill-current" : ""}`} />
              {saved ? "Saved" : "Save"}
            </button>
            <button className="inline-flex items-center justify-center gap-1.5 rounded-xl border border-border px-3 py-2 text-sm hover:bg-accent">
              <Download className="size-4" />
              Download
            </button>
          </div>
        </div>
      </aside>
    </div>
  );
}

function EmptyState({
  scope,
  onNew,
}: {
  scope: CreativeScope;
  onNew: () => void;
}) {
  return (
    <div className="rounded-2xl border border-dashed border-border p-12 grid place-items-center text-center gap-2">
      <Loader2 className="size-5 text-muted-foreground animate-spin" />
      <div className="font-medium text-foreground mt-1">
        {scope === "community" ? "Nothing here yet" : "No creatives in your workspace"}
      </div>
      <div className="text-sm text-muted-foreground">
        {scope === "community"
          ? "Be the first to publish from Studio."
          : "Generate your first image to see it here."}
      </div>
      <button
        onClick={onNew}
        className="mt-2 inline-flex items-center gap-2 px-4 py-2 rounded-xl bg-primary text-primary-foreground text-sm font-medium hover:opacity-90"
      >
        <Plus className="size-4" />
        Open Studio
      </button>
    </div>
  );
}
