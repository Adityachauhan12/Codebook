import { createFileRoute, Link } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { Megaphone, Plus, Search } from "lucide-react";
import { AppShell } from "@/components/AppShell";
import { MOCK_CAMPAIGNS, type CampaignStatus } from "@/mocks/campaigns";

export const Route = createFileRoute("/campaigns/")({
  component: CampaignsListPage,
  head: () => ({
    meta: [
      { title: "Campaigns — Loom" },
      { name: "description", content: "Your marketing campaigns across Google and Meta." },
    ],
  }),
});

const FILTERS: (CampaignStatus | "All")[] = ["All", "Live", "Draft", "Paused", "Ended"];

const STATUS_STYLE: Record<CampaignStatus, string> = {
  Live: "bg-emerald-500/10 text-emerald-600",
  Draft: "bg-muted text-muted-foreground",
  Paused: "bg-amber-500/10 text-amber-600",
  Ended: "bg-rose-500/10 text-rose-600",
};

function CampaignsListPage() {
  const [filter, setFilter] = useState<(typeof FILTERS)[number]>("All");
  const [q, setQ] = useState("");

  const rows = useMemo(() => {
    return MOCK_CAMPAIGNS.filter(
      (c) =>
        (filter === "All" || c.status === filter) &&
        (q.trim() === "" || c.name.toLowerCase().includes(q.toLowerCase())),
    );
  }, [filter, q]);

  return (
    <AppShell>
      <div className="px-6 py-8 max-w-6xl mx-auto">
        <div className="flex items-center justify-between mb-6 gap-4 flex-wrap">
          <div className="flex items-center gap-3">
            <div className="size-10 rounded-xl bg-primary/10 grid place-items-center">
              <Megaphone className="size-5 text-primary" />
            </div>
            <div>
              <h1 className="text-2xl font-display font-bold tracking-tight">Campaigns</h1>
              <p className="text-sm text-muted-foreground">
                {MOCK_CAMPAIGNS.length} total · {MOCK_CAMPAIGNS.filter((c) => c.status === "Live").length} live
              </p>
            </div>
          </div>
          <Link
            to="/campaigns/new"
            className="inline-flex items-center gap-2 px-4 py-2 rounded-xl bg-primary text-primary-foreground text-sm font-medium hover:opacity-90"
          >
            <Plus className="size-4" />
            New campaign
          </Link>
        </div>

        <div className="flex items-center gap-3 mb-4 flex-wrap">
          <div className="flex items-center gap-1 bg-accent/60 rounded-xl p-1">
            {FILTERS.map((f) => (
              <button
                key={f}
                onClick={() => setFilter(f)}
                className={`px-3 py-1.5 text-xs rounded-lg transition-colors ${
                  filter === f
                    ? "bg-surface text-foreground font-medium shadow-sm"
                    : "text-muted-foreground hover:text-foreground"
                }`}
              >
                {f}
              </button>
            ))}
          </div>
          <div className="relative flex-1 min-w-[220px] max-w-sm">
            <Search className="size-4 text-muted-foreground absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              value={q}
              onChange={(e) => setQ(e.target.value)}
              placeholder="Search campaigns…"
              className="w-full pl-9 pr-3 py-2 rounded-xl border border-border bg-surface text-sm outline-none focus:border-primary/60"
            />
          </div>
        </div>

        {rows.length === 0 ? (
          <div className="rounded-2xl border border-dashed border-border p-12 grid place-items-center text-center text-muted-foreground">
            <div className="font-medium text-foreground">No campaigns match</div>
            <div className="text-sm">Try a different filter or search term.</div>
          </div>
        ) : (
          <div className="rounded-2xl border border-border bg-surface overflow-hidden">
            <table className="w-full text-sm">
              <thead className="bg-accent/40 text-xs text-muted-foreground uppercase tracking-wider">
                <tr>
                  <th className="text-left px-5 py-3 font-medium">Campaign</th>
                  <th className="text-left px-5 py-3 font-medium">Status</th>
                  <th className="text-left px-5 py-3 font-medium">Objective</th>
                  <th className="text-left px-5 py-3 font-medium">Channels</th>
                  <th className="text-right px-5 py-3 font-medium">Budget</th>
                  <th className="text-right px-5 py-3 font-medium">ROAS</th>
                  <th className="text-right px-5 py-3 font-medium">CTR</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-border">
                {rows.map((c) => {
                  const pct = c.budget ? Math.round((c.spent / c.budget) * 100) : 0;
                  return (
                    <tr key={c.id} className="hover:bg-accent/30 transition-colors">
                      <td className="px-5 py-3">
                        <Link
                          to="/campaigns/$id"
                          params={{ id: c.id }}
                          className="font-medium hover:text-primary"
                        >
                          {c.name}
                        </Link>
                        <div className="text-[11px] text-muted-foreground mt-0.5">
                          Started {c.startedAt}
                        </div>
                      </td>
                      <td className="px-5 py-3">
                        <span
                          className={`inline-flex items-center gap-1.5 text-[11px] font-medium px-2 py-0.5 rounded-full ${STATUS_STYLE[c.status]}`}
                        >
                          <span className="size-1.5 rounded-full bg-current" />
                          {c.status}
                        </span>
                      </td>
                      <td className="px-5 py-3 text-muted-foreground">{c.objective}</td>
                      <td className="px-5 py-3">
                        <div className="flex flex-wrap gap-1">
                          {c.channels.slice(0, 2).map((ch) => (
                            <span
                              key={ch}
                              className="text-[10px] px-1.5 py-0.5 rounded bg-accent text-muted-foreground"
                            >
                              {ch}
                            </span>
                          ))}
                          {c.channels.length > 2 && (
                            <span className="text-[10px] text-muted-foreground">
                              +{c.channels.length - 2}
                            </span>
                          )}
                        </div>
                      </td>
                      <td className="px-5 py-3 text-right">
                        <div className="tabular-nums">
                          ${c.spent.toLocaleString()}
                          <span className="text-muted-foreground">
                            {" "}
                            / ${c.budget.toLocaleString()}
                          </span>
                        </div>
                        <div className="mt-1 h-1 rounded-full bg-accent overflow-hidden">
                          <div
                            className="h-full bg-primary"
                            style={{ width: `${pct}%` }}
                          />
                        </div>
                      </td>
                      <td className="px-5 py-3 text-right font-medium tabular-nums">{c.roas}</td>
                      <td className="px-5 py-3 text-right tabular-nums text-muted-foreground">
                        {c.ctr}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </AppShell>
  );
}
