import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import {
  ArrowLeft,
  Calendar,
  Check,
  ChevronRight,
  RefreshCw,
  Repeat,
  Save,
  Sparkles,
  Target,
  TrendingUp,
  Users,
  X,
  AlertTriangle,
} from "lucide-react";
import {
  Cell,
  Pie,
  PieChart,
  ResponsiveContainer,
  Tooltip,
} from "recharts";
import { AppShell } from "@/components/AppShell";

export const Route = createFileRoute("/campaigns/plan")({
  component: PlanPage,
  head: () => ({
    meta: [
      { title: "Campaign plan — Loom" },
      { name: "description", content: "Auto-generated KPI, channel, and creative plan." },
    ],
  }),
});

type Brief = {
  objective?: string;
  budget?: string;
  duration?: string;
  audience?: string;
  channels?: string[];
  assets?: string;
};

type KPI = { label: string; value: string; hint: string };
type ChannelSlice = { name: string; pct: number; color: string };
type Audience = {
  channel: string;
  age: string;
  geo: string;
  interests: string[];
};
type Creative = {
  id: string;
  headline: string;
  copy: string;
  seed: number;
};

const CHANNEL_COLORS: Record<string, string> = {
  "Google Search": "#4285F4",
  "Google PMax": "#34A853",
  "Meta Feed": "#1877F2",
  "Meta Reels": "#E4405F",
  "Meta Stories": "#FB8C00",
  TikTok: "#000000",
  LinkedIn: "#0A66C2",
  YouTube: "#FF0000",
};

function defaultChannels(brief: Brief): ChannelSlice[] {
  const chosen = brief.channels?.length
    ? brief.channels
    : ["Google Search", "Google PMax", "Meta Feed", "Meta Reels"];
  const base = 100 / chosen.length;
  return chosen.map((name, i) => ({
    name,
    pct: Math.round(base + (i === 0 ? 5 : i === chosen.length - 1 ? -5 : 0)),
    color: CHANNEL_COLORS[name] ?? "#000099",
  }));
}

function seedCreatives(objective?: string): Creative[] {
  const verbs =
    objective === "Leads"
      ? ["Book a demo", "Get a quote", "Talk to sales"]
      : objective === "App installs"
      ? ["Download now", "Get the app", "Try it free"]
      : objective === "Awareness"
      ? ["Meet the new", "Introducing", "Say hello to"]
      : ["Shop the drop", "Save 20% today", "Limited-time offer"];
  return verbs.map((v, i) => ({
    id: `c${i}`,
    headline: v,
    copy:
      "Crafted for your audience — punchy hook, clear value, and a call-to-action that converts.",
    seed: 1000 + i * 7,
  }));
}

function PlanPage() {
  const navigate = useNavigate();
  const [brief, setBrief] = useState<Brief>({});
  const [launching, setLaunching] = useState(false);
  const [launchStep, setLaunchStep] = useState(0);

  const launchSteps = [
    "Creating Google Ads campaign…",
    "Uploading assets to Meta…",
    "Setting audiences…",
    "Verifying tracking…",
    "Going live",
  ];

  useEffect(() => {
    if (!launching) return;
    setLaunchStep(0);
    const timers: ReturnType<typeof setTimeout>[] = [];
    launchSteps.forEach((_, i) => {
      timers.push(setTimeout(() => setLaunchStep(i + 1), (i + 1) * 700));
    });
    timers.push(
      setTimeout(() => {
        navigate({ to: "/campaigns/$id", params: { id: "live-1" } });
      }, (launchSteps.length + 1) * 700),
    );
    return () => timers.forEach(clearTimeout);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [launching]);

  useEffect(() => {
    try {
      const raw = sessionStorage.getItem("loom.brief");
      if (raw) setBrief(JSON.parse(raw));
    } catch {}
  }, []);

  const [kpis, setKpis] = useState<KPI[]>([
    { label: "ROAS", value: "3.2x", hint: "Return on ad spend" },
    { label: "CPA", value: "$18", hint: "Cost per acquisition" },
    { label: "CTR", value: "2.4%", hint: "Click-through rate" },
    { label: "Impressions", value: "1.2M", hint: "Reach goal" },
  ]);

  const [channels, setChannels] = useState<ChannelSlice[]>(() => defaultChannels(brief));
  useEffect(() => {
    setChannels(defaultChannels(brief));
  }, [brief]);

  const [audiences, setAudiences] = useState<Audience[]>([]);
  useEffect(() => {
    setAudiences(
      (brief.channels?.length
        ? brief.channels
        : ["Google Search", "Meta Feed"]
      ).map((c) => ({
        channel: c,
        age: "18–34",
        geo: brief.audience ?? "United States",
        interests: ["shopping", "lifestyle", "deals", "new arrivals"],
      })),
    );
  }, [brief]);

  const [creatives, setCreatives] = useState<Creative[]>(seedCreatives(brief.objective));
  useEffect(() => {
    setCreatives(seedCreatives(brief.objective));
  }, [brief.objective]);

  const [pacing, setPacing] = useState<"Even" | "Accelerated">("Even");
  const [startDate, setStartDate] = useState(new Date().toISOString().slice(0, 10));
  const endDate = useMemo(() => {
    const d = new Date(startDate);
    d.setDate(d.getDate() + 30);
    return d.toISOString().slice(0, 10);
  }, [startDate]);

  function updateChannel(idx: number, next: number) {
    setChannels((prev) => {
      const clamped = Math.max(0, Math.min(100, next));
      const others = prev.filter((_, i) => i !== idx);
      const otherSum = others.reduce((s, c) => s + c.pct, 0);
      const remaining = 100 - clamped;
      const scale = otherSum === 0 ? 0 : remaining / otherSum;
      return prev.map((c, i) =>
        i === idx ? { ...c, pct: clamped } : { ...c, pct: Math.round(c.pct * scale) },
      );
    });
  }

  function updateKpi(idx: number, value: string) {
    setKpis((prev) => prev.map((k, i) => (i === idx ? { ...k, value } : k)));
  }

  function removeInterest(aIdx: number, tag: string) {
    setAudiences((prev) =>
      prev.map((a, i) =>
        i === aIdx ? { ...a, interests: a.interests.filter((t) => t !== tag) } : a,
      ),
    );
  }

  function regenerate(cid: string) {
    setCreatives((prev) =>
      prev.map((c) => (c.id === cid ? { ...c, seed: c.seed + Math.floor(Math.random() * 100) } : c)),
    );
  }

  return (
    <AppShell>
      <div className="min-h-[calc(100vh-3.5rem)] pb-24">
        {/* Header */}
        <div className="sticky top-14 z-20 bg-background/90 backdrop-blur border-b border-border">
          <div className="max-w-5xl mx-auto px-6 py-4 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Link
                to="/campaigns/new"
                className="size-8 grid place-items-center rounded-lg hover:bg-accent text-muted-foreground"
              >
                <ArrowLeft className="size-4" />
              </Link>
              <div>
                <div className="text-xs text-muted-foreground">Step 2 of 3 · Plan</div>
                <h1 className="text-lg font-display font-bold tracking-tight">
                  {brief.objective ?? "New campaign"} plan
                </h1>
              </div>
            </div>
            <div className="hidden sm:flex items-center gap-1.5 text-xs px-2.5 py-1 rounded-full bg-accent">
              <Sparkles className="size-3 text-[var(--accent-ai)]" />
              <span className="font-medium">Auto-drafted</span>
            </div>
          </div>
        </div>

        <div className="max-w-5xl mx-auto px-6 py-8 flex flex-col gap-8">
          {/* Brief recap */}
          <section className="rounded-2xl border border-border bg-surface/60 p-5">
            <div className="text-xs font-medium uppercase tracking-wider text-muted-foreground mb-3">
              From your brief
            </div>
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-x-6 gap-y-3 text-sm">
              <Recap label="Objective" value={brief.objective} />
              <Recap label="Budget" value={brief.budget} />
              <Recap label="Duration" value={brief.duration} />
              <Recap label="Audience" value={brief.audience} />
              <Recap label="Channels" value={brief.channels?.join(" · ")} />
              <Recap label="Assets" value={brief.assets} />
            </div>
          </section>

          {/* KPIs */}
          <Section icon={Target} title="KPIs & targets" hint="Edit inline">
            <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
              {kpis.map((k, i) => (
                <div key={k.label} className="rounded-xl border border-border bg-surface p-4">
                  <div className="text-xs text-muted-foreground mb-1">{k.label}</div>
                  <input
                    value={k.value}
                    onChange={(e) => updateKpi(i, e.target.value)}
                    className="w-full bg-transparent text-2xl font-display font-bold tracking-tight outline-none focus:text-primary"
                  />
                  <div className="text-[11px] text-muted-foreground mt-1">{k.hint}</div>
                </div>
              ))}
            </div>
          </Section>

          {/* Channel split */}
          <Section icon={TrendingUp} title="Channel split" hint="Total locks to 100%">
            <div className="grid md:grid-cols-[240px_1fr] gap-6 items-center">
              <div className="h-56">
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie
                      data={channels}
                      dataKey="pct"
                      nameKey="name"
                      innerRadius={55}
                      outerRadius={90}
                      paddingAngle={2}
                      stroke="none"
                    >
                      {channels.map((c) => (
                        <Cell key={c.name} fill={c.color} />
                      ))}
                    </Pie>
                    <Tooltip
                      contentStyle={{
                        background: "var(--surface)",
                        border: "1px solid var(--border)",
                        borderRadius: 8,
                        fontSize: 12,
                      }}
                    />
                  </PieChart>
                </ResponsiveContainer>
              </div>
              <div className="flex flex-col gap-3">
                {channels.map((c, i) => (
                  <div key={c.name} className="flex items-center gap-3">
                    <div
                      className="size-3 rounded-sm shrink-0"
                      style={{ background: c.color }}
                    />
                    <div className="w-32 text-sm shrink-0">{c.name}</div>
                    <input
                      type="range"
                      min={0}
                      max={100}
                      value={c.pct}
                      onChange={(e) => updateChannel(i, Number(e.target.value))}
                      className="flex-1 accent-[color:var(--primary)]"
                    />
                    <div className="w-12 text-right text-sm font-mono tabular-nums">
                      {c.pct}%
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </Section>

          {/* Audiences */}
          <Section icon={Users} title="Audiences" hint="Chips are removable">
            <div className="grid sm:grid-cols-2 gap-3">
              {audiences.map((a, i) => (
                <div key={a.channel} className="rounded-xl border border-border bg-surface p-4">
                  <div className="flex items-center gap-2 mb-3">
                    <div
                      className="size-2 rounded-full"
                      style={{ background: CHANNEL_COLORS[a.channel] ?? "#000099" }}
                    />
                    <div className="text-sm font-medium">{a.channel}</div>
                  </div>
                  <div className="grid grid-cols-2 gap-2 text-xs text-muted-foreground mb-3">
                    <div>
                      <div className="uppercase tracking-wider mb-0.5">Age</div>
                      <div className="text-foreground text-sm">{a.age}</div>
                    </div>
                    <div>
                      <div className="uppercase tracking-wider mb-0.5">Geo</div>
                      <div className="text-foreground text-sm">{a.geo}</div>
                    </div>
                  </div>
                  <div className="flex flex-wrap gap-1.5">
                    {a.interests.map((t) => (
                      <button
                        key={t}
                        onClick={() => removeInterest(i, t)}
                        className="group flex items-center gap-1 rounded-full bg-accent px-2.5 py-1 text-xs hover:bg-accent/80"
                      >
                        {t}
                        <X className="size-3 opacity-40 group-hover:opacity-100" />
                      </button>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          </Section>

          {/* Creatives */}
          <Section icon={Sparkles} title="Creatives" hint="Approve, regenerate, or swap">
            <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
              {creatives.map((c) => (
                <div
                  key={c.id}
                  className="rounded-xl border border-border bg-surface overflow-hidden flex flex-col"
                >
                  <div className="aspect-[4/5] bg-accent overflow-hidden">
                    <img
                      src={`https://picsum.photos/seed/${c.seed}/480/600`}
                      alt=""
                      className="w-full h-full object-cover"
                    />
                  </div>
                  <div className="p-3 flex-1 flex flex-col gap-1">
                    <div className="font-medium text-sm">{c.headline}</div>
                    <div className="text-xs text-muted-foreground line-clamp-2">{c.copy}</div>
                  </div>
                  <div className="border-t border-border grid grid-cols-3 divide-x divide-border text-xs">
                    <button className="py-2 flex items-center justify-center gap-1 hover:bg-accent">
                      <Check className="size-3.5" /> Approve
                    </button>
                    <button
                      onClick={() => regenerate(c.id)}
                      className="py-2 flex items-center justify-center gap-1 hover:bg-accent"
                    >
                      <RefreshCw className="size-3.5" /> Regen
                    </button>
                    <button className="py-2 flex items-center justify-center gap-1 hover:bg-accent">
                      <Repeat className="size-3.5" /> Swap
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </Section>

          {/* Schedule */}
          <Section icon={Calendar} title="Schedule">
            <div className="grid sm:grid-cols-3 gap-4">
              <div className="rounded-xl border border-border bg-surface p-4">
                <div className="text-xs text-muted-foreground mb-1">Start date</div>
                <input
                  type="date"
                  value={startDate}
                  onChange={(e) => setStartDate(e.target.value)}
                  className="w-full bg-transparent text-sm outline-none"
                />
              </div>
              <div className="rounded-xl border border-border bg-surface p-4">
                <div className="text-xs text-muted-foreground mb-1">End date</div>
                <div className="text-sm">{endDate}</div>
              </div>
              <div className="rounded-xl border border-border bg-surface p-4">
                <div className="text-xs text-muted-foreground mb-2">Pacing</div>
                <div className="flex gap-1 bg-accent p-1 rounded-lg">
                  {(["Even", "Accelerated"] as const).map((p) => (
                    <button
                      key={p}
                      onClick={() => setPacing(p)}
                      className={`flex-1 text-xs py-1.5 rounded-md transition ${
                        pacing === p ? "bg-surface font-medium" : "text-muted-foreground"
                      }`}
                    >
                      {p}
                    </button>
                  ))}
                </div>
              </div>
            </div>
          </Section>

          {/* Risks */}
          <Section icon={AlertTriangle} title="Risks & notes">
            <ul className="rounded-xl border border-border bg-surface p-5 flex flex-col gap-2 text-sm text-muted-foreground">
              <li>• Meta Reels creatives may underperform without vertical video assets.</li>
              <li>• Google Search CPCs in this vertical trended ~12% higher last week.</li>
              <li>• Consider adding a retargeting segment once volume clears 10k impressions.</li>
            </ul>
          </Section>
        </div>

        {/* Sticky footer */}
        <div className="fixed bottom-0 inset-x-0 z-30 border-t border-border bg-background/95 backdrop-blur">
          <div className="max-w-5xl mx-auto px-6 py-3 flex items-center justify-between gap-3">
            <Link
              to="/campaigns/new"
              className="text-sm text-muted-foreground hover:text-foreground flex items-center gap-1.5"
            >
              <ArrowLeft className="size-4" />
              Back to brief
            </Link>
            <div className="flex items-center gap-2">
              <button className="flex items-center gap-1.5 rounded-xl border border-border px-4 py-2 text-sm hover:bg-accent">
                <Save className="size-4" />
                Save draft
              </button>
              <button
                onClick={() => setLaunching(true)}
                className="flex items-center gap-1.5 rounded-xl bg-primary text-primary-foreground px-4 py-2 text-sm font-medium hover:opacity-90"
              >
                Launch campaign
                <ChevronRight className="size-4" />
              </button>
            </div>
          </div>
        </div>

        {launching && (
          <div className="fixed inset-0 z-50 bg-background/80 backdrop-blur-sm grid place-items-center p-6">
            <div className="w-full max-w-md rounded-2xl border border-border bg-surface p-6 shadow-2xl">
              <div className="flex items-center gap-2 mb-1">
                <Sparkles className="size-4 text-[var(--accent-ai)]" />
                <div className="text-xs font-medium uppercase tracking-wider text-muted-foreground">
                  Launching
                </div>
              </div>
              <h3 className="text-lg font-display font-bold tracking-tight mb-4">
                Pushing your campaign live
              </h3>
              <ul className="flex flex-col gap-3">
                {launchSteps.map((s, i) => {
                  const done = i < launchStep;
                  const active = i === launchStep;
                  return (
                    <li key={s} className="flex items-center gap-3 text-sm">
                      <div
                        className={`size-5 shrink-0 rounded-full grid place-items-center transition-colors ${
                          done
                            ? "bg-primary text-primary-foreground"
                            : active
                              ? "bg-primary/20 text-primary"
                              : "bg-accent text-muted-foreground"
                        }`}
                      >
                        {done ? (
                          <Check className="size-3" />
                        ) : active ? (
                          <span className="size-2 rounded-full bg-primary animate-pulse" />
                        ) : (
                          <span className="size-1.5 rounded-full bg-muted-foreground/40" />
                        )}
                      </div>
                      <span
                        className={
                          done
                            ? "text-foreground"
                            : active
                              ? "text-foreground font-medium"
                              : "text-muted-foreground"
                        }
                      >
                        {s}
                      </span>
                    </li>
                  );
                })}
              </ul>
            </div>
          </div>
        )}
      </div>
    </AppShell>
  );
}

function Section({
  icon: Icon,
  title,
  hint,
  children,
}: {
  icon: typeof Target;
  title: string;
  hint?: string;
  children: React.ReactNode;
}) {
  return (
    <section>
      <div className="flex items-center justify-between mb-3">
        <div className="flex items-center gap-2">
          <Icon className="size-4 text-muted-foreground" />
          <h2 className="text-sm font-display font-bold tracking-tight uppercase">{title}</h2>
        </div>
        {hint && <div className="text-xs text-muted-foreground">{hint}</div>}
      </div>
      {children}
    </section>
  );
}

function Recap({ label, value }: { label: string; value?: string }) {
  return (
    <div>
      <div className="text-xs text-muted-foreground mb-0.5">{label}</div>
      <div className={value ? "text-foreground" : "text-muted-foreground/50 italic"}>
        {value || "—"}
      </div>
    </div>
  );
}
