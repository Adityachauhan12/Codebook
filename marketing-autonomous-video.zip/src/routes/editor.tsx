import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useRef, useState } from "react";
import * as fabric from "fabric";
import {
  LayoutTemplate,
  Shapes,
  Type as TypeIcon,
  ImageIcon,
  Palette,
  Download,
  Trash2,
  Bold,
  Italic,
  Underline,
  AlignLeft,
  AlignCenter,
  AlignRight,
  ChevronDown,
  Grid3x3,
  Keyboard,
  HelpCircle,
  X,
  ChevronRight,
  ChevronLeft,
  Images,
  Loader2,
  PanelRight,
  Home,
  Info,
} from "lucide-react";
import { Tooltip, TooltipContent, TooltipTrigger, TooltipProvider } from "@/components/ui/tooltip";

export const Route = createFileRoute("/editor")({
  component: Editor,
  head: () => ({
    meta: [
      { title: "Canvas — Minimal Image Editor" },
      { name: "description", content: "Design social posts, covers, and posters on a focused canvas." },
    ],
  }),
});

/* ---------- constants ---------- */

const FONTS = [
  "Sora",
  "Manrope",
  "Poppins",
  "Bauhaus Std",
  "Inter",
  "Georgia",
  "Courier New",
  "Impact",
  "Comic Sans MS",
];

const PRESETS: { label: string; w: number; h: number }[] = [
  { label: "Instagram Post", w: 1080, h: 1080 },
  { label: "Instagram Story", w: 1080, h: 1920 },
  { label: "Instagram Portrait", w: 1080, h: 1350 },
  { label: "Pinterest Pin", w: 1000, h: 1500 },
  { label: "TikTok / Reel", w: 1080, h: 1920 },
  { label: "Twitter Post", w: 1600, h: 900 },
  { label: "Facebook Cover", w: 1200, h: 630 },
  { label: "A4 Portrait", w: 2480, h: 3508 },
  { label: "A4 Landscape", w: 3508, h: 2480 },
  { label: "Letter Portrait", w: 2550, h: 3300 },
  { label: "HD Landscape", w: 1920, h: 1080 },
  { label: "HD Portrait", w: 1080, h: 1920 },
  { label: "Square", w: 1000, h: 1000 },
];

const BG_SWATCHES = [
  "#ffffff", "#fafbfc", "#0f172a", "#111827",
  "#3b82f6", "#ef4444", "#10b981", "#f59e0b",
  "#fde047", "#a78bfa", "#f472b6", "#1e1b4b",
];

type ButtonMeta = { kind: "button"; radius: number };
type ToolId = "templates" | "assets" | "text" | "uploads" | "background" | "batch";

type CustomTemplate = {
  id: string;
  name: string;
  w: number;
  h: number;
  thumb: string;
  json: unknown;
  createdAt: number;
};

const CUSTOM_TPL_KEY = "canvas.customTemplates.v1";

function loadCustomTemplates(): CustomTemplate[] {
  if (typeof window === "undefined") return [];
  try {
    const raw = window.localStorage.getItem(CUSTOM_TPL_KEY);
    return raw ? (JSON.parse(raw) as CustomTemplate[]) : [];
  } catch {
    return [];
  }
}

function persistCustomTemplates(list: CustomTemplate[]) {
  if (typeof window === "undefined") return;
  try {
    window.localStorage.setItem(CUSTOM_TPL_KEY, JSON.stringify(list));
  } catch {
    // storage may be full — fail silently
  }
}

/* ---------- component ---------- */

type BoardFrame = {
  id: string;
  label: string;
  w: number;
  h: number;
  sourceJSON: object;
  sourceW: number;
  sourceH: number;
  fit: "cover" | "contain";
  bg: string;
};

function Editor() {
  const canvasElRef = useRef<HTMLCanvasElement>(null);
  const stageRef = useRef<HTMLDivElement>(null);
  const canvasRef = useRef<fabric.Canvas | null>(null);
  const mainCanvasRef = useRef<fabric.Canvas | null>(null);
  const frameCanvasesRef = useRef<Map<string, fabric.Canvas>>(new Map());
  const historyRef = useRef<{ stack: string[]; index: number; suspend: boolean }>({ stack: [], index: -1, suspend: false });
  const [selected, setSelected] = useState<fabric.FabricObject | null>(null);
  const [size, setSize] = useState<{ w: number; h: number }>({ w: 1080, h: 1080 });
  const [zoom, setZoom] = useState(1);
  const [activeTool, setActiveTool] = useState<ToolId | null>("templates");
  const [customTemplates, setCustomTemplates] = useState<CustomTemplate[]>([]);
  const [showGrid, setShowGrid] = useState(false);
  const [showShortcuts, setShowShortcuts] = useState(false);
  const [showInspector, setShowInspector] = useState(true);
  const [boardFrames, setBoardFrames] = useState<BoardFrame[]>([]);
  const [activeFrameId, setActiveFrameId] = useState<string | null>(null);
  const [boardZoom, setBoardZoom] = useState(0.5);

  const [tourStep, setTourStep] = useState<number>(-1);
  useEffect(() => {
    try {
      if (!window.localStorage.getItem("canvas.tourDone")) setTourStep(0);
    } catch {}
  }, []);
  const [, force] = useState(0);
  const rerender = () => force((n) => n + 1);

  useEffect(() => {
    setCustomTemplates(loadCustomTemplates());
  }, []);


  // Attach selection/history events to any fabric.Canvas. Used for the main
  // canvas and every board frame canvas so the inspector works on any of them.
  const attachCanvasEvents = (canvas: fabric.Canvas, opts: { history: boolean }) => {
    const onSel = () => {
      setSelected(canvas.getActiveObject() ?? null);
      rerender();
    };
    canvas.on("selection:created", onSel);
    canvas.on("selection:updated", onSel);
    canvas.on("selection:cleared", () => setSelected(null));
    canvas.on("object:modified", rerender);
    if (!opts.history) return;
    const snapshot = () => {
      const h = historyRef.current;
      if (h.suspend) return;
      const json = JSON.stringify((canvas as unknown as { toJSON: (p?: string[]) => object }).toJSON(["data"]));
      h.stack = h.stack.slice(0, h.index + 1);
      if (h.stack[h.index] === json) return;
      h.stack.push(json);
      if (h.stack.length > 50) h.stack.shift();
      h.index = h.stack.length - 1;
    };
    setTimeout(snapshot, 0);
    canvas.on("object:added", snapshot);
    canvas.on("object:modified", snapshot);
    canvas.on("object:removed", snapshot);
    canvas.on("path:created", snapshot);
  };

  useEffect(() => {
    if (!canvasElRef.current) return;
    const canvas = new fabric.Canvas(canvasElRef.current, {
      width: size.w,
      height: size.h,
      backgroundColor: "#ffffff",
    });
    canvasRef.current = canvas;
    mainCanvasRef.current = canvas;

    // More visible selection handles
    fabric.FabricObject.ownDefaults.transparentCorners = false;
    fabric.FabricObject.ownDefaults.cornerColor = "#ffffff";
    fabric.FabricObject.ownDefaults.cornerStrokeColor = "#3b82f6";
    fabric.FabricObject.ownDefaults.borderColor = "#3b82f6";
    fabric.FabricObject.ownDefaults.cornerSize = 12;
    fabric.FabricObject.ownDefaults.cornerStyle = "circle";
    fabric.FabricObject.ownDefaults.borderScaleFactor = 2;
    fabric.FabricObject.ownDefaults.padding = 4;

    attachCanvasEvents(canvas, { history: true });

    return () => {
      canvas.dispose();
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // Called by each FrameCanvas after it mounts its own fabric.Canvas.
  const handleFrameReady = (id: string, canvas: fabric.Canvas) => {
    frameCanvasesRef.current.set(id, canvas);
    attachCanvasEvents(canvas, { history: false });
    // Auto-activate the first frame so the inspector has a target.
    setActiveFrameId((cur) => {
      if (cur) return cur;
      canvasRef.current = canvas;
      return id;
    });
  };

  const activateFrame = (id: string) => {
    const c = frameCanvasesRef.current.get(id);
    if (!c) return;
    canvasRef.current = c;
    setActiveFrameId(id);
    setSelected(c.getActiveObject() ?? null);
    rerender();
  };

  const exitBoardMode = () => {
    // Dispose per-frame canvases and restore the main canvas as active.
    frameCanvasesRef.current.forEach((c) => c.dispose());
    frameCanvasesRef.current.clear();
    setBoardFrames([]);
    setActiveFrameId(null);
    if (mainCanvasRef.current) {
      canvasRef.current = mainCanvasRef.current;
      setSelected(mainCanvasRef.current.getActiveObject() ?? null);
    }
    rerender();
  };


  useEffect(() => {
    const canvas = mainCanvasRef.current;
    const stage = stageRef.current;
    if (!canvas || !stage) return;
    if (boardFrames.length > 0) return;


    const fit = () => {
      canvas.setDimensions({ width: size.w, height: size.h });
      const pad = 48;
      const sw = Math.max(100, stage.clientWidth - pad);
      const sh = Math.max(100, stage.clientHeight - pad);
      const scale = Math.min(sw / size.w, sh / size.h, 1);
      setZoom(scale);
      canvas.setDimensions(
        { width: `${size.w * scale}px`, height: `${size.h * scale}px` },
        { cssOnly: true }
      );
      canvas.renderAll();
    };
    fit();
    const ro = new ResizeObserver(fit);
    ro.observe(stage);
    return () => ro.disconnect();
  }, [size, boardFrames.length]);

  /* ---------- actions ---------- */

  const uploadImage = (file: File) => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const reader = new FileReader();
    reader.onload = async (e) => {
      const img = await fabric.FabricImage.fromURL(e.target?.result as string);
      const s = Math.min(canvas.width! / img.width!, canvas.height! / img.height!, 1) * 0.8;
      img.scale(s);
      img.set({
        left: (canvas.width! - img.width! * s) / 2,
        top: (canvas.height! - img.height! * s) / 2,
      });
      canvas.add(img);
      canvas.setActiveObject(img);
      canvas.renderAll();
    };
    reader.readAsDataURL(file);
  };

  const canvasIsBlank = () => {
    const c = canvasRef.current;
    if (!c) return true;
    const bg = (c.backgroundColor as string) ?? "";
    return (
      c.getObjects().length === 0 &&
      !c.backgroundImage &&
      (bg === "" || bg === "#ffffff" || bg === "rgb(255,255,255)")
    );
  };

  const addImageFromUrl = async (url: string) => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    try {
      // Fetch as blob → dataURL so exported canvas stays taint-free.
      const res = await fetch(url, { mode: "cors" });
      const blob = await res.blob();
      const dataUrl = await new Promise<string>((resolve, reject) => {
        const fr = new FileReader();
        fr.onload = () => resolve(fr.result as string);
        fr.onerror = reject;
        fr.readAsDataURL(blob);
      });
      const img = await fabric.FabricImage.fromURL(dataUrl);
      if (canvasIsBlank()) {
        const w = img.width!;
        const h = img.height!;
        setSize({ w, h });
        canvas.setDimensions({ width: w, height: h });
        img.set({ left: 0, top: 0, originX: "left", originY: "top" });
        canvas.add(img);
        canvas.setActiveObject(img);
        canvas.renderAll();
        return;
      }
      const s = Math.min(canvas.width! / img.width!, canvas.height! / img.height!, 1) * 0.4;
      img.scale(s);
      img.set({
        left: (canvas.width! - img.width! * s) / 2,
        top: (canvas.height! - img.height! * s) / 2,
      });
      canvas.add(img);
      canvas.setActiveObject(img);
      canvas.renderAll();
    } catch (err) {
      console.error("Failed to load logo", err);
      alert("Couldn't load that image URL (CORS or network error).");
    }
  };

  const replaceSelectedImage = async (url: string) => {
    const canvas = canvasRef.current;
    const obj = canvas?.getActiveObject();
    if (!canvas || !(obj instanceof fabric.FabricImage)) return;
    try {
      const res = await fetch(url, { mode: "cors" });
      const blob = await res.blob();
      const dataUrl = await new Promise<string>((resolve, reject) => {
        const fr = new FileReader();
        fr.onload = () => resolve(fr.result as string);
        fr.onerror = reject;
        fr.readAsDataURL(blob);
      });
      await obj.setSrc(dataUrl);
      canvas.requestRenderAll();
      rerender();
    } catch {
      alert("Couldn't load that image.");
    }
  };

  const placeBatchOnCanvas = async (
    items: {
      label: string;
      w: number;
      h: number;
      sourceJSON: object;
      sourceW: number;
      sourceH: number;
      fit: "cover" | "contain";
      bg: string;
    }[],
  ) => {
    if (items.length === 0) return;
    // Dispose any prior board and swap in the new set of frames. Each frame
    // gets its own independent fabric.Canvas rendered by <FrameCanvas />.
    frameCanvasesRef.current.forEach((c) => c.dispose());
    frameCanvasesRef.current.clear();
    const frames: BoardFrame[] = items.map((it, i) => ({
      id: `frame-${Date.now()}-${i}`,
      ...it,
    }));
    setActiveFrameId(null);
    setSelected(null);
    setBoardFrames(frames);
  };

  const downloadFrame = (id: string, label: string) => {
    const c = frameCanvasesRef.current.get(id);
    if (!c) return;
    const url = c.toDataURL({ format: "png", multiplier: 1 });
    const a = document.createElement("a");
    a.href = url;
    a.download = `${label.replace(/\s+/g, "-").toLowerCase()}.png`;
    a.click();
  };

  const downloadAllFrames = () => {
    boardFrames.forEach((f, i) =>
      setTimeout(() => downloadFrame(f.id, f.label), i * 150),
    );
  };




  const setBgColor = (color: string) => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    canvas.backgroundImage = undefined;
    canvas.backgroundColor = color;
    canvas.renderAll();
    rerender();
  };

  const setBgImage = (file: File) => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const reader = new FileReader();
    reader.onload = async (e) => {
      const img = await fabric.FabricImage.fromURL(e.target?.result as string);
      img.scaleX = canvas.width! / img.width!;
      img.scaleY = canvas.height! / img.height!;
      canvas.backgroundImage = img;
      canvas.renderAll();
    };
    reader.readAsDataURL(file);
  };

  const addText = (preset: "heading" | "sub" | "body" = "body") => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const fs = preset === "heading" ? 96 : preset === "sub" ? 56 : 32;
    const weight = preset === "heading" ? "700" : preset === "sub" ? "600" : "400";
    const family = preset === "body" ? "Poppins" : "Bauhaus Std";
    const margin = 80;
    const boxW = Math.max(160, canvas.width! - margin * 2);
    const text = new fabric.Textbox(
      preset === "heading" ? "Add a headline" : preset === "sub" ? "Subheading" : "Body text",
      {
        left: canvas.width! / 2,
        top: canvas.height! / 2,
        originX: "center",
        originY: "center",
        width: boxW,
        fill: "#0f172a",
        fontFamily: family,
        fontSize: fs,
        fontWeight: weight,
        textAlign: "center",
        splitByGrapheme: false,
      }
    );
    canvas.add(text);
    canvas.setActiveObject(text);
    canvas.renderAll();
  };

  const addButton = (variant: "solid" | "outline" = "solid") => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const isOutline = variant === "outline";
    const rect = new fabric.Rect({
      width: 220,
      height: 64,
      fill: isOutline ? "transparent" : "#000099",
      stroke: isOutline ? "#000099" : undefined,
      strokeWidth: isOutline ? 2 : 0,
      rx: 32,
      ry: 32,
      originX: "center",
      originY: "center",
    });
    const label = new fabric.IText("Click me", {
      fill: isOutline ? "#000099" : "#ffffff",
      fontFamily: "Sora",
      fontSize: 22,
      fontWeight: "600",
      originX: "center",
      originY: "center",
    });
    const group = new fabric.Group([rect, label], {
      left: 200, top: 240, subTargetCheck: true,
    });
    (group as fabric.Group & { data?: ButtonMeta }).data = { kind: "button", radius: 32 };
    canvas.add(group);
    canvas.setActiveObject(group);
    canvas.renderAll();
  };

  const updateSelected = (patch: Record<string, unknown>) => {
    const canvas = canvasRef.current;
    const obj = canvas?.getActiveObject();
    if (!canvas || !obj) return;
    obj.set(patch);
    if ("setCoords" in obj) obj.setCoords();
    canvas.renderAll();
    rerender();
  };

  const getButtonParts = (group: fabric.Group) => {
    const objs = group.getObjects();
    const rect = objs.find((o) => o instanceof fabric.Rect) as fabric.Rect | undefined;
    const label = objs.find((o) => o instanceof fabric.IText) as fabric.IText | undefined;
    return { rect, label };
  };

  const isButton = (obj: fabric.FabricObject | null): obj is fabric.Group => {
    if (!(obj instanceof fabric.Group)) return false;
    if ((obj as fabric.Group & { data?: ButtonMeta }).data?.kind === "button") return true;
    // Structural fallback: any group made of a Rect + IText behaves like a button
    const { rect, label } = getButtonParts(obj);
    if (rect && label && obj.getObjects().length === 2) {
      (obj as fabric.Group & { data?: ButtonMeta }).data = {
        kind: "button",
        radius: (rect.rx as number) ?? 15,
      };
      return true;
    }
    return false;
  };

  const updateButton = (patch: { text?: string; radius?: number; bg?: string; color?: string; fontFamily?: string }) => {
    const canvas = canvasRef.current;
    const obj = canvas?.getActiveObject();
    if (!canvas || !obj || !isButton(obj)) return;
    const { rect, label } = getButtonParts(obj);
    if (patch.text !== undefined && label) label.set({ text: patch.text });
    if (patch.radius !== undefined && rect) {
      rect.set({ rx: patch.radius, ry: patch.radius });
      (obj as fabric.Group & { data?: ButtonMeta }).data = { kind: "button", radius: patch.radius };
    }
    if (patch.bg !== undefined && rect) rect.set({ fill: patch.bg });
    if (patch.color !== undefined && label) label.set({ fill: patch.color });
    if (patch.fontFamily !== undefined && label) label.set({ fontFamily: patch.fontFamily });
    if (rect) rect.dirty = true;
    if (label) label.dirty = true;
    obj.dirty = true;
    obj.set({ dirty: true });
    canvas.requestRenderAll();
    rerender();
  };

  const addShape = (kind: "rect" | "circle" | "triangle" | "star" | "line") => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const common = { left: size.w / 2 - 80, top: size.h / 2 - 80, fill: "#3b82f6" };
    let obj: fabric.FabricObject;
    if (kind === "rect") obj = new fabric.Rect({ ...common, width: 200, height: 160, rx: 12, ry: 12 });
    else if (kind === "circle") obj = new fabric.Circle({ ...common, radius: 90 });
    else if (kind === "triangle") obj = new fabric.Triangle({ ...common, width: 180, height: 180 });
    else if (kind === "line") obj = new fabric.Line([0, 0, 240, 0], { left: common.left, top: common.top, stroke: "#0f172a", strokeWidth: 6 });
    else {
      const pts: { x: number; y: number }[] = [];
      const outer = 90, inner = 38;
      for (let i = 0; i < 10; i++) {
        const r = i % 2 === 0 ? outer : inner;
        const a = (Math.PI / 5) * i - Math.PI / 2;
        pts.push({ x: r * Math.cos(a), y: r * Math.sin(a) });
      }
      obj = new fabric.Polygon(pts, { ...common, fill: "#f59e0b" });
    }
    canvas.add(obj);
    canvas.setActiveObject(obj);
    canvas.renderAll();
  };

  const addSticker = (emoji: string) => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const t = new fabric.IText(emoji, {
      left: size.w / 2 - 80, top: size.h / 2 - 80, fontSize: 140, fontFamily: "Sora",
    });
    canvas.add(t);
    canvas.setActiveObject(t);
    canvas.renderAll();
  };

  const applyTemplate = (id: string) => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    canvas.remove(...canvas.getObjects());
    canvas.backgroundImage = undefined;

    const w = size.w, h = size.h;
    const cx = w / 2;

    if (id === "quote") {
      canvas.backgroundColor = "#0f172a";
      canvas.add(new fabric.IText("“Design is intelligence made visible.”", {
        left: cx, top: h / 2 - 40, originX: "center", originY: "center",
        fill: "#f8fafc", fontFamily: "Sora", fontStyle: "italic",
        fontSize: Math.round(w * 0.055), textAlign: "center", width: w * 0.8,
      }));
      canvas.add(new fabric.IText("— Alina Wheeler", {
        left: cx, top: h / 2 + Math.round(w * 0.08), originX: "center", originY: "center",
        fill: "#94a3b8", fontFamily: "Manrope", fontSize: Math.round(w * 0.025),
      }));
    } else if (id === "sale") {
      canvas.backgroundColor = "#fde047";
      canvas.add(new fabric.IText("50% OFF", {
        left: cx, top: h * 0.35, originX: "center", originY: "center",
        fill: "#111", fontFamily: "Sora", fontSize: Math.round(w * 0.18), fontWeight: "800",
      }));
      canvas.add(new fabric.IText("Summer sale — this week only", {
        left: cx, top: h * 0.55, originX: "center", originY: "center",
        fill: "#111", fontFamily: "Manrope", fontSize: Math.round(w * 0.035),
      }));
      const rect = new fabric.Rect({ width: 280, height: 72, fill: "#111", rx: 15, ry: 15, originX: "center", originY: "center" });
      const label = new fabric.IText("Shop now", { fill: "#fff", fontFamily: "Sora", fontSize: 26, fontWeight: "600", originX: "center", originY: "center" });
      const g = new fabric.Group([rect, label], { left: cx, top: h * 0.75, originX: "center", originY: "center", subTargetCheck: true });
      (g as fabric.Group & { data?: ButtonMeta }).data = { kind: "button", radius: 15 };
      canvas.add(g);
    } else if (id === "event") {
      canvas.backgroundColor = "#1e1b4b";
      canvas.add(new fabric.IText("DESIGN\nCONF 26", {
        left: cx, top: h * 0.35, originX: "center", originY: "center",
        fill: "#fff", fontFamily: "Sora", fontWeight: "800",
        fontSize: Math.round(w * 0.14), textAlign: "center", lineHeight: 0.95,
      }));
      canvas.add(new fabric.IText("July 12 · Lisbon", {
        left: cx, top: h * 0.62, originX: "center", originY: "center",
        fill: "#c7d2fe", fontFamily: "Manrope", fontSize: Math.round(w * 0.035),
      }));
      const rect = new fabric.Rect({ width: 260, height: 68, fill: "#f59e0b", rx: 15, ry: 15, originX: "center", originY: "center" });
      const label = new fabric.IText("Get tickets", { fill: "#111", fontFamily: "Sora", fontSize: 24, fontWeight: "700", originX: "center", originY: "center" });
      const g = new fabric.Group([rect, label], { left: cx, top: h * 0.78, originX: "center", originY: "center", subTargetCheck: true });
      (g as fabric.Group & { data?: ButtonMeta }).data = { kind: "button", radius: 15 };
      canvas.add(g);
    } else if (id === "minimal") {
      canvas.backgroundColor = "#f5f5f4";
      canvas.add(new fabric.Rect({ left: w * 0.1, top: h * 0.15, width: w * 0.8, height: h * 0.5, fill: "#e7e5e4", rx: 12, ry: 12 }));
      canvas.add(new fabric.IText("Field Notes", {
        left: w * 0.1, top: h * 0.72, fill: "#111", fontFamily: "Sora",
        fontSize: Math.round(w * 0.07), fontWeight: "700",
      }));
      canvas.add(new fabric.IText("Volume 01 · Winter", {
        left: w * 0.1, top: h * 0.72 + Math.round(w * 0.09),
        fill: "#57534e", fontFamily: "Manrope", fontSize: Math.round(w * 0.025),
      }));
    }
    canvas.renderAll();
    rerender();
  };

  const applyCustomTemplate = (tpl: CustomTemplate) => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    setSize({ w: tpl.w, h: tpl.h });
    canvas.loadFromJSON(tpl.json as object).then(() => {
      canvas.renderAll();
      rerender();
    });
  };

  const saveAsTemplate = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const name = window.prompt("Template name", "My template");
    if (!name) return;
    // Preserve custom fabric metadata (e.g. button group `data`)
    const json = (canvas as unknown as { toJSON: (p?: string[]) => object }).toJSON(["data"]);
    // Small thumbnail (max 200px on the long edge)
    const maxSide = 200;
    const mult = Math.min(maxSide / size.w, maxSide / size.h, 1);
    const thumb = canvas.toDataURL({ format: "png", multiplier: mult });
    const tpl: CustomTemplate = {
      id: `custom_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`,
      name: name.trim() || "Untitled",
      w: size.w,
      h: size.h,
      thumb,
      json,
      createdAt: Date.now(),
    };
    const next = [tpl, ...customTemplates];
    setCustomTemplates(next);
    persistCustomTemplates(next);
    setActiveTool("templates");
  };

  const deleteCustomTemplate = (id: string) => {
    const next = customTemplates.filter((t) => t.id !== id);
    setCustomTemplates(next);
    persistCustomTemplates(next);
  };

  const deleteSelected = () => {
    const canvas = canvasRef.current;
    const obj = canvas?.getActiveObject();
    if (!canvas || !obj) return;
    canvas.remove(obj);
    canvas.discardActiveObject();
    canvas.renderAll();
    setSelected(null);
  };

  const clipboardRef = useRef<fabric.FabricObject | null>(null);

  const copySelected = async () => {
    const canvas = canvasRef.current;
    const obj = canvas?.getActiveObject();
    if (!obj) return;
    clipboardRef.current = await obj.clone(["selectable", "hasControls", "data"]);
  };

  const pasteClipboard = async () => {
    const canvas = canvasRef.current;
    const clip = clipboardRef.current;
    if (!canvas || !clip) return;
    const cloned = await clip.clone(["selectable", "hasControls", "data"]);
    canvas.discardActiveObject();
    cloned.set({
      left: (cloned.left ?? 0) + 20,
      top: (cloned.top ?? 0) + 20,
      evented: true,
    });
    if (cloned instanceof fabric.ActiveSelection) {
      cloned.canvas = canvas;
      cloned.forEachObject((o) => canvas.add(o));
      cloned.setCoords();
    } else {
      canvas.add(cloned);
    }
    canvas.setActiveObject(cloned);
    canvas.requestRenderAll();
  };

  const undo = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const h = historyRef.current;
    if (h.index <= 0) return;
    h.index -= 1;
    const json = h.stack[h.index];
    h.suspend = true;
    canvas.loadFromJSON(JSON.parse(json)).then(() => {
      canvas.requestRenderAll();
      h.suspend = false;
      setSelected(null);
    });
  };
  const redo = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const h = historyRef.current;
    if (h.index >= h.stack.length - 1) return;
    h.index += 1;
    const json = h.stack[h.index];
    h.suspend = true;
    canvas.loadFromJSON(JSON.parse(json)).then(() => {
      canvas.requestRenderAll();
      h.suspend = false;
      setSelected(null);
    });
  };

  useEffect(() => {
    const isEditable = (el: EventTarget | null) => {
      if (!(el instanceof HTMLElement)) return false;
      const tag = el.tagName;
      return tag === "INPUT" || tag === "TEXTAREA" || el.isContentEditable;
    };
    const onKey = (e: KeyboardEvent) => {
      const canvas = canvasRef.current;
      if (!canvas) return;
      const active = canvas.getActiveObject() as fabric.FabricObject & { isEditing?: boolean } | null;
      if (active && (active as fabric.IText).isEditing) return;
      if (isEditable(e.target)) return;
      const mod = e.metaKey || e.ctrlKey;
      if ((e.key === "Delete" || e.key === "Backspace") && active) {
        e.preventDefault();
        deleteSelected();
      } else if (mod && e.key.toLowerCase() === "c") {
        e.preventDefault();
        copySelected();
      } else if (mod && e.key.toLowerCase() === "v") {
        e.preventDefault();
        pasteClipboard();
      } else if (mod && e.key.toLowerCase() === "d") {
        e.preventDefault();
        (async () => { await copySelected(); await pasteClipboard(); })();
      } else if (mod && !e.shiftKey && e.key.toLowerCase() === "z") {
        e.preventDefault();
        undo();
      } else if ((mod && e.shiftKey && e.key.toLowerCase() === "z") || (mod && e.key.toLowerCase() === "y")) {
        e.preventDefault();
        redo();
      } else if (e.key === "Escape") {
        canvas.discardActiveObject();
        canvas.requestRenderAll();
        setSelected(null);
        setShowShortcuts(false);
      } else if (e.key === "?" || (e.shiftKey && e.key === "/")) {
        e.preventDefault();
        setShowShortcuts((v) => !v);
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, []);

  const download = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const url = canvas.toDataURL({ format: "png", multiplier: 2 });
    const a = document.createElement("a");
    a.href = url;
    a.download = "design.png";
    a.click();
  };

  const isText = selected instanceof fabric.IText;
  const selectedIsButton = isButton(selected);
  const selectedIsImage = selected instanceof fabric.FabricImage;
  const buttonParts = selectedIsButton
    ? getButtonParts(selected as fabric.Group)
    : { rect: undefined, label: undefined };

  const currentPreset =
    PRESETS.find((p) => p.w === size.w && p.h === size.h)?.label ?? "Custom";

  return (
    <div className="flex h-screen flex-col overflow-hidden bg-background text-foreground">
      {/* Top bar */}
      <header className="flex h-14 shrink-0 items-center justify-between border-b border-border bg-surface px-4">
        <div className="flex items-center gap-3">
          <div className="grid h-8 w-8 shrink-0 place-items-center rounded-lg bg-primary text-primary-foreground shadow-sm">
            <span className="font-display text-sm font-bold">C</span>
          </div>
          <div className="min-w-0">
            <h1 className="truncate font-display text-sm font-semibold">Canvas</h1>
            <p className="truncate text-[11px] text-muted-foreground">Minimal image editor</p>
          </div>
        </div>

        <div className="hidden items-center gap-2 md:flex" data-tour="header">
          <SizeMenu size={size} setSize={setSize} currentLabel={currentPreset} />
          <button
            onClick={() => setShowGrid((v) => !v)}
            title={showGrid ? "Hide gridlines" : "Show gridlines"}
            className={`inline-flex h-8 w-8 items-center justify-center rounded-md border border-border transition ${
              showGrid ? "bg-accent text-primary" : "bg-surface text-muted-foreground hover:text-foreground"
            }`}
          >
            <Grid3x3 className="h-4 w-4" />
          </button>
          <div className="hidden items-center gap-1 rounded-md border border-border bg-surface px-2 py-1.5 text-xs text-muted-foreground lg:flex">
            <span className="font-mono">{Math.round(zoom * 100)}%</span>
          </div>
        </div>

        <div className="flex items-center gap-2" data-tour="help">
          <button
            onClick={() => setShowShortcuts(true)}
            title="Keyboard shortcuts (?)"
            className="inline-flex h-8 w-8 items-center justify-center rounded-md border border-border bg-surface text-muted-foreground transition hover:text-foreground"
          >
            <Keyboard className="h-4 w-4" />
          </button>
          <button
            onClick={() => setTourStep(0)}
            title="Show tour"
            className="inline-flex h-8 w-8 items-center justify-center rounded-md border border-border bg-surface text-muted-foreground transition hover:text-foreground"
          >
            <HelpCircle className="h-4 w-4" />
          </button>
          <button
            onClick={download}
            className="inline-flex items-center gap-1.5 rounded-md bg-primary px-3.5 py-2 text-sm font-medium text-primary-foreground shadow-sm transition hover:opacity-95"
          >
            <Download className="h-4 w-4" />
            Export PNG
          </button>
        </div>
      </header>

      {/* Body: rail + panel + canvas + inspector */}
      <div className="relative flex min-h-0 flex-1">
        {/* Left icon rail */}
        <nav className="flex w-14 shrink-0 flex-col items-center gap-1 border-r border-border bg-surface py-2">
          <RailBtn icon={<LayoutTemplate className="h-5 w-5" />} label="Templates" active={activeTool === "templates"} onClick={() => setActiveTool(activeTool === "templates" ? null : "templates")} />
          <RailBtn icon={<Shapes className="h-5 w-5" />} label="Assets" active={activeTool === "assets"} onClick={() => setActiveTool(activeTool === "assets" ? null : "assets")} />
          <RailBtn icon={<TypeIcon className="h-5 w-5" />} label="Text" active={activeTool === "text"} onClick={() => setActiveTool(activeTool === "text" ? null : "text")} />
          <RailBtn icon={<ImageIcon className="h-5 w-5" />} label="Uploads" active={activeTool === "uploads"} onClick={() => setActiveTool(activeTool === "uploads" ? null : "uploads")} />
          <RailBtn icon={<Palette className="h-5 w-5" />} label="Background" active={activeTool === "background"} onClick={() => setActiveTool(activeTool === "background" ? null : "background")} />
          <RailBtn icon={<Images className="h-5 w-5" />} label="Batch" active={activeTool === "batch"} onClick={() => setActiveTool(activeTool === "batch" ? null : "batch")} />
          <div className="mt-auto pt-2 border-t border-border w-full flex justify-center">
            <Link
              to="/"
              title="Back to home"
              className="group flex h-10 w-10 flex-col items-center justify-center gap-0.5 rounded-lg text-muted-foreground hover:bg-accent hover:text-foreground"
            >
              <Home className="h-5 w-5" />
              <span className="text-[9px] leading-none">Home</span>
            </Link>
          </div>
        </nav>

        {/* Slide-out tool panel */}
        {activeTool && (
          <section className="flex w-72 shrink-0 flex-col border-r border-border bg-surface">
            <div className="flex h-11 shrink-0 items-center justify-between border-b border-border px-4">
              <div className="flex items-center gap-1.5">
                <h2 className="font-display text-sm font-semibold capitalize">{activeTool}</h2>
                {(activeTool === "templates" || activeTool === "batch") && (
                  <TooltipProvider delayDuration={150}>
                    <Tooltip>
                      <TooltipTrigger asChild>
                        <button
                          type="button"
                          aria-label={`About ${activeTool}`}
                          className="text-muted-foreground transition hover:text-foreground"
                        >
                          <Info className="h-3.5 w-3.5" />
                        </button>
                      </TooltipTrigger>
                      <TooltipContent side="right" className="max-w-[240px] text-left leading-snug">
                        {activeTool === "templates"
                          ? "Ready-made designs to start from. Pick one and tweak the text, colors, and images to make it yours — or save your own designs as reusable templates."
                          : "Turn one design into every size you need — Instagram post, story, YouTube thumbnail, banner, and more. Pick sizes (or add custom ones) and export them all at once."}
                      </TooltipContent>
                    </Tooltip>
                  </TooltipProvider>
                )}
              </div>
              <button
                onClick={() => setActiveTool(null)}
                className="text-xs text-muted-foreground hover:text-foreground"
              >
                Close
              </button>
            </div>
            <div className="min-h-0 flex-1 overflow-y-auto p-4">
              {activeTool === "templates" && (
                <TemplatesPanel
                  onPick={applyTemplate}
                  custom={customTemplates}
                  onPickCustom={applyCustomTemplate}
                  onSaveCurrent={saveAsTemplate}
                  onDeleteCustom={deleteCustomTemplate}
                />
              )}
              {activeTool === "assets" && <AssetsPanel onAddLogo={addImageFromUrl} />}
              {activeTool === "text" && <TextPanel onAdd={addText} onButton={addButton} />}
              {activeTool === "uploads" && <UploadsPanel onAdd={addImageFromUrl} />}
              {activeTool === "background" && (
                <BackgroundPanel onColor={setBgColor} onImage={setBgImage} />
              )}
              {activeTool === "batch" && (
                <BatchPanel
                  getCanvasSource={() => {
                    const c = canvasRef.current;
                    if (!c) return null;
                    return {
                      json: (c as unknown as { toJSON: (p?: string[]) => object }).toJSON([
                        "data",
                      ]),
                      w: c.getWidth(),
                      h: c.getHeight(),
                    };
                  }}
                  onPlaceOnCanvas={placeBatchOnCanvas}
                />
              )}
            </div>
          </section>
        )}

        {/* Canvas stage */}
        <div
          ref={stageRef}
          data-tour="canvas"
          className="checker-bg relative flex min-h-0 flex-1 overflow-hidden"
        >
          {/* Main single-canvas view (kept mounted so its fabric instance survives) */}
          <div
            className={
              boardFrames.length > 0
                ? "hidden"
                : "flex min-h-0 flex-1 items-center justify-center"
            }
          >
            <div className="relative rounded-sm shadow-[0_10px_40px_-10px_rgba(15,23,42,0.25)] ring-1 ring-black/5">
              <canvas ref={canvasElRef} />
              {showGrid && (
                <div
                  className="pointer-events-none absolute inset-0"
                  style={{
                    backgroundImage:
                      "linear-gradient(to right, rgba(59,130,246,0.28) 1px, transparent 1px), linear-gradient(to bottom, rgba(59,130,246,0.28) 1px, transparent 1px)",
                    backgroundSize: `${Math.max(8, 50 * zoom)}px ${Math.max(8, 50 * zoom)}px`,
                  }}
                />
              )}
            </div>
          </div>

          {/* Multi-canvas board view — each frame is its own fabric.Canvas */}
          {boardFrames.length > 0 && (
            <div className="flex min-h-0 flex-1 flex-col">
              <div className="flex h-10 shrink-0 items-center justify-between gap-2 border-b border-border bg-surface px-4">
                <div className="text-xs text-muted-foreground">
                  Board · {boardFrames.length} frame{boardFrames.length === 1 ? "" : "s"} · click a
                  frame to edit
                </div>
                <div className="flex items-center gap-3">
                  <label className="flex items-center gap-2 text-xs text-muted-foreground">
                    Zoom
                    <input
                      type="range"
                      min={0.2}
                      max={1}
                      step={0.05}
                      value={boardZoom}
                      onChange={(e) => setBoardZoom(parseFloat(e.target.value))}
                    />
                    <span className="tabular-nums">{Math.round(boardZoom * 100)}%</span>
                  </label>
                  <button
                    onClick={downloadAllFrames}
                    className="inline-flex items-center gap-1.5 rounded-md bg-primary px-3 py-1 text-xs font-medium text-primary-foreground hover:opacity-95"
                  >
                    <Download className="h-3 w-3" /> Download all
                  </button>
                  <button
                    onClick={exitBoardMode}
                    className="rounded-md border border-border bg-background px-3 py-1 text-xs font-medium hover:bg-accent"
                  >
                    Exit board
                  </button>
                </div>
              </div>
              <div className="min-h-0 flex-1 overflow-auto p-10">
                <div
                  className="flex flex-wrap items-start gap-14"
                  style={{ transform: `scale(${boardZoom})`, transformOrigin: "top left" }}
                >
                  {boardFrames.map((f) => (
                    <FrameCanvas
                      key={f.id}
                      frame={f}
                      active={activeFrameId === f.id}
                      onReady={handleFrameReady}
                      onActivate={activateFrame}
                      onDownload={() => downloadFrame(f.id, f.label)}
                    />
                  ))}
                </div>
              </div>
            </div>
          )}
        </div>


        {/* Right inspector */}
        {showInspector && (
        <aside data-tour="inspector" className="hidden w-80 shrink-0 flex-col border-l border-border bg-surface lg:flex">
          <div className="flex h-11 shrink-0 items-center justify-between gap-2 border-b border-border px-4">
            <h2 className="font-display text-sm font-semibold">Inspector</h2>
            <div className="flex items-center gap-1">
              {selected && (
                <button
                  onClick={deleteSelected}
                  className="inline-flex items-center gap-1 rounded-md border border-border px-2 py-1 text-xs text-muted-foreground transition hover:border-destructive hover:text-destructive"
                >
                  <Trash2 className="h-3.5 w-3.5" /> Delete
                </button>
              )}
              <button
                onClick={() => setShowInspector(false)}
                title="Hide inspector"
                className="inline-flex h-7 w-7 items-center justify-center rounded-md text-muted-foreground transition hover:bg-accent hover:text-foreground"
              >
                <ChevronRight className="h-4 w-4" />
              </button>
            </div>
          </div>

          <div className="min-h-0 flex-1 space-y-5 overflow-y-auto p-4">
            {!selected && (
              <div className="rounded-lg border border-dashed border-border p-6 text-center">
                <p className="font-display text-sm font-semibold">Nothing selected</p>
                <p className="mt-1 text-xs text-muted-foreground">
                  Click an object on the canvas to edit its style, size, and color.
                </p>
              </div>
            )}

            {selected && isText && (
              <Group title="Text">
                <Field label="Content">
                  <input
                    type="text"
                    value={(selected as fabric.IText).text ?? ""}
                    onChange={(e) => updateSelected({ text: e.target.value })}
                    className="ui-input"
                  />
                </Field>
                <Field label={`Size — ${(selected as fabric.IText).fontSize}px`}>
                  <SliderNum
                    min={8} max={240}
                    value={(selected as fabric.IText).fontSize ?? 16}
                    onChange={(v) => updateSelected({ fontSize: v })}
                  />
                </Field>
                <Field label="Font">
                  <select
                    value={(selected as fabric.IText).fontFamily as string}
                    onChange={(e) => updateSelected({ fontFamily: e.target.value })}
                    className="ui-input"
                  >
                    {FONTS.map((f) => <option key={f} value={f}>{f}</option>)}
                  </select>
                </Field>
                <div className="grid grid-cols-3 gap-2">
                  <ToggleBtn
                    active={(selected as fabric.IText).fontWeight === "bold" || (selected as fabric.IText).fontWeight === "700"}
                    onClick={() => updateSelected({ fontWeight: ((selected as fabric.IText).fontWeight === "bold" || (selected as fabric.IText).fontWeight === "700") ? "normal" : "bold" })}
                  >
                    <Bold className="h-4 w-4" />
                  </ToggleBtn>
                  <ToggleBtn
                    active={(selected as fabric.IText).fontStyle === "italic"}
                    onClick={() => updateSelected({ fontStyle: (selected as fabric.IText).fontStyle === "italic" ? "normal" : "italic" })}
                  >
                    <Italic className="h-4 w-4" />
                  </ToggleBtn>
                  <ToggleBtn
                    active={!!(selected as fabric.IText).underline}
                    onClick={() => updateSelected({ underline: !(selected as fabric.IText).underline })}
                  >
                    <Underline className="h-4 w-4" />
                  </ToggleBtn>
                </div>
                <Field label="Alignment">
                  <div className="grid grid-cols-3 gap-2">
                    {(["left", "center", "right"] as const).map((a) => {
                      const Icon = a === "left" ? AlignLeft : a === "center" ? AlignCenter : AlignRight;
                      return (
                        <ToggleBtn
                          key={a}
                          active={((selected as fabric.IText).textAlign ?? "left") === a}
                          onClick={() => updateSelected({ textAlign: a })}
                        >
                          <Icon className="h-4 w-4" />
                        </ToggleBtn>
                      );
                    })}
                  </div>
                </Field>
                <Field label={`Line height — ${((selected as fabric.IText).lineHeight ?? 1.16).toFixed(2)}`}>
                  <SliderNum
                    min={0.5} max={3} step={0.05}
                    value={(selected as fabric.IText).lineHeight ?? 1.16}
                    onChange={(v) => updateSelected({ lineHeight: v })}
                  />
                </Field>
                <Field label="Color">
                  <ColorRow
                    value={((selected as fabric.IText).fill as string) ?? "#000000"}
                    onChange={(c) => updateSelected({ fill: c })}
                  />
                </Field>
              </Group>
            )}

            {selected && selectedIsButton && (
              <Group title="Button">
                <Field label="Label">
                  <input
                    type="text"
                    value={buttonParts.label?.text ?? ""}
                    onChange={(e) => updateButton({ text: e.target.value })}
                    className="ui-input"
                  />
                </Field>
                <Field label={`Radius — ${((selected as fabric.Group & { data?: ButtonMeta }).data?.radius ?? 12)}px`}>
                  <SliderNum
                    min={0} max={999}
                    value={(selected as fabric.Group & { data?: ButtonMeta }).data?.radius ?? 12}
                    onChange={(v) => updateButton({ radius: v })}
                  />
                </Field>
                <Field label="Background">
                  <ColorRow
                    value={(buttonParts.rect?.fill as string) ?? "#3b82f6"}
                    onChange={(c) => updateButton({ bg: c })}
                  />
                </Field>
                <Field label="Text color">
                  <ColorRow
                    value={(buttonParts.label?.fill as string) ?? "#ffffff"}
                    onChange={(c) => updateButton({ color: c })}
                  />
                </Field>
                <Field label="Font">
                  <select
                    value={(buttonParts.label?.fontFamily as string) ?? "Sora"}
                    onChange={(e) => updateButton({ fontFamily: e.target.value })}
                    className="w-full rounded-md border border-border bg-surface px-2 py-1.5 text-sm"
                  >
                    {FONTS.map((f) => <option key={f} value={f}>{f}</option>)}
                  </select>
                </Field>
              </Group>
            )}

            {selected && selectedIsImage && (
              <Group title="Image">
                <label className="flex cursor-pointer items-center justify-center gap-2 rounded-md border border-dashed border-border bg-surface px-3 py-2 text-xs font-medium text-foreground transition hover:border-primary hover:bg-accent">
                  <ImageIcon className="h-3.5 w-3.5" /> Replace image
                  <input
                    type="file"
                    accept="image/*"
                    className="hidden"
                    onChange={(e) => {
                      const f = e.target.files?.[0];
                      if (!f) return;
                      const fr = new FileReader();
                      fr.onload = () => replaceSelectedImage(fr.result as string);
                      fr.readAsDataURL(f);
                      e.target.value = "";
                    }}
                  />
                </label>
                <button
                  onClick={() => {
                    const url = window.prompt("Paste image URL")?.trim();
                    if (url) replaceSelectedImage(url);
                  }}
                  className="w-full rounded-md border border-border bg-surface px-3 py-2 text-xs text-muted-foreground transition hover:border-primary hover:text-foreground"
                >
                  Replace from URL
                </button>
              </Group>
            )}

            {selected && !isText && !selectedIsButton && !selectedIsImage && "fill" in selected && (
              <Group title="Shape">
                <Field label="Fill">
                  <ColorRow
                    value={(selected.fill as string) ?? "#000000"}
                    onChange={(c) => updateSelected({ fill: c })}
                  />
                </Field>
              </Group>
            )}

            {selected && (
              <Group title="Appearance">
                <Field label={`Opacity — ${Math.round((selected.opacity ?? 1) * 100)}%`}>
                  <SliderNum
                    min={0} max={100}
                    value={(selected.opacity ?? 1) * 100}
                    onChange={(v) => updateSelected({ opacity: v / 100 })}
                  />
                </Field>
              </Group>
            )}
          </div>
        </aside>
        )}
        {!showInspector && (
          <button
            onClick={() => setShowInspector(true)}
            title="Show inspector"
            data-tour="inspector"
            className="absolute right-0 top-1/2 z-10 hidden h-16 w-6 -translate-y-1/2 items-center justify-center rounded-l-md border border-r-0 border-border bg-surface text-muted-foreground shadow-sm transition hover:text-foreground lg:flex"
          >
            <ChevronLeft className="h-4 w-4" />
          </button>
        )}
      </div>

      <style>{`
        .ui-input {
          width: 100%;
          padding: 0.5rem 0.65rem;
          font-size: 0.8125rem;
          border-radius: 0.5rem;
          border: 1px solid var(--color-border);
          background: var(--color-surface);
          color: var(--color-foreground);
          transition: border-color .15s, box-shadow .15s;
        }
        .ui-input:focus {
          outline: none;
          border-color: var(--color-primary);
          box-shadow: 0 0 0 3px color-mix(in oklab, var(--color-primary) 18%, transparent);
        }
      `}</style>

      {showShortcuts && <ShortcutsDialog onClose={() => setShowShortcuts(false)} />}
      {tourStep >= 0 && (
        <TourOverlay
          step={tourStep}
          onNext={() => setTourStep((s) => s + 1)}
          onPrev={() => setTourStep((s) => Math.max(0, s - 1))}
          onDone={() => {
            setTourStep(-1);
            try { window.localStorage.setItem("canvas.tourDone", "1"); } catch {}
          }}
        />
      )}
    </div>
  );
}

function ShortcutsDialog({ onClose }: { onClose: () => void }) {
  const mod = typeof navigator !== "undefined" && /Mac/i.test(navigator.platform) ? "⌘" : "Ctrl";
  const groups: { title: string; items: [string, string][] }[] = [
    {
      title: "Edit",
      items: [
        [`${mod} + Z`, "Undo"],
        [`${mod} + Shift + Z`, "Redo"],
        [`${mod} + C`, "Copy selection"],
        [`${mod} + V`, "Paste"],
        [`${mod} + D`, "Duplicate"],
        ["Delete / Backspace", "Delete selection"],
      ],
    },
    {
      title: "Canvas",
      items: [
        ["Esc", "Deselect / close dialog"],
        ["?", "Toggle this cheatsheet"],
        ["Drag corner", "Resize object"],
        ["Double-click text", "Edit text inline"],
      ],
    },
  ];
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 p-4" onClick={onClose}>
      <div
        className="w-full max-w-lg overflow-hidden rounded-xl border border-border bg-surface shadow-2xl"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-center justify-between border-b border-border px-5 py-3">
          <div className="flex items-center gap-2">
            <Keyboard className="h-4 w-4 text-primary" />
            <h3 className="font-display text-sm font-semibold">Keyboard shortcuts</h3>
          </div>
          <button
            onClick={onClose}
            className="rounded-md p-1 text-muted-foreground hover:bg-accent hover:text-foreground"
          >
            <X className="h-4 w-4" />
          </button>
        </div>
        <div className="grid gap-5 p-5 sm:grid-cols-2">
          {groups.map((g) => (
            <div key={g.title}>
              <div className="mb-2 text-[10px] font-semibold uppercase tracking-wider text-muted-foreground">
                {g.title}
              </div>
              <ul className="space-y-1.5">
                {g.items.map(([k, v]) => (
                  <li key={k} className="flex items-center justify-between gap-3 text-xs">
                    <span className="text-foreground">{v}</span>
                    <kbd className="rounded-md border border-border bg-background px-1.5 py-0.5 font-mono text-[10px] text-muted-foreground">
                      {k}
                    </kbd>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>
        <div className="border-t border-border bg-background/50 px-5 py-2.5 text-[11px] text-muted-foreground">
          Press <kbd className="rounded border border-border bg-surface px-1 font-mono">?</kbd> anywhere to open this panel.
        </div>
      </div>
    </div>
  );
}

const TOUR_STEPS: { title: string; body: string; target: string | null }[] = [
  {
    title: "Welcome!",
    body: "Let's take a quick walk through everything you can do here. It only takes a minute — and you can replay this tour anytime by clicking the ? button up top.",
    target: null,
  },
  {
    title: "Templates — start with a ready-made design",
    body: "Not sure where to begin? Pick a done-for-you design like an Instagram post, YouTube thumbnail, or a Facebook cover. Just click one and it appears on your canvas, ready for you to edit. You can also save your own designs here to reuse later.",
    target: '[data-tour="templates"]',
  },
  {
    title: "Assets — decorate with logos and shapes",
    body: "Add simple decorations like circles, squares, and sample logos to make your design more interesting. Think of these as stickers you can place anywhere.",
    target: '[data-tour="assets"]',
  },
  {
    title: "Text — add words to your design",
    body: "Add a big headline, a paragraph, or a nice-looking button that says something like 'Buy now' or 'Learn more'. Pick from filled or outlined button styles.",
    target: '[data-tour="text"]',
  },
  {
    title: "Uploads — bring your own photos",
    body: "Have a photo, logo, or image on your computer? Upload it here and drop it onto your design. Your uploads stay available while you work.",
    target: '[data-tour="uploads"]',
  },
  {
    title: "Background — set the color or photo behind everything",
    body: "Change the color behind your design, or use one of your photos as a background. It's like choosing the wall color before you hang up pictures.",
    target: '[data-tour="background"]',
  },
  {
    title: "Batch — one design, every size at once",
    body: "Say you made an Instagram post but also need a story, a YouTube thumbnail, and a Facebook banner from the same design. Batch does that for you — pick the sizes you want (or type your own), and it creates all of them at once so you can download each one. No redoing your work.",
    target: '[data-tour="batch"]',
  },
  {
    title: "Inspector — change what you've selected",
    body: "Click anything on your design and its options show up here — text, color, size, position, and more. Need more room? Hide this panel with the arrow, then reopen it with the little tab on the right edge.",
    target: '[data-tour="inspector"]',
  },
  {
    title: "Canvas size, gridlines & download",
    body: "Up here you can resize your canvas (like switching from a square to a wide banner), turn on gridlines to help line things up, and download your finished design as an image file.",
    target: '[data-tour="header"]',
  },
  {
    title: "Shortcuts and help",
    body: "Click the keyboard icon (or press ?) to see handy shortcuts like undo, copy, and paste. The ? next to it replays this tour anytime.",
    target: '[data-tour="help"]',
  },
];

function TourOverlay({ step, onNext, onPrev, onDone }: { step: number; onNext: () => void; onPrev: () => void; onDone: () => void }) {
  const [rect, setRect] = useState<{ x: number; y: number; w: number; h: number } | null>(null);

  useEffect(() => {
    if (step >= TOUR_STEPS.length) return;
    const s = TOUR_STEPS[step];
    const measure = () => {
      if (!s.target) { setRect(null); return; }
      const el = document.querySelector(s.target) as HTMLElement | null;
      if (!el) { setRect(null); return; }
      const r = el.getBoundingClientRect();
      setRect({ x: r.left, y: r.top, w: r.width, h: r.height });
    };
    measure();
    window.addEventListener("resize", measure);
    window.addEventListener("scroll", measure, true);
    const id = window.setInterval(measure, 400);
    return () => {
      window.removeEventListener("resize", measure);
      window.removeEventListener("scroll", measure, true);
      window.clearInterval(id);
    };
  }, [step]);

  if (step >= TOUR_STEPS.length) { onDone(); return null; }
  const s = TOUR_STEPS[step];
  const isLast = step === TOUR_STEPS.length - 1;

  const vw = typeof window !== "undefined" ? window.innerWidth : 1200;
  const vh = typeof window !== "undefined" ? window.innerHeight : 800;
  const pad = 8;
  const cardW = 340;
  const cardH = 200;

  let cardStyle: React.CSSProperties;
  if (rect) {
    // Prefer right of target, else left, else below
    let left = rect.x + rect.w + 16;
    let top = Math.max(16, rect.y);
    if (left + cardW > vw - 16) left = rect.x - cardW - 16;
    if (left < 16) { left = Math.min(vw - cardW - 16, Math.max(16, rect.x)); top = rect.y + rect.h + 16; }
    if (top + cardH > vh - 16) top = Math.max(16, vh - cardH - 16);
    cardStyle = { left, top };
  } else {
    cardStyle = { left: "50%", top: "50%", transform: "translate(-50%, -50%)" };
  }

  return (
    <div className="pointer-events-none fixed inset-0 z-40">
      {/* Spotlight overlay */}
      <svg className="absolute inset-0 h-full w-full" width={vw} height={vh}>
        <defs>
          <mask id="tour-mask">
            <rect x="0" y="0" width={vw} height={vh} fill="white" />
            {rect && (
              <rect
                x={rect.x - pad}
                y={rect.y - pad}
                width={rect.w + pad * 2}
                height={rect.h + pad * 2}
                rx={10}
                ry={10}
                fill="black"
              />
            )}
          </mask>
        </defs>
        <rect x="0" y="0" width={vw} height={vh} fill="rgba(15,23,42,0.55)" mask="url(#tour-mask)" />
      </svg>

      {/* Highlight ring */}
      {rect && (
        <div
          className="pointer-events-none absolute rounded-[10px] ring-2 ring-primary shadow-[0_0_0_4px_rgba(59,130,246,0.25)] transition-all"
          style={{
            left: rect.x - pad,
            top: rect.y - pad,
            width: rect.w + pad * 2,
            height: rect.h + pad * 2,
          }}
        />
      )}

      {/* Card */}
      <div
        className="pointer-events-auto absolute w-[340px] rounded-xl border border-border bg-surface p-4 shadow-2xl transition-all"
        style={cardStyle}
      >
        <div className="mb-1 flex items-center justify-between">
          <span className="text-[10px] font-semibold uppercase tracking-wider text-primary">
            Step {step + 1} of {TOUR_STEPS.length}
          </span>
          <button
            onClick={onDone}
            className="rounded p-0.5 text-muted-foreground hover:text-foreground"
            title="Skip tour"
          >
            <X className="h-3.5 w-3.5" />
          </button>
        </div>
        <h4 className="font-display text-sm font-semibold">{s.title}</h4>
        <p className="mt-1 text-xs leading-relaxed text-muted-foreground">{s.body}</p>
        <div className="mt-3 flex items-center justify-between gap-2">
          <button onClick={onDone} className="text-[11px] text-muted-foreground hover:text-foreground">
            Skip
          </button>
          <div className="flex items-center gap-2">
            <button
              onClick={onPrev}
              disabled={step === 0}
              className="inline-flex items-center gap-1 rounded-md border border-border bg-surface px-3 py-1.5 text-xs font-medium text-foreground transition hover:bg-accent disabled:cursor-not-allowed disabled:opacity-40"
            >
              <ChevronLeft className="h-3.5 w-3.5" />
              Previous
            </button>
            <button
              onClick={isLast ? onDone : onNext}
              className="inline-flex items-center gap-1 rounded-md bg-primary px-3 py-1.5 text-xs font-medium text-primary-foreground hover:opacity-95"
            >
              {isLast ? "Got it!" : "Next"}
              {!isLast && <ChevronRight className="h-3.5 w-3.5" />}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

/* ---------- small building blocks ---------- */

function RailBtn({
  icon, label, active, onClick,
}: { icon: React.ReactNode; label: string; active?: boolean; onClick: () => void }) {
  return (
    <button
      onClick={onClick}
      title={label}
      data-tour={label.toLowerCase()}
      className={`group flex h-14 w-12 flex-col items-center justify-center gap-1 rounded-lg transition ${
        active
          ? "bg-accent text-primary"
          : "text-muted-foreground hover:bg-accent/60 hover:text-foreground"
      }`}
    >
      {icon}
      <span className="text-[10px] font-medium">{label}</span>
    </button>
  );
}

function SizeMenu({
  size, setSize, currentLabel,
}: { size: { w: number; h: number }; setSize: (s: { w: number; h: number }) => void; currentLabel: string }) {
  const [open, setOpen] = useState(false);
  const [draftW, setDraftW] = useState(size.w);
  const [draftH, setDraftH] = useState(size.h);
  useEffect(() => { setDraftW(size.w); setDraftH(size.h); }, [size.w, size.h]);
  const dirty = draftW !== size.w || draftH !== size.h;
  const apply = () => {
    const w = Math.max(50, Math.min(8000, Math.round(draftW) || 0));
    const h = Math.max(50, Math.min(8000, Math.round(draftH) || 0));
    setSize({ w, h });
    setOpen(false);
  };
  return (
    <div className="relative">
      <button
        onClick={() => setOpen((v) => !v)}
        className="inline-flex items-center gap-2 rounded-md border border-border bg-surface px-3 py-1.5 text-xs font-medium text-foreground hover:bg-accent"
      >
        <span>{currentLabel}</span>
        <span className="text-muted-foreground">{size.w}×{size.h}</span>
        <ChevronDown className="h-3.5 w-3.5 text-muted-foreground" />
      </button>
      {open && (
        <>
          <div className="fixed inset-0 z-10" onClick={() => setOpen(false)} />
          <div className="absolute right-0 z-20 mt-1 w-64 overflow-hidden rounded-lg border border-border bg-popover shadow-lg">
            <ul className="max-h-64 overflow-y-auto py-1 text-xs">
              {PRESETS.map((p) => {
                const active = p.w === size.w && p.h === size.h;
                return (
                  <li key={p.label}>
                    <button
                      onClick={() => { setSize({ w: p.w, h: p.h }); setOpen(false); }}
                      className={`flex w-full items-center justify-between px-3 py-2 hover:bg-accent ${active ? "text-primary" : ""}`}
                    >
                      <span>{p.label}</span>
                      <span className="text-muted-foreground">{p.w}×{p.h}</span>
                    </button>
                  </li>
                );
              })}
            </ul>
            <div className="space-y-2 border-t border-border p-2">
              <div className="text-[10px] font-medium uppercase tracking-wide text-muted-foreground">Custom size</div>
              <div className="grid grid-cols-2 gap-2">
                <label className="text-[10px] text-muted-foreground">
                  Width
                  <input
                    type="number" min={50} max={8000} value={draftW}
                    onChange={(e) => setDraftW(Number(e.target.value) || 0)}
                    onKeyDown={(e) => { if (e.key === "Enter") apply(); }}
                    className="ui-input mt-1"
                  />
                </label>
                <label className="text-[10px] text-muted-foreground">
                  Height
                  <input
                    type="number" min={50} max={8000} value={draftH}
                    onChange={(e) => setDraftH(Number(e.target.value) || 0)}
                    onKeyDown={(e) => { if (e.key === "Enter") apply(); }}
                    className="ui-input mt-1"
                  />
                </label>
              </div>
              <button
                onClick={apply}
                disabled={!dirty}
                className="w-full rounded-md bg-primary px-3 py-1.5 text-xs font-medium text-primary-foreground shadow-sm transition hover:opacity-95 disabled:cursor-not-allowed disabled:opacity-40"
              >
                Apply
              </button>
            </div>
          </div>
        </>
      )}
    </div>
  );
}

/* ---------- panels ---------- */

const TEMPLATES: { id: string; label: string; preview: React.ReactNode }[] = [
  { id: "quote", label: "Quote card", preview: <div className="flex h-full items-center justify-center bg-slate-900 text-[10px] italic text-slate-100">"quote"</div> },
  { id: "sale", label: "Sale banner", preview: <div className="flex h-full items-center justify-center bg-yellow-300 text-xs font-black text-black">50%</div> },
  { id: "event", label: "Event poster", preview: <div className="flex h-full flex-col items-center justify-center bg-indigo-950 text-[9px] font-black leading-tight text-white">CONF<span className="text-amber-400">26</span></div> },
  { id: "minimal", label: "Minimal cover", preview: <div className="flex h-full flex-col justify-end bg-stone-100 p-1 text-[8px] font-bold text-stone-900">Notes</div> },
];

function TemplatesPanel({
  onPick,
  custom,
  onPickCustom,
  onSaveCurrent,
  onDeleteCustom,
}: {
  onPick: (id: string) => void;
  custom: CustomTemplate[];
  onPickCustom: (tpl: CustomTemplate) => void;
  onSaveCurrent: () => void;
  onDeleteCustom: (id: string) => void;
}) {
  return (
    <div className="space-y-5">
      <button
        onClick={onSaveCurrent}
        className="flex w-full items-center justify-center gap-1.5 rounded-md border border-dashed border-border bg-surface px-3 py-2.5 text-xs font-medium text-foreground transition hover:border-primary hover:bg-accent"
      >
        + Save current as template
      </button>

      {custom.length > 0 && (
        <div>
          <PanelHeading>Your templates</PanelHeading>
          <div className="grid grid-cols-2 gap-3">
            {custom.map((t) => (
              <div
                key={t.id}
                className="group relative overflow-hidden rounded-lg border border-border bg-surface transition hover:border-primary hover:shadow-sm"
              >
                <button onClick={() => onPickCustom(t)} className="block w-full text-left">
                  <div
                    className="w-full overflow-hidden bg-muted"
                    style={{ aspectRatio: `${t.w} / ${t.h}`, maxHeight: 160 }}
                  >
                    <img src={t.thumb} alt={t.name} className="h-full w-full object-cover" />
                  </div>
                  <div className="border-t border-border px-2 py-1.5 text-[11px] font-medium">
                    {t.name}
                  </div>
                </button>
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    if (window.confirm(`Delete "${t.name}"?`)) onDeleteCustom(t.id);
                  }}
                  className="absolute right-1.5 top-1.5 rounded-md bg-background/90 p-1 text-muted-foreground opacity-0 shadow-sm transition hover:text-destructive group-hover:opacity-100"
                  aria-label="Delete template"
                >
                  <Trash2 className="h-3.5 w-3.5" />
                </button>
              </div>
            ))}
          </div>
        </div>
      )}

      <div>
        <PanelHeading>Starter templates</PanelHeading>
        <div className="grid grid-cols-2 gap-3">
          {TEMPLATES.map((t) => (
            <button
              key={t.id}
              onClick={() => onPick(t.id)}
              className="group overflow-hidden rounded-lg border border-border bg-surface transition hover:border-primary hover:shadow-sm"
            >
              <div className="aspect-video w-full">{t.preview}</div>
              <div className="border-t border-border px-2 py-1.5 text-left text-[11px] font-medium">
                {t.label}
              </div>
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}

const SHAPES: { kind: "rect" | "circle" | "triangle" | "star" | "line"; label: string }[] = [
  { kind: "rect", label: "▭" },
  { kind: "circle", label: "●" },
  { kind: "triangle", label: "▲" },
  { kind: "star", label: "★" },
  { kind: "line", label: "─" },
];

const STICKERS = ["✨","🔥","💡","❤️","⭐","🎉","👉","✅","⚡","🌟","💬","🎯"];

const LOGOS_STORAGE_KEY = "canvas.logos.v1";
const DEFAULT_LOGOS: { id: string; name: string; url: string }[] = [
  {
    id: "indigo-1",
    name: "IndiGo",
    url: "https://upload.wikimedia.org/wikipedia/commons/thumb/1/1d/IndiGo_Airlines_logo.svg/2560px-IndiGo_Airlines_logo.svg.png",
  },
  {
    id: "indigo-2",
    name: "IndiGo Tail",
    url: "https://upload.wikimedia.org/wikipedia/commons/thumb/8/85/IndiGo_logo.svg/2048px-IndiGo_logo.svg.png",
  },
];

function AssetsPanel({
  onAddLogo,
}: {
  onAddLogo: (url: string) => void;
}) {
  const [logos, setLogos] = useState<{ id: string; name: string; url: string }[]>(() => {
    if (typeof window === "undefined") return DEFAULT_LOGOS;
    try {
      const raw = localStorage.getItem(LOGOS_STORAGE_KEY);
      if (!raw) return DEFAULT_LOGOS;
      const parsed = JSON.parse(raw);
      return Array.isArray(parsed) && parsed.length ? parsed : DEFAULT_LOGOS;
    } catch {
      return DEFAULT_LOGOS;
    }
  });

  const persist = (next: typeof logos) => {
    setLogos(next);
    try {
      localStorage.setItem(LOGOS_STORAGE_KEY, JSON.stringify(next));
    } catch {
      // ignore quota errors
    }
  };

  const addLogoFromUrl = () => {
    const url = window.prompt("Paste image URL (PNG / SVG / JPG)")?.trim();
    if (!url) return;
    const name = window.prompt("Name this logo", "Logo")?.trim() || "Logo";
    const next = [{ id: `logo-${Date.now()}`, name, url }, ...logos];
    persist(next);
  };

  const uploadLogo = (file: File) => {
    const reader = new FileReader();
    reader.onload = () => {
      const dataUrl = reader.result as string;
      const name = file.name.replace(/\.[^.]+$/, "") || "Logo";
      const next = [{ id: `logo-${Date.now()}`, name, url: dataUrl }, ...logos];
      persist(next);
    };
    reader.onerror = () => alert("Couldn't read that file.");
    reader.readAsDataURL(file);
  };

  const remove = (id: string) => {
    persist(logos.filter((l) => l.id !== id));
  };

  return (
    <div className="space-y-5">
      <div>
        <PanelHeading>Logos & Icons</PanelHeading>
        <div className="grid grid-cols-3 gap-2">
          {logos.map((l) => (
            <div key={l.id} className="group relative">
              <button
                onClick={() => onAddLogo(l.url)}
                title={l.name}
                className="flex aspect-square w-full items-center justify-center rounded-lg border border-border bg-surface p-2 transition hover:border-primary hover:bg-accent"
              >
                <img src={l.url} alt={l.name} className="max-h-full max-w-full object-contain" />
              </button>
              <button
                onClick={() => remove(l.id)}
                className="absolute -right-1 -top-1 hidden h-5 w-5 items-center justify-center rounded-full bg-foreground text-[10px] text-background group-hover:flex"
                aria-label={`Remove ${l.name}`}
              >
                ×
              </button>
            </div>
          ))}
          <label
            className="flex aspect-square cursor-pointer items-center justify-center rounded-lg border border-dashed border-border bg-surface text-2xl text-muted-foreground transition hover:border-primary hover:text-primary"
            aria-label="Upload logo"
            title="Upload from device"
          >
            +
            <input
              type="file"
              accept="image/*"
              className="hidden"
              onChange={(e) => {
                const f = e.target.files?.[0];
                if (f) uploadLogo(f);
                e.target.value = "";
              }}
            />
          </label>
        </div>
        <button
          onClick={addLogoFromUrl}
          className="mt-2 w-full rounded-lg border border-border bg-surface px-3 py-2 text-xs text-muted-foreground transition hover:border-primary hover:text-foreground"
        >
          + Add from URL
        </button>
        <p className="mt-2 text-[11px] text-muted-foreground">Saved locally to your browser.</p>
      </div>
    </div>
  );
}

function TextPanel({
  onAdd,
  onButton,
}: {
  onAdd: (kind: "heading" | "sub" | "body") => void;
  onButton: (variant: "solid" | "outline") => void;
}) {
  const items: { kind: "heading" | "sub" | "body"; label: string; sub: string; cls: string }[] = [
    { kind: "heading", label: "Add a headline", sub: "Bauhaus Std · 96 · Bold", cls: "text-2xl font-bold" },
    { kind: "sub", label: "Add a subheading", sub: "Bauhaus Std · 56 · Semibold", cls: "text-lg font-semibold" },
    { kind: "body", label: "Add body text", sub: "Poppins · 32 · Regular", cls: "text-sm" },
  ];
  return (
    <div className="space-y-5">
      <div className="space-y-2">
        {items.map((it) => (
          <button
            key={it.kind}
            onClick={() => onAdd(it.kind)}
            className="w-full rounded-lg border border-border bg-surface p-3 text-left transition hover:border-primary hover:bg-accent"
          >
            <div className={`font-display ${it.cls}`}>{it.label}</div>
            <div className="mt-0.5 text-[11px] text-muted-foreground">{it.sub}</div>
          </button>
        ))}
      </div>
      <div>
        <PanelHeading>Buttons</PanelHeading>
        <div className="grid grid-cols-2 gap-2">
          <button
            onClick={() => onButton("solid")}
            className="flex flex-col items-center gap-2 rounded-lg border border-border bg-surface p-3 transition hover:border-primary hover:bg-accent"
          >
            <span className="rounded-full bg-primary px-4 py-1.5 text-[11px] font-semibold text-primary-foreground">
              Click me
            </span>
            <span className="text-[11px] text-muted-foreground">Solid</span>
          </button>
          <button
            onClick={() => onButton("outline")}
            className="flex flex-col items-center gap-2 rounded-lg border border-border bg-surface p-3 transition hover:border-primary hover:bg-accent"
          >
            <span className="rounded-full border-2 border-primary px-4 py-1 text-[11px] font-semibold text-primary">
              Click me
            </span>
            <span className="text-[11px] text-muted-foreground">Outline</span>
          </button>
        </div>
      </div>
    </div>
  );
}

const UPLOADS_STORAGE_KEY = "canvas.uploads.v1";

function UploadsPanel({ onAdd }: { onAdd: (url: string) => void }) {
  const [items, setItems] = useState<{ id: string; name: string; url: string }[]>(() => {
    if (typeof window === "undefined") return [];
    try {
      const raw = localStorage.getItem(UPLOADS_STORAGE_KEY);
      return raw ? (JSON.parse(raw) as { id: string; name: string; url: string }[]) : [];
    } catch {
      return [];
    }
  });

  const persist = (next: typeof items) => {
    setItems(next);
    try {
      localStorage.setItem(UPLOADS_STORAGE_KEY, JSON.stringify(next));
    } catch {
      alert("Storage is full — remove some uploads to add more.");
    }
  };

  const handleFile = (file: File) => {
    const reader = new FileReader();
    reader.onload = () => {
      const dataUrl = reader.result as string;
      const name = file.name.replace(/\.[^.]+$/, "") || "Image";
      const next = [{ id: `up-${Date.now()}`, name, url: dataUrl }, ...items];
      persist(next);
      onAdd(dataUrl);
    };
    reader.onerror = () => alert("Couldn't read that file.");
    reader.readAsDataURL(file);
  };

  const remove = (id: string) => persist(items.filter((i) => i.id !== id));

  return (
    <div className="space-y-4">
      <label className="flex cursor-pointer flex-col items-center justify-center gap-2 rounded-lg border border-dashed border-border bg-surface p-6 text-center transition hover:border-primary hover:bg-accent">
        <ImageIcon className="h-6 w-6 text-muted-foreground" />
        <div className="font-display text-sm font-semibold">Upload an image</div>
        <div className="text-[11px] text-muted-foreground">PNG, JPG, or SVG</div>
        <input
          type="file" accept="image/*" className="hidden"
          onChange={(e) => {
            const f = e.target.files?.[0];
            if (f) handleFile(f);
            e.target.value = "";
          }}
        />
      </label>

      <div>
        <PanelHeading>Your uploads</PanelHeading>
        {items.length === 0 ? (
          <div className="rounded-lg border border-dashed border-border p-4 text-center text-[11px] text-muted-foreground">
            Uploaded images appear here and are saved on this device.
          </div>
        ) : (
          <div className="grid grid-cols-3 gap-2">
            {items.map((it) => (
              <div key={it.id} className="group relative">
                <button
                  onClick={() => onAdd(it.url)}
                  title={`Add ${it.name}`}
                  className="flex aspect-square w-full items-center justify-center overflow-hidden rounded-md border border-border bg-surface p-1 transition hover:border-primary hover:bg-accent"
                >
                  <img src={it.url} alt={it.name} className="max-h-full max-w-full object-contain" />
                </button>
                <button
                  onClick={() => remove(it.id)}
                  className="absolute -right-1 -top-1 hidden h-5 w-5 items-center justify-center rounded-full border border-border bg-background text-[10px] text-muted-foreground shadow-sm group-hover:flex hover:text-destructive"
                  title="Remove"
                >
                  ×
                </button>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

function BackgroundPanel({
  onColor, onImage,
}: { onColor: (c: string) => void; onImage: (f: File) => void }) {
  return (
    <div className="space-y-5">
      <div>
        <PanelHeading>Solid color</PanelHeading>
        <div className="grid grid-cols-6 gap-2">
          {BG_SWATCHES.map((c) => (
            <button
              key={c}
              onClick={() => onColor(c)}
              className="aspect-square rounded-md border border-border ring-offset-2 transition hover:ring-2 hover:ring-primary"
              style={{ background: c }}
              title={c}
            />
          ))}
        </div>
        <label className="mt-3 flex cursor-pointer items-center justify-between rounded-lg border border-border p-2 text-xs hover:bg-accent">
          <span>Custom color</span>
          <input
            type="color" onChange={(e) => onColor(e.target.value)}
            className="h-6 w-10 cursor-pointer rounded border border-border bg-transparent"
          />
        </label>
      </div>
      <div>
        <PanelHeading>Background image</PanelHeading>
        <label className="flex cursor-pointer flex-col items-center justify-center gap-1 rounded-lg border border-dashed border-border p-4 text-center text-xs hover:border-primary hover:bg-accent">
          <ImageIcon className="h-5 w-5 text-muted-foreground" />
          <span className="font-medium">Upload background</span>
          <input
            type="file" accept="image/*" className="hidden"
            onChange={(e) => e.target.files?.[0] && onImage(e.target.files[0])}
          />
        </label>
      </div>
    </div>
  );
}

/* ---------- inspector primitives ---------- */

function Group({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <div className="space-y-3">
      <PanelHeading>{title}</PanelHeading>
      <div className="space-y-3">{children}</div>
    </div>
  );
}

function PanelHeading({ children }: { children: React.ReactNode }) {
  return (
    <h3 className="mb-2 text-[10px] font-semibold uppercase tracking-[0.14em] text-muted-foreground">
      {children}
    </h3>
  );
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div className="space-y-1.5">
      <label className="text-[11px] font-medium text-muted-foreground">{label}</label>
      {children}
    </div>
  );
}

function SliderNum({
  value, min, max, step = 1, onChange,
}: { value: number; min: number; max: number; step?: number; onChange: (v: number) => void }) {
  return (
    <div className="flex items-center gap-2">
      <input
        type="range" min={min} max={max} step={step} value={value}
        onChange={(e) => onChange(Number(e.target.value))}
        className="flex-1 accent-primary"
      />
      <input
        type="number" min={min} max={max} step={step} value={value}
        onChange={(e) => onChange(Number(e.target.value))}
        className="ui-input w-16"
      />
    </div>
  );
}

function ToggleBtn({
  active, onClick, children,
}: { active?: boolean; onClick: () => void; children: React.ReactNode }) {
  return (
    <button
      onClick={onClick}
      className={`flex h-9 items-center justify-center rounded-md border text-sm transition ${
        active
          ? "border-primary bg-primary/10 text-primary"
          : "border-border bg-surface text-foreground hover:bg-accent"
      }`}
    >
      {children}
    </button>
  );
}

const QUICK_COLORS = ["#000000","#ffffff","#3b82f6","#ef4444","#10b981","#f59e0b","#a78bfa","#f472b6"];

function ColorRow({ value, onChange }: { value: string; onChange: (c: string) => void }) {
  return (
    <div className="flex items-center gap-2">
      <label
        className="relative h-8 w-8 shrink-0 cursor-pointer overflow-hidden rounded-md border border-border"
        style={{ background: value }}
      >
        <input
          type="color"
          value={typeof value === "string" && value.startsWith("#") ? value : "#000000"}
          onChange={(e) => onChange(e.target.value)}
          className="absolute inset-0 h-full w-full cursor-pointer opacity-0"
        />
      </label>
      <div className="flex flex-1 flex-wrap gap-1">
        {QUICK_COLORS.map((c) => (
          <button
            key={c}
            onClick={() => onChange(c)}
            className="h-6 w-6 rounded border border-border transition hover:scale-110"
            style={{ background: c }}
          />
        ))}
      </div>
    </div>
  );
}

type Ratio = { id: string; label: string; w: number; h: number };
const BATCH_RATIOS: Ratio[] = [
  { id: "1x1", label: "Square 1:1", w: 1080, h: 1080 },
  { id: "4x5", label: "Portrait 4:5", w: 1080, h: 1350 },
  { id: "9x16", label: "Story 9:16", w: 1080, h: 1920 },
  { id: "16x9", label: "Landscape 16:9", w: 1920, h: 1080 },
  { id: "3x4", label: "Portrait 3:4", w: 1080, h: 1440 },
  { id: "4x3", label: "Landscape 4:3", w: 1440, h: 1080 },
  { id: "191x1", label: "OG 1.91:1", w: 1200, h: 628 },
  { id: "2x3", label: "Poster 2:3", w: 1080, h: 1620 },
];


const BATCH_CUSTOM_KEY = "canvas.batch.custom.v1";

function BatchPanel({
  getCanvasSource,
  onPlaceOnCanvas,
}: {
  getCanvasSource: () => { json: object; w: number; h: number } | null;
  onPlaceOnCanvas: (
    items: {
      label: string;
      w: number;
      h: number;
      sourceJSON: object;
      sourceW: number;
      sourceH: number;
      fit: "cover" | "contain";
      bg: string;
    }[],
  ) => void | Promise<void>;
}) {
  const [source, setSource] = useState<"canvas" | "upload">("canvas");
  const [uploadUrl, setUploadUrl] = useState<string | null>(null);
  const [uploadDims, setUploadDims] = useState<{ w: number; h: number } | null>(null);
  const [uploadName, setUploadName] = useState<string>("image");
  const [customRatios, setCustomRatios] = useState<Ratio[]>(() => {
    if (typeof window === "undefined") return [];
    try {
      const raw = localStorage.getItem(BATCH_CUSTOM_KEY);
      return raw ? (JSON.parse(raw) as Ratio[]) : [];
    } catch {
      return [];
    }
  });
  const allRatios = [...BATCH_RATIOS, ...customRatios];
  const [selected, setSelected] = useState<Set<string>>(
    new Set(["1x1", "4x5", "9x16", "16x9"]),
  );
  const [fit, setFit] = useState<"cover" | "contain">("cover");
  const [bg, setBg] = useState<string>("#ffffff");
  const [wIn, setWIn] = useState<string>("");
  const [hIn, setHIn] = useState<string>("");
  const [busy, setBusy] = useState(false);

  const persistCustom = (next: Ratio[]) => {
    setCustomRatios(next);
    try { localStorage.setItem(BATCH_CUSTOM_KEY, JSON.stringify(next)); } catch {}
  };

  const toggle = (id: string) => {
    setSelected((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id); else next.add(id);
      return next;
    });
  };

  const addCustom = () => {
    const w = Math.round(Number(wIn));
    const h = Math.round(Number(hIn));
    if (!w || !h || w < 16 || h < 16 || w > 8000 || h > 8000) {
      alert("Enter width and height between 16 and 8000.");
      return;
    }
    const g = (a: number, b: number): number => (b === 0 ? a : g(b, a % b));
    const d = g(w, h);
    const label = `Custom ${w / d}:${h / d}`;
    const id = `c-${w}x${h}-${Date.now()}`;
    const ratio: Ratio = { id, label, w, h };
    persistCustom([...customRatios, ratio]);
    setSelected((prev) => new Set(prev).add(id));
    setWIn(""); setHIn("");
  };

  const removeCustom = (id: string) => {
    persistCustom(customRatios.filter((r) => r.id !== id));
    setSelected((prev) => {
      const next = new Set(prev);
      next.delete(id);
      return next;
    });
  };

  const handleFile = (file: File) => {
    const reader = new FileReader();
    reader.onload = () => {
      const url = reader.result as string;
      const img = new Image();
      img.onload = () => {
        setUploadUrl(url);
        setUploadDims({ w: img.width, h: img.height });
        setUploadName(file.name.replace(/\.[^.]+$/, "") || "image");
        setSource("upload");
      };
      img.src = url;
    };
    reader.readAsDataURL(file);
  };

  const buildUploadJSON = (url: string, w: number, h: number): object => ({
    version: fabric.version,
    objects: [
      {
        type: "Image",
        src: url,
        left: 0,
        top: 0,
        originX: "left",
        originY: "top",
        width: w,
        height: h,
        scaleX: 1,
        scaleY: 1,
        crossOrigin: "anonymous",
      },
    ],
    background: "#ffffff",
  });

  const generate = async () => {
    if (selected.size === 0) { alert("Pick at least one aspect ratio."); return; }
    let sourceJSON: object;
    let sourceW: number;
    let sourceH: number;
    if (source === "canvas") {
      const src = getCanvasSource();
      if (!src) { alert("No canvas."); return; }
      sourceJSON = src.json;
      sourceW = src.w;
      sourceH = src.h;
    } else {
      if (!uploadUrl || !uploadDims) { alert("Upload an image first."); return; }
      sourceW = uploadDims.w;
      sourceH = uploadDims.h;
      sourceJSON = buildUploadJSON(uploadUrl, sourceW, sourceH);
    }
    setBusy(true);
    try {
      const chosen = allRatios.filter((r) => selected.has(r.id));
      await onPlaceOnCanvas(
        chosen.map((r) => ({
          label: r.label,
          w: r.w,
          h: r.h,
          sourceJSON,
          sourceW,
          sourceH,
          fit,
          bg,
        })),
      );
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="space-y-5">
      <div>
        <PanelHeading>Source</PanelHeading>
        <div className="grid grid-cols-2 gap-2">
          <button
            onClick={() => setSource("canvas")}
            className={`rounded-lg border p-2.5 text-left text-xs transition ${
              source === "canvas" ? "border-primary bg-accent" : "border-border bg-surface hover:border-primary"
            }`}
          >
            <div className="font-semibold text-foreground">Current canvas</div>
            <div className="mt-0.5 text-[10px] text-muted-foreground">Text, buttons, images</div>
          </button>
          <label
            className={`cursor-pointer rounded-lg border p-2.5 text-left text-xs transition ${
              source === "upload" ? "border-primary bg-accent" : "border-border bg-surface hover:border-primary"
            }`}
          >
            <div className="font-semibold text-foreground">Upload</div>
            <div className="mt-0.5 truncate text-[10px] text-muted-foreground">
              {uploadUrl ? uploadName : "PNG, JPG"}
            </div>
            <input
              type="file"
              accept="image/*"
              className="hidden"
              onChange={(e) => {
                const f = e.target.files?.[0];
                if (f) handleFile(f);
                e.target.value = "";
              }}
            />
          </label>
        </div>
      </div>

      <div>
        <PanelHeading>Fit</PanelHeading>
        <div className="grid grid-cols-2 gap-2">
          <button
            onClick={() => setFit("cover")}
            className={`rounded-lg border p-2 text-xs transition ${
              fit === "cover" ? "border-primary bg-accent text-foreground" : "border-border bg-surface text-muted-foreground hover:text-foreground"
            }`}
          >
            Cover
          </button>
          <button
            onClick={() => setFit("contain")}
            className={`rounded-lg border p-2 text-xs transition ${
              fit === "contain" ? "border-primary bg-accent text-foreground" : "border-border bg-surface text-muted-foreground hover:text-foreground"
            }`}
          >
            Contain
          </button>
        </div>
        {fit === "contain" && (
          <label className="mt-2 flex items-center justify-between rounded-lg border border-border bg-background px-3 py-2 text-xs">
            <span className="text-muted-foreground">Background</span>
            <input type="color" value={bg} onChange={(e) => setBg(e.target.value)} className="h-6 w-10 cursor-pointer rounded border-0 bg-transparent p-0" />
          </label>
        )}
      </div>

      <div>
        <div className="mb-2 flex items-center justify-between">
          <PanelHeading>Aspect ratios</PanelHeading>
          <button
            onClick={() =>
              setSelected(selected.size === allRatios.length ? new Set() : new Set(allRatios.map((r) => r.id)))
            }
            className="text-[10px] text-primary hover:underline"
          >
            {selected.size === allRatios.length ? "Clear" : "All"}
          </button>
        </div>
        <div className="space-y-1.5">
          {allRatios.map((r) => {
            const active = selected.has(r.id);
            const isCustom = r.id.startsWith("c-");
            return (
              <div
                key={r.id}
                className={`group flex items-center gap-2 rounded-lg border p-2 text-xs transition ${
                  active ? "border-primary bg-accent" : "border-border bg-surface"
                }`}
              >
                <button onClick={() => toggle(r.id)} className="flex flex-1 items-center gap-2 text-left">
                  <div
                    className="shrink-0 rounded-sm border border-border bg-background"
                    style={{
                      width: 22,
                      height: Math.max(6, Math.min(28, 22 * (r.h / r.w))),
                    }}
                  />
                  <div className="min-w-0 flex-1">
                    <div className="truncate font-semibold text-foreground">{r.label}</div>
                    <div className="text-[10px] text-muted-foreground">{r.w}×{r.h}</div>
                  </div>
                  <input
                    type="checkbox"
                    checked={active}
                    readOnly
                    className="h-3.5 w-3.5 accent-primary"
                  />
                </button>
                {isCustom && (
                  <button
                    onClick={() => removeCustom(r.id)}
                    className="rounded p-1 text-muted-foreground opacity-0 transition group-hover:opacity-100 hover:text-destructive"
                    aria-label="Remove"
                  >
                    <X className="h-3 w-3" />
                  </button>
                )}
              </div>
            );
          })}
        </div>
      </div>

      <div>
        <PanelHeading>Add custom</PanelHeading>
        <div className="flex items-center gap-1.5">
          <input
            type="number"
            min={16}
            placeholder="W"
            value={wIn}
            onChange={(e) => setWIn(e.target.value)}
            className="ui-input"
          />
          <span className="text-muted-foreground">×</span>
          <input
            type="number"
            min={16}
            placeholder="H"
            value={hIn}
            onChange={(e) => setHIn(e.target.value)}
            className="ui-input"
          />
          <button
            onClick={addCustom}
            className="shrink-0 rounded-md bg-primary px-2.5 py-1.5 text-xs font-medium text-primary-foreground hover:opacity-95"
          >
            Add
          </button>
        </div>
        <p className="mt-1.5 text-[10px] text-muted-foreground">e.g. 1200 × 630 for OG. Saved locally.</p>
      </div>

      <button
        onClick={generate}
        disabled={busy}
        className="inline-flex w-full items-center justify-center gap-1.5 rounded-md bg-primary px-3.5 py-2 text-xs font-medium text-primary-foreground shadow-sm transition hover:opacity-95 disabled:opacity-60"
      >
        {busy ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Images className="h-3.5 w-3.5" />}
        {busy ? "Generating…" : `Generate ${selected.size}`}
      </button>
      <p className="text-[10px] text-muted-foreground">
        Each ratio opens as its own editable frame on the board — you can tweak text, images and buttons per frame before downloading.
      </p>
    </div>
  );
}

/* ---------- FrameCanvas: one independent fabric.Canvas per batch frame ---------- */

function FrameCanvas({
  frame,
  active,
  onReady,
  onActivate,
  onDownload,
}: {
  frame: BoardFrame;
  active: boolean;
  onReady: (id: string, canvas: fabric.Canvas) => void;
  onActivate: (id: string) => void;
  onDownload: () => void;
}) {
  const elRef = useRef<HTMLCanvasElement>(null);
  const fabricRef = useRef<fabric.Canvas | null>(null);
  // Cap the on-screen size so frames stay manageable while the fabric canvas
  // keeps working at target resolution.
  const maxDim = 640;
  const s = Math.min(maxDim / frame.w, maxDim / frame.h, 1);
  const dispW = Math.round(frame.w * s);
  const dispH = Math.round(frame.h * s);

  useEffect(() => {
    if (!elRef.current) return;
    const canvas = new fabric.Canvas(elRef.current, {
      width: frame.w,
      height: frame.h,
      backgroundColor: frame.fit === "contain" ? frame.bg || "#ffffff" : "#ffffff",
    });
    canvas.setDimensions(
      { width: `${dispW}px`, height: `${dispH}px` },
      { cssOnly: true },
    );
    fabricRef.current = canvas;

    const scale =
      frame.fit === "cover"
        ? Math.max(frame.w / frame.sourceW, frame.h / frame.sourceH)
        : Math.min(frame.w / frame.sourceW, frame.h / frame.sourceH);
    const offsetX = (frame.w - frame.sourceW * scale) / 2;
    const offsetY = (frame.h - frame.sourceH * scale) / 2;

    // Deep-clone the JSON — fabric mutates the object graph during
    // deserialization, so sharing the same reference across frames causes
    // later frames to lose images and other nested content.
    const jsonCopy = JSON.parse(JSON.stringify(frame.sourceJSON));

    (canvas as unknown as {
      loadFromJSON: (j: object, cb?: () => void) => Promise<fabric.Canvas>;
    })
      .loadFromJSON(jsonCopy)
      .then(() => {
        // Preserve the source background color unless the user picked one
        // explicitly via "Contain" fit.
        if (frame.fit === "contain") {
          canvas.backgroundColor = frame.bg || "#ffffff";
        }
        canvas.getObjects().forEach((o) => {
          const left = (o.left ?? 0) * scale + offsetX;
          const top = (o.top ?? 0) * scale + offsetY;
          o.set({
            left,
            top,
            scaleX: (o.scaleX ?? 1) * scale,
            scaleY: (o.scaleY ?? 1) * scale,
          });
          o.setCoords();
        });
        if (canvas.backgroundImage) {
          const bg = canvas.backgroundImage as fabric.FabricImage;
          bg.set({
            scaleX: (bg.scaleX ?? 1) * scale,
            scaleY: (bg.scaleY ?? 1) * scale,
            left: (bg.left ?? 0) * scale + offsetX,
            top: (bg.top ?? 0) * scale + offsetY,
          });
        }
        canvas.requestRenderAll();
        // Some image decodes resolve after the promise settles — kick a
        // second render so nothing shows up blank on first paint.
        requestAnimationFrame(() => canvas.requestRenderAll());
      })
      .catch(() => {
        /* ignore load failures */
      });

    onReady(frame.id, canvas);

    return () => {
      canvas.dispose();
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [frame.id]);

  return (
    <div className="shrink-0" onMouseDown={() => onActivate(frame.id)}>
      <div className="mb-2 flex items-center justify-between gap-2">
        <span className="text-xs font-medium text-muted-foreground">{frame.label}</span>
        <div className="flex items-center gap-2">
          <span className="text-[10px] text-muted-foreground/70 tabular-nums">
            {frame.w} × {frame.h}
          </span>
          <button
            onClick={(e) => {
              e.stopPropagation();
              onDownload();
            }}
            className="inline-flex items-center gap-1 rounded border border-border bg-background px-1.5 py-0.5 text-[10px] font-medium text-muted-foreground hover:border-primary hover:text-primary"
            aria-label="Download frame"
          >
            <Download className="h-3 w-3" /> PNG
          </button>
        </div>
      </div>
      <div
        className={
          "rounded-sm bg-white shadow-[0_10px_40px_-10px_rgba(15,23,42,0.25)] ring-1 " +
          (active ? "ring-2 ring-[color:var(--primary)]" : "ring-black/10")
        }
        style={{ width: dispW, height: dispH }}
      >
        <canvas ref={elRef} />
      </div>
    </div>
  );
}
