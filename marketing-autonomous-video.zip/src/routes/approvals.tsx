import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import { CheckCircle2, XCircle, Clock, MessageSquare, ShieldCheck, Filter, ChevronDown } from "lucide-react";
import { AppShell } from "@/components/AppShell";

export const Route = createFileRoute("/approvals")({
  component: ApprovalsPage,
  head: () => ({
    meta: [
      { title: "Approvals — Loom" },
      { name: "description", content: "Superadmin review queue for creatives." },
    ],
  }),
});

export type ApprovalStatus = "pending" | "approved" | "rejected";
export type Approval = {
  id: string;
  image: string;
  prompt: string;
  project: string;
  submittedBy: string;
  submittedAt: number;
  status: ApprovalStatus;
  comment?: string;
  reviewedAt?: number;
  reviewedBy?: string;
};

const KEY = "approvals.queue";

const SEED: Approval[] = [
  {
    id: "a1",
    image: "https://picsum.photos/seed/301/800/800",
    prompt: "Summer flights to Bali — hero image, warm gradient, boarding pass motif",
    project: "Summer sale 2026",
    submittedBy: "Ananya Rao",
    submittedAt: Date.now() - 1000 * 60 * 60 * 3,
    status: "pending",
  },
  {
    id: "a2",
    image: "https://picsum.photos/seed/402/800/800",
    prompt: "FlyMiles loyalty tier upgrade banner, premium gold accents",
    project: "Loyalty Q3",
    submittedBy: "Rohan Kapoor",
    submittedAt: Date.now() - 1000 * 60 * 60 * 26,
    status: "pending",
  },
  {
    id: "a3",
    image: "https://picsum.photos/seed/503/800/800",
    prompt: "Cargo freight campaign, industrial mood, blue palette",
    project: "Cargo push",
    submittedBy: "Meera Shah",
    submittedAt: Date.now() - 1000 * 60 * 60 * 50,
    status: "approved",
    comment: "Great composition, ship it.",
    reviewedAt: Date.now() - 1000 * 60 * 60 * 40,
    reviewedBy: "You",
  },
];

export function loadApprovals(): Approval[] {
  try {
    const raw = localStorage.getItem(KEY);
    if (!raw) return SEED;
    return JSON.parse(raw);
  } catch {
    return SEED;
  }
}
export function saveApprovals(list: Approval[]) {
  localStorage.setItem(KEY, JSON.stringify(list));
}
export function submitForApproval(a: Omit<Approval, "id" | "submittedAt" | "status">) {
  const list = loadApprovals();
  const item: Approval = {
    ...a,
    id: crypto.randomUUID(),
    submittedAt: Date.now(),
    status: "pending",
  };
  saveApprovals([item, ...list]);
  return item;
}

function timeAgo(t: number) {
  const s = Math.floor((Date.now() - t) / 1000);
  if (s < 60) return `${s}s ago`;
  const m = Math.floor(s / 60);
  if (m < 60) return `${m}m ago`;
  const h = Math.floor(m / 60);
  if (h < 24) return `${h}h ago`;
  return `${Math.floor(h / 24)}d ago`;
}

function ApprovalsPage() {
  const [list, setList] = useState<Approval[]>([]);
  const [filter, setFilter] = useState<"pending" | "approved" | "rejected" | "all">("pending");
  const [openId, setOpenId] = useState<string | null>(null);
  const [comments, setComments] = useState<Record<string, string>>({});

  useEffect(() => {
    setList(loadApprovals());
  }, []);

  useEffect(() => {
    if (list.length) saveApprovals(list);
  }, [list]);

  const filtered = useMemo(
    () => (filter === "all" ? list : list.filter((a) => a.status === filter)),
    [list, filter],
  );

  const counts = useMemo(
    () => ({
      pending: list.filter((a) => a.status === "pending").length,
      approved: list.filter((a) => a.status === "approved").length,
      rejected: list.filter((a) => a.status === "rejected").length,
    }),
    [list],
  );

  function decide(id: string, status: ApprovalStatus) {
    const comment = (comments[id] ?? list.find((a) => a.id === id)?.comment ?? "").trim();
    setList((prev) =>
      prev.map((a) =>
        a.id === id
          ? {
              ...a,
              status,
              comment: comment || undefined,
              reviewedAt: Date.now(),
              reviewedBy: "You",
            }
          : a,
      ),
    );
    setOpenId(null);
  }

  return (
    <AppShell>
      <div className="px-6 py-8 max-w-6xl mx-auto flex flex-col gap-6">
        <div className="flex items-center gap-3">
          <div className="size-10 rounded-xl bg-primary/10 text-primary grid place-items-center">
            <ShieldCheck className="size-5" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-2xl font-display font-bold tracking-tight">Approvals</h1>
              <span className="inline-flex items-center gap-1 text-[11px] font-medium px-1.5 py-0.5 rounded-full bg-primary/10 text-primary">
                Superadmin
              </span>
            </div>
            <p className="text-sm text-muted-foreground">
              Review AI-generated creatives before they go live.
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <Filter className="size-4 text-muted-foreground" />
          {(["pending", "approved", "rejected", "all"] as const).map((f) => (
            <button
              key={f}
              onClick={() => setFilter(f)}
              className={`px-3 py-1.5 rounded-full text-xs font-medium capitalize ${
                filter === f
                  ? "bg-primary text-primary-foreground"
                  : "bg-accent text-muted-foreground hover:text-foreground"
              }`}
            >
              {f}
              {f !== "all" && (
                <span className="ml-1.5 opacity-70">{counts[f as keyof typeof counts]}</span>
              )}
            </button>
          ))}
        </div>

        {filtered.length === 0 ? (
          <div className="rounded-2xl border border-border bg-surface p-12 text-center text-sm text-muted-foreground">
            No creatives in this queue.
          </div>
        ) : (
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-3">
            {filtered.map((a) => {
              const open = openId === a.id;
              const comment = comments[a.id] ?? a.comment ?? "";
              return (
                <div
                  key={a.id}
                  className="rounded-xl border border-border bg-surface overflow-hidden flex flex-col"
                >
                  <div className="aspect-square overflow-hidden bg-accent">
                    <img src={a.image} alt="" className="w-full h-full object-cover" />
                  </div>
                  <div className="p-3 flex flex-col gap-1.5">
                    <div className="text-xs font-medium line-clamp-2">{a.prompt}</div>
                    <div className="flex items-center justify-between text-[11px] text-muted-foreground">
                      <span className="truncate">{a.project}</span>
                      <StatusPill status={a.status} />
                    </div>
                    <div className="text-[11px] text-muted-foreground">
                      by {a.submittedBy} · {timeAgo(a.submittedAt)}
                    </div>

                    {!open ? (
                      <button
                        onClick={() => setOpenId(a.id)}
                        className="mt-2 inline-flex items-center justify-center gap-1 px-3 py-1.5 rounded-lg border border-border text-xs font-medium hover:bg-accent"
                      >
                        {a.status === "pending" ? "Take action" : "Review"}
                        <ChevronDown className="size-3.5" />
                      </button>
                    ) : (
                      <div className="mt-2 flex flex-col gap-2">
                        <label className="text-[11px] font-medium text-muted-foreground flex items-center gap-1">
                          <MessageSquare className="size-3" />
                          Comment
                        </label>
                        <textarea
                          value={comment}
                          onChange={(e) =>
                            setComments((c) => ({ ...c, [a.id]: e.target.value }))
                          }
                          placeholder="Leave feedback…"
                          rows={3}
                          className="w-full rounded-lg border border-border bg-background px-2 py-1.5 text-xs outline-none focus:border-primary focus:ring-2 focus:ring-primary/20 resize-none"
                        />
                        {a.status !== "pending" && (
                          <div className="text-[10px] text-muted-foreground">
                            Reviewed {a.reviewedAt ? timeAgo(a.reviewedAt) : ""} by {a.reviewedBy}
                          </div>
                        )}
                        <div className="flex gap-1.5">
                          <button
                            onClick={() => decide(a.id, "rejected")}
                            className="flex-1 inline-flex items-center justify-center gap-1 px-2 py-1.5 rounded-lg border border-border text-xs font-medium hover:bg-rose-50 hover:text-rose-700 hover:border-rose-200 dark:hover:bg-rose-950/30"
                          >
                            <XCircle className="size-3.5" />
                            Reject
                          </button>
                          <button
                            onClick={() => decide(a.id, "approved")}
                            className="flex-1 inline-flex items-center justify-center gap-1 px-2 py-1.5 rounded-lg bg-emerald-600 text-white text-xs font-medium hover:bg-emerald-700"
                          >
                            <CheckCircle2 className="size-3.5" />
                            Approve
                          </button>
                        </div>
                        <button
                          onClick={() => setOpenId(null)}
                          className="text-[11px] text-muted-foreground hover:text-foreground"
                        >
                          Cancel
                        </button>
                      </div>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </AppShell>
  );
}

function StatusPill({ status }: { status: ApprovalStatus }) {
  const map = {
    pending: { icon: Clock, cls: "bg-amber-100 text-amber-800 dark:bg-amber-950/40 dark:text-amber-200" },
    approved: { icon: CheckCircle2, cls: "bg-emerald-100 text-emerald-800 dark:bg-emerald-950/40 dark:text-emerald-200" },
    rejected: { icon: XCircle, cls: "bg-rose-100 text-rose-800 dark:bg-rose-950/40 dark:text-rose-200" },
  } as const;
  const { icon: Icon, cls } = map[status];
  return (
    <span className={`inline-flex items-center gap-1 px-1.5 py-0.5 rounded-full text-[10px] font-medium capitalize ${cls}`}>
      <Icon className="size-2.5" />
      {status}
    </span>
  );
}
