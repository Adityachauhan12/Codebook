import { createFileRoute, Link } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import {
  ArrowDownRight,
  ArrowLeft,
  ArrowUpRight,
  Download,
  Image as ImageIcon,
  Megaphone,
  Search,
  Sparkles,
  Wand2,
  Zap,
} from "lucide-react";
import { AppShell } from "@/components/AppShell";

export const Route = createFileRoute("/settings_/transactions")({
  component: TransactionsPage,
  head: () => ({
    meta: [
      { title: "Credit transactions — Loom" },
      { name: "description", content: "See where your credits are going." },
    ],
  }),
});

type TxnType = "generation" | "edit" | "campaign" | "topup" | "plan";

type Txn = {
  id: string;
  date: string;
  type: TxnType;
  title: string;
  meta: string;
  credits: number; // negative = spend, positive = added
};

const TXNS: Txn[] = [
  { id: "t_2431", date: "2026-07-21 09:12", type: "generation", title: "Studio · Summer sale", meta: "4 images · Photoreal · 1024²", credits: -8 },
  { id: "t_2430", date: "2026-07-21 08:47", type: "edit",       title: "Editor · Bali hero v3", meta: "Masked inpaint · 2048²", credits: -6 },
  { id: "t_2429", date: "2026-07-20 22:04", type: "campaign",   title: "Campaign · Monsoon getaways", meta: "Plan generation + audience research", credits: -14 },
  { id: "t_2428", date: "2026-07-20 18:33", type: "generation", title: "Studio · Festival hotel 24", meta: "8 images · Product · 1:1", credits: -16 },
  { id: "t_2427", date: "2026-07-19 14:21", type: "topup",      title: "Top-up · Studio plan", meta: "Visa ending 4242", credits: +500 },
  { id: "t_2426", date: "2026-07-19 11:02", type: "campaign",   title: "Campaign · Business class Europe", meta: "Launch to Google Ads + Meta", credits: -22 },
  { id: "t_2425", date: "2026-07-18 16:58", type: "edit",       title: "Editor · Batch export", meta: "12 frames · PNG", credits: -12 },
  { id: "t_2424", date: "2026-07-18 09:14", type: "generation", title: "Studio · Diwali special", meta: "6 images · Editorial · 16:9", credits: -12 },
  { id: "t_2423", date: "2026-07-17 20:11", type: "plan",       title: "Monthly credits · Studio plan", meta: "Recurring allowance", credits: +1000 },
  { id: "t_2422", date: "2026-07-17 12:40", type: "campaign",   title: "Campaign · Weekend flash sale", meta: "KPI plan + creative brief", credits: -9 },
  { id: "t_2421", date: "2026-07-16 15:22", type: "generation", title: "Studio · Loyalty push", meta: "3 images · Photoreal · 4:5", credits: -6 },
  { id: "t_2420", date: "2026-07-15 10:05", type: "edit",       title: "Editor · Logo cleanup", meta: "Background remove · 1024²", credits: -3 },
];

const TYPE_META: Record<TxnType, { label: string; icon: typeof Sparkles; color: string }> = {
  generation: { label: "AI generation", icon: Sparkles, color: "#000099" },
  edit:       { label: "AI edit",       icon: Wand2,    color: "#7C3AED" },
  campaign:   { label: "Campaign",      icon: Megaphone,color: "#F97316" },
  topup:      { label: "Top-up",        icon: Zap,      color: "#10B981" },
  plan:       { label: "Plan credit",   icon: Zap,      color: "#10B981" },
};

const FILTERS: { id: "all" | TxnType; label: string }[] = [
  { id: "all", label: "All" },
  { id: "generation", label: "Generations" },
  { id: "edit", label: "Edits" },
  { id: "campaign", label: "Campaigns" },
  { id: "topup", label: "Top-ups" },
];

function TransactionsPage() {
  const [filter, setFilter] = useState<"all" | TxnType>("all");
  const [q, setQ] = useState("");

  const filtered = useMemo(() => {
    return TXNS.filter((t) => {
      if (filter !== "all" && t.type !== filter) return false;
      if (q && !(`${t.title} ${t.meta}`.toLowerCase().includes(q.toLowerCase()))) return false;
      return true;
    });
  }, [filter, q]);

  const totals = useMemo(() => {
    const spent = TXNS.filter((t) => t.credits < 0).reduce((a, t) => a + t.credits, 0);
    const added = TXNS.filter((t) => t.credits > 0).reduce((a, t) => a + t.credits, 0);
    return { spent: Math.abs(spent), added };
  }, []);

  const byType = useMemo(() => {
    const map: Record<string, number> = {};
    for (const t of TXNS) if (t.credits < 0) map[t.type] = (map[t.type] || 0) + Math.abs(t.credits);
    const total = Object.values(map).reduce((a, b) => a + b, 0) || 1;
    return Object.entries(map).map(([k, v]) => ({
      type: k as TxnType,
      credits: v,
      pct: Math.round((v / total) * 100),
    })).sort((a, b) => b.credits - a.credits);
  }, []);

  return (
    <AppShell>
      <div className="px-6 py-8 max-w-5xl mx-auto flex flex-col gap-6">
        <div className="flex items-center gap-3">
          <Link
            to="/settings"
            className="size-9 grid place-items-center rounded-lg border border-border hover:bg-accent"
          >
            <ArrowLeft className="size-4" />
          </Link>
          <div className="flex-1">
            <h1 className="text-2xl font-display font-bold tracking-tight">Credit transactions</h1>
            <p className="text-sm text-muted-foreground">
              Track every credit spent on generations, edits, and campaign launches.
            </p>
          </div>
          <button className="inline-flex items-center gap-1.5 rounded-lg border border-border px-3 py-2 text-sm font-medium hover:bg-accent">
            <Download className="size-4" /> Export CSV
          </button>
        </div>

        {/* Summary */}
        <div className="grid md:grid-cols-3 gap-3">
          <div className="rounded-xl border border-border bg-surface p-5">
            <div className="text-xs text-muted-foreground">Credits balance</div>
            <div className="flex items-baseline gap-2 mt-1">
              <div className="text-3xl font-display font-bold tracking-tight">248</div>
              <div className="text-xs text-muted-foreground">/ 1,000 monthly</div>
            </div>
            <div className="h-1.5 rounded-full bg-accent mt-3 overflow-hidden">
              <div className="h-full bg-primary" style={{ width: "24%" }} />
            </div>
          </div>
          <div className="rounded-xl border border-border bg-surface p-5">
            <div className="text-xs text-muted-foreground flex items-center gap-1">
              <ArrowDownRight className="size-3.5 text-rose-500" /> Spent this cycle
            </div>
            <div className="text-3xl font-display font-bold tracking-tight mt-1">{totals.spent}</div>
            <div className="text-[11px] text-muted-foreground mt-1">Across {TXNS.filter(t => t.credits<0).length} activities</div>
          </div>
          <div className="rounded-xl border border-border bg-surface p-5">
            <div className="text-xs text-muted-foreground flex items-center gap-1">
              <ArrowUpRight className="size-3.5 text-emerald-500" /> Added this cycle
            </div>
            <div className="text-3xl font-display font-bold tracking-tight mt-1">{totals.added}</div>
            <div className="text-[11px] text-muted-foreground mt-1">Plan renewals + top-ups</div>
          </div>
        </div>

        {/* Breakdown */}
        <section className="rounded-xl border border-border bg-surface p-5">
          <div className="flex items-center gap-2 mb-4">
            <ImageIcon className="size-4 text-muted-foreground" />
            <h2 className="text-sm font-display font-bold uppercase tracking-tight">Where credits went</h2>
          </div>
          <div className="flex flex-col gap-3">
            {byType.map((row) => {
              const meta = TYPE_META[row.type];
              const Icon = meta.icon;
              return (
                <div key={row.type} className="flex items-center gap-3">
                  <div
                    className="size-8 rounded-lg grid place-items-center text-white shrink-0"
                    style={{ background: meta.color }}
                  >
                    <Icon className="size-4" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between text-sm mb-1">
                      <span className="font-medium">{meta.label}</span>
                      <span className="text-muted-foreground text-xs">
                        {row.credits} credits · {row.pct}%
                      </span>
                    </div>
                    <div className="h-1.5 rounded-full bg-accent overflow-hidden">
                      <div className="h-full" style={{ width: `${row.pct}%`, background: meta.color }} />
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </section>

        {/* Ledger */}
        <section className="rounded-xl border border-border bg-surface overflow-hidden">
          <div className="flex flex-col md:flex-row md:items-center gap-3 p-4 border-b border-border">
            <div className="flex-1 flex flex-wrap gap-1.5">
              {FILTERS.map((f) => (
                <button
                  key={f.id}
                  onClick={() => setFilter(f.id)}
                  className={`px-3 py-1.5 rounded-full text-xs font-medium transition-colors ${
                    filter === f.id
                      ? "bg-primary text-primary-foreground"
                      : "bg-accent text-muted-foreground hover:text-foreground"
                  }`}
                >
                  {f.label}
                </button>
              ))}
            </div>
            <div className="relative">
              <Search className="size-4 text-muted-foreground absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                value={q}
                onChange={(e) => setQ(e.target.value)}
                placeholder="Search transactions"
                className="pl-9 pr-3 py-2 rounded-lg border border-border bg-background text-sm w-full md:w-64 focus:outline-none focus:ring-2 focus:ring-primary/20"
              />
            </div>
          </div>

          <div className="divide-y divide-border">
            {filtered.length === 0 && (
              <div className="p-8 text-center text-sm text-muted-foreground">
                No transactions match your filters.
              </div>
            )}
            {filtered.map((t) => {
              const meta = TYPE_META[t.type];
              const Icon = meta.icon;
              const positive = t.credits > 0;
              return (
                <div key={t.id} className="flex items-center gap-4 px-4 py-3.5">
                  <div
                    className="size-9 rounded-lg grid place-items-center text-white shrink-0"
                    style={{ background: meta.color }}
                  >
                    <Icon className="size-4" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="text-sm font-medium truncate">{t.title}</div>
                    <div className="text-xs text-muted-foreground truncate">{t.meta}</div>
                  </div>
                  <div className="text-right shrink-0">
                    <div className={`text-sm font-display font-bold tabular-nums ${positive ? "text-emerald-600" : ""}`}>
                      {positive ? "+" : ""}{t.credits}
                    </div>
                    <div className="text-[11px] text-muted-foreground">{t.date}</div>
                  </div>
                </div>
              );
            })}
          </div>
        </section>
      </div>
    </AppShell>
  );
}
