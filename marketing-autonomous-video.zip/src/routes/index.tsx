import { createFileRoute, Link } from "@tanstack/react-router";
import { Sparkles, Megaphone, Palette, TrendingUp, Image as ImageIcon, DollarSign, MousePointerClick, Activity } from "lucide-react";
import { AppShell } from "@/components/AppShell";

export const Route = createFileRoute("/")({
  component: DashboardPage,
  head: () => ({
    meta: [
      { title: "Dashboard — Loom" },
      { name: "description", content: "Your AI creative and marketing command center." },
    ],
  }),
});

const KPIS = [
  { label: "Active campaigns", value: "4", delta: "+1", icon: Megaphone, tone: "text-[var(--primary)]" },
  { label: "Spend this week", value: "$1,842", delta: "+12%", icon: DollarSign, tone: "text-[var(--accent-ai)]" },
  { label: "CTR (avg)", value: "3.4%", delta: "+0.4%", icon: MousePointerClick, tone: "text-[var(--success)]" },
  { label: "Images generated", value: "128", delta: "+23", icon: ImageIcon, tone: "text-[var(--warning)]" },
];

const ACTIONS = [
  {
    to: "/studio",
    title: "Generate an image",
    desc: "Prompt with reference images, edit, and iterate.",
    icon: Sparkles,
    gradient: "from-violet-500/15 to-fuchsia-500/10",
  },
  {
    to: "/campaigns/new",
    title: "Launch a campaign",
    desc: "Describe your goal — we plan, budget, and run it.",
    icon: Megaphone,
    gradient: "from-blue-500/15 to-cyan-500/10",
  },
  {
    to: "/editor",
    title: "Open the editor",
    desc: "Compose posters, posts, and covers on a canvas.",
    icon: Palette,
    gradient: "from-emerald-500/15 to-teal-500/10",
  },
];

const ACTIVITY = [
  { icon: Sparkles, text: "Generated 4 variations for 'Summer flights to Bali hero'", time: "2m ago", tone: "text-[var(--accent-ai)]" },
  { icon: TrendingUp, text: "Meta Reels CTR jumped to 4.8% — shifted 15% budget", time: "1h ago", tone: "text-[var(--success)]" },
  { icon: Megaphone, text: "Campaign 'Back to School' switched to Live", time: "3h ago", tone: "text-[var(--primary)]" },
  { icon: Activity, text: "Google Search added 3 new headlines", time: "yesterday", tone: "text-muted-foreground" },
];

function DashboardPage() {
  return (
    <AppShell>
      <div className="px-8 py-8 max-w-7xl mx-auto space-y-8">
        <div>
          <h1 className="text-3xl font-display font-bold tracking-tight">Welcome back</h1>
          <p className="text-muted-foreground mt-1">Here's what's happening across your workspace.</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {ACTIONS.map((a) => {
            const Icon = a.icon;
            return (
              <Link
                key={a.to}
                to={a.to}
                className={`group relative rounded-2xl border border-border bg-gradient-to-br ${a.gradient} p-5 hover:border-foreground/20 transition-colors`}
              >
                <div className="size-10 rounded-xl bg-surface grid place-items-center shadow-sm border border-border mb-4">
                  <Icon className="size-5" />
                </div>
                <div className="font-semibold">{a.title}</div>
                <div className="text-sm text-muted-foreground mt-1">{a.desc}</div>
              </Link>
            );
          })}
        </div>

        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {KPIS.map((k) => {
            const Icon = k.icon;
            return (
              <div key={k.label} className="rounded-2xl border border-border bg-surface p-5">
                <div className="flex items-center justify-between">
                  <Icon className={`size-4 ${k.tone}`} />
                  <span className="text-xs text-[var(--success)] font-medium">{k.delta}</span>
                </div>
                <div className="mt-3 text-2xl font-display font-bold">{k.value}</div>
                <div className="text-xs text-muted-foreground mt-0.5">{k.label}</div>
              </div>
            );
          })}
        </div>

        <div className="rounded-2xl border border-border bg-surface p-6">
          <div className="flex items-center justify-between mb-4">
            <h2 className="font-display font-semibold">Recent activity</h2>
            <button className="text-xs text-muted-foreground hover:text-foreground">View all</button>
          </div>
          <ul className="space-y-3">
            {ACTIVITY.map((a, i) => {
              const Icon = a.icon;
              return (
                <li key={i} className="flex items-start gap-3 text-sm">
                  <div className="size-8 rounded-lg bg-accent grid place-items-center shrink-0">
                    <Icon className={`size-4 ${a.tone}`} />
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="text-foreground">{a.text}</div>
                    <div className="text-xs text-muted-foreground">{a.time}</div>
                  </div>
                </li>
              );
            })}
          </ul>
        </div>
      </div>
    </AppShell>
  );
}
