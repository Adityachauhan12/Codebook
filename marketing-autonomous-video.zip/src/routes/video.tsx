import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useMemo, useRef, useState } from "react";
import {
  Sparkles,
  Film,
  Wand2,
  Loader2,
  Play,
  Pause,
  RefreshCw,
  Check,
  Music,
  Volume2,
  VolumeX,
  Upload,
  Download,
  ArrowLeft,
  ArrowRight,
  Clock,
  Pencil,
  Plus,
  Trash2,
  Layers,
  Info,
} from "lucide-react";
import { AppShell } from "@/components/AppShell";
import {
  Sheet,
  SheetContent,
  SheetDescription,
  SheetHeader,
  SheetTitle,
} from "@/components/ui/sheet";

export const Route = createFileRoute("/video")({
  component: VideoPage,
  head: () => ({
    meta: [
      { title: "AI Video — Loom" },
      { name: "description", content: "Generate full videos from a single prompt." },
    ],
  }),
});

type Step = "brief" | "storyboard" | "clips" | "audio" | "final";

type ClipPrompt = {
  id: string;
  order: number;
  title: string;
  prompt: string;
  status: "idle" | "generating" | "ready";
  progress: number;
  seed: number;
};

type AudioTrack = {
  id: string;
  kind: "music" | "voiceover" | "sfx";
  label: string;
  prompt: string;
  selected: boolean;
  status: "idle" | "generating" | "ready";
  duration: string;
};

type StoryOption = {
  id: string;
  title: string;
  summary: string;
  briefStory: string;
  clips: ClipPrompt[];
};

type AttachmentItem = {
  id: string;
  file: File;
  previewUrl: string;
};

const STYLE_PRESETS = [
  { id: "cinematic", label: "Cinematic", desc: "Filmic, warm grade" },
  { id: "product", label: "Product", desc: "Clean studio look" },
  { id: "docu", label: "Documentary", desc: "Handheld, real" },
  { id: "animated", label: "Animated", desc: "2.5D motion" },
  { id: "ugc", label: "UGC / social", desc: "Vertical, punchy" },
];

const RATIOS = [
  { id: "16:9", label: "16:9 Landscape" },
  { id: "9:16", label: "9:16 Vertical" },
  { id: "1:1", label: "1:1 Square" },
  { id: "4:5", label: "4:5 Feed" },
];

function seedPrompts(brief: string, seconds: number, angle: string, storyId: string): ClipPrompt[] {
  const totalClips = Math.max(1, Math.round(seconds / 10));
  const beats = [
    "Opening hero shot that sets the scene",
    "Introduce the main subject with a slow push-in",
    "Show a key benefit or feature in action",
    "Cut to a customer / product moment",
    "Reveal the environment with a wide shot",
    "Close-up detail shot with texture",
    "Emotional beat — reaction / smile",
    "Motion graphics overlay with key value",
    "Second product / feature highlight",
    "Testimonial-style talking head moment",
    "Fast montage of use cases",
    "Aspirational lifestyle sequence",
  ];
  return Array.from({ length: totalClips }, (_, i) => ({
    id: `${storyId}-clip-${i}`,
    order: i + 1,
    title: `Scene ${i + 1}`,
    prompt: `${beats[i % beats.length]}. Angle: ${angle}. Tone based on brief: "${brief.slice(0, 60) || "your idea"}".`,
    status: "idle" as const,
    progress: 0,
    seed: 1000 + i,
  }));
}

function seedStoryOptions(brief: string, seconds: number): StoryOption[] {
  const trimmed = brief.trim() || "your campaign";
  const opening = (brief.trim() || "Our story opens with a bold visual that sets the tone.").replace(/\s+/g, " ");
  return [
    {
      id: "story-1",
      title: "Story 1",
      summary: `Emotion-led journey focused on aspiration and human moments for ${trimmed.slice(0, 42)}.`,
      briefStory: `${opening} We move through warm, human moments that build aspiration and emotional connection. The middle scenes reveal key value in a natural way, and the story closes with a confident, uplifting call to action.`,
      clips: seedPrompts(brief, seconds, "Emotional and cinematic narrative", "story-1"),
    },
    {
      id: "story-2",
      title: "Story 2",
      summary: `Feature-led narrative highlighting product value, proof points, and CTA for ${trimmed.slice(0, 42)}.`,
      briefStory: `${opening} The narrative quickly shifts into clear product proof, showing practical benefits scene by scene. Each beat reinforces trust with direct value moments, then lands on a crisp, action-focused ending that drives conversion.`,
      clips: seedPrompts(brief, seconds, "Benefit-first, fast-paced commercial style", "story-2"),
    },
    {
      id: "story-3",
      title: "Story 3",
      summary: `Premium lifestyle sequence that leans into atmosphere and brand memory for ${trimmed.slice(0, 42)}.`,
      briefStory: `${opening} We open with striking lifestyle imagery, then build through tactile product moments, ambient scenes, and elegant pacing. The final beats feel polished and memorable, leaving the audience with a strong brand impression.`,
      clips: seedPrompts(brief, seconds, "Premium lifestyle, slower build", "story-3"),
    },
    {
      id: "story-4",
      title: "Story 4",
      summary: `Fast social cut built for punchy hooks, motion, and quick conversion for ${trimmed.slice(0, 42)}.`,
      briefStory: `${opening} This version opens with a bold hook, keeps the pacing tight, and leans into quick-cut energy with clear on-screen payoffs. It finishes with a direct CTA designed for social performance and fast recall.`,
      clips: seedPrompts(brief, seconds, "Punchy social hook and quick cuts", "story-4"),
    },
  ];
}

function seedAudio(brief: string): AudioTrack[] {
  return [
    {
      id: "a1",
      kind: "music",
      label: "Warm cinematic lift",
      prompt: `Warm orchestral build, hopeful, subtle percussion. Matches brief: ${brief.slice(0, 40) || "the story"}.`,
      selected: true,
      status: "idle",
      duration: "0:30",
    },
    {
      id: "a2",
      kind: "music",
      label: "Modern upbeat pulse",
      prompt: "Downtempo electronic, soft synths, gentle 90 BPM groove.",
      selected: false,
      status: "idle",
      duration: "0:30",
    },
    {
      id: "a3",
      kind: "music",
      label: "Soft emotional bed",
      prompt: "Gentle emotional bed with room to breathe under the edit.",
      selected: false,
      status: "idle",
      duration: "0:18",
    },
    {
      id: "a4",
      kind: "music",
      label: "Light airy groove",
      prompt: "Subtle groove with soft movement and a clean polished feel.",
      selected: false,
      status: "idle",
      duration: "0:30",
    },
    {
      id: "a5",
      kind: "music",
      label: "Minimal clean beat",
      prompt: "Minimal beat that stays light and unobtrusive under the visuals.",
      selected: false,
      status: "idle",
      duration: "0:30",
    },
  ];
}

function VideoPage() {
  const [step, setStep] = useState<Step>("brief");
  const [brief, setBrief] = useState("");
  const [seconds, setSeconds] = useState(30);
  const [style, setStyle] = useState("cinematic");
  const [ratio, setRatio] = useState("16:9");
  const [attachments, setAttachments] = useState<AttachmentItem[]>([]);

  const [clips, setClips] = useState<ClipPrompt[]>([]);
  const [stories, setStories] = useState<StoryOption[]>([]);
  const [selectedStoryId, setSelectedStoryId] = useState<string | null>(null);
  const [audio, setAudio] = useState<AudioTrack[]>([]);
  const [mergeStatus, setMergeStatus] = useState<"idle" | "merging" | "ready">("idle");
  const [muted, setMuted] = useState(false);
  const [playing, setPlaying] = useState(false);

  const totalClips = Math.max(1, Math.round(seconds / 10));

  useEffect(() => {
    return () => {
      attachments.forEach((attachment) => URL.revokeObjectURL(attachment.previewUrl));
    };
  }, []);

  const canvasAspect = useMemo(() => {
    const [w, h] = ratio.split(":").map(Number);
    return `${w} / ${h}`;
  }, [ratio]);

  const selectedStory = useMemo(
    () => stories.find((s) => s.id === selectedStoryId) ?? null,
    [stories, selectedStoryId],
  );

  function goStoryboard() {
    const nextStories = seedStoryOptions(brief, seconds);
    setStories(nextStories);
    setSelectedStoryId(nextStories[0]?.id ?? null);
    setClips(nextStories[0]?.clips ?? []);
    setStep("storyboard");
  }

  function selectStory(id: string) {
    setSelectedStoryId(id);
    const target = stories.find((s) => s.id === id);
    if (target) {
      setClips(target.clips);
    }
  }

  function regenerateStory(id: string) {
    const index = stories.findIndex((s) => s.id === id);
    if (index < 0) return;

    const refreshed = seedStoryOptions(brief, seconds)[index];
    setStories((current) => current.map((s) => (s.id === id ? refreshed : s)));
    if (selectedStoryId === id) {
      setClips(refreshed.clips);
    }
  }

  function generateClip(id: string) {
    setClips((cs) =>
      cs.map((c) => (c.id === id ? { ...c, status: "generating", progress: 0 } : c)),
    );
    const iv = setInterval(() => {
      setClips((cs) =>
        cs.map((c) => {
          if (c.id !== id) return c;
          const next = c.progress + 8 + Math.random() * 12;
          if (next >= 100) {
            clearInterval(iv);
            return { ...c, progress: 100, status: "ready" };
          }
          return { ...c, progress: next };
        }),
      );
    }, 250);
  }

  function generateAllClips() {
    clips.forEach((c) => c.status !== "ready" && generateClip(c.id));
  }

  function updateClipPrompt(id: string, value: string) {
    setStories((current) =>
      current.map((story) => ({
        ...story,
        clips: story.clips.map((c) => (c.id === id ? { ...c, prompt: value } : c)),
      })),
    );
    setClips((cs) => cs.map((c) => (c.id === id ? { ...c, prompt: value } : c)));
  }

  function removeClip(id: string) {
    setStories((current) =>
      current.map((story) => {
        if (story.id !== selectedStoryId) return story;
        return {
          ...story,
          clips: story.clips.filter((c) => c.id !== id).map((c, i) => ({ ...c, order: i + 1 })),
        };
      }),
    );
    setClips((cs) => cs.filter((c) => c.id !== id).map((c, i) => ({ ...c, order: i + 1 })));
  }

  function addClip() {
    const next = {
      id: `${selectedStoryId ?? "story"}-clip-${Date.now()}`,
      order: clips.length + 1,
      title: `Scene ${clips.length + 1}`,
      prompt: "Describe this new 10-second scene...",
      status: "idle" as const,
      progress: 0,
      seed: Math.floor(Math.random() * 9999),
    };

    setStories((current) =>
      current.map((story) => {
        if (story.id !== selectedStoryId) return story;
        return { ...story, clips: [...story.clips, next] };
      }),
    );
    setClips((cs) => [...cs, next]);
  }

  function goAudio() {
    setAudio(seedAudio(brief));
    setStep("audio");
  }

  function generateAudio(id: string) {
    setAudio((as) => as.map((a) => (a.id === id ? { ...a, status: "generating" } : a)));
    setTimeout(() => {
      setAudio((as) => as.map((a) => (a.id === id ? { ...a, status: "ready" } : a)));
    }, 1400);
  }

  function toggleAudio(id: string) {
    setAudio((as) => as.map((a) => ({ ...a, selected: a.id === id })));
  }

  function mergeFinal() {
    setStep("final");
    setMergeStatus("merging");
    setTimeout(() => setMergeStatus("ready"), 2200);
  }

  const readyClips = clips.filter((c) => c.status === "ready").length;
  const canMerge = clips.length > 0 && readyClips === clips.length;

  return (
    <AppShell>
      <div className="max-w-[1400px] mx-auto px-4 sm:px-6 py-6">
        <Header step={step} setStep={setStep} clipsCount={clips.length} />

        {step === "brief" && (
          <BriefStep
            brief={brief}
            setBrief={setBrief}
            seconds={seconds}
            setSeconds={setSeconds}
            style={style}
            setStyle={setStyle}
            ratio={ratio}
            setRatio={setRatio}
            totalClips={totalClips}
            attachments={attachments}
            setAttachments={setAttachments}
            onNext={goStoryboard}
          />
        )}

        {step === "storyboard" && (
          <StoryboardStep
            stories={stories}
            selectedStoryId={selectedStoryId}
            onChange={updateClipPrompt}
            onRemove={removeClip}
            onAdd={addClip}
            onSelectStory={selectStory}
            onRegenerateStory={regenerateStory}
            onBack={() => setStep("brief")}
            onNext={() => {
              if (selectedStory) {
                setClips(selectedStory.clips);
              }
              setStep("clips");
            }}
          />
        )}

        {step === "clips" && (
          <ClipsStep
            clips={clips}
            aspect={canvasAspect}
            onGenerate={generateClip}
            onGenerateAll={generateAllClips}
            onEdit={(id) => {
              setClips((cs) => cs.map((c) => (c.id === id ? { ...c, status: "idle", progress: 0 } : c)));
            }}
            onBack={() => setStep("storyboard")}
            onNext={goAudio}
            canProceed={canMerge}
          />
        )}

        {step === "audio" && (
          <AudioStep
            tracks={audio}
            onGenerate={generateAudio}
            onToggle={toggleAudio}
            onUpdate={(id, v) => setAudio((as) => as.map((a) => (a.id === id ? { ...a, prompt: v } : a)))}
            onBack={() => setStep("clips")}
            onNext={mergeFinal}
          />
        )}

        {step === "final" && (
          <FinalStep
            status={mergeStatus}
            aspect={canvasAspect}
            playing={playing}
            setPlaying={setPlaying}
            muted={muted}
            setMuted={setMuted}
            clips={clips}
            audio={audio.filter((a) => a.selected)}
            onBack={() => setStep("audio")}
            onRestart={() => {
              setStep("brief");
              setClips([]);
              setStories([]);
              setSelectedStoryId(null);
              setAudio([]);
              setMergeStatus("idle");
            }}
          />
        )}
      </div>
    </AppShell>
  );
}

/* ---------------- Header / Stepper ---------------- */

function Header({
  step,
  setStep,
  clipsCount,
}: {
  step: Step;
  setStep: (s: Step) => void;
  clipsCount: number;
}) {
  const steps: { id: Step; label: string; icon: typeof Film }[] = [
    { id: "brief", label: "Brief", icon: Pencil },
    { id: "storyboard", label: "Storyboard", icon: Layers },
    { id: "clips", label: "Clips", icon: Film },
    { id: "audio", label: "Audio", icon: Music },
    { id: "final", label: "Final video", icon: Sparkles },
  ];
  const currentIndex = steps.findIndex((s) => s.id === step);

  return (
    <div className="mb-6">
      <div className="flex items-center justify-between mb-4">
        <div>
          <div className="flex items-center gap-2 text-sm text-muted-foreground mb-1">
            <Film className="size-4" />
            AI Video Studio
          </div>
          <h1 className="text-2xl font-bold tracking-tight">Turn your idea into a full video</h1>
          <p className="text-sm text-muted-foreground mt-1">
            Describe your video, we plan 10-second scenes, generate clips, then merge with audio.
          </p>
        </div>
      </div>

      <div className="flex items-center gap-1 sm:gap-2 p-1.5 rounded-xl border border-border bg-surface overflow-x-auto">
        {steps.map((s, i) => {
          const Icon = s.icon;
          const active = s.id === step;
          const done = i < currentIndex;
          const clickable = i <= currentIndex || (i === 1 && clipsCount > 0);
          return (
            <button
              key={s.id}
              disabled={!clickable}
              onClick={() => clickable && setStep(s.id)}
              className={`flex items-center gap-2 px-3 py-2 rounded-lg text-sm whitespace-nowrap transition-colors ${
                active
                  ? "bg-primary text-primary-foreground font-medium"
                  : done
                    ? "text-foreground hover:bg-accent"
                    : "text-muted-foreground"
              } ${!clickable ? "opacity-50 cursor-not-allowed" : ""}`}
            >
              <div
                className={`size-5 grid place-items-center rounded-full text-[10px] font-semibold ${
                  active
                    ? "bg-primary-foreground/20"
                    : done
                      ? "bg-primary/10 text-primary"
                      : "bg-accent"
                }`}
              >
                {done ? <Check className="size-3" /> : i + 1}
              </div>
              <Icon className="size-4" />
              <span className="hidden sm:inline">{s.label}</span>
            </button>
          );
        })}
      </div>
    </div>
  );
}

/* ---------------- Step 1: Brief ---------------- */

function BriefStep({
  brief,
  setBrief,
  seconds,
  setSeconds,
  style,
  setStyle,
  ratio,
  setRatio,
  totalClips,
  attachments,
  setAttachments,
  onNext,
}: {
  brief: string;
  setBrief: (v: string) => void;
  seconds: number;
  setSeconds: (n: number) => void;
  style: string;
  setStyle: (s: string) => void;
  ratio: string;
  setRatio: (r: string) => void;
  totalClips: number;
  attachments: AttachmentItem[];
  setAttachments: React.Dispatch<React.SetStateAction<AttachmentItem[]>>;
  onNext: () => void;
}) {
  const EXAMPLES = [
    "A 60-second ad for our new Bali summer flight route with beach shots and happy families.",
    "A 90-second brand film about our loyalty program, warm and cinematic.",
    "A 30-second vertical Reel for our winter sale, energetic and colorful.",
  ];

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
      <div className="lg:col-span-2 space-y-6">
        <div className="rounded-2xl border border-border bg-surface p-5">
          <label className="text-sm font-medium mb-2 block">What video do you want to make?</label>
          <textarea
            value={brief}
            onChange={(e) => setBrief(e.target.value)}
            placeholder="Example: A cinematic 1-minute video promoting our new Bali summer route — sunrise beach, family boarding, aerial shots, warm music."
            className="w-full min-h-[140px] rounded-xl border border-border bg-background p-4 text-sm resize-none focus:outline-none focus:ring-2 focus:ring-primary"
          />
          <div className="mt-3 flex flex-wrap gap-2">
            {EXAMPLES.map((e) => (
              <button
                key={e}
                onClick={() => setBrief(e)}
                className="text-xs px-3 py-1.5 rounded-full border border-border bg-background hover:bg-accent text-muted-foreground"
              >
                {e.slice(0, 50)}…
              </button>
            ))}
          </div>

          <div className="mt-5 rounded-xl border border-dashed border-border bg-background p-4">
            <div className="flex items-center justify-between gap-3">
              <div>
                <div className="text-sm font-medium">Attachments</div>
                <div className="text-xs text-muted-foreground">Add references, scripts, images, or PDFs.</div>
              </div>
              <label className="inline-flex items-center gap-2 rounded-lg border border-border bg-surface px-3 py-2 text-sm font-medium hover:bg-accent cursor-pointer">
                <Upload className="size-4" />
                Add files
                <input
                  type="file"
                  multiple
                  className="hidden"
                  onChange={(e) => {
                    const selectedFiles = Array.from(e.target.files ?? []);
                    if (selectedFiles.length === 0) return;
                    setAttachments((current) => [
                      ...current,
                      ...selectedFiles.map((file) => ({
                        id: `${file.name}-${file.lastModified}-${Math.random().toString(36).slice(2)}`,
                        file,
                        previewUrl: URL.createObjectURL(file),
                      })),
                    ]);
                    e.currentTarget.value = "";
                  }}
                />
              </label>
            </div>

            {attachments.length > 0 ? (
              <div className="mt-3 flex flex-wrap gap-3">
                {attachments.map((attachment) => {
                  const isImage = attachment.file.type.startsWith("image/");
                  const label = attachment.file.name.split(".").pop()?.toUpperCase() || "FILE";

                  return (
                    <div
                      key={attachment.id}
                      className="group relative h-[60px] w-[100px] shrink-0 overflow-hidden rounded-lg border border-border bg-surface"
                    >
                      {isImage ? (
                        <img
                          src={attachment.previewUrl}
                          alt={attachment.file.name}
                          className="h-full w-full object-cover"
                        />
                      ) : (
                        <div className="flex h-full w-full flex-col items-center justify-center gap-2 p-3 text-center">
                          <div className="grid size-12 place-items-center rounded-lg bg-primary/10 text-xs font-semibold text-primary">
                            {label.slice(0, 4)}
                          </div>
                          <div className="text-[11px] font-medium text-foreground/90 line-clamp-2">
                            {attachment.file.name}
                          </div>
                        </div>
                      )}

                      <div className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-black/70 to-transparent p-2">
                        <div className="text-[11px] text-white line-clamp-1">{attachment.file.name}</div>
                      </div>

                      <button
                        onClick={() =>
                          setAttachments((current) => {
                            const target = current.find((item) => item.id === attachment.id);
                            if (target) URL.revokeObjectURL(target.previewUrl);
                            return current.filter((item) => item.id !== attachment.id);
                          })
                        }
                        className="absolute right-2 top-2 rounded-full bg-black/60 p-1.5 text-white opacity-0 transition-opacity group-hover:opacity-100"
                        aria-label={`Remove ${attachment.file.name}`}
                      >
                        <Trash2 className="size-3.5" />
                      </button>
                    </div>
                  );
                })}
              </div>
            ) : (
              <div className="mt-3 text-xs text-muted-foreground">No attachments added yet.</div>
            )}
          </div>
        </div>

        <div className="rounded-2xl border border-border bg-surface p-5">
          <div className="flex items-center justify-between mb-3">
            <label className="text-sm font-medium">How long should the video be?</label>
            <div className="flex items-center gap-2 text-sm">
              <input
                type="number"
                min={10}
                max={100}
                step={10}
                value={seconds}
                onChange={(e) => setSeconds(Math.max(10, Math.min(100, Number(e.target.value) || 30)))}
                className="w-20 rounded-lg border border-border bg-background px-3 py-1.5 text-sm text-right"
              />
              <span className="text-muted-foreground">seconds</span>
            </div>
          </div>
          <input
            type="range"
            min={10}
            max={100}
            step={10}
            value={seconds}
            onChange={(e) => setSeconds(Number(e.target.value))}
            className="w-full accent-primary"
          />
          <div className="mt-3 flex items-center gap-2 text-xs text-muted-foreground">
            <Info className="size-3.5" />
            We'll break this into {totalClips} × 10-second clips you can review and edit.
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="rounded-2xl border border-border bg-surface p-5">
            <label className="text-sm font-medium mb-3 block">Style</label>
            <div className="grid grid-cols-2 gap-2">
              {STYLE_PRESETS.map((s) => (
                <button
                  key={s.id}
                  onClick={() => setStyle(s.id)}
                  className={`text-left rounded-xl border p-3 transition-colors ${
                    style === s.id
                      ? "border-primary bg-primary/5"
                      : "border-border bg-background hover:bg-accent"
                  }`}
                >
                  <div className="text-sm font-medium">{s.label}</div>
                  <div className="text-xs text-muted-foreground">{s.desc}</div>
                </button>
              ))}
            </div>
          </div>

          <div className="rounded-2xl border border-border bg-surface p-5">
            <label className="text-sm font-medium mb-3 block">Aspect ratio</label>
            <div className="grid grid-cols-2 gap-2">
              {RATIOS.map((r) => (
                <button
                  key={r.id}
                  onClick={() => setRatio(r.id)}
                  className={`rounded-xl border p-3 text-sm transition-colors ${
                    ratio === r.id
                      ? "border-primary bg-primary/5 font-medium"
                      : "border-border bg-background hover:bg-accent"
                  }`}
                >
                  {r.label}
                </button>
              ))}
            </div>
          </div>
        </div>
      </div>

      <aside className="lg:sticky lg:top-20 self-start rounded-2xl border border-border bg-surface p-5">
        <div className="text-sm font-medium mb-3">What happens next</div>
        <ol className="space-y-3 text-sm">
          {[
            "We turn your brief into a scene-by-scene storyboard (10 sec each).",
            "You review & tweak each scene's prompt.",
            "Generate every clip, refine anything you don't love.",
            "Pick a music track & voiceover, we merge it into your final video.",
          ].map((t, i) => (
            <li key={i} className="flex gap-3">
              <div className="size-6 rounded-full bg-primary/10 text-primary text-xs grid place-items-center font-semibold shrink-0">
                {i + 1}
              </div>
              <span className="text-muted-foreground">{t}</span>
            </li>
          ))}
        </ol>

        <button
          onClick={onNext}
          disabled={!brief.trim()}
          className="mt-5 cursor-pointer w-full inline-flex items-center justify-center gap-2 rounded-xl bg-primary text-primary-foreground py-3 text-sm font-medium hover:opacity-90 disabled:opacity-50 disabled:cursor-not-allowed"
        >
          <Wand2 className="size-4" />
          Plan my storyboard
          <ArrowRight className="size-4" />
        </button>
      </aside>
    </div>
  );
}

/* ---------------- Step 2: Storyboard ---------------- */

function StoryboardStep({
  stories,
  selectedStoryId,
  onChange,
  onRemove,
  onAdd,
  onSelectStory,
  onRegenerateStory,
  onBack,
  onNext,
}: {
  stories: StoryOption[];
  selectedStoryId: string | null;
  onChange: (id: string, v: string) => void;
  onRemove: (id: string) => void;
  onAdd: () => void;
  onSelectStory: (id: string) => void;
  onRegenerateStory: (id: string) => void;
  onBack: () => void;
  onNext: () => void;
}) {
  const selected = stories.find((s) => s.id === selectedStoryId) ?? null;
  const [openClips, setOpenClips] = useState(false);

  return (
    <div>
      <div className="flex items-center justify-between mb-4">
        <div>
          <h2 className="text-lg font-semibold">Pick your story direction</h2>
          <p className="text-sm text-muted-foreground">
            Compare both story options, review each brief and clips, then choose one to continue.
          </p>
        </div>
        <div className="flex items-center gap-2 text-sm text-muted-foreground">
          <Clock className="size-4" />
          Selected: {selected?.title ?? "None"} · {selected?.clips.length ?? 0} scenes
        </div>
      </div>

      <div className="grid grid-cols-1 xl:grid-cols-[minmax(0,1.15fr)_minmax(360px,0.85fr)] gap-4 items-start">
        {stories.map((story) => {
          const isSelected = story.id === selectedStoryId;
          return (
            <div
              key={story.id}
              role="button"
              tabIndex={0}
              onClick={() => {
                onSelectStory(story.id);
              }}
              onKeyDown={(e) => {
                if (e.key === "Enter" || e.key === " ") {
                  e.preventDefault();
                  onSelectStory(story.id);
                }
              }}
              className={`rounded-2xl border p-4 cursor-pointer transition-all ${
                isSelected ? "border-primary bg-primary/5" : "border-border bg-surface"
              }`}
            >
              <div className="flex items-start justify-between mb-3 gap-2">
                <div>
                  <div className="text-sm font-semibold">{story.title}</div>
                  <div className="text-xs text-muted-foreground mt-1">{story.summary}</div>
                </div>
                <div className="flex items-center gap-2 shrink-0">
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      onRegenerateStory(story.id);
                    }}
                    className="inline-flex items-center gap-1 rounded-lg border border-border bg-background px-2.5 py-1.5 text-xs hover:bg-accent"
                  >
                    <RefreshCw className="size-3.5" />
                    Change story
                  </button>
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      onSelectStory(story.id);
                    }}
                    className={`inline-flex items-center gap-1 rounded-lg px-2.5 py-1.5 text-xs font-medium ${
                      isSelected
                        ? "bg-primary text-primary-foreground"
                        : "bg-accent text-foreground hover:bg-accent/70"
                    }`}
                  >
                    {isSelected ? "Selected" : "Use this story"}
                  </button>
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      onSelectStory(story.id);
                      setOpenClips(true);
                    }}
                    className="inline-flex items-center gap-1 rounded-lg border border-border bg-background px-2.5 py-1.5 text-xs hover:bg-accent"
                  >
                    Show clips
                  </button>
                </div>
              </div>

              <div className="rounded-xl border border-border bg-background p-3">
                <div className="text-xs font-semibold uppercase tracking-wide text-muted-foreground mb-1">
                  Brief story
                </div>
                <p className="text-sm text-foreground/90 leading-relaxed">{story.briefStory}</p>
              </div>
            </div>
          );
        })}

        <aside className="rounded-2xl border border-border bg-surface p-4 xl:sticky xl:top-20 self-start">
          {selected ? (
            <div className="space-y-4">
              <div className="text-sm text-muted-foreground">
                Select a story card, then use the card's Show clips action to open the drawer.
              </div>
            </div>
          ) : (
            <div className="text-sm text-muted-foreground">Select a story to review its clips here.</div>
          )}
        </aside>
      </div>

      <Sheet open={openClips} onOpenChange={setOpenClips}>
        <SheetContent side="right" className="w-full sm:max-w-2xl p-0 bg-surface">
          <div className="h-full overflow-auto p-6">
            <SheetHeader className="mb-5 text-left">
              <SheetTitle>{selected?.title ?? "Story clips"}</SheetTitle>
              <SheetDescription>
                Review and edit the scene prompts for the currently selected story.
              </SheetDescription>
            </SheetHeader>

            {selected ? (
              <div className="space-y-4">
                <div className="text-sm text-muted-foreground">{selected.summary}</div>
                <div className="space-y-3">
                  {selected.clips.map((c) => (
                    <div key={c.id} className="rounded-xl border border-border bg-background p-3">
                      <div className="flex items-center justify-between mb-2">
                        <div className="flex items-center gap-2">
                          <div className="size-7 rounded-lg bg-primary/10 text-primary text-xs font-semibold grid place-items-center">
                            {c.order}
                          </div>
                          <div className="text-sm font-medium">{c.title}</div>
                          <div className="text-xs text-muted-foreground">· 10s</div>
                        </div>
                        <button
                          onClick={() => onRemove(c.id)}
                          className="p-1.5 rounded-lg text-muted-foreground hover:bg-accent hover:text-foreground"
                          aria-label="Remove scene"
                        >
                          <Trash2 className="size-4" />
                        </button>
                      </div>
                      <textarea
                        value={c.prompt}
                        onChange={(e) => onChange(c.id, e.target.value)}
                        className="w-full min-h-[96px] rounded-lg border border-border bg-surface p-3 text-sm resize-none focus:outline-none focus:ring-2 focus:ring-primary"
                      />
                    </div>
                  ))}
                </div>

                <button
                  onClick={onAdd}
                  className="w-full rounded-xl border-2 border-dashed border-border p-3 text-sm text-muted-foreground hover:border-primary hover:text-foreground flex items-center justify-center gap-2"
                >
                  <Plus className="size-4" />
                  Add another scene
                </button>
              </div>
            ) : (
              <div className="text-sm text-muted-foreground">Select a story first.</div>
            )}
          </div>
        </SheetContent>
      </Sheet>

      <FooterNav
        onBack={onBack}
        onNext={onNext}
        nextLabel="Generate all clips"
        nextIcon={<Wand2 className="size-4" />}
        disabled={!selected || selected.clips.length === 0}
      />
    </div>
  );
}

/* ---------------- Step 3: Clips ---------------- */

function ClipsStep({
  clips,
  aspect,
  onGenerate,
  onGenerateAll,
  onEdit,
  onBack,
  onNext,
  canProceed,
}: {
  clips: ClipPrompt[];
  aspect: string;
  onGenerate: (id: string) => void;
  onGenerateAll: () => void;
  onEdit: (id: string) => void;
  onBack: () => void;
  onNext: () => void;
  canProceed: boolean;
}) {
  const ready = clips.filter((c) => c.status === "ready").length;
  const autoGeneratedRef = useRef(false);

  useEffect(() => {
    if (!autoGeneratedRef.current && clips.length > 0 && clips.some((clip) => clip.status !== "ready")) {
      autoGeneratedRef.current = true;
      onGenerateAll();
    }
  }, [clips, onGenerateAll]);

  return (
    <div>
      <div className="flex items-center justify-between mb-4 flex-wrap gap-3">
        <div>
          <h2 className="text-lg font-semibold">Generate your clips</h2>
          <p className="text-sm text-muted-foreground">
            {ready} of {clips.length} clips ready · refine any that need work.
          </p>
        </div>
        <button
          onClick={onGenerateAll}
          className="inline-flex items-center gap-2 rounded-xl bg-primary text-primary-foreground px-4 py-2 text-sm font-medium hover:opacity-90"
        >
          <Wand2 className="size-4" />
          Generate all
        </button>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {clips.map((c) => (
          <div key={c.id} className="rounded-2xl border border-border bg-surface overflow-hidden">
            <div
              className="w-full bg-gradient-to-br from-primary/20 via-[var(--accent-ai)]/10 to-background relative"
              style={{ aspectRatio: aspect }}
            >
              {c.status === "idle" && (
                <div className="absolute inset-0 grid place-items-center text-xs text-muted-foreground">
                  Scene {c.order} preview
                </div>
              )}
              {c.status === "generating" && (
                <div className="absolute inset-0 grid place-items-center">
                  <div className="text-center">
                    <Loader2 className="size-6 animate-spin text-primary mx-auto mb-2" />
                    <div className="text-xs text-muted-foreground">Generating… {Math.floor(c.progress)}%</div>
                  </div>
                </div>
              )}
              {c.status === "ready" && (
                <>
                  <div
                    className="absolute inset-0"
                    style={{
                      backgroundImage: `linear-gradient(${(c.seed * 37) % 360}deg, hsl(${(c.seed * 47) % 360} 70% 55%), hsl(${(c.seed * 91) % 360} 65% 40%))`,
                    }}
                  />
                  <div className="absolute inset-0 grid place-items-center">
                    <div className="size-12 rounded-full bg-black/40 backdrop-blur grid place-items-center text-white">
                      <Play className="size-5 fill-white" />
                    </div>
                  </div>
                  <div className="absolute top-2 left-2 text-[10px] px-2 py-0.5 rounded-full bg-black/60 text-white">
                    10s · Scene {c.order}
                  </div>
                </>
              )}
            </div>
            <div className="p-3">
              <div className="text-xs text-muted-foreground line-clamp-2 min-h-[32px]">{c.prompt}</div>
              <div className="mt-3 flex items-center gap-2">
                {c.status !== "generating" ? (
                  <button
                    onClick={() => onGenerate(c.id)}
                    className="flex-1 inline-flex items-center justify-center gap-1.5 rounded-lg bg-accent text-foreground text-xs font-medium py-1.5 hover:bg-accent/70"
                  >
                    {c.status === "ready" ? (
                      <>
                        <RefreshCw className="size-3.5" /> Refine
                      </>
                    ) : (
                      <>
                        <Wand2 className="size-3.5" /> Generate
                      </>
                    )}
                  </button>
                ) : (
                  <div className="flex-1 h-1.5 rounded-full bg-accent overflow-hidden">
                    <div
                      className="h-full bg-primary transition-all"
                      style={{ width: `${c.progress}%` }}
                    />
                  </div>
                )}
                <button
                  onClick={() => onEdit(c.id)}
                  className="p-1.5 rounded-lg text-muted-foreground hover:bg-accent hover:text-foreground"
                  aria-label="Edit prompt"
                >
                  <Pencil className="size-3.5" />
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>

      <FooterNav
        onBack={onBack}
        onNext={onNext}
        nextLabel={canProceed ? "Add audio" : `Generate all ${clips.length} clips to continue`}
        nextIcon={<Music className="size-4" />}
        disabled={!canProceed}
      />
    </div>
  );
}

/* ---------------- Step 4: Audio ---------------- */

function AudioStep({
  tracks,
  onGenerate,
  onToggle,
  onUpdate,
  onBack,
  onNext,
}: {
  tracks: AudioTrack[];
  onGenerate: (id: string) => void;
  onToggle: (id: string) => void;
  onUpdate: (id: string, v: string) => void;
  onBack: () => void;
  onNext: () => void;
}) {
  const selectedCount = tracks.filter((t) => t.selected).length;

  return (
    <div>
      <div className="mb-4">
        <h2 className="text-lg font-semibold">Pick an audio vibe for your video</h2>
        <p className="text-sm text-muted-foreground">
          Choose one or more options below. We'll generate and mix the one(s) you like.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
        {tracks.map((t) => (
          <div
            key={t.id}
            className={`rounded-2xl border p-4 transition-colors ${
              t.selected ? "border-primary bg-primary/5" : "border-border bg-surface"
            }`}
          >
            <div className="flex items-start gap-3">
              <button
                onClick={() => onToggle(t.id)}
                className={`size-5 rounded-md border-2 shrink-0 mt-0.5 grid place-items-center ${
                  t.selected ? "bg-primary border-primary text-primary-foreground" : "border-border"
                }`}
              >
                {t.selected && <Check className="size-3" />}
              </button>
              <div className="flex-1 min-w-0">
                <div className="flex items-center justify-between gap-2">
                  <div className="text-sm font-medium">{t.label}</div>
                  <div className="text-xs text-muted-foreground">{t.duration}</div>
                </div>
                <textarea
                  value={t.prompt}
                  onChange={(e) => onUpdate(t.id, e.target.value)}
                  className="mt-2 w-full min-h-[60px] rounded-lg border border-border bg-background p-2.5 text-xs resize-none focus:outline-none focus:ring-2 focus:ring-primary"
                />
                <div className="mt-2 flex items-center gap-2">
                  {t.status === "ready" ? (
                    <button className="inline-flex items-center gap-1.5 rounded-lg bg-accent text-foreground text-xs font-medium px-3 py-1.5">
                      <Play className="size-3" /> Preview
                    </button>
                  ) : (
                    <button
                      onClick={() => onGenerate(t.id)}
                      disabled={t.status === "generating"}
                      className="inline-flex items-center gap-1.5 rounded-lg bg-primary text-primary-foreground text-xs font-medium px-3 py-1.5 disabled:opacity-60"
                    >
                      {t.status === "generating" ? (
                        <>
                          <Loader2 className="size-3 animate-spin" /> Generating…
                        </>
                      ) : (
                        <>
                          <Wand2 className="size-3" /> Generate
                        </>
                      )}
                    </button>
                  )}
                  {t.status === "ready" && (
                    <button
                      onClick={() => onGenerate(t.id)}
                      className="inline-flex items-center gap-1.5 rounded-lg bg-accent text-foreground text-xs font-medium px-3 py-1.5"
                    >
                      <RefreshCw className="size-3" /> Regenerate
                    </button>
                  )}
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>

      <FooterNav
        onBack={onBack}
        onNext={onNext}
        nextLabel={`Merge into final video (${selectedCount} track${selectedCount === 1 ? "" : "s"})`}
        nextIcon={<Sparkles className="size-4" />}
      />
    </div>
  );
}

/* ---------------- Step 5: Final ---------------- */

function FinalStep({
  status,
  aspect,
  playing,
  setPlaying,
  muted,
  setMuted,
  clips,
  audio,
  onBack,
  onRestart,
}: {
  status: "idle" | "merging" | "ready";
  aspect: string;
  playing: boolean;
  setPlaying: (v: boolean) => void;
  muted: boolean;
  setMuted: (v: boolean) => void;
  clips: ClipPrompt[];
  audio: AudioTrack[];
  onBack: () => void;
  onRestart: () => void;
}) {
  const seekRef = useRef<HTMLDivElement>(null);
  const totalSec = clips.length * 10;

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
      <div className="lg:col-span-2">
        <div className="rounded-2xl border border-border bg-surface p-4">
          <div
            className="w-full rounded-xl overflow-hidden bg-black relative"
            style={{ aspectRatio: aspect }}
          >
            {status === "merging" && (
              <div className="absolute inset-0 grid place-items-center text-white">
                <div className="text-center">
                  <Loader2 className="size-8 animate-spin mx-auto mb-3" />
                  <div className="text-sm font-medium">Merging clips & mixing audio…</div>
                  <div className="text-xs text-white/70 mt-1">Rendering {clips.length} scenes</div>
                </div>
              </div>
            )}
            {status === "ready" && (
              <>
                <div
                  className="absolute inset-0 transition-opacity"
                  style={{
                    backgroundImage: `linear-gradient(120deg, hsl(${(clips[0]?.seed || 0) * 47 % 360} 70% 45%), hsl(${(clips[clips.length - 1]?.seed || 0) * 91 % 360} 65% 30%))`,
                  }}
                />
                <button
                  onClick={() => setPlaying(!playing)}
                  className="absolute inset-0 grid place-items-center group"
                >
                  <div className="size-16 rounded-full bg-black/50 backdrop-blur grid place-items-center text-white group-hover:scale-110 transition-transform">
                    {playing ? <Pause className="size-6" /> : <Play className="size-6 fill-white" />}
                  </div>
                </button>
                <div className="absolute bottom-0 left-0 right-0 p-3 bg-gradient-to-t from-black/70 to-transparent">
                  <div ref={seekRef} className="h-1 rounded-full bg-white/20 overflow-hidden mb-2">
                    <div className="h-full bg-white w-1/3" />
                  </div>
                  <div className="flex items-center justify-between text-white text-xs">
                    <div className="flex items-center gap-2">
                      <button onClick={() => setPlaying(!playing)}>
                        {playing ? <Pause className="size-4" /> : <Play className="size-4" />}
                      </button>
                      <span>
                        0:{String(Math.floor(totalSec / 3)).padStart(2, "0")} / 0:{String(totalSec).padStart(2, "0")}
                      </span>
                    </div>
                    <button onClick={() => setMuted(!muted)}>
                      {muted ? <VolumeX className="size-4" /> : <Volume2 className="size-4" />}
                    </button>
                  </div>
                </div>
              </>
            )}
          </div>

          {status === "ready" && (
            <div className="mt-4 flex items-center gap-2 flex-wrap">
              <button className="inline-flex items-center gap-2 rounded-xl bg-primary text-primary-foreground px-4 py-2 text-sm font-medium hover:opacity-90">
                <Download className="size-4" />
                Download MP4
              </button>
              <button className="inline-flex items-center gap-2 rounded-xl border border-border bg-background px-4 py-2 text-sm font-medium hover:bg-accent">
                <RefreshCw className="size-4" />
                Re-render
              </button>
              <button
                onClick={onRestart}
                className="inline-flex items-center gap-2 rounded-xl border border-border bg-background px-4 py-2 text-sm font-medium hover:bg-accent"
              >
                <Sparkles className="size-4" />
                Start a new video
              </button>
            </div>
          )}
        </div>
      </div>

      <aside className="space-y-4">
        <div className="rounded-2xl border border-border bg-surface p-4">
          <div className="text-sm font-medium mb-3 flex items-center gap-2">
            <Layers className="size-4 text-primary" />
            Timeline
          </div>
          <div className="space-y-2">
            {clips.map((c) => (
              <div key={c.id} className="flex items-center gap-2 text-xs">
                <div className="size-6 rounded bg-primary/10 text-primary grid place-items-center font-semibold shrink-0">
                  {c.order}
                </div>
                <div className="flex-1 truncate text-muted-foreground">{c.prompt}</div>
                <div className="text-muted-foreground">10s</div>
              </div>
            ))}
          </div>
        </div>

        <div className="rounded-2xl border border-border bg-surface p-4">
          <div className="text-sm font-medium mb-3 flex items-center gap-2">
            <Music className="size-4 text-primary" />
            Audio mix
          </div>
          {audio.length === 0 ? (
            <div className="text-xs text-muted-foreground">No audio tracks selected.</div>
          ) : (
            <div className="space-y-2">
              {audio.map((a) => (
                <div key={a.id} className="flex items-center gap-2 text-xs">
                  <Check className="size-3.5 text-primary shrink-0" />
                  <div className="flex-1 truncate">{a.label}</div>
                  <div className="text-muted-foreground capitalize">{a.kind}</div>
                </div>
              ))}
            </div>
          )}
        </div>

        <button
          onClick={onBack}
          className="w-full inline-flex items-center justify-center gap-2 rounded-xl border border-border bg-background py-2.5 text-sm hover:bg-accent"
        >
          <ArrowLeft className="size-4" />
          Back to audio
        </button>
      </aside>
    </div>
  );
}

/* ---------------- Shared footer ---------------- */

function FooterNav({
  onBack,
  onNext,
  nextLabel,
  nextIcon,
  disabled,
}: {
  onBack: () => void;
  onNext: () => void;
  nextLabel: string;
  nextIcon?: React.ReactNode;
  disabled?: boolean;
}) {
  return (
    <div className="mt-6 flex items-center justify-between gap-3">
      <button
        onClick={onBack}
        className="inline-flex items-center cursor-pointer gap-2 rounded-xl border border-border bg-background px-4 py-2.5 text-sm hover:bg-accent"
      >
        <ArrowLeft className="size-4" />
        Back
      </button>
      <button
        onClick={onNext}
        disabled={disabled}
        className="inline-flex cursor-pointer items-center gap-2 rounded-xl bg-primary text-primary-foreground px-5 py-2.5 text-sm font-medium hover:opacity-90 disabled:opacity-50 disabled:cursor-not-allowed"
      >
        {nextIcon}
        {nextLabel}
        <ArrowRight className="size-4" />
      </button>
    </div>
  );
}
