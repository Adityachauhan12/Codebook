import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import {
  ArrowRight,
  BadgeCheck,
  CreditCard,
  Loader2,
  Palette,
  Plug,
  Receipt,
  Settings as SettingsIcon,
  Sparkles,
  Upload,
  Wand2,
  X,
  Zap,
} from "lucide-react";
import { AppShell } from "@/components/AppShell";

export const Route = createFileRoute("/settings")({
  component: SettingsPage,
  head: () => ({
    meta: [
      { title: "Settings — Loom" },
      { name: "description", content: "Connections, brand kit, and billing." },
    ],
  }),
});

type ConnectionId = "google-ads" | "meta-ads" | "google-analytics";

type Connection = {
  id: ConnectionId;
  name: string;
  desc: string;
  color: string;
  initials: string;
};

const CONNECTIONS: Connection[] = [
  {
    id: "google-ads",
    name: "Google Ads",
    desc: "Search, Performance Max, and YouTube placements.",
    color: "#4285F4",
    initials: "GA",
  },
  {
    id: "meta-ads",
    name: "Meta Ads",
    desc: "Facebook Feed, Instagram Reels, and Stories.",
    color: "#1877F2",
    initials: "M",
  },
  {
    id: "google-analytics",
    name: "Google Analytics",
    desc: "Attribution and conversion events.",
    color: "#F9AB00",
    initials: "G4",
  },
];

const SWATCHES = ["#000099", "#111827", "#F97316", "#10B981", "#E4405F", "#FFFFFF"];
const FONT_PAIRS = [
  { display: "Plus Jakarta Sans", body: "Plus Jakarta Sans" },
  { display: "Sora", body: "Manrope" },
  { display: "Space Grotesk", body: "Inter" },
];
const TONES = ["Playful", "Confident", "Editorial", "Direct", "Warm"];

function SettingsPage() {
  const [connected, setConnected] = useState<Record<ConnectionId, boolean>>({
    "google-ads": false,
    "meta-ads": false,
    "google-analytics": false,
  });
  const [modal, setModal] = useState<Connection | null>(null);
  const [connecting, setConnecting] = useState(false);
  const [step, setStep] = useState<"consent" | "connecting" | "done">("consent");

  const [swatches, setSwatches] = useState<string[]>(["#000099", "#111827", "#F97316"]);
  const [fontIdx, setFontIdx] = useState(0);
  const [tone, setTone] = useState("Confident");
  const [logoUrl, setLogoUrl] = useState<string | null>(null);
  const [brandPrompt, setBrandPrompt] = useState<string>("");
  const [savedPrompt, setSavedPrompt] = useState<string>("");

  useEffect(() => {
    const stored = localStorage.getItem("settings.brandPrompt") ?? "";
    setBrandPrompt(stored);
    setSavedPrompt(stored);
  }, []);

  function saveBrandPrompt() {
    localStorage.setItem("settings.brandPrompt", brandPrompt);
    setSavedPrompt(brandPrompt);
  }

  function openConnect(c: Connection) {
    setModal(c);
    setStep("consent");
    setConnecting(false);
  }

  function runConnect() {
    if (!modal) return;
    setConnecting(true);
    setStep("connecting");
    setTimeout(() => {
      setStep("done");
      setConnected((s) => ({ ...s, [modal.id]: true }));
    }, 1400);
  }

  function toggleSwatch(hex: string) {
    setSwatches((prev) =>
      prev.includes(hex) ? prev.filter((c) => c !== hex) : [...prev, hex].slice(-6),
    );
  }

  function onLogoFile(f?: File) {
    if (!f) return;
    setLogoUrl(URL.createObjectURL(f));
  }

  return (
    <AppShell>
      <div className="px-6 py-8 max-w-4xl mx-auto flex flex-col gap-8">
        <div className="flex items-center gap-3">
          <div className="size-10 rounded-xl bg-accent grid place-items-center">
            <SettingsIcon className="size-5" />
          </div>
          <div>
            <h1 className="text-2xl font-display font-bold tracking-tight">Settings</h1>
            <p className="text-sm text-muted-foreground">
              Connections, brand kit, and billing.
            </p>
          </div>
        </div>

        {/* Connections */}
        <SectionCard icon={Plug} title="Connections" desc="Ad platforms and analytics.">
          <div className="grid gap-3">
            {CONNECTIONS.map((c) => {
              const isOn = connected[c.id];
              return (
                <div
                  key={c.id}
                  className="flex items-center gap-4 rounded-xl border border-border bg-surface p-4"
                >
                  <div
                    className="size-10 rounded-lg grid place-items-center text-white font-display font-bold text-sm"
                    style={{ background: c.color }}
                  >
                    {c.initials}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2">
                      <div className="font-medium">{c.name}</div>
                      {isOn && (
                        <span className="inline-flex items-center gap-1 text-[11px] font-medium px-1.5 py-0.5 rounded-full bg-emerald-500/10 text-emerald-600">
                          <BadgeCheck className="size-3" />
                          Connected
                        </span>
                      )}
                    </div>
                    <div className="text-xs text-muted-foreground">{c.desc}</div>
                  </div>
                  <button
                    onClick={() =>
                      isOn
                        ? setConnected((s) => ({ ...s, [c.id]: false }))
                        : openConnect(c)
                    }
                    className={`text-sm px-3 py-1.5 rounded-lg font-medium ${
                      isOn
                        ? "border border-border hover:bg-accent"
                        : "bg-primary text-primary-foreground hover:opacity-90"
                    }`}
                  >
                    {isOn ? "Disconnect" : "Connect"}
                  </button>
                </div>
              );
            })}
          </div>
        </SectionCard>

        {/* Brand kit */}
        <SectionCard icon={Palette} title="Brand kit" desc="Reused across Studio and campaigns.">
          <div className="grid md:grid-cols-2 gap-6">
            {/* Logo */}
            <div>
              <div className="text-xs font-medium uppercase tracking-wider text-muted-foreground mb-2">
                Logo
              </div>
              <label className="flex items-center gap-4 rounded-xl border border-dashed border-border p-4 cursor-pointer hover:bg-accent/40 transition-colors">
                <div className="size-16 rounded-lg bg-accent grid place-items-center overflow-hidden shrink-0">
                  {logoUrl ? (
                    <img src={logoUrl} alt="Logo" className="w-full h-full object-contain" />
                  ) : (
                    <Upload className="size-5 text-muted-foreground" />
                  )}
                </div>
                <div className="flex-1 text-sm">
                  <div className="font-medium">
                    {logoUrl ? "Replace logo" : "Upload your logo"}
                  </div>
                  <div className="text-xs text-muted-foreground">PNG or SVG, up to 2MB</div>
                </div>
                <input
                  type="file"
                  accept="image/*"
                  className="hidden"
                  onChange={(e) => onLogoFile(e.target.files?.[0])}
                />
              </label>
            </div>

            {/* Tone */}
            <div>
              <div className="text-xs font-medium uppercase tracking-wider text-muted-foreground mb-2">
                Default tone-of-voice
              </div>
              <div className="flex flex-wrap gap-1.5">
                {TONES.map((t) => (
                  <button
                    key={t}
                    onClick={() => setTone(t)}
                    className={`px-3 py-1.5 rounded-full text-xs transition-colors ${
                      tone === t
                        ? "bg-primary text-primary-foreground"
                        : "bg-accent text-muted-foreground hover:text-foreground"
                    }`}
                  >
                    {t}
                  </button>
                ))}
              </div>
            </div>

            {/* Swatches */}
            <div>
              <div className="text-xs font-medium uppercase tracking-wider text-muted-foreground mb-2">
                Color swatches
              </div>
              <div className="flex flex-wrap gap-2">
                {SWATCHES.map((hex) => {
                  const on = swatches.includes(hex);
                  return (
                    <button
                      key={hex}
                      onClick={() => toggleSwatch(hex)}
                      className={`size-10 rounded-lg border-2 transition-all ${
                        on ? "border-foreground scale-105" : "border-transparent"
                      }`}
                      style={{ background: hex }}
                      aria-label={hex}
                    />
                  );
                })}
              </div>
              <div className="text-[11px] text-muted-foreground mt-2">
                {swatches.length} selected
              </div>
            </div>

            {/* Font pair */}
            <div>
              <div className="text-xs font-medium uppercase tracking-wider text-muted-foreground mb-2">
                Font pair
              </div>
              <div className="flex flex-col gap-2">
                {FONT_PAIRS.map((f, i) => (
                  <button
                    key={f.display}
                    onClick={() => setFontIdx(i)}
                    className={`text-left rounded-xl border p-3 transition-colors ${
                      fontIdx === i
                        ? "border-primary bg-primary/5"
                        : "border-border hover:bg-accent"
                    }`}
                  >
                    <div className="font-display font-bold text-sm">{f.display}</div>
                    <div className="text-xs text-muted-foreground">Body: {f.body}</div>
                  </button>
                ))}
              </div>
            </div>
          </div>
        </SectionCard>

        {/* Brand system prompt */}
        <SectionCard
          icon={Sparkles}
          title="Brand system prompt"
          desc="Sent as system context to every AI generation and campaign."
        >
          <div className="rounded-xl border border-border bg-surface p-4 flex flex-col gap-3">
            <div className="flex items-start gap-2 text-xs text-muted-foreground">
              <Wand2 className="size-3.5 mt-0.5 shrink-0 text-primary" />
              <span>
                Describe your brand voice, do's & don'ts, product positioning, forbidden words,
                signature phrases — anything the AI should always keep in mind.
              </span>
            </div>
            <textarea
              value={brandPrompt}
              onChange={(e) => setBrandPrompt(e.target.value)}
              placeholder={`Example:\nWe are Loomair, a premium regional airline. Voice: confident, warm, never salesy.\nAlways highlight comfort, on-time performance, and Indian hospitality.\nNever use the words "cheap" or "discount" — prefer "value" and "member fare".\nHeadlines under 8 words. Copy under 25 words. Use metric units.`}
              rows={12}
              className="w-full resize-y rounded-lg border border-border bg-background p-3 text-sm font-mono leading-relaxed focus:outline-none focus:ring-2 focus:ring-primary/20"
            />
            <div className="flex items-center justify-between">
              <div className="text-[11px] text-muted-foreground">
                {brandPrompt.length.toLocaleString()} characters
                {brandPrompt !== savedPrompt && (
                  <span className="ml-2 text-amber-600">· Unsaved changes</span>
                )}
              </div>
              <div className="flex items-center gap-2">
                <button
                  onClick={() => setBrandPrompt(savedPrompt)}
                  disabled={brandPrompt === savedPrompt}
                  className="text-sm px-3 py-1.5 rounded-lg border border-border hover:bg-accent disabled:opacity-40"
                >
                  Reset
                </button>
                <button
                  onClick={saveBrandPrompt}
                  disabled={brandPrompt === savedPrompt}
                  className="text-sm px-3 py-1.5 rounded-lg bg-primary text-primary-foreground font-medium hover:opacity-90 disabled:opacity-40"
                >
                  Save prompt
                </button>
              </div>
            </div>
          </div>
        </SectionCard>

        {/* Billing */}
        <SectionCard icon={CreditCard} title="Billing" desc="Credits power AI generations.">
          <div className="grid md:grid-cols-2 gap-4">
            <div className="rounded-xl border border-border bg-surface p-5">
              <div className="text-xs text-muted-foreground">Credit balance</div>
              <div className="flex items-baseline gap-2 mt-1">
                <div className="text-3xl font-display font-bold tracking-tight">248</div>
                <div className="text-xs text-muted-foreground">credits</div>
              </div>
              <div className="h-1.5 rounded-full bg-accent mt-3 overflow-hidden">
                <div className="h-full bg-primary" style={{ width: "24%" }} />
              </div>
              <div className="text-[11px] text-muted-foreground mt-1.5">
                24% of monthly plan used
              </div>
              <button className="mt-4 w-full inline-flex items-center justify-center gap-1.5 rounded-xl bg-primary text-primary-foreground px-3 py-2 text-sm font-medium hover:opacity-90">
                <Zap className="size-4" />
                Top up credits
              </button>
            </div>
            <div className="rounded-xl border border-border bg-surface p-5">
              <div className="text-xs text-muted-foreground">Current plan</div>
              <div className="flex items-center gap-2 mt-1">
                <div className="text-2xl font-display font-bold tracking-tight">Studio</div>
                <span className="text-[11px] font-medium px-1.5 py-0.5 rounded bg-accent">
                  $49/mo
                </span>
              </div>
              <ul className="mt-3 flex flex-col gap-1.5 text-sm text-muted-foreground">
                <li>· 1,000 credits / month</li>
                <li>· Unlimited campaigns</li>
                <li>· 3 team seats</li>
              </ul>
              <button className="mt-4 w-full rounded-xl border border-border px-3 py-2 text-sm font-medium hover:bg-accent">
                Change plan
              </button>
            </div>
          </div>
        </SectionCard>

        {/* Transactions */}
        <SectionCard
          icon={Receipt}
          title="Credit transactions"
          desc="See exactly where your credits are going."
        >
          <Link
            to="/settings/transactions"
            className="group flex items-center gap-4 rounded-xl border border-border bg-surface p-4 hover:border-primary/40 transition-colors"
          >
            <div className="size-11 rounded-lg bg-primary/10 text-primary grid place-items-center shrink-0">
              <Receipt className="size-5" />
            </div>
            <div className="flex-1 min-w-0">
              <div className="font-medium text-sm">View credit ledger</div>
              <div className="text-xs text-muted-foreground">
                Every AI generation, edit, campaign launch, top-up, and monthly refill.
              </div>
            </div>
            <div className="hidden sm:flex flex-col items-end mr-2">
              <div className="text-[11px] text-muted-foreground">Last 30 days</div>
              <div className="text-sm font-display font-bold tabular-nums">108 credits</div>
            </div>
            <ArrowRight className="size-4 text-muted-foreground group-hover:text-foreground group-hover:translate-x-0.5 transition-all" />
          </Link>
        </SectionCard>
      </div>

      {/* Connect modal */}
      {modal && (
        <div className="fixed inset-0 z-50 bg-background/80 backdrop-blur-sm grid place-items-center p-6">
          <div className="w-full max-w-md rounded-2xl border border-border bg-surface shadow-2xl overflow-hidden">
            <div className="flex items-center justify-between px-5 py-4 border-b border-border">
              <div className="flex items-center gap-2.5">
                <div
                  className="size-8 rounded-lg grid place-items-center text-white font-display font-bold text-xs"
                  style={{ background: modal.color }}
                >
                  {modal.initials}
                </div>
                <div className="font-medium">Connect {modal.name}</div>
              </div>
              <button
                onClick={() => setModal(null)}
                disabled={connecting && step !== "done"}
                className="size-8 grid place-items-center rounded-lg hover:bg-accent text-muted-foreground disabled:opacity-40"
              >
                <X className="size-4" />
              </button>
            </div>
            <div className="p-6 min-h-[220px] flex flex-col">
              {step === "consent" && (
                <>
                  <div className="text-sm text-muted-foreground mb-4">
                    Loom will request permission to read campaigns, manage assets, and publish ads on your behalf.
                  </div>
                  <ul className="flex flex-col gap-2 text-sm mb-6">
                    <li className="flex items-center gap-2">
                      <BadgeCheck className="size-4 text-primary" /> Read campaign performance
                    </li>
                    <li className="flex items-center gap-2">
                      <BadgeCheck className="size-4 text-primary" /> Upload creatives
                    </li>
                    <li className="flex items-center gap-2">
                      <BadgeCheck className="size-4 text-primary" /> Manage audiences & budgets
                    </li>
                  </ul>
                  <button
                    onClick={runConnect}
                    className="mt-auto w-full rounded-xl bg-primary text-primary-foreground px-4 py-2.5 text-sm font-medium hover:opacity-90"
                  >
                    Continue with {modal.name}
                  </button>
                </>
              )}
              {step === "connecting" && (
                <div className="m-auto flex flex-col items-center gap-3 text-center">
                  <Loader2 className="size-8 animate-spin text-primary" />
                  <div className="text-sm font-medium">Redirecting to {modal.name}…</div>
                  <div className="text-xs text-muted-foreground">
                    Verifying account and permissions
                  </div>
                </div>
              )}
              {step === "done" && (
                <div className="m-auto flex flex-col items-center gap-3 text-center">
                  <div className="size-12 rounded-full bg-emerald-500/10 grid place-items-center">
                    <BadgeCheck className="size-6 text-emerald-500" />
                  </div>
                  <div className="text-sm font-medium">{modal.name} connected</div>
                  <div className="text-xs text-muted-foreground">
                    You can now launch campaigns to this platform.
                  </div>
                  <button
                    onClick={() => setModal(null)}
                    className="mt-2 w-full rounded-xl bg-primary text-primary-foreground px-4 py-2 text-sm font-medium hover:opacity-90"
                  >
                    Done
                  </button>
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </AppShell>
  );
}

function SectionCard({
  icon: Icon,
  title,
  desc,
  children,
}: {
  icon: typeof SettingsIcon;
  title: string;
  desc: string;
  children: React.ReactNode;
}) {
  return (
    <section>
      <div className="flex items-center gap-2 mb-3">
        <Icon className="size-4 text-muted-foreground" />
        <h2 className="text-sm font-display font-bold tracking-tight uppercase">{title}</h2>
        <span className="text-xs text-muted-foreground">· {desc}</span>
      </div>
      {children}
    </section>
  );
}
