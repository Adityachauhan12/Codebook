import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useMemo, useRef, useState } from "react";
import {
  Sparkles,
  Upload,
  X,
  Download,
  Wand2,
  Palette,
  ArrowRight,
  Loader2,
  ImageIcon,
  History,
  Square,
  RectangleVertical,
  RectangleHorizontal,
  Smartphone,
  Brush,
  Eraser,
  Pencil,
  FolderPlus,
  Folder,
  ChevronDown,
  Plus,
  Trash2,
  Info,
  Send,
  Check,
} from "lucide-react";
import { AppShell } from "@/components/AppShell";
import { submitForApproval } from "@/routes/approvals";

export const Route = createFileRoute("/studio")({
  component: StudioPage,
  head: () => ({
    meta: [
      { title: "AI Studio — Loom" },
      { name: "description", content: "Generate and edit images with references." },
    ],
  }),
});

type Project = {
  id: string;
  name: string;
  createdAt: number;
};

const PROJECTS_KEY = "studio.projects";
const ACTIVE_KEY = "studio.activeProject";
const HISTORY_KEY = (id: string) => `studio.history.${id}`;

type Ratio = "1:1" | "4:5" | "16:9" | "9:16" | "custom";
type RefRole = "Style" | "Subject" | "Composition";

type Reference = {
  id: string;
  url: string;
  name: string;
  weight: number;
  role: RefRole;
};

type HistoryItem = {
  id: string;
  prompt: string;
  seed: number;
  time: string;
};

const STYLES: { id: string; label: string; seed: number; hint: string }[] = [
  { id: "photoreal", label: "Photoreal", seed: 1015, hint: "Lifelike photo" },
  { id: "3d", label: "3D", seed: 1080, hint: "Rendered CGI" },
  { id: "illustration", label: "Illustration", seed: 1043, hint: "Hand-drawn" },
  { id: "product", label: "Product", seed: 1062, hint: "Studio shot" },
  { id: "poster", label: "Poster", seed: 1074, hint: "Bold graphic" },
  { id: "cinematic", label: "Cinematic", seed: 1027, hint: "Filmic mood" },
];
const MODELS = [
  { id: "nano-banana", label: "Nano Banana", tag: "fast" },
  { id: "gpt-image", label: "GPT-Image", tag: "quality" },
  { id: "flux", label: "Flux", tag: "creative" },
];
const RATIOS: { id: Ratio; icon: typeof Square; label: string }[] = [
  { id: "1:1", icon: Square, label: "Square" },
  { id: "4:5", icon: RectangleVertical, label: "Portrait" },
  { id: "16:9", icon: RectangleHorizontal, label: "Wide" },
  { id: "9:16", icon: Smartphone, label: "Story" },
];

const SEED_HISTORY: HistoryItem[] = [
  { id: "h1", prompt: "Minimalist ceramic mug on marble, morning light", seed: 42, time: "2m ago" },
  { id: "h2", prompt: "Summer sale hero, playful gradient, bold typography", seed: 128, time: "1h ago" },
  { id: "h3", prompt: "Portrait of a runner at golden hour, film grain", seed: 7, time: "yesterday" },
];

function ratioStyle(ratio: Ratio, customW: number, customH: number): React.CSSProperties {
  if (ratio === "custom") {
    const w = Math.max(1, customW);
    const h = Math.max(1, customH);
    return { aspectRatio: `${w} / ${h}` };
  }
  const [w, h] = ratio.split(":").map(Number);
  return { aspectRatio: `${w} / ${h}` };
}

function mockImage(seed: number, w = 800) {
  return `https://picsum.photos/seed/${seed}/${w}/${w}`;
}

function StudioPage() {
  const [mode, setMode] = useState<"generate" | "edit">("generate");
  const [prompt, setPrompt] = useState("");
  const [style, setStyle] = useState<string | null>("photoreal");
  const [ratio, setRatio] = useState<Ratio>("1:1");
  const [customW, setCustomW] = useState(3);
  const [customH, setCustomH] = useState(2);
  const [model, setModel] = useState("nano-banana");
  const [refs, setRefs] = useState<Reference[]>([]);
  const [source, setSource] = useState<string | null>(null);
  const [maskEnabled, setMaskEnabled] = useState(false);
  const [brush, setBrush] = useState<"paint" | "erase">("paint");
  const [brushSize, setBrushSize] = useState(40);
  const [status, setStatus] = useState<"idle" | "loading" | "partial" | "done">("idle");
  const [result, setResult] = useState<{ main: string; variations: string[] } | null>(null);
  const [history, setHistory] = useState<HistoryItem[]>(SEED_HISTORY);
  const [hasMaskStrokes, setHasMaskStrokes] = useState(false);
  const fileRef = useRef<HTMLInputElement>(null);
  const sourceRef = useRef<HTMLInputElement>(null);
  const maskCanvasRef = useRef<HTMLCanvasElement>(null);
  const maskContainerRef = useRef<HTMLDivElement>(null);
  const paintingRef = useRef(false);
  const lastPointRef = useRef<{ x: number; y: number } | null>(null);

  // ----- Projects -----
  const [projects, setProjects] = useState<Project[]>([]);
  const [activeProjectId, setActiveProjectId] = useState<string | null>(null);
  const [showPicker, setShowPicker] = useState(false);
  const [newProjectName, setNewProjectName] = useState("");
  const [projectsLoaded, setProjectsLoaded] = useState(false);

  // Load projects + active id
  useEffect(() => {
    try {
      const raw = localStorage.getItem(PROJECTS_KEY);
      const list: Project[] = raw ? JSON.parse(raw) : [];
      setProjects(list);
      const active = localStorage.getItem(ACTIVE_KEY);
      if (active && list.some((p) => p.id === active)) setActiveProjectId(active);
    } catch {
      /* noop */
    }
    setProjectsLoaded(true);
  }, []);

  // Persist projects
  useEffect(() => {
    if (!projectsLoaded) return;
    localStorage.setItem(PROJECTS_KEY, JSON.stringify(projects));
  }, [projects, projectsLoaded]);

  useEffect(() => {
    if (!projectsLoaded) return;
    if (activeProjectId) localStorage.setItem(ACTIVE_KEY, activeProjectId);
    else localStorage.removeItem(ACTIVE_KEY);
  }, [activeProjectId, projectsLoaded]);

  // Load per-project history when active project changes
  useEffect(() => {
    if (!activeProjectId) return;
    try {
      const raw = localStorage.getItem(HISTORY_KEY(activeProjectId));
      setHistory(raw ? JSON.parse(raw) : SEED_HISTORY);
    } catch {
      setHistory(SEED_HISTORY);
    }
    // reset workspace
    setPrompt("");
    setResult(null);
    setStatus("idle");
    setRefs([]);
    setSource(null);
  }, [activeProjectId]);

  // Persist per-project history
  useEffect(() => {
    if (!activeProjectId) return;
    localStorage.setItem(HISTORY_KEY(activeProjectId), JSON.stringify(history));
  }, [history, activeProjectId]);

  const activeProject = useMemo(
    () => projects.find((p) => p.id === activeProjectId) ?? null,
    [projects, activeProjectId],
  );

  function createProject(name: string) {
    const trimmed = name.trim();
    if (!trimmed) return;
    const p: Project = { id: crypto.randomUUID(), name: trimmed, createdAt: Date.now() };
    setProjects((prev) => [p, ...prev]);
    setActiveProjectId(p.id);
    setNewProjectName("");
    setShowPicker(false);
  }

  function deleteProject(id: string) {
    setProjects((prev) => prev.filter((p) => p.id !== id));
    try {
      localStorage.removeItem(HISTORY_KEY(id));
    } catch {
      /* noop */
    }
    if (activeProjectId === id) setActiveProjectId(null);
  }


  // Keep canvas backing store in sync with its displayed size
  useEffect(() => {
    if (!maskEnabled || !source) return;
    const canvas = maskCanvasRef.current;
    const container = maskContainerRef.current;
    if (!canvas || !container) return;
    const resize = () => {
      const rect = container.getBoundingClientRect();
      if (canvas.width !== Math.round(rect.width) || canvas.height !== Math.round(rect.height)) {
        // Preserve existing pixels on resize
        const prev = document.createElement("canvas");
        prev.width = canvas.width;
        prev.height = canvas.height;
        const pctx = prev.getContext("2d");
        if (pctx && canvas.width && canvas.height) pctx.drawImage(canvas, 0, 0);
        canvas.width = Math.round(rect.width);
        canvas.height = Math.round(rect.height);
        const ctx = canvas.getContext("2d");
        if (ctx && prev.width) ctx.drawImage(prev, 0, 0, canvas.width, canvas.height);
      }
    };
    resize();
    const ro = new ResizeObserver(resize);
    ro.observe(container);
    return () => ro.disconnect();
  }, [maskEnabled, source, ratio, customW, customH, status, result]);

  function clearMask() {
    const canvas = maskCanvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    ctx?.clearRect(0, 0, canvas.width, canvas.height);
    setHasMaskStrokes(false);
  }

  function pointFromEvent(e: React.PointerEvent<HTMLCanvasElement>) {
    const canvas = maskCanvasRef.current!;
    const rect = canvas.getBoundingClientRect();
    return {
      x: ((e.clientX - rect.left) / rect.width) * canvas.width,
      y: ((e.clientY - rect.top) / rect.height) * canvas.height,
    };
  }

  function drawStroke(from: { x: number; y: number }, to: { x: number; y: number }) {
    const canvas = maskCanvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;
    ctx.globalCompositeOperation = brush === "erase" ? "destination-out" : "source-over";
    ctx.strokeStyle = "rgba(139, 92, 246, 0.55)";
    ctx.fillStyle = "rgba(139, 92, 246, 0.55)";
    ctx.lineWidth = brushSize;
    ctx.lineCap = "round";
    ctx.lineJoin = "round";
    ctx.beginPath();
    ctx.moveTo(from.x, from.y);
    ctx.lineTo(to.x, to.y);
    ctx.stroke();
    ctx.beginPath();
    ctx.arc(to.x, to.y, brushSize / 2, 0, Math.PI * 2);
    ctx.fill();
  }

  function onPointerDown(e: React.PointerEvent<HTMLCanvasElement>) {
    (e.target as HTMLCanvasElement).setPointerCapture(e.pointerId);
    paintingRef.current = true;
    const p = pointFromEvent(e);
    lastPointRef.current = p;
    drawStroke(p, p);
    setHasMaskStrokes(true);
  }
  function onPointerMove(e: React.PointerEvent<HTMLCanvasElement>) {
    if (!paintingRef.current) return;
    const p = pointFromEvent(e);
    const last = lastPointRef.current ?? p;
    drawStroke(last, p);
    lastPointRef.current = p;
  }
  function onPointerUp(e: React.PointerEvent<HTMLCanvasElement>) {
    paintingRef.current = false;
    lastPointRef.current = null;
    try {
      (e.target as HTMLCanvasElement).releasePointerCapture(e.pointerId);
    } catch {
      /* noop */
    }
  }

  function onSourceFile(files: FileList | null) {
    const f = files?.[0];
    if (f) {
      setSource(URL.createObjectURL(f));
      setMaskEnabled(false);
      setHasMaskStrokes(false);
    }
  }

  function onFiles(files: FileList | null) {
    if (!files) return;
    const next = [...refs];
    for (const f of Array.from(files).slice(0, 4 - refs.length)) {
      next.push({
        id: crypto.randomUUID(),
        url: URL.createObjectURL(f),
        name: f.name,
        weight: 60,
        role: "Style",
      });
    }
    setRefs(next);
  }

  function updateRef(id: string, patch: Partial<Reference>) {
    setRefs((r) => r.map((x) => (x.id === id ? { ...x, ...patch } : x)));
  }

  function removeRef(id: string) {
    setRefs((r) => r.filter((x) => x.id !== id));
  }

  async function generate() {
    if (!prompt.trim()) return;
    const seed = Math.floor(Math.random() * 10000);
    setStatus("loading");
    setResult(null);

    // fake progressive load: skeleton → partial (blurred) → final
    await new Promise((r) => setTimeout(r, 700));
    setResult({ main: mockImage(seed, 400), variations: [] });
    setStatus("partial");
    await new Promise((r) => setTimeout(r, 1400));
    setResult({
      main: mockImage(seed, 900),
      variations: [seed + 1, seed + 2, seed + 3, seed + 4].map((s) => mockImage(s, 400)),
    });
    setStatus("done");

    setHistory((h) => [
      { id: crypto.randomUUID(), prompt: prompt.trim(), seed, time: "just now" },
      ...h,
    ]);
  }

  function restoreHistory(h: HistoryItem) {
    setPrompt(h.prompt);
    setResult({
      main: mockImage(h.seed, 900),
      variations: [h.seed + 1, h.seed + 2, h.seed + 3, h.seed + 4].map((s) => mockImage(s, 400)),
    });
    setStatus("done");
  }

  // Landing: no active project → project picker
  if (projectsLoaded && (!activeProject || showPicker)) {
    return (
      <AppShell>
        <div className="mx-auto max-w-3xl px-6 py-14">
          <div className="flex items-center gap-3">
            <div className="size-10 rounded-xl bg-gradient-to-br from-[var(--primary)] to-[var(--accent-ai)] grid place-items-center text-white">
              <Sparkles className="size-5" />
            </div>
            <div>
              <h1 className="font-display text-2xl font-bold tracking-tight">AI Studio projects</h1>
              <p className="text-sm text-muted-foreground">
                Group your generations and edits into projects like <em>Summer sale</em> or <em>Festival hotel 24</em>.
              </p>
            </div>
          </div>

          <div className="mt-8 rounded-2xl border border-border bg-surface p-5">
            <label className="text-xs font-medium text-muted-foreground">New project</label>
            <form
              onSubmit={(e) => {
                e.preventDefault();
                createProject(newProjectName);
              }}
              className="mt-1.5 flex gap-2"
            >
              <input
                autoFocus
                value={newProjectName}
                onChange={(e) => setNewProjectName(e.target.value)}
                placeholder="e.g. Summer sale 2026"
                className="flex-1 rounded-lg border border-border bg-background px-3 py-2 text-sm outline-none focus:border-[var(--accent-ai)] focus:ring-2 focus:ring-[var(--accent-ai)]/20"
              />
              <button
                type="submit"
                disabled={!newProjectName.trim()}
                className="inline-flex items-center gap-1.5 px-4 py-2 rounded-lg bg-gradient-to-r from-[var(--primary)] to-[var(--accent-ai)] text-white text-sm font-medium disabled:opacity-50"
              >
                <FolderPlus className="size-4" /> Create
              </button>
            </form>
          </div>

          {projects.length > 0 && (
            <div className="mt-8">
              <div className="text-xs font-medium text-muted-foreground mb-2">Your projects</div>
              <div className="grid sm:grid-cols-2 gap-3">
                {projects.map((p) => (
                  <div
                    key={p.id}
                    className="group flex items-center gap-3 rounded-xl border border-border bg-surface p-3 hover:border-foreground/30 transition-colors"
                  >
                    <button
                      onClick={() => {
                        setActiveProjectId(p.id);
                        setShowPicker(false);
                      }}
                      className="flex-1 flex items-center gap-3 text-left min-w-0"
                    >
                      <div className="size-9 rounded-lg bg-accent grid place-items-center">
                        <Folder className="size-4 text-muted-foreground" />
                      </div>
                      <div className="min-w-0">
                        <div className="text-sm font-medium truncate">{p.name}</div>
                        <div className="text-[11px] text-muted-foreground">
                          Created {new Date(p.createdAt).toLocaleDateString()}
                        </div>
                      </div>
                    </button>
                    <button
                      onClick={() => deleteProject(p.id)}
                      className="opacity-0 group-hover:opacity-100 text-muted-foreground hover:text-destructive transition-opacity"
                      aria-label="Delete project"
                    >
                      <Trash2 className="size-4" />
                    </button>
                  </div>
                ))}
              </div>
            </div>
          )}

          {activeProject && (
            <button
              onClick={() => setShowPicker(false)}
              className="mt-6 text-xs text-muted-foreground hover:text-foreground"
            >
              ← Back to “{activeProject.name}”
            </button>
          )}
        </div>
      </AppShell>
    );
  }

  return (
    <AppShell>
      <div className="grid grid-cols-1 lg:grid-cols-[340px_1fr_280px] min-h-[calc(100vh-3.5rem)]">
        {/* LEFT: prompt composer */}
        <div className="border-r border-border bg-surface/40 p-5 space-y-5 overflow-y-auto">
          {/* Project switcher */}
          <button
            onClick={() => setShowPicker(true)}
            className="w-full flex items-center gap-2 p-2 rounded-lg border border-border bg-surface hover:bg-accent transition-colors text-left"
          >
            <div className="size-7 rounded-md bg-accent grid place-items-center">
              <Folder className="size-3.5 text-muted-foreground" />
            </div>
            <div className="flex-1 min-w-0">
              <div className="text-[10px] uppercase tracking-wide text-muted-foreground">Project</div>
              <div className="text-sm font-medium truncate">{activeProject?.name}</div>
            </div>
            <ChevronDown className="size-4 text-muted-foreground" />
          </button>

          <div className="flex p-1 rounded-lg bg-accent">

            {(["generate", "edit"] as const).map((m) => (
              <button
                key={m}
                onClick={() => setMode(m)}
                className={`flex-1 flex items-center justify-center gap-1.5 text-xs font-medium py-1.5 rounded-md transition-colors capitalize ${
                  mode === m ? "bg-surface text-foreground shadow-sm" : "text-muted-foreground"
                }`}
              >
                {m === "generate" ? <Wand2 className="size-3.5" /> : <Pencil className="size-3.5" />}
                {m}
              </button>
            ))}
          </div>

          {mode === "edit" && (
            <Link
              to="/editor"
              className="flex items-start gap-2 rounded-lg border border-dashed border-[var(--accent-ai)]/40 bg-[var(--accent-ai)]/5 p-2.5 text-xs text-foreground hover:bg-[var(--accent-ai)]/10 transition-colors"
            >
              <Info className="size-3.5 mt-0.5 text-[var(--accent-ai)] shrink-0" />
              <span>
                Need advanced editing? Try the <span className="font-semibold underline">Editor</span> for layers, text, and full canvas control.
              </span>
            </Link>
          )}

          {mode === "edit" && (
            <div>
              <label className="text-xs font-medium text-muted-foreground">Source image</label>
              {source ? (
                <div className="mt-1.5 relative rounded-lg overflow-hidden border border-border">
                  <img src={source} alt="source" className="w-full aspect-square object-cover" />
                  <button
                    onClick={() => setSource(null)}
                    className="absolute top-1.5 right-1.5 size-6 grid place-items-center rounded-full bg-black/60 text-white hover:bg-black/80"
                  >
                    <X className="size-3" />
                  </button>
                </div>
              ) : (
                <div
                  onDragOver={(e) => e.preventDefault()}
                  onDrop={(e) => {
                    e.preventDefault();
                    onSourceFile(e.dataTransfer.files);
                  }}
                  onClick={() => sourceRef.current?.click()}
                  className="mt-1.5 border border-dashed border-border rounded-lg p-6 text-center cursor-pointer hover:border-foreground/30 hover:bg-accent/30 transition-colors"
                >
                  <Upload className="size-4 mx-auto text-muted-foreground" />
                  <div className="text-xs text-muted-foreground mt-1">Drop image to edit</div>
                  <input
                    ref={sourceRef}
                    type="file"
                    accept="image/*"
                    className="hidden"
                    onChange={(e) => onSourceFile(e.target.files)}
                  />
                </div>
              )}
            </div>
          )}

          {mode === "edit" && source && (
            <div>
              <div className="flex items-center justify-between">
                <label className="text-xs font-medium text-muted-foreground">Mask (optional)</label>
                {maskEnabled && (
                  <button
                    onClick={() => {
                      clearMask();
                      setMaskEnabled(false);
                    }}
                    className="text-[10px] text-muted-foreground hover:text-foreground"
                  >
                    Remove mask
                  </button>
                )}
              </div>
              {!maskEnabled ? (
                <button
                  onClick={() => setMaskEnabled(true)}
                  className="mt-1.5 w-full flex items-center justify-center gap-1.5 text-xs py-2 rounded-lg border border-dashed border-border text-muted-foreground hover:text-foreground hover:border-foreground/30 transition-colors"
                >
                  <Brush className="size-3.5" /> Add a mask to edit only part of the image
                </button>
              ) : (
                <>
                  <div className="mt-1.5 flex gap-1.5">
                    <button
                      onClick={() => setBrush("paint")}
                      className={`flex-1 flex items-center justify-center gap-1.5 text-xs py-1.5 rounded-lg border transition-colors ${
                        brush === "paint"
                          ? "bg-[var(--accent-ai)] text-white border-[var(--accent-ai)]"
                          : "bg-surface border-border text-muted-foreground"
                      }`}
                    >
                      <Brush className="size-3.5" /> Paint
                    </button>
                    <button
                      onClick={() => setBrush("erase")}
                      className={`flex-1 flex items-center justify-center gap-1.5 text-xs py-1.5 rounded-lg border transition-colors ${
                        brush === "erase"
                          ? "bg-foreground text-background border-foreground"
                          : "bg-surface border-border text-muted-foreground"
                      }`}
                    >
                      <Eraser className="size-3.5" /> Erase
                    </button>
                  </div>
                  <div className="mt-2 flex items-center gap-2">
                    <span className="text-[10px] text-muted-foreground w-12">Size {brushSize}</span>
                    <input
                      type="range"
                      min={4}
                      max={120}
                      value={brushSize}
                      onChange={(e) => setBrushSize(Number(e.target.value))}
                      className="flex-1 h-1 accent-[var(--accent-ai)]"
                    />
                  </div>
                  <div className="mt-2 flex items-center justify-between">
                    <p className="text-[10px] text-muted-foreground">
                      Paint the area to change, then describe the edit.
                    </p>
                    <button
                      onClick={clearMask}
                      disabled={!hasMaskStrokes}
                      className="text-[10px] text-muted-foreground hover:text-foreground disabled:opacity-40"
                    >
                      Clear
                    </button>
                  </div>
                </>
              )}
            </div>
          )}


          <div>
            <label className="text-xs font-medium text-muted-foreground">
              {mode === "edit" ? "Edit instruction" : "Prompt"}
            </label>
            <textarea
              value={prompt}
              onChange={(e) => setPrompt(e.target.value)}
              placeholder={
                mode === "edit"
                  ? "Replace the sky with a sunset, warm tones…"
                  : "A ceramic mug on marble, soft morning light…"
              }
              className="mt-1 w-full h-28 resize-none rounded-lg border border-border bg-surface px-3 py-2 text-sm outline-none focus:border-[var(--accent-ai)] focus:ring-2 focus:ring-[var(--accent-ai)]/20"
            />
          </div>

          <div>
            <label className="text-xs font-medium text-muted-foreground">Style</label>
            <div className="mt-1.5 grid grid-cols-3 gap-1.5">
              {STYLES.map((s) => {
                const active = style === s.id;
                return (
                  <button
                    key={s.id}
                    onClick={() => setStyle(active ? null : s.id)}
                    title={s.hint}
                    className={`group relative overflow-hidden rounded-lg border text-left transition-all ${
                      active
                        ? "border-[var(--accent-ai)] ring-2 ring-[var(--accent-ai)]/30"
                        : "border-border hover:border-foreground/30"
                    }`}
                  >
                    <div className="aspect-square bg-accent">
                      <img
                        src={`https://picsum.photos/seed/style-${s.id}/160/160`}
                        alt={s.label}
                        className="w-full h-full object-cover"
                      />
                    </div>
                    <div className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-black/80 to-transparent px-1.5 py-1">
                      <div className="text-[10px] font-medium text-white leading-tight">
                        {s.label}
                      </div>
                    </div>
                  </button>
                );
              })}
            </div>
          </div>

          <div>
            <label className="text-xs font-medium text-muted-foreground">Aspect ratio</label>
            <div className="mt-1.5 grid grid-cols-4 gap-1.5">
              {RATIOS.map((r) => {
                const Icon = r.icon;
                const active = ratio === r.id;
                return (
                  <button
                    key={r.id}
                    onClick={() => setRatio(r.id)}
                    title={r.label}
                    className={`flex flex-col items-center gap-1 py-2 rounded-lg border text-xs transition-colors ${
                      active
                        ? "bg-accent border-foreground/20 text-foreground"
                        : "bg-surface border-border text-muted-foreground hover:text-foreground"
                    }`}
                  >
                    <Icon className="size-4" />
                    {r.id}
                  </button>
                );
              })}
            </div>
            <button
              onClick={() => setRatio("custom")}
              className={`mt-1.5 w-full text-xs px-2.5 py-1.5 rounded-lg border transition-colors ${
                ratio === "custom"
                  ? "bg-accent border-foreground/20 text-foreground"
                  : "bg-surface border-border text-muted-foreground hover:text-foreground"
              }`}
            >
              Custom ratio
            </button>
            {ratio === "custom" && (
              <div className="mt-2 flex items-center gap-2">
                <input
                  type="number"
                  min={1}
                  max={64}
                  value={customW}
                  onChange={(e) => setCustomW(Number(e.target.value) || 1)}
                  className="w-full rounded-lg border border-border bg-surface px-2 py-1.5 text-sm outline-none focus:border-[var(--accent-ai)]"
                />
                <span className="text-muted-foreground text-xs">:</span>
                <input
                  type="number"
                  min={1}
                  max={64}
                  value={customH}
                  onChange={(e) => setCustomH(Number(e.target.value) || 1)}
                  className="w-full rounded-lg border border-border bg-surface px-2 py-1.5 text-sm outline-none focus:border-[var(--accent-ai)]"
                />
              </div>
            )}
          </div>


          <div>
            <label className="text-xs font-medium text-muted-foreground">Reference images</label>
            <div
              onDragOver={(e) => e.preventDefault()}
              onDrop={(e) => {
                e.preventDefault();
                onFiles(e.dataTransfer.files);
              }}
              onClick={() => fileRef.current?.click()}
              className="mt-1.5 border border-dashed border-border rounded-lg p-3 text-center cursor-pointer hover:border-foreground/30 hover:bg-accent/30 transition-colors"
            >
              <Upload className="size-4 mx-auto text-muted-foreground" />
              <div className="text-xs text-muted-foreground mt-1">
                Drop up to 4 images ({refs.length}/4)
              </div>
              <input
                ref={fileRef}
                type="file"
                accept="image/*"
                multiple
                className="hidden"
                onChange={(e) => onFiles(e.target.files)}
              />
            </div>
            {refs.length > 0 && (
              <div className="mt-2 space-y-2">
                {refs.map((r) => (
                  <div key={r.id} className="flex gap-2 items-center bg-surface border border-border rounded-lg p-2">
                    <img src={r.url} alt="" className="size-10 rounded object-cover" />
                    <div className="flex-1 min-w-0 space-y-1">
                      <div className="flex gap-1">
                        {(["Style", "Subject", "Composition"] as RefRole[]).map((role) => (
                          <button
                            key={role}
                            onClick={() => updateRef(r.id, { role })}
                            className={`text-[10px] px-1.5 py-0.5 rounded-full ${
                              r.role === role
                                ? "bg-[var(--accent-ai)] text-white"
                                : "bg-accent text-muted-foreground"
                            }`}
                          >
                            {role}
                          </button>
                        ))}
                      </div>
                      <input
                        type="range"
                        min={0}
                        max={100}
                        value={r.weight}
                        onChange={(e) => updateRef(r.id, { weight: Number(e.target.value) })}
                        className="w-full h-1 accent-[var(--accent-ai)]"
                      />
                    </div>
                    <button onClick={() => removeRef(r.id)} className="text-muted-foreground hover:text-foreground">
                      <X className="size-3.5" />
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>

          <div>
            <label className="text-xs font-medium text-muted-foreground">Model</label>
            <div className="mt-1.5 space-y-1">
              {MODELS.map((m) => (
                <button
                  key={m.id}
                  onClick={() => setModel(m.id)}
                  className={`w-full flex items-center justify-between px-3 py-2 rounded-lg border text-sm transition-colors ${
                    model === m.id
                      ? "bg-accent border-foreground/20"
                      : "bg-surface border-border hover:bg-accent/50"
                  }`}
                >
                  <span className="font-medium">{m.label}</span>
                  <span className="text-[10px] px-1.5 py-0.5 rounded-full bg-background text-muted-foreground border border-border">
                    {m.tag}
                  </span>
                </button>
              ))}
            </div>
          </div>

          <button
            onClick={generate}
            disabled={
              !prompt.trim() ||
              status === "loading" ||
              status === "partial" ||
              (mode === "edit" && !source)
            }
            className="w-full flex items-center justify-center gap-2 px-4 py-2.5 rounded-lg bg-gradient-to-r from-[var(--primary)] to-[var(--accent-ai)] text-white font-medium text-sm shadow-sm disabled:opacity-50 disabled:cursor-not-allowed"
          >
            {status === "loading" || status === "partial" ? (
              <>
                <Loader2 className="size-4 animate-spin" />
                {mode === "edit" ? "Applying edit…" : "Generating…"}
              </>
            ) : (
              <>
                {mode === "edit" ? <Pencil className="size-4" /> : <Wand2 className="size-4" />}
                {mode === "edit" ? "Apply edit" : "Generate"}
                <span className="ml-1 text-xs opacity-80">~2 credits</span>
              </>
            )}
          </button>
        </div>

        {/* CENTER: canvas / result */}
        <div className="p-8 flex flex-col items-center overflow-y-auto">
          <div className="w-full max-w-2xl">
            <div
              ref={maskContainerRef}
              style={ratioStyle(ratio, customW, customH)}
              className="w-full rounded-2xl border border-border bg-surface overflow-hidden relative"
            >
              {status === "idle" && !result && mode === "edit" && source && (
                <>
                  <img src={source} alt="source" className="absolute inset-0 w-full h-full object-cover" />
                  {maskEnabled && (
                    <>
                      <canvas
                        ref={maskCanvasRef}
                        onPointerDown={onPointerDown}
                        onPointerMove={onPointerMove}
                        onPointerUp={onPointerUp}
                        onPointerLeave={onPointerUp}
                        className={`absolute inset-0 w-full h-full touch-none ${
                          brush === "erase" ? "cursor-cell" : "cursor-crosshair"
                        }`}
                      />
                      <div className="absolute bottom-3 left-3 flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-black/60 text-white text-xs backdrop-blur pointer-events-none">
                        <Brush className="size-3" />
                        {hasMaskStrokes ? "Masking area" : "Paint the area to change"}
                      </div>
                    </>
                  )}
                </>
              )}
              {status === "idle" && !result && !(mode === "edit" && source) && (
                <div className="absolute inset-0 grid place-items-center text-muted-foreground">
                  <div className="text-center">
                    <ImageIcon className="size-10 mx-auto opacity-30" />
                    <div className="mt-2 text-sm">
                      {mode === "edit"
                        ? "Add a source image to start editing"
                        : "Your generated image will appear here"}
                    </div>
                  </div>
                </div>
              )}
              {status === "loading" && (
                <div className="absolute inset-0 bg-gradient-to-br from-accent to-surface-2 animate-pulse" />
              )}
              {result && (
                <img
                  src={result.main}
                  alt="Generated"
                  className={`absolute inset-0 w-full h-full object-cover transition-[filter] duration-500 ${
                    status === "partial" ? "blur-2xl scale-105" : "blur-0"
                  }`}
                />
              )}
              {status === "partial" && (
                <div className="absolute bottom-3 left-3 flex items-center gap-2 px-2.5 py-1 rounded-full bg-black/50 text-white text-xs backdrop-blur">
                  <Loader2 className="size-3 animate-spin" />
                  Rendering
                </div>
              )}
            </div>

            {status === "done" && result && (
              <>
                <div className="mt-4 flex flex-wrap items-center gap-2">
                  <button className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-foreground text-background text-sm font-medium hover:opacity-90">
                    <Download className="size-4" />
                    Download
                  </button>
                  <SendToApprovalButton
                    image={result.main}
                    prompt={prompt || "Untitled generation"}
                    project={activeProject?.name ?? "Untitled project"}
                  />
                  <button className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-border bg-surface text-sm hover:bg-accent">
                    <Palette className="size-4" />
                    Send to editor
                  </button>
                  <button className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-border bg-surface text-sm hover:bg-accent">
                    Use in campaign
                    <ArrowRight className="size-4" />
                  </button>
                </div>

                <div className="mt-6">
                  <div className="text-xs font-medium text-muted-foreground mb-2">Variations</div>
                  <div className="grid grid-cols-4 gap-3">
                    {result.variations.map((v, i) => (
                      <button
                        key={i}
                        onClick={() => setResult({ ...result, main: v })}
                        className="aspect-square rounded-lg overflow-hidden border border-border hover:border-foreground/30 transition-colors"
                      >
                        <img src={v} alt="" className="w-full h-full object-cover" />
                      </button>
                    ))}
                  </div>
                </div>
              </>
            )}
          </div>
        </div>

        {/* RIGHT: history */}
        <div className="hidden lg:flex flex-col border-l border-border bg-surface/40 overflow-y-auto">
          <div className="p-4 border-b border-border flex items-center gap-2">
            <History className="size-4" />
            <div className="font-display font-semibold text-sm">History</div>
          </div>
          <div className="p-3 space-y-2">
            {history.map((h) => (
              <button
                key={h.id}
                onClick={() => restoreHistory(h)}
                className="w-full text-left flex gap-2.5 p-2 rounded-lg hover:bg-accent transition-colors group"
              >
                <img
                  src={mockImage(h.seed, 120)}
                  alt=""
                  className="size-12 rounded object-cover shrink-0"
                />
                <div className="flex-1 min-w-0">
                  <div className="text-xs text-foreground line-clamp-2 group-hover:text-foreground">
                    {h.prompt}
                  </div>
                  <div className="text-[10px] text-muted-foreground mt-0.5">{h.time}</div>
                </div>
              </button>
            ))}
          </div>
        </div>
      </div>
    </AppShell>
  );
}

function SendToApprovalButton({
  image,
  prompt,
  project,
}: {
  image: string;
  prompt: string;
  project: string;
}) {
  const [sent, setSent] = useState(false);
  return (
    <button
      onClick={() => {
        if (sent) return;
        submitForApproval({
          image,
          prompt,
          project,
          submittedBy: "You",
        });
        setSent(true);
        setTimeout(() => setSent(false), 2500);
      }}
      className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-sm font-medium transition-colors ${
        sent
          ? "bg-emerald-600 text-white"
          : "bg-[var(--accent-ai)] text-white hover:opacity-90"
      }`}
    >
      {sent ? (
        <>
          <Check className="size-4" />
          Sent for approval
        </>
      ) : (
        <>
          <Send className="size-4" />
          Send to approval
        </>
      )}
    </button>
  );
}
