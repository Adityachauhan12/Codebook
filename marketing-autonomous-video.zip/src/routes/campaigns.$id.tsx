import { createFileRoute, Link } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import {
  Activity,
  ArrowLeft,
  BarChart3,
  Image as ImageIcon,
  Pause,
  Play,
  Radio,
  Sparkles,
  Users,
} from "lucide-react";
import {
  CartesianGrid,
  Line,
  LineChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";
import { AppShell } from "@/components/AppShell";

export const Route = createFileRoute("/campaigns/$id")({
  component: CampaignDetailPage,
  head: () => ({
    meta: [
      { title: "Campaign — Loom" },
      { name: "description", content: "Campaign performance across channels." },
    ],
  }),
});

type Tab = "overview" | "channels" | "creatives" | "audiences" | "activity";

const TABS: { id: Tab; label: string; icon: typeof BarChart3 }[] = [
  { id: "overview", label: "Overview", icon: BarChart3 },
  { id: "channels", label: "Channels", icon: Radio },
  { id: "creatives", label: "Creatives", icon: ImageIcon },
  { id: "audiences", label: "Audiences", icon: Users },
  { id: "activity", label: "Activity", icon: Activity },
];

const CHANNEL_COLORS: Record<string, string> = {
  "Google Search": "#4285F4",
  "Google PMax": "#34A853",
  "Meta Feed": "#1877F2",
  "Meta Reels": "#E4405F",
  "Meta Stories": "#FB8C00",
};

function seriesFor(seed: number, days = 14) {
  const out: { day: string; spend: number; conv: number }[] = [];
  let s = seed;
  for (let i = 0; i < days; i++) {
    s = (s * 9301 + 49297) % 233280;
    const rnd = s / 233280;
    const spend = Math.round(80 + rnd * 220);
    const conv = Math.round(2 + rnd * 18);
    out.push({ day: `D${i + 1}`, spend, conv });
  }
  return out;
}

function CampaignDetailPage() {
  const { id } = Route.useParams();
  const [tab, setTab] = useState<Tab>("overview");
  const [paused, setPaused] = useState(false);

  const seed = useMemo(() => {
    const s = String(id);
    let n = 0;
    for (let i = 0; i < s.length; i++) n += s.charCodeAt(i);
    return n || 42;
  }, [id]);
  const data = useMemo(() => seriesFor(seed), [seed]);

  const kpis = [
    { label: "Spend", value: "$1,284", delta: "+8%" },
    { label: "Impressions", value: "412k", delta: "+12%" },
    { label: "Clicks", value: "9,820", delta: "+5%" },
    { label: "CTR", value: "2.4%", delta: "+0.3pp" },
    { label: "Conv.", value: "184", delta: "+11%" },
    { label: "CPA", value: "$16.20", delta: "-4%" },
    { label: "ROAS", value: "3.4x", delta: "+0.2x" },
  ];

  const channels = [
    { name: "Google Search", spend: 520, ctr: "3.1%", conv: 78, roas: "4.1x" },
    { name: "Google PMax", spend: 310, ctr: "2.2%", conv: 42, roas: "3.2x" },
    { name: "Meta Feed", spend: 280, ctr: "1.9%", conv: 41, roas: "2.8x" },
    { name: "Meta Reels", spend: 174, ctr: "2.6%", conv: 23, roas: "2.4x" },
  ];

  const budget = 3000;
  const spent = 1284;
  const spentPct = Math.round((spent / budget) * 100);

  return (
    <AppShell>
      <div className="max-w-6xl mx-auto px-6 py-6 flex flex-col gap-6">
        {/* Header */}
        <div className="flex flex-col gap-4">
          <Link
            to="/campaigns"
            className="inline-flex items-center gap-1.5 text-xs text-muted-foreground hover:text-foreground w-fit"
          >
            <ArrowLeft className="size-3.5" />
            All campaigns
          </Link>
          <div className="flex flex-wrap items-start justify-between gap-4">
            <div className="flex items-start gap-3">
              <div>
                <div className="flex items-center gap-2 mb-1">
                  <span
                    className={`inline-flex items-center gap-1.5 text-[11px] font-medium px-2 py-0.5 rounded-full ${
                      paused
                        ? "bg-amber-500/10 text-amber-600"
                        : "bg-emerald-500/10 text-emerald-600"
                    }`}
                  >
                    <span
                      className={`size-1.5 rounded-full ${
                        paused ? "bg-amber-500" : "bg-emerald-500 animate-pulse"
                      }`}
                    />
                    {paused ? "Paused" : "Live"}
                  </span>
                  <span className="text-xs text-muted-foreground">#{id}</span>
                </div>
                <h1 className="text-2xl font-display font-bold tracking-tight">
                  Summer flights to Bali — Q3 push
                </h1>
                <div className="text-sm text-muted-foreground mt-0.5">
                  Jul 12 → Aug 11 · 4 channels · US 25–44 · leisure travelers
                </div>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <button
                onClick={() => setPaused((p) => !p)}
                className="inline-flex items-center gap-1.5 rounded-xl border border-border px-3 py-2 text-sm hover:bg-accent"
              >
                {paused ? <Play className="size-4" /> : <Pause className="size-4" />}
                {paused ? "Resume" : "Pause"}
              </button>
            </div>
          </div>

          {/* Budget bar */}
          <div className="rounded-xl border border-border bg-surface p-4">
            <div className="flex items-center justify-between text-sm mb-2">
              <div className="font-medium">Budget</div>
              <div className="text-muted-foreground tabular-nums">
                ${spent.toLocaleString()} / ${budget.toLocaleString()}
              </div>
            </div>
            <div className="h-2 rounded-full bg-accent overflow-hidden">
              <div
                className="h-full bg-primary transition-all"
                style={{ width: `${spentPct}%` }}
              />
            </div>
            <div className="text-[11px] text-muted-foreground mt-1.5">
              {spentPct}% spent · pacing on track
            </div>
          </div>
        </div>

        {/* Tabs */}
        <div className="border-b border-border">
          <div className="flex items-center gap-0.5 overflow-x-auto">
            {TABS.map((t) => {
              const Icon = t.icon;
              const active = t.id === tab;
              return (
                <button
                  key={t.id}
                  onClick={() => setTab(t.id)}
                  className={`inline-flex items-center gap-1.5 px-3 py-2.5 text-sm border-b-2 transition-colors whitespace-nowrap ${
                    active
                      ? "border-primary text-foreground font-medium"
                      : "border-transparent text-muted-foreground hover:text-foreground"
                  }`}
                >
                  <Icon className="size-4" />
                  {t.label}
                </button>
              );
            })}
          </div>
        </div>

        {/* Tab content */}
        {tab === "overview" && (
          <div className="flex flex-col gap-6">
            <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-7 gap-3">
              {kpis.map((k) => (
                <div key={k.label} className="rounded-xl border border-border bg-surface p-3">
                  <div className="text-[11px] text-muted-foreground">{k.label}</div>
                  <div className="text-lg font-display font-bold tracking-tight mt-1">
                    {k.value}
                  </div>
                  <div
                    className={`text-[11px] mt-0.5 ${
                      k.delta.startsWith("-") ? "text-rose-500" : "text-emerald-500"
                    }`}
                  >
                    {k.delta}
                  </div>
                </div>
              ))}
            </div>

            <div className="rounded-2xl border border-border bg-surface p-5">
              <div className="flex items-center justify-between mb-4">
                <div className="text-sm font-medium">Spend & conversions (14d)</div>
                <div className="text-xs text-muted-foreground">Daily</div>
              </div>
              <div className="h-64">
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart data={data} margin={{ top: 4, right: 8, bottom: 0, left: -12 }}>
                    <CartesianGrid stroke="var(--border)" strokeDasharray="3 3" vertical={false} />
                    <XAxis dataKey="day" tick={{ fontSize: 11 }} stroke="var(--muted-foreground)" />
                    <YAxis tick={{ fontSize: 11 }} stroke="var(--muted-foreground)" />
                    <Tooltip
                      contentStyle={{
                        background: "var(--surface)",
                        border: "1px solid var(--border)",
                        borderRadius: 8,
                        fontSize: 12,
                      }}
                    />
                    <Line
                      type="monotone"
                      dataKey="spend"
                      stroke="var(--primary)"
                      strokeWidth={2}
                      dot={false}
                    />
                    <Line
                      type="monotone"
                      dataKey="conv"
                      stroke="var(--accent-ai, #7c3aed)"
                      strokeWidth={2}
                      dot={false}
                    />
                  </LineChart>
                </ResponsiveContainer>
              </div>
            </div>

            <div className="rounded-2xl border border-border bg-surface overflow-hidden">
              <div className="px-5 py-3 border-b border-border text-sm font-medium">
                Channel breakdown
              </div>
              <div className="divide-y divide-border">
                {channels.map((c) => (
                  <div
                    key={c.name}
                    className="grid grid-cols-5 gap-3 px-5 py-3 text-sm items-center"
                  >
                    <div className="flex items-center gap-2 col-span-2">
                      <div
                        className="size-2.5 rounded-sm"
                        style={{ background: CHANNEL_COLORS[c.name] ?? "#000099" }}
                      />
                      <div className="font-medium">{c.name}</div>
                    </div>
                    <div className="tabular-nums">${c.spend}</div>
                    <div className="text-muted-foreground">
                      CTR {c.ctr} · {c.conv} conv
                    </div>
                    <div className="text-right font-medium tabular-nums">{c.roas}</div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {tab === "channels" && (
          <div className="grid md:grid-cols-2 gap-4">
            {channels.map((c) => (
              <div key={c.name} className="rounded-2xl border border-border bg-surface p-5">
                <div className="flex items-center justify-between mb-4">
                  <div className="flex items-center gap-2">
                    <div
                      className="size-3 rounded-sm"
                      style={{ background: CHANNEL_COLORS[c.name] ?? "#000099" }}
                    />
                    <div className="font-medium">{c.name}</div>
                  </div>
                  <label className="inline-flex items-center gap-2 text-xs text-muted-foreground cursor-pointer">
                    <input type="checkbox" defaultChecked className="accent-[color:var(--primary)]" />
                    Active
                  </label>
                </div>
                <div className="grid grid-cols-4 gap-3 text-sm">
                  <Stat label="Spend" value={`$${c.spend}`} />
                  <Stat label="CTR" value={c.ctr} />
                  <Stat label="Conv." value={String(c.conv)} />
                  <Stat label="ROAS" value={c.roas} />
                </div>
              </div>
            ))}
          </div>
        )}

        {tab === "creatives" && (
          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {[101, 202, 303, 404, 505, 606, 707, 808].map((s) => (
              <div
                key={s}
                className="rounded-xl border border-border bg-surface overflow-hidden"
              >
                <div className="aspect-[4/5] bg-accent">
                  <img
                    src={`https://picsum.photos/seed/${s}/400/500`}
                    alt=""
                    className="w-full h-full object-cover"
                  />
                </div>
                <div className="p-3 text-xs flex items-center justify-between">
                  <div className="text-muted-foreground">CTR 2.{s % 9}%</div>
                  <button className="text-primary hover:underline">Replace</button>
                </div>
              </div>
            ))}
          </div>
        )}

        {tab === "audiences" && (
          <div className="rounded-2xl border border-border bg-surface overflow-hidden">
            <table className="w-full text-sm">
              <thead className="bg-accent/40 text-xs text-muted-foreground uppercase tracking-wider">
                <tr>
                  <th className="text-left px-5 py-3 font-medium">Segment</th>
                  <th className="text-left px-5 py-3 font-medium">Channel</th>
                  <th className="text-right px-5 py-3 font-medium">Reach</th>
                  <th className="text-right px-5 py-3 font-medium">CTR</th>
                  <th className="text-right px-5 py-3 font-medium">CPA</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-border">
                {[
                  ["US 18–24 · Shopping", "Meta Feed", "82k", "2.9%", "$14"],
                  ["US 25–34 · Deals", "Google Search", "134k", "3.4%", "$12"],
                  ["Lookalike 1% · Buyers", "Meta Reels", "56k", "2.2%", "$19"],
                  ["Retarget · Cart", "Google PMax", "18k", "5.1%", "$8"],
                ].map((row) => (
                  <tr key={row[0]}>
                    {row.map((cell, i) => (
                      <td
                        key={i}
                        className={`px-5 py-3 ${i > 1 ? "text-right tabular-nums" : ""}`}
                      >
                        {cell}
                      </td>
                    ))}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}

        {tab === "activity" && (
          <div className="rounded-2xl border border-border bg-surface p-5">
            <ol className="flex flex-col gap-4">
              {[
                {
                  t: "2m ago",
                  msg: "Shifted 15% budget from Meta Stories → Google Search due to higher ROAS.",
                },
                { t: "1h ago", msg: "Approved 3 new creative variants for Meta Feed." },
                {
                  t: "4h ago",
                  msg: "Auto-paused underperforming audience 'Broad 35+' on Meta Reels.",
                },
                { t: "Yesterday", msg: "Launched campaign across Google Ads and Meta Ads." },
              ].map((e, i) => (
                <li key={i} className="flex gap-3">
                  <div className="mt-1 size-6 shrink-0 rounded-full bg-[var(--accent-ai)]/10 grid place-items-center">
                    <Sparkles className="size-3 text-[var(--accent-ai)]" />
                  </div>
                  <div className="flex-1">
                    <div className="text-sm">{e.msg}</div>
                    <div className="text-[11px] text-muted-foreground mt-0.5">{e.t}</div>
                  </div>
                </li>
              ))}
            </ol>
          </div>
        )}
      </div>
    </AppShell>
  );
}

function Stat({ label, value }: { label: string; value: string }) {
  return (
    <div>
      <div className="text-[11px] text-muted-foreground">{label}</div>
      <div className="font-display font-bold tracking-tight">{value}</div>
    </div>
  );
}
