import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useEffect, useMemo, useRef, useState } from "react";
import {
  ArrowUp,
  Bot,
  Check,
  ChevronRight,
  Loader2,
  Sparkles,
  Target,
  Wallet,
  Calendar,
  Users,
  Radio,
  ImageIcon,
} from "lucide-react";
import { AppShell } from "@/components/AppShell";

export const Route = createFileRoute("/campaigns/new")({
  component: NewCampaignPage,
  head: () => ({
    meta: [
      { title: "New campaign — Loom" },
      { name: "description", content: "Describe your goal and we build the campaign." },
    ],
  }),
});

type Role = "user" | "assistant";
type Message = { id: string; role: Role; text: string };

type Brief = {
  objective?: string;
  budget?: string;
  duration?: string;
  audience?: string;
  channels?: string[];
  assets?: string;
};

const SUGGESTIONS = [
  "Launch a summer sale, $2,000, US 18–34, focus IG + Google Search",
  "Drive app installs in Germany, €5k over 3 weeks, TikTok-style creatives",
  "Promote our new SaaS free trial, $1.5k, LinkedIn + Google, B2B ops leads",
];

// Deterministic canned assistant script — walks the user through the brief.
const ASSISTANT_SCRIPT: Array<{
  reply: (userText: string, brief: Brief) => string;
  extract: (userText: string, brief: Brief) => Brief;
}> = [
  {
    reply: () =>
      "Got it. What's the primary conversion you want to optimize for — purchases, leads, installs, or signups?",
    extract: (t, b) => ({
      ...b,
      objective: b.objective ?? guessObjective(t) ?? "Awareness + conversions",
      budget: b.budget ?? guessBudget(t),
      audience: b.audience ?? guessAudience(t),
      channels: b.channels ?? guessChannels(t),
      duration: b.duration ?? guessDuration(t),
    }),
  },
  {
    reply: () =>
      "Noted. Do you have creatives to reuse from the Studio, or should I generate a fresh set?",
    extract: (t, b) => ({ ...b, objective: refineObjective(t, b.objective) }),
  },
  {
    reply: () =>
      "Perfect. Any hard constraints — regions to exclude, tone of voice, or brands to avoid?",
    extract: (t, b) => ({
      ...b,
      assets: b.assets ?? (/(studio|reuse|existing)/i.test(t) ? "Reuse Studio history" : "Generate fresh"),
    }),
  },
  {
    reply: () =>
      "Great — I have enough to draft a plan. I'll propose KPIs, channel split, audiences, and creatives. Ready?",
    extract: (t, b) => ({
      ...b,
      audience: b.audience ?? t.slice(0, 80),
    }),
  },
];

function guessBudget(t: string) {
  const m = t.match(/(\$|€|£)\s?([\d,.]+)\s?(k|K)?/);
  if (!m) return undefined;
  const num = m[3] ? `${m[2]}k` : m[2];
  return `${m[1]}${num}`;
}
function guessDuration(t: string) {
  const m = t.match(/(\d+)\s?(day|days|week|weeks|month|months)/i);
  return m ? `${m[1]} ${m[2].toLowerCase()}` : undefined;
}
function guessAudience(t: string) {
  const m = t.match(/(US|UK|EU|DE|FR|IN|CA|AU)[^.]{0,60}/i);
  return m ? m[0].trim() : undefined;
}
function guessChannels(t: string): string[] | undefined {
  const map: Record<string, string> = {
    ig: "Meta Feed",
    instagram: "Meta Feed",
    meta: "Meta Feed",
    facebook: "Meta Feed",
    reels: "Meta Reels",
    stories: "Meta Stories",
    google: "Google Search",
    search: "Google Search",
    pmax: "Google PMax",
    tiktok: "TikTok",
    linkedin: "LinkedIn",
    youtube: "YouTube",
  };
  const found = new Set<string>();
  for (const [k, v] of Object.entries(map)) {
    if (new RegExp(`\\b${k}\\b`, "i").test(t)) found.add(v);
  }
  return found.size ? Array.from(found) : undefined;
}
function guessObjective(t: string) {
  if (/sale|purchase|revenue|roas/i.test(t)) return "Purchases";
  if (/lead|signup|sign-up|demo/i.test(t)) return "Leads";
  if (/install|app/i.test(t)) return "App installs";
  if (/awareness|reach|brand/i.test(t)) return "Awareness";
  return undefined;
}
function refineObjective(t: string, current?: string) {
  const o = guessObjective(t);
  return o ?? current;
}

function NewCampaignPage() {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: "m0",
      role: "assistant",
      text:
        "Hey — tell me about the campaign you want to run. A one-liner works: goal, budget, timing, and who it's for.",
    },
  ]);
  const [brief, setBrief] = useState<Brief>({});
  const [input, setInput] = useState("");
  const [thinking, setThinking] = useState(false);
  const [step, setStep] = useState(0);
  const scrollRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLTextAreaElement>(null);

  useEffect(() => {
    inputRef.current?.focus();
  }, []);

  useEffect(() => {
    scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight, behavior: "smooth" });
  }, [messages, thinking]);

  const readyToPlan = step >= ASSISTANT_SCRIPT.length;

  function send(text: string) {
    const trimmed = text.trim();
    if (!trimmed || thinking) return;
    const userMsg: Message = { id: `u${Date.now()}`, role: "user", text: trimmed };
    setMessages((m) => [...m, userMsg]);
    setInput("");
    setThinking(true);

    const nextStepIdx = Math.min(step, ASSISTANT_SCRIPT.length - 1);
    const script = ASSISTANT_SCRIPT[nextStepIdx];

    setTimeout(() => {
      setBrief((b) => script.extract(trimmed, b));
      setMessages((m) => [
        ...m,
        { id: `a${Date.now()}`, role: "assistant", text: script.reply(trimmed, brief) },
      ]);
      setStep((s) => s + 1);
      setThinking(false);
      requestAnimationFrame(() => inputRef.current?.focus());
    }, 750);
  }

  function handleKey(e: React.KeyboardEvent<HTMLTextAreaElement>) {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      send(input);
    }
  }

  const completion = useMemo(() => {
    const fields = [brief.objective, brief.budget, brief.duration, brief.audience, brief.channels?.length, brief.assets];
    const filled = fields.filter(Boolean).length;
    return Math.round((filled / fields.length) * 100);
  }, [brief]);

  const navigate = useNavigate();

  return (
    <AppShell>
      <div className="grid grid-cols-1 lg:grid-cols-[1fr_360px] gap-0 h-[calc(100vh-3.5rem)] min-h-0 overflow-hidden">
        {/* Chat column */}
        <section className="relative flex flex-col border-r border-border min-w-0 min-h-0 h-full overflow-hidden">
          <div className="px-6 py-4 border-b border-border flex items-center justify-between">
            <div>
              <div className="text-xs text-muted-foreground">Step 1 of 3 · Brief</div>
              <h1 className="text-lg font-display font-bold tracking-tight">New campaign</h1>
            </div>
            <Link
              to="/campaigns"
              className="text-xs text-muted-foreground hover:text-foreground"
            >
              Cancel
            </Link>
          </div>

          <div ref={scrollRef} className="flex-1 min-h-0 overflow-y-auto px-6 py-6 pb-40">
            <div className="mx-auto max-w-2xl flex flex-col gap-5">
              {messages.map((m) => (
                <MessageBubble key={m.id} message={m} />
              ))}
              {thinking && (
                <div className="flex items-start gap-3">
                  <Avatar role="assistant" />
                  <div className="rounded-2xl rounded-tl-sm bg-surface border border-border px-4 py-3 flex items-center gap-2 text-sm text-muted-foreground">
                    <Loader2 className="size-3.5 animate-spin" />
                    Thinking…
                  </div>
                </div>
              )}

              {messages.length === 1 && !thinking && (
                <div className="mt-2 flex flex-col gap-2">
                  <div className="text-xs text-muted-foreground px-1">Try one of these</div>
                  {SUGGESTIONS.map((s) => (
                    <button
                      key={s}
                      onClick={() => send(s)}
                      className="text-left text-sm rounded-xl border border-border bg-surface hover:bg-accent transition-colors px-4 py-3"
                    >
                      {s}
                    </button>
                  ))}
                </div>
              )}
            </div>
          </div>

          <div className="pointer-events-none absolute inset-x-0 bottom-0 px-4 pb-5 pt-10 bg-gradient-to-t from-background via-background/85 to-transparent">
            <div className="pointer-events-auto mx-auto max-w-2xl">
              <div className="relative rounded-2xl border border-border bg-surface/95 backdrop-blur shadow-lg shadow-black/10 focus-within:border-primary/60 transition-colors">
                <textarea
                  ref={inputRef}
                  value={input}
                  onChange={(e) => setInput(e.target.value)}
                  onKeyDown={handleKey}
                  rows={2}
                  placeholder="Describe your campaign…"
                  className="w-full resize-none bg-transparent px-4 py-3 pr-14 text-sm outline-none placeholder:text-muted-foreground"
                />
                <button
                  onClick={() => send(input)}
                  disabled={!input.trim() || thinking}
                  className="absolute bottom-2.5 right-2.5 size-9 rounded-xl bg-primary text-primary-foreground grid place-items-center disabled:opacity-40 disabled:cursor-not-allowed hover:opacity-90 transition"
                  aria-label="Send"
                >
                  <ArrowUp className="size-4" />
                </button>
              </div>
              <div className="mt-2 text-[11px] text-muted-foreground px-1 text-center">
                Press Enter to send · Shift+Enter for newline
              </div>
            </div>
          </div>
        </section>


        {/* Brief summary rail */}
        <aside className="bg-surface/40 flex flex-col">
          <div className="px-5 py-4 border-b border-border">
            <div className="flex items-center justify-between mb-2">
              <div className="text-xs font-medium uppercase tracking-wider text-muted-foreground">
                Brief summary
              </div>
              <span className="text-xs text-muted-foreground">{completion}%</span>
            </div>
            <div className="h-1.5 rounded-full bg-accent overflow-hidden">
              <div
                className="h-full bg-primary transition-all duration-500"
                style={{ width: `${completion}%` }}
              />
            </div>
          </div>

          <div className="flex-1 overflow-y-auto p-5 flex flex-col gap-3">
            <BriefField icon={Target} label="Objective" value={brief.objective} />
            <BriefField icon={Wallet} label="Budget" value={brief.budget} />
            <BriefField icon={Calendar} label="Duration" value={brief.duration} />
            <BriefField icon={Users} label="Audience" value={brief.audience} />
            <BriefField
              icon={Radio}
              label="Channels"
              value={brief.channels?.length ? brief.channels.join(" · ") : undefined}
            />
            <BriefField icon={ImageIcon} label="Assets" value={brief.assets} />
          </div>

          <div className="p-4 border-t border-border">
            <button
              type="button"
              disabled={!readyToPlan}
              onClick={() => {
                try {
                  sessionStorage.setItem("loom.brief", JSON.stringify(brief));
                } catch {}
                navigate({ to: "/campaigns/plan" });
              }}
              className={`w-full flex items-center justify-center gap-2 rounded-xl px-4 py-2.5 text-sm font-medium transition ${
                readyToPlan
                  ? "bg-primary text-primary-foreground hover:opacity-90"
                  : "bg-accent text-muted-foreground cursor-not-allowed"
              }`}
            >
              {readyToPlan ? (
                <>
                  Generate plan
                  <ChevronRight className="size-4" />
                </>
              ) : (
                <>
                  <Sparkles className="size-4" />
                  Keep chatting to unlock plan
                </>
              )}
            </button>
          </div>
        </aside>
      </div>
    </AppShell>
  );
}

function MessageBubble({ message }: { message: Message }) {
  const isUser = message.role === "user";
  return (
    <div className={`flex items-start gap-3 ${isUser ? "flex-row-reverse" : ""}`}>
      <Avatar role={message.role} />
      <div
        className={`max-w-[85%] rounded-2xl px-4 py-3 text-sm leading-relaxed ${
          isUser
            ? "bg-primary text-primary-foreground rounded-tr-sm"
            : "bg-surface border border-border text-foreground rounded-tl-sm"
        }`}
      >
        {message.text}
      </div>
    </div>
  );
}

function Avatar({ role }: { role: Role }) {
  if (role === "user") {
    return <div className="size-7 shrink-0 rounded-full bg-gradient-to-br from-primary to-[var(--accent-ai)]" />;
  }
  return (
    <div className="size-7 shrink-0 rounded-full bg-accent border border-border grid place-items-center">
      <Bot className="size-3.5 text-foreground" />
    </div>
  );
}

function BriefField({
  icon: Icon,
  label,
  value,
}: {
  icon: typeof Target;
  label: string;
  value?: string;
}) {
  const filled = Boolean(value);
  return (
    <div
      className={`rounded-xl border p-3 transition-colors ${
        filled ? "border-border bg-surface" : "border-dashed border-border/60 bg-transparent"
      }`}
    >
      <div className="flex items-center justify-between mb-1">
        <div className="flex items-center gap-2 text-xs font-medium text-muted-foreground">
          <Icon className="size-3.5" />
          {label}
        </div>
        {filled && <Check className="size-3.5 text-[var(--success,theme(colors.emerald.500))]" />}
      </div>
      <div className={`text-sm ${filled ? "text-foreground" : "text-muted-foreground/60 italic"}`}>
        {filled ? value : "—"}
      </div>
    </div>
  );
}
